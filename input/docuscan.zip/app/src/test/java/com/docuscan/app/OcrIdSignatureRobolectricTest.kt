package com.docuscan.app

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.net.Uri
import androidx.compose.ui.test.assertIsDisplayed
import androidx.compose.ui.test.junit4.createComposeRule
import androidx.compose.ui.test.onNodeWithTag
import androidx.compose.ui.test.onNodeWithText
import androidx.compose.ui.test.performClick
import androidx.compose.ui.test.performScrollTo
import androidx.room.Room
import androidx.test.core.app.ApplicationProvider
import com.docuscan.app.database.DocuScanDatabase
import com.docuscan.app.domain.model.AppLanguage
import com.docuscan.app.domain.model.DocumentFileType
import com.docuscan.app.domain.model.DocumentItem
import com.docuscan.app.domain.model.IdDocumentType
import com.docuscan.app.domain.model.IdSideScanState
import com.docuscan.app.domain.model.NormalizedCropRect
import com.docuscan.app.domain.model.PdfCreationOptions
import com.docuscan.app.domain.model.PdfPageSize
import com.docuscan.app.domain.model.ScanFilter
import com.docuscan.app.domain.model.ScanPage
import com.docuscan.app.domain.model.ScanQuality
import com.docuscan.app.domain.model.SignatureItem
import com.docuscan.app.domain.model.ThemeMode
import com.docuscan.app.domain.model.UserPreferences
import com.docuscan.app.domain.repository.SettingsRepository
import com.docuscan.app.ocr.DetectedLanguageInfo
import com.docuscan.app.ocr.OcrEngine
import com.docuscan.app.ocr.OcrLanguageDetector
import com.docuscan.app.ocr.OcrProvider
import com.docuscan.app.ocr.OcrScript
import com.docuscan.app.ocr.TesseractBengaliOcrProvider
import com.docuscan.app.pdf.PdfGenerator
import com.docuscan.app.pdf.PdfRenderOutcome
import com.docuscan.app.pdf.PdfRendererHelper
import com.docuscan.app.repository.LocalDocumentRepository
import com.docuscan.app.scanner.BitmapFilterEngine
import com.docuscan.app.scanner.DocumentScannerGateway
import com.docuscan.app.scanner.ScanSessionManager
import com.docuscan.app.scanner.ScannerActivityOutcome
import com.docuscan.app.scanner.ScannerStartOutcome
import com.docuscan.app.ui.screens.IdScannerScreen
import com.docuscan.app.ui.screens.OcrExtractorScreen
import com.docuscan.app.ui.screens.SignPdfScreen
import com.docuscan.app.ui.theme.DocuScanTheme
import com.docuscan.app.ui.viewmodel.OcrRunState
import com.docuscan.app.ui.viewmodel.OcrUiState
import com.docuscan.app.ui.viewmodel.OcrViewModel
import com.docuscan.app.ui.viewmodel.OperationState
import com.docuscan.app.ui.viewmodel.ScannerViewModel
import com.docuscan.app.ui.viewmodel.SignPdfUiState
import com.docuscan.app.ui.viewmodel.SignatureViewModel
import com.docuscan.app.util.LocalFileManager
import com.google.mlkit.vision.common.InputImage
import com.google.mlkit.vision.documentscanner.GmsDocumentScannerOptions
import com.tom_roush.pdfbox.android.PDFBoxResourceLoader
import com.tom_roush.pdfbox.pdmodel.PDDocument
import com.tom_roush.pdfbox.pdmodel.graphics.image.PDImageXObject
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.ExperimentalCoroutinesApi
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.test.StandardTestDispatcher
import kotlinx.coroutines.test.advanceUntilIdle
import kotlinx.coroutines.test.resetMain
import kotlinx.coroutines.test.runTest
import kotlinx.coroutines.test.setMain
import org.junit.After
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertTrue
import org.junit.Before
import org.junit.Rule
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config
import org.robolectric.annotation.GraphicsMode
import java.io.ByteArrayOutputStream
import java.io.File
import java.io.FileOutputStream
import java.util.UUID

@OptIn(ExperimentalCoroutinesApi::class)
@RunWith(RobolectricTestRunner::class)
@Config(sdk = [36])
@GraphicsMode(GraphicsMode.Mode.NATIVE)
class OcrIdSignatureRobolectricTest {

    @get:Rule
    val composeTestRule = createComposeRule()

    private lateinit var context: Context
    private lateinit var fileManager: LocalFileManager
    private lateinit var pdfGenerator: PdfGenerator
    private lateinit var pdfRendererHelper: PdfRendererHelper
    private lateinit var db: DocuScanDatabase
    private lateinit var repository: LocalDocumentRepository
    private lateinit var settingsRepository: SettingsRepository
    private val testDispatcher = StandardTestDispatcher()

    @Before
    fun setup() {
        Dispatchers.setMain(testDispatcher)
        context = ApplicationProvider.getApplicationContext()
        if (!PDFBoxResourceLoader.isReady()) {
            PDFBoxResourceLoader.init(context)
        }
        fileManager = LocalFileManager(context, ioDispatcher = testDispatcher)
        pdfGenerator = PdfGenerator(context = context, ioDispatcher = testDispatcher)
        pdfRendererHelper = PdfRendererHelper(context = context, ioDispatcher = testDispatcher)
        db = Room.databaseBuilder(context, DocuScanDatabase::class.java, "ocr_id_sig_test.db")
            .allowMainThreadQueries()
            .setQueryExecutor { it.run() }
            .setTransactionExecutor { it.run() }
            .build()
        repository = LocalDocumentRepository(
            documentDao = db.documentDao(),
            folderDao = db.folderDao(),
            signatureDao = db.signatureDao(),
            fileManager = fileManager,
            pdfGenerator = pdfGenerator,
            deletedDocumentDao = db.deletedDocumentDao(),
            ioDispatcher = testDispatcher
        )
        settingsRepository = InMemoryTestSettingsRepository()
    }

    @After
    fun tearDown() {
        db.close()
        context.deleteDatabase("ocr_id_sig_test.db")
        fileManager.scansDir.deleteRecursively()
        fileManager.documentsDir.deleteRecursively()
        fileManager.signaturesDir.deleteRecursively()
        fileManager.backupsDir.deleteRecursively()
        Dispatchers.resetMain()
    }

    // ---------- TASK A: OCR TEXT EXTRACTION ----------

    @Test
    fun `ocr script support includes offline Bengali Tesseract alongside ML Kit scripts`() = runTest(testDispatcher) {
        val engine = OcrEngine(context = context)

        assertTrue(OcrScript.LATIN.isSupported)
        assertTrue(OcrScript.DEVANAGARI.isSupported)
        assertTrue(OcrScript.BENGALI.isSupported)
        assertEquals("Tesseract", OcrScript.BENGALI.supportBadge)

        assertTrue(engine.isScriptSupported(OcrScript.LATIN))
        assertTrue(engine.isScriptSupported(OcrScript.DEVANAGARI))
        assertTrue(engine.isScriptSupported(OcrScript.BENGALI))
        assertTrue(engine.getProvider(OcrScript.BENGALI) is TesseractBengaliOcrProvider)

        // Verify ensureTessDataCached reports clear error when traineddata assets are missing,
        // and succeeds once ben.traineddata & eng.traineddata are cached in filesDir/tessdata/
        val tessDir = File(context.filesDir, "tessdata")
        tessDir.deleteRecursively()
        val missingDataResult = OcrEngine.ensureTessDataCached(context)
        assertTrue(missingDataResult.isFailure)
        assertTrue(missingDataResult.exceptionOrNull()!!.message!!.contains("ben.traineddata"))

        tessDir.mkdirs()
        File(tessDir, "ben.traineddata").writeBytes(byteArrayOf(1, 2, 3, 4))
        File(tessDir, "eng.traineddata").writeBytes(byteArrayOf(5, 6, 7, 8))
        val cachedResult = OcrEngine.ensureTessDataCached(context)
        assertTrue(cachedResult.isSuccess)
        assertEquals(context.filesDir.absolutePath, cachedResult.getOrThrow().absolutePath)
        assertTrue(OcrEngine.hasBengaliTrainedData(context))
        tessDir.deleteRecursively()

        val sample = createCrispTextBitmap("Invoice #1042")
        // Verify modular provider slot routes Bengali extraction directly
        engine.registerProvider(object : OcrProvider {
            override val script = OcrScript.BENGALI
            override val engineName = "Test Tesseract Bengali"
            override val isAvailable = true
            override suspend fun recognizeBitmap(bitmap: Bitmap, rotationDegrees: Int) =
                Result.success("বাংলা নথি")
        })
        assertTrue(engine.isScriptSupported(OcrScript.BENGALI))
        val customResult = engine.extractTextFromBitmap(sample, OcrScript.BENGALI)
        assertTrue(customResult.isSuccess)
        assertEquals("বাংলা নথি", customResult.getOrThrow().combinedText)

        // Ensure ML Kit Context & default providers instantiate cleanly without missing symbols
        com.google.mlkit.common.sdkinternal.MlKitContext.initializeIfNeeded(context)
        val inputImage = InputImage.fromBitmap(sample, 0)
        assertEquals(sample.width, inputImage.width)
        assertNotNull(engine.getProvider(OcrScript.LATIN))
        assertNotNull(engine.getProvider(OcrScript.DEVANAGARI))
        assertNotNull(engine.getProvider(OcrScript.CHINESE))
        assertNotNull(engine.getProvider(OcrScript.JAPANESE))
        assertNotNull(engine.getProvider(OcrScript.KOREAN))
        assertNotNull(engine.getProvider(OcrScript.BENGALI))
        assertTrue(OcrScript.AUTO.isSupported)
        assertTrue(engine.isScriptSupported(OcrScript.AUTO))
        sample.recycle()
    }

    @Test
    fun `ocr auto detect selects winning script across Latin Devanagari Bengali Chinese Japanese and Korean`() = runTest(testDispatcher) {
        val sample = createCrispTextBitmap("Multi-Language Sample")

        fun buildAutoEngine(
            latinText: String = "",
            devanagariText: String = "",
            bengaliText: String = "",
            chineseText: String = "",
            japaneseText: String = "",
            koreanText: String = ""
        ): OcrEngine = OcrEngine(
            initialProviders = mapOf(
                OcrScript.LATIN to object : OcrProvider {
                    override val script = OcrScript.LATIN
                    override val engineName = "Mock Latin"
                    override val isAvailable = true
                    override suspend fun recognizeBitmap(bitmap: Bitmap, rotationDegrees: Int) = Result.success(latinText)
                },
                OcrScript.DEVANAGARI to object : OcrProvider {
                    override val script = OcrScript.DEVANAGARI
                    override val engineName = "Mock Devanagari"
                    override val isAvailable = true
                    override suspend fun recognizeBitmap(bitmap: Bitmap, rotationDegrees: Int) = Result.success(devanagariText)
                },
                OcrScript.BENGALI to object : OcrProvider {
                    override val script = OcrScript.BENGALI
                    override val engineName = "Mock Tesseract Bengali"
                    override val isAvailable = true
                    override suspend fun recognizeBitmap(bitmap: Bitmap, rotationDegrees: Int) = Result.success(bengaliText)
                },
                OcrScript.CHINESE to object : OcrProvider {
                    override val script = OcrScript.CHINESE
                    override val engineName = "Mock Chinese"
                    override val isAvailable = true
                    override suspend fun recognizeBitmap(bitmap: Bitmap, rotationDegrees: Int) = Result.success(chineseText)
                },
                OcrScript.JAPANESE to object : OcrProvider {
                    override val script = OcrScript.JAPANESE
                    override val engineName = "Mock Japanese"
                    override val isAvailable = true
                    override suspend fun recognizeBitmap(bitmap: Bitmap, rotationDegrees: Int) = Result.success(japaneseText)
                },
                OcrScript.KOREAN to object : OcrProvider {
                    override val script = OcrScript.KOREAN
                    override val engineName = "Mock Korean"
                    override val isAvailable = true
                    override suspend fun recognizeBitmap(bitmap: Bitmap, rotationDegrees: Int) = Result.success(koreanText)
                }
            ),
            workerDispatcher = testDispatcher
        )

        // 1. Hindi / Devanagari document wins over noisy Latin fragments
        val hindiRes = buildAutoEngine(
            latinText = "12 34",
            devanagariText = "नमस्ते भारत सरकार पहचान पत्र दस्तावेज़"
        ).extractTextFromBitmap(sample, OcrScript.AUTO).getOrThrow()
        assertEquals(OcrScript.DEVANAGARI, hindiRes.effectiveScript)
        assertTrue(hindiRes.combinedText.contains("नमस्ते"))
        assertNotNull(hindiRes.detectedLanguage)
        assertEquals("Devanagari", hindiRes.detectedLanguage!!.scriptFamily)

        // 2. Bengali document wins via Bengali Unicode block scoring
        val bnRes = buildAutoEngine(
            latinText = "102",
            bengaliText = "বাংলা নথি স্ক্যান করা হয়েছে এবং সংরক্ষিত আছে"
        ).extractTextFromBitmap(sample, OcrScript.AUTO).getOrThrow()
        assertEquals(OcrScript.BENGALI, bnRes.effectiveScript)
        assertTrue(bnRes.combinedText.contains("বাংলা"))
        assertEquals("Bengali", bnRes.detectedLanguage?.displayName)

        // 3. Japanese document wins over Chinese when kana is present
        val jpRes = buildAutoEngine(
            latinText = "JP",
            chineseText = "日本書類",
            japaneseText = "こんにちは これは日本語の書類です"
        ).extractTextFromBitmap(sample, OcrScript.AUTO).getOrThrow()
        assertEquals(OcrScript.JAPANESE, jpRes.effectiveScript)
        assertTrue(jpRes.combinedText.contains("こんにちは"))
        assertEquals("Japanese", jpRes.detectedLanguage?.displayName)

        // 4. Korean document wins via Hangul scoring
        val krRes = buildAutoEngine(
            latinText = "KR",
            koreanText = "안녕하세요 한국어 문서 스캔 결과입니다"
        ).extractTextFromBitmap(sample, OcrScript.AUTO).getOrThrow()
        assertEquals(OcrScript.KOREAN, krRes.effectiveScript)
        assertEquals("Korean", krRes.detectedLanguage?.displayName)

        // 5. Chinese document wins via Han script scoring
        val zhRes = buildAutoEngine(
            latinText = "CN",
            chineseText = "欢迎使用文档扫描仪提取中文内容"
        ).extractTextFromBitmap(sample, OcrScript.AUTO).getOrThrow()
        assertEquals(OcrScript.CHINESE, zhRes.effectiveScript)
        assertEquals("Chinese", zhRes.detectedLanguage?.displayName)

        // 6. Latin document wins when English text is present
        val enRes = buildAutoEngine(
            latinText = "Invoice #2026 Total Balance Due $450.00"
        ).extractTextFromBitmap(sample, OcrScript.AUTO).getOrThrow()
        assertEquals(OcrScript.LATIN, enRes.effectiveScript)
        assertEquals("Latin", enRes.detectedLanguage?.scriptFamily)

        sample.recycle()
    }

    @Test
    fun `bitmap filter engine downsamples oversized images to 2560px and preprocesses for Tesseract`() {
        val tempDir = File(context.cacheDir, "bitmap_cap_test").apply { mkdirs() }
        val hugeBmp = Bitmap.createBitmap(3400, 2200, Bitmap.Config.ARGB_8888).apply {
            eraseColor(Color.WHITE)
        }
        val hugeFile = saveBitmapJpeg(File(tempDir, "huge_camera.jpg"), hugeBmp)

        // Requesting 4096px should still cap cleanly at MAX_SAFE_IMAGE_DIMENSION (2560px)
        val decoded = BitmapFilterEngine.decodeSampledBitmap(hugeFile.absolutePath, maxDimension = 4096)!!
        assertTrue("Expected width <= 2560, got ${decoded.width}", decoded.width <= BitmapFilterEngine.MAX_SAFE_IMAGE_DIMENSION)
        assertTrue("Expected height <= 2560, got ${decoded.height}", decoded.height <= BitmapFilterEngine.MAX_SAFE_IMAGE_DIMENSION)

        val prepared = BitmapFilterEngine.prepareForTesseractOcr(decoded, rotationDegrees = 90)
        assertFalse(prepared.isRecycled)
        assertTrue(prepared.width <= BitmapFilterEngine.MAX_SAFE_IMAGE_DIMENSION)
        assertTrue(prepared.height <= BitmapFilterEngine.MAX_SAFE_IMAGE_DIMENSION)
        prepared.recycle()
        decoded.recycle()
        tempDir.deleteRecursively()
    }

    @Test
    fun `bengali tesseract preprocessing upscales narrow images 2x and applies high contrast grayscale`() {
        // 1. Bitmap narrower than 1500px -> upscaled 2x with bilinear filtering + high-contrast grayscale
        val narrowBmp = Bitmap.createBitmap(600, 400, Bitmap.Config.ARGB_8888).apply {
            // Light warm paper shadow background + dark ink stroke block
            eraseColor(Color.rgb(218, 212, 198))
            val c = Canvas(this)
            val p = Paint().apply { color = Color.rgb(32, 28, 30) }
            c.drawRect(100f, 100f, 112f, 112f, p)
        }
        val upscaled = TesseractBengaliOcrProvider.preprocessBitmapForBengaliOcr(narrowBmp)
        try {
            assertEquals(1200, upscaled.width)
            assertEquals(800, upscaled.height)
            assertFalse(narrowBmp.isRecycled)

            // Paper shadow pixel should be grayscale (R==G==B) and brightened toward pure white
            val bgPx = upscaled.getPixel(10, 10)
            val r = Color.red(bgPx)
            val g = Color.green(bgPx)
            val b = Color.blue(bgPx)
            assertTrue("Expected grayscale paper background, got ($r,$g,$b)", kotlin.math.abs(r - g) <= 2 && kotlin.math.abs(g - b) <= 2)
            assertTrue("Expected lifted brightness on paper shadow (>=240), got $r", r >= 240)

            // Dark ink stroke interior should stay crisp and dark
            val inkPx = upscaled.getPixel(210, 210)
            assertTrue("Expected dark ink pixel (<40), got ${Color.red(inkPx)}", Color.red(inkPx) < 40)
        } finally {
            upscaled.recycle()
            narrowBmp.recycle()
        }

        // 2. Bitmap already >= 1500px wide -> NOT upscaled beyond original dimensions
        val wideBmp = Bitmap.createBitmap(1600, 900, Bitmap.Config.ARGB_8888).apply {
            eraseColor(Color.rgb(230, 225, 220))
        }
        val processedWide = TesseractBengaliOcrProvider.preprocessBitmapForBengaliOcr(wideBmp)
        try {
            assertEquals(1600, processedWide.width)
            assertEquals(900, processedWide.height)
            assertFalse(wideBmp.isRecycled)
        } finally {
            processedWide.recycle()
            wideBmp.recycle()
        }
    }

    @Test
    fun `unicode language detector accurately identifies global scripts`() {
        assertEquals("Bengali", OcrLanguageDetector.detectByUnicodeScript("বাংলা নথি স্ক্যান করা হয়েছে")?.displayName)
        assertEquals("Tamil", OcrLanguageDetector.detectByUnicodeScript("தமிழ் ஆவணம் ஸ்கேன் செய்யப்பட்டது")?.displayName)
        assertEquals("Telugu", OcrLanguageDetector.detectByUnicodeScript("తెలుగు పత్రం స్కాన్ చేయబడింది")?.displayName)
        assertEquals("Gujarati", OcrLanguageDetector.detectByUnicodeScript("ગુજરાતી દસ્તાવેજ સ્કેન")?.displayName)
        assertEquals("Punjabi", OcrLanguageDetector.detectByUnicodeScript("ਪੰਜਾਬੀ ਦਸਤਾਵੇਜ਼ ਸਕੈਨ")?.displayName)
        assertEquals("Arabic / Urdu", OcrLanguageDetector.detectByUnicodeScript("مرحبا بكم في مسح المستندات")?.displayName)
        assertEquals("Russian / Cyrillic", OcrLanguageDetector.detectByUnicodeScript("Привет мир документ")?.displayName)
        assertEquals("Thai", OcrLanguageDetector.detectByUnicodeScript("สวัสดีเอกสารสแกน")?.displayName)
        assertEquals("Greek", OcrLanguageDetector.detectByUnicodeScript("Καλημέρα έγγραφο")?.displayName)
    }

    @Test
    fun `ocr detects empty and blurry images passes rotated images and preserves multi-page order`() = runTest(testDispatcher) {
        val observedRotations = mutableListOf<Int>()
        val observedScripts = mutableListOf<OcrScript>()
        var callCounter = 0

        val testEngine = OcrEngine(
            initialProviders = mapOf(
                OcrScript.LATIN to object : OcrProvider {
                    override val script = OcrScript.LATIN
                    override val engineName = "Test Latin OCR"
                    override val isAvailable = true
                    override suspend fun recognizeBitmap(bitmap: Bitmap, rotationDegrees: Int): Result<String> {
                        callCounter++
                        observedRotations.add(rotationDegrees)
                        observedScripts.add(script)
                        return Result.success("English Page $callCounter Content")
                    }
                },
                OcrScript.DEVANAGARI to object : OcrProvider {
                    override val script = OcrScript.DEVANAGARI
                    override val engineName = "Test Devanagari OCR"
                    override val isAvailable = true
                    override suspend fun recognizeBitmap(bitmap: Bitmap, rotationDegrees: Int): Result<String> {
                        observedScripts.add(script)
                        return Result.success("नमस्ते भारत पृष्ठ")
                    }
                }
            ),
            workerDispatcher = testDispatcher
        )

        // 1. Blank/Empty image fails gracefully
        val blankBmp = Bitmap.createBitmap(400, 300, Bitmap.Config.ARGB_8888).apply {
            eraseColor(Color.WHITE)
        }
        assertTrue(BitmapFilterEngine.assessImageQuality(blankBmp).isBlankOrUniform)
        val blankResult = testEngine.extractTextFromBitmap(blankBmp, OcrScript.LATIN)
        assertTrue(blankResult.isFailure)
        assertTrue(blankResult.exceptionOrNull()!!.message!!.contains("empty", ignoreCase = true))
        blankBmp.recycle()

        // 2. Blurry low-contrast image emits warning while still extracting text
        val blurryBmp = createBlurryLowContrastBitmap()
        assertTrue(BitmapFilterEngine.assessImageQuality(blurryBmp).isLikelyBlurry)
        val blurryResult = testEngine.extractTextFromBitmap(blurryBmp, OcrScript.LATIN).getOrThrow()
        assertTrue(blurryResult.warnings.any { it.contains("blurry", ignoreCase = true) })
        blurryBmp.recycle()

        // 3. Rotated image passes rotation angle accurately
        val crispBmp = createCrispTextBitmap("DocuScan Receipt")
        testEngine.extractTextFromBitmap(crispBmp, OcrScript.LATIN, rotationDegrees = 90).getOrThrow()
        assertEquals(90, observedRotations.last())

        // 4. Devanagari script routing
        val hindiResult = testEngine.extractTextFromBitmap(crispBmp, OcrScript.DEVANAGARI).getOrThrow()
        assertEquals("नमस्ते भारत पृष्ठ", hindiResult.combinedText)
        assertEquals(OcrScript.DEVANAGARI, observedScripts.last())
        crispBmp.recycle()

        // 5. Multi-page PDF OCR preserves exact page order and reports progress
        val tempDir = File(context.cacheDir, "ocr_multi").apply { mkdirs() }
        val p1 = saveBitmapJpeg(File(tempDir, "p1.jpg"), createCrispTextBitmap("Page One Alpha"))
        val p2 = saveBitmapJpeg(File(tempDir, "p2.jpg"), createCrispTextBitmap("Page Two Beta"))
        val p3 = saveBitmapJpeg(File(tempDir, "p3.jpg"), createCrispTextBitmap("Page Three Gamma"))
        val multiPdf = File(tempDir, "three_pages.pdf")
        pdfGenerator.generatePdfFromPages(
            pages = listOf(p1, p2, p3).mapIndexed { i, f ->
                ScanPage(UUID.randomUUID().toString(), f.absolutePath, ScanFilter.ORIGINAL, 0, i)
            },
            outputFile = multiPdf,
            options = PdfCreationOptions(pageSize = PdfPageSize.A4, quality = ScanQuality.STANDARD)
        )

        callCounter = 0
        val progressEvents = mutableListOf<Pair<Int, Int>>()
        val multiResult = testEngine.extractTextFromPdf(
            pdfPath = multiPdf.absolutePath,
            pdfRendererHelper = pdfRendererHelper,
            script = OcrScript.LATIN,
            onProgress = { curr, total -> progressEvents.add(curr to total) }
        ).getOrThrow()

        assertEquals(listOf(1 to 3, 2 to 3, 3 to 3), progressEvents)
        assertEquals(3, multiResult.pages.size)
        assertEquals(1, multiResult.pages[0].pageNumberOneBased)
        assertEquals(2, multiResult.pages[1].pageNumberOneBased)
        assertEquals(3, multiResult.pages[2].pageNumberOneBased)
        assertTrue(multiResult.combinedText.indexOf("--- Page 1 ---") < multiResult.combinedText.indexOf("--- Page 2 ---"))
        assertTrue(multiResult.combinedText.indexOf("--- Page 2 ---") < multiResult.combinedText.indexOf("--- Page 3 ---"))
    }

    @Test
    fun `ocr viewModel supports error retry search editing Room save and txt file export`() = runTest(testDispatcher) {
        var shouldFail = true
        val flakyEngine = OcrEngine(
            initialProviders = mapOf(
                OcrScript.LATIN to object : OcrProvider {
                    override val script = OcrScript.LATIN
                    override val engineName = "Retryable Test Engine"
                    override val isAvailable = true
                    override suspend fun recognizeBitmap(bitmap: Bitmap, rotationDegrees: Int): Result<String> {
                        return if (shouldFail) {
                            Result.failure(IllegalStateException("Transient OCR failure"))
                        } else {
                            Result.success("Quarterly Revenue Report\nTotal Amount: $4200\nRevenue Growth Verified")
                        }
                    }
                }
            ),
            workerDispatcher = testDispatcher
        )

        val tempDir = File(context.cacheDir, "ocr_vm").apply { mkdirs() }
        val imgFile = saveBitmapJpeg(File(tempDir, "report.jpg"), createCrispTextBitmap("Revenue Report"))
        val doc = repository.saveSingleImageDocument(
            title = "Q4_Report",
            page = ScanPage(UUID.randomUUID().toString(), imgFile.absolutePath),
            folderId = null
        ).getOrThrow()

        val vm = OcrViewModel(flakyEngine, repository, pdfRendererHelper, fileManager)
        vm.selectDocument(doc)

        // First attempt errors -> retry available
        vm.runExtraction()
        advanceUntilIdle()
        val errState = vm.uiState.value.runState as? OcrRunState.Error
        assertNotNull(errState)
        assertTrue(errState!!.canRetry)

        // Retry succeeds
        shouldFail = false
        vm.runExtraction()
        advanceUntilIdle()
        assertTrue(vm.uiState.value.runState is OcrRunState.Success)
        assertTrue(vm.uiState.value.editableText.contains("Quarterly Revenue Report"))

        // Search inside extracted text
        vm.updateSearchQuery("Revenue")
        assertEquals(2, vm.uiState.value.totalMatchCount)
        assertEquals(2, vm.uiState.value.searchMatches.size)

        // Edit text and persist back to Document in Room
        vm.updateEditableText(vm.uiState.value.editableText + "\nReviewed by Finance")
        vm.saveExtractedNotesToDocument()
        advanceUntilIdle()
        val persistedDoc = repository.getDocumentById(doc.id)!!
        assertTrue(persistedDoc.ocrText.contains("Reviewed by Finance"))

        // Save as TXT via Uri
        val txtOutFile = File(tempDir, "exported_ocr.txt")
        vm.saveAsTxtToUri(Uri.fromFile(txtOutFile))
        advanceUntilIdle()
        assertTrue(txtOutFile.exists())
        assertTrue(txtOutFile.readText().contains("Quarterly Revenue Report"))
    }

    // ---------- TASK B: ID DOCUMENT SCANNER WORKFLOWS ----------

    @Test
    fun `all five ID workflows support crop enhancement combination and encrypted local storage`() = runTest(testDispatcher) {
        val fakeGateway = object : DocumentScannerGateway {
            override fun buildDefaultOptions(pageLimit: Int): GmsDocumentScannerOptions =
                GmsDocumentScannerOptions.Builder().setPageLimit(pageLimit).build()
            override fun prepareScanIntent(activity: android.app.Activity, pageLimit: Int, onResult: (ScannerStartOutcome) -> Unit) {}
            override fun parseActivityResult(resultCode: Int, data: android.content.Intent?) = ScannerActivityOutcome.Cancelled
        }
        val scannerVm = ScannerViewModel(
            documentRepository = repository,
            settingsRepository = settingsRepository,
            sessionManager = ScanSessionManager(),
            fileManager = fileManager,
            scannerGateway = fakeGateway
        )

        val tempDir = File(context.cacheDir, "id_inputs").apply { mkdirs() }
        val frontFile = saveBitmapJpeg(File(tempDir, "id_front.jpg"), createDetailedCardBitmap(1000, 630, Color.CYAN))
        val backFile = saveBitmapJpeg(File(tempDir, "id_back.jpg"), createDetailedCardBitmap(1000, 630, Color.YELLOW))

        // Verify crop + rotation transforms preserve exact relative proportions
        val decodedFront = BitmapFilterEngine.decodeSampledBitmap(frontFile.absolutePath, 1000)!!
        val croppedRotated = BitmapFilterEngine.cropAndTransform(
            source = decodedFront,
            cropRect = NormalizedCropRect(0.10f, 0.20f, 0.90f, 0.80f),
            rotationDegrees = 90,
            filter = ScanFilter.DOCUMENT_BW
        )
        // Rotated 90° -> raw width 1000 becomes height, raw height 630 becomes width; then cropped 80% x 60%
        assertTrue(croppedRotated.width in 490..520)
        assertTrue(croppedRotated.height in 590..615)
        croppedRotated.recycle()

        // Test every ID workflow creates valid local PDF with custom filename
        IdDocumentType.entries.forEach { docType ->
            scannerVm.selectIdDocumentType(docType)
            scannerVm.setIdFrontFromFile(frontFile)
            scannerVm.updateIdSideCrop(isFront = true, NormalizedCropRect(0.05f, 0.05f, 0.95f, 0.95f))
            scannerVm.updateIdSideFilter(isFront = true, ScanFilter.HIGH_CONTRAST)
            if (docType.requiresBackSide) {
                scannerVm.setIdBackFromFile(backFile)
                scannerVm.rotateIdSide(isFront = false, deltaDegrees = 180)
            }
            scannerVm.setIdSingleCombinedSheet(true)

            var createdDocId = -1L
            val customName = "My_${docType.name}_LocalScan"
            scannerVm.generateIdCardPdf(
                title = customName,
                password = if (docType == IdDocumentType.PASSPORT) "pass123" else null
            ) { createdDoc ->
                createdDocId = createdDoc.id
            }
            advanceUntilIdle()

            assertTrue("Expected created ID doc for $docType", createdDocId > 0L)
            val saved = repository.getDocumentById(createdDocId)!!
            assertEquals(customName, saved.title)
            assertEquals(DocumentFileType.ID_CARD, saved.fileType)
            assertEquals(1, saved.pageCount) // Combined single sheet
            assertTrue(File(saved.filePath).exists())

            if (docType == IdDocumentType.PASSPORT) {
                assertTrue(saved.isPasswordProtected)
                assertTrue(pdfRendererHelper.renderPageOutcome(saved.filePath, 0, 800, null) is PdfRenderOutcome.PasswordRequired)
                assertTrue(pdfRendererHelper.renderPageOutcome(saved.filePath, 0, 800, "pass123") is PdfRenderOutcome.Success)
            } else {
                assertFalse(saved.isPasswordProtected)
                assertEquals(1, pdfRendererHelper.getPageCount(saved.filePath))
            }
        }
    }

    @Test
    fun `two sided ID scan with combined sheet off produces 2 separate A4 pages`() = runTest(testDispatcher) {
        val tempDir = File(context.cacheDir, "id_two_page").apply { mkdirs() }
        val frontFile = saveBitmapJpeg(File(tempDir, "dl_front.jpg"), createDetailedCardBitmap(900, 560, Color.GREEN))
        val backFile = saveBitmapJpeg(File(tempDir, "dl_back.jpg"), createDetailedCardBitmap(900, 560, Color.MAGENTA))

        val doc = repository.createIdCardPdfDocument(
            title = "DL_TwoPage",
            docType = IdDocumentType.DRIVING_LICENCE,
            frontSide = com.docuscan.app.domain.model.IdSideScanState(frontFile.absolutePath),
            backSide = com.docuscan.app.domain.model.IdSideScanState(backFile.absolutePath),
            singleCombinedSheet = false,
            quality = ScanQuality.STANDARD
        ).getOrThrow()

        assertEquals(2, doc.pageCount)
        assertEquals(2, pdfRendererHelper.getPageCount(doc.filePath))
    }

    // ---------- TASK C: SIGNATURE DRAW, SAVE & PDF INSERTION ----------

    @Test
    fun `signature save clear redraw and insert into resized repositioned PDF page preserves source PDF`() = runTest(testDispatcher) {
        val tempDir = File(context.cacheDir, "sig_test").apply { mkdirs() }
        val p1File = saveBitmapJpeg(File(tempDir, "contract1.jpg"), createBlankishCardWithBorder(800, 1100))
        val p2File = saveBitmapJpeg(File(tempDir, "contract2.jpg"), createBlankishCardWithBorder(800, 1100))

        val contractDoc = repository.createPdfDocument(
            title = "Service_Agreement",
            pages = listOf(
                ScanPage("1", p1File.absolutePath, ScanFilter.ORIGINAL, 0, 0),
                ScanPage("2", p2File.absolutePath, ScanFilter.ORIGINAL, 0, 1)
            ),
            folderId = null,
            options = PdfCreationOptions(pageSize = PdfPageSize.A4, quality = ScanQuality.STANDARD)
        ).getOrThrow()
        val originalSize = File(contractDoc.filePath).length()

        val sigVm = SignatureViewModel(repository, pdfRendererHelper)
        val sigBytes = createTransparentSignaturePngBytes()
        var savedSigId = -1L
        sigVm.saveSignature("Primary Ink", sigBytes) { sig ->
            savedSigId = sig.id
        }
        advanceUntilIdle()
        assertTrue(savedSigId > 0L)
        val sigList = repository.observeSignatures().first()
        assertEquals(1, sigList.size)
        assertTrue(File(sigList.first().filePath).exists())

        // Initialize signing session, switch to Page 2, reposition & resize signature
        sigVm.initSignPdfSession(contractDoc.id, savedSigId)
        advanceUntilIdle()
        assertEquals(2, sigVm.signPdfState.value.totalPages)

        sigVm.goToSignPage(1)
        advanceUntilIdle()
        sigVm.updatePlacement(normX = 0.58f, normY = 0.72f, normWidth = 0.28f)
        assertEquals(1, sigVm.signPdfState.value.placement.pageIndex)
        assertEquals(0.28f, sigVm.signPdfState.value.placement.normWidth, 0.001f)

        var signedDocId = -1L
        sigVm.applySignatureToPdf("Service_Agreement_Signed") { signedDoc ->
            signedDocId = signedDoc.id
        }
        advanceUntilIdle()
        assertTrue(signedDocId > 0L)

        val signedDoc = repository.getDocumentById(signedDocId)!!
        assertEquals("Service_Agreement_Signed", signedDoc.title)
        assertEquals(2, signedDoc.pageCount)

        // Original PDF untouched
        assertEquals(originalSize, File(contractDoc.filePath).length())

        // Inspect signed PDF XObjects: Page 1 has 1 image (scanned page); Page 2 has 2 images (page + signature PNG)
        PDDocument.load(File(signedDoc.filePath)).use { pd ->
            assertEquals(2, pd.numberOfPages)
            val page0Images = pd.getPage(0).resources.xObjectNames.count {
                pd.getPage(0).resources.getXObject(it) is PDImageXObject
            }
            val page1Images = pd.getPage(1).resources.xObjectNames.count {
                pd.getPage(1).resources.getXObject(it) is PDImageXObject
            }
            assertEquals(1, page0Images)
            assertEquals(2, page1Images)
        }

        // Delete signature removes file & DB entry
        sigVm.deleteSignature(savedSigId)
        advanceUntilIdle()
        assertTrue(repository.observeSignatures().first().isEmpty())
    }

    @Test
    fun `ocr ui enables Bengali Tesseract script cleanly without unsupported warning`() {
        composeTestRule.setContent {
            DocuScanTheme {
                OcrExtractorScreen(
                    documents = emptyList(),
                    activeSessionPages = emptyList(),
                    initialDocumentId = -1L,
                    uiState = OcrUiState(selectedScript = OcrScript.BENGALI),
                    createCameraTempFile = { fileManager.createTempCameraFile() },
                    onInitializeDocument = {},
                    onSelectDocument = {},
                    onImportImageUri = {},
                    onCapturedImageFile = {},
                    onSelectScanSession = {},
                    onSelectScript = {},
                    onUpdatePdfPassword = {},
                    onRunExtraction = {},
                    onUpdateEditableText = {},
                    onUpdateSearchQuery = {},
                    onSaveNotesToDocument = {},
                    onSaveAsTxtToUri = {},
                    onClearStatusMessage = {},
                    onScanFirstDocument = {},
                    onBack = {}
                )
            }
        }
        composeTestRule.waitForIdle()
        composeTestRule.onNodeWithTag("ocr_script_auto").performScrollTo().assertIsDisplayed()
        composeTestRule.onNodeWithTag("ocr_script_latin").performScrollTo().assertIsDisplayed()
        composeTestRule.onNodeWithTag("ocr_script_devanagari").performScrollTo().assertIsDisplayed()
        composeTestRule.onNodeWithTag("ocr_script_chinese").performScrollTo().assertIsDisplayed()
        composeTestRule.onNodeWithTag("ocr_script_japanese").performScrollTo().assertIsDisplayed()
        composeTestRule.onNodeWithTag("ocr_script_korean").performScrollTo().assertIsDisplayed()
        composeTestRule.onNodeWithTag("ocr_script_bengali").performScrollTo().assertIsDisplayed()
        composeTestRule.onNodeWithText("Bengali (বাংলা)").performScrollTo().assertIsDisplayed()
        composeTestRule.onNodeWithText("Tesseract").performScrollTo().assertIsDisplayed()
    }

    @Test
    fun `ocr ui renders detected language badge when auto detection completes`() {
        composeTestRule.setContent {
            DocuScanTheme {
                OcrExtractorScreen(
                    documents = emptyList(),
                    activeSessionPages = emptyList(),
                    initialDocumentId = -1L,
                    uiState = OcrUiState(
                        selectedScript = OcrScript.AUTO,
                        editableText = "नमस्ते भारत दस्तावेज़",
                        detectedLanguage = DetectedLanguageInfo(
                            languageCode = "hi",
                            displayName = "Hindi",
                            confidence = 0.96f,
                            scriptFamily = "Devanagari",
                            suggestedOcrScript = OcrScript.DEVANAGARI
                        ),
                        detectedScriptUsed = OcrScript.DEVANAGARI
                    ),
                    createCameraTempFile = { fileManager.createTempCameraFile() },
                    onInitializeDocument = {},
                    onSelectDocument = {},
                    onImportImageUri = {},
                    onCapturedImageFile = {},
                    onSelectScanSession = {},
                    onSelectScript = {},
                    onUpdatePdfPassword = {},
                    onRunExtraction = {},
                    onUpdateEditableText = {},
                    onUpdateSearchQuery = {},
                    onSaveNotesToDocument = {},
                    onSaveAsTxtToUri = {},
                    onClearStatusMessage = {},
                    onScanFirstDocument = {},
                    onBack = {}
                )
            }
        }
        composeTestRule.waitForIdle()
        composeTestRule.onNodeWithTag("ocr_detected_language_badge").performScrollTo().assertIsDisplayed()
    }

    @Test
    fun `id scanner ui exposes all five workflows and non verification privacy disclaimer`() {
        composeTestRule.setContent {
            DocuScanTheme {
                IdScannerScreen(
                    selectedType = IdDocumentType.AADHAAR,
                    frontSide = IdSideScanState(),
                    backSide = IdSideScanState(),
                    singleCombinedSheet = true,
                    operationState = OperationState.Idle,
                    createCameraTempFile = { fileManager.createTempCameraFile() },
                    onSelectDocumentType = {},
                    onSetSingleCombinedSheet = {},
                    onPickFrontUri = {},
                    onPickBackUri = {},
                    onCaptureFrontFile = {},
                    onCaptureBackFile = {},
                    onUpdateSideCrop = { _, _ -> },
                    onUpdateSideFilter = { _, _ -> },
                    onRotateSide = {},
                    onClearSide = {},
                    onGenerateIdPdf = { _, _, _ -> },
                    onPdfCreated = {},
                    onClearOperationError = {},
                    onBack = {}
                )
            }
        }
        composeTestRule.waitForIdle()
        composeTestRule.onNodeWithTag("id_type_aadhaar").performScrollTo().assertIsDisplayed()
        composeTestRule.onNodeWithTag("id_type_pan").performScrollTo().assertIsDisplayed()
        composeTestRule.onNodeWithTag("id_type_passport").performScrollTo().assertIsDisplayed()
        composeTestRule.onNodeWithTag("id_type_driving_licence").performScrollTo().assertIsDisplayed()
        composeTestRule.onNodeWithTag("id_type_voter_id").performScrollTo().assertIsDisplayed()
        composeTestRule.onNodeWithText("Offline Local Storage Only").performScrollTo().assertIsDisplayed()
    }

    @Test
    fun `id scanner front and back camera buttons open guided camera overlay cleanly`() {
        composeTestRule.setContent {
            DocuScanTheme {
                IdScannerScreen(
                    selectedType = IdDocumentType.AADHAAR,
                    frontSide = IdSideScanState(),
                    backSide = IdSideScanState(),
                    singleCombinedSheet = true,
                    operationState = OperationState.Idle,
                    createCameraTempFile = { fileManager.createTempCameraFile() },
                    onSelectDocumentType = {},
                    onSetSingleCombinedSheet = {},
                    onPickFrontUri = {},
                    onPickBackUri = {},
                    onCaptureFrontFile = {},
                    onCaptureBackFile = {},
                    onUpdateSideCrop = { _, _ -> },
                    onUpdateSideFilter = { _, _ -> },
                    onRotateSide = {},
                    onClearSide = {},
                    onGenerateIdPdf = { _, _, _ -> },
                    onPdfCreated = {},
                    onClearOperationError = {},
                    onBack = {}
                )
            }
        }
        composeTestRule.waitForIdle()

        // Tap Front Side Camera -> opens guided ID Camera Overlay without throwing SecurityException
        composeTestRule.onNodeWithTag("id_camera_front_btn").performScrollTo().performClick()
        composeTestRule.waitForIdle()
        composeTestRule.onNodeWithTag("id_camera_overlay").assertIsDisplayed()
        composeTestRule.onNodeWithTag("id_camera_close_btn").performClick()
        composeTestRule.waitForIdle()

        // Tap Back Side Camera -> opens guided ID Camera Overlay cleanly
        composeTestRule.onNodeWithTag("id_camera_back_btn").performScrollTo().performClick()
        composeTestRule.waitForIdle()
        composeTestRule.onNodeWithTag("id_camera_overlay").assertIsDisplayed()
        composeTestRule.onNodeWithTag("id_camera_close_btn").performClick()
        composeTestRule.waitForIdle()
    }

    @Test
    fun `id scanner interactive crop studio applies card fit preset ratio lock rotation and updates crop rect`() {
        val tempDir = File(context.cacheDir, "id_crop_ui").apply { mkdirs() }
        val frontFile = saveBitmapJpeg(File(tempDir, "front_portrait.jpg"), createDetailedCardBitmap(600, 1000, Color.CYAN))
        val backFile = saveBitmapJpeg(File(tempDir, "back_landscape.jpg"), createDetailedCardBitmap(1000, 630, Color.YELLOW))

        // Verify exact centered aspect crop helper for portrait capture
        val portraitFit = BitmapFilterEngine.computeCenteredAspectCrop(
            imageWidth = 600,
            imageHeight = 1000,
            targetAspectRatio = IdDocumentType.AADHAAR.aspectRatio,
            fillFraction = 0.88f
        )
        val croppedPixelW = (portraitFit.right - portraitFit.left) * 600f
        val croppedPixelH = (portraitFit.bottom - portraitFit.top) * 1000f
        assertEquals(IdDocumentType.AADHAAR.aspectRatio, croppedPixelW / croppedPixelH, 0.05f)

        var appliedFrontCrop: NormalizedCropRect? = null
        var appliedBackCrop: NormalizedCropRect? = null
        var frontRotations = 0

        composeTestRule.setContent {
            DocuScanTheme {
                IdScannerScreen(
                    selectedType = IdDocumentType.AADHAAR,
                    frontSide = IdSideScanState(imagePath = frontFile.absolutePath),
                    backSide = IdSideScanState(imagePath = backFile.absolutePath),
                    singleCombinedSheet = true,
                    operationState = OperationState.Idle,
                    createCameraTempFile = { fileManager.createTempCameraFile() },
                    onSelectDocumentType = {},
                    onSetSingleCombinedSheet = {},
                    onPickFrontUri = {},
                    onPickBackUri = {},
                    onCaptureFrontFile = {},
                    onCaptureBackFile = {},
                    onUpdateSideCrop = { isFront, rect ->
                        if (isFront) appliedFrontCrop = rect else appliedBackCrop = rect
                    },
                    onUpdateSideFilter = { _, _ -> },
                    onRotateSide = { isFront -> if (isFront) frontRotations++ },
                    onClearSide = {},
                    onGenerateIdPdf = { _, _, _ -> },
                    onPdfCreated = {},
                    onClearOperationError = {},
                    onBack = {}
                )
            }
        }
        composeTestRule.waitForIdle()

        // Open Front Crop Studio, choose Card Fit, lock ID ratio, rotate 90°, and apply
        composeTestRule.onNodeWithTag("id_crop_front_btn").performScrollTo().performClick()
        composeTestRule.waitForIdle()
        composeTestRule.onNodeWithTag("id_crop_studio_dialog").assertIsDisplayed()
        composeTestRule.onNodeWithTag("id_crop_preset_card_fit").performClick()
        composeTestRule.onNodeWithTag("id_crop_ratio_lock_btn").performClick()
        composeTestRule.onNodeWithTag("id_crop_rotate_btn").performClick()
        composeTestRule.onNodeWithTag("id_crop_apply_btn").performClick()
        composeTestRule.waitForIdle()

        assertEquals(1, frontRotations)
        assertNotNull(appliedFrontCrop)
        assertFalse(appliedFrontCrop!!.isFullFrame)

        // Open Back Crop Studio, select Tight preset, and apply
        composeTestRule.onNodeWithTag("id_crop_back_btn").performScrollTo().performClick()
        composeTestRule.waitForIdle()
        composeTestRule.onNodeWithTag("id_crop_studio_dialog").assertIsDisplayed()
        composeTestRule.onNodeWithTag("id_crop_preset_tight").performClick()
        composeTestRule.onNodeWithTag("id_crop_apply_btn").performClick()
        composeTestRule.waitForIdle()

        assertNotNull(appliedBackCrop)
        assertFalse(appliedBackCrop!!.isFullFrame)
    }

    @Test
    fun `sign pdf ui renders interactive signature overlay resize slider and save button`() {
        val tempDir = File(context.cacheDir, "sign_pdf_ui").apply { mkdirs() }
        val sigFile = File(tempDir, "sig.png").apply {
            writeBytes(createTransparentSignaturePngBytes())
        }
        val pageBmp = createBlankishCardWithBorder(600, 840)
        val doc = DocumentItem(
            id = 10L,
            title = "Rental_Contract",
            filePath = File(tempDir, "contract.pdf").absolutePath,
            fileType = DocumentFileType.PDF,
            pageCount = 1,
            sizeBytes = 1024L,
            createdAt = 1L,
            updatedAt = 1L
        )
        val sig = SignatureItem(
            id = 5L,
            name = "My Ink",
            filePath = sigFile.absolutePath,
            createdAt = 1L
        )

        composeTestRule.setContent {
            DocuScanTheme {
                SignPdfScreen(
                    initialDocumentId = doc.id,
                    initialSignatureId = sig.id,
                    pdfDocuments = listOf(doc),
                    savedSignatures = listOf(sig),
                    uiState = SignPdfUiState(
                        selectedDocument = doc,
                        selectedSignatureId = sig.id,
                        totalPages = 1,
                        currentPageIndex = 0,
                        pageBitmap = pageBmp
                    ),
                    statusMessage = null,
                    onInitSession = { _, _ -> },
                    onSelectDocument = {},
                    onUnlockPassword = {},
                    onSelectSignature = {},
                    onSelectPage = {},
                    onUpdatePlacement = { _, _, _ -> },
                    onApplySignature = { _, _ -> },
                    onDrawNewSignature = {},
                    onClearMessage = {},
                    onSignedPdfCreated = {},
                    onBack = {}
                )
            }
        }
        composeTestRule.waitForIdle()
        composeTestRule.onNodeWithTag("sign_pdf_overlay").performScrollTo().assertIsDisplayed()
        composeTestRule.onNodeWithTag("sign_pdf_size_slider").performScrollTo().assertIsDisplayed()
        composeTestRule.onNodeWithTag("sign_pdf_save_btn").performScrollTo().assertIsDisplayed()
    }

    // ---------- TEST HELPERS & IMAGE GENERATORS ----------

    private class InMemoryTestSettingsRepository : SettingsRepository {
        private val state = MutableStateFlow(UserPreferences())
        override val preferences: Flow<UserPreferences> = state
        override suspend fun setThemeMode(mode: ThemeMode) { state.update { it.copy(themeMode = mode) } }
        override suspend fun setAppLanguage(language: AppLanguage) { state.update { it.copy(appLanguage = language) } }
        override suspend fun setOnboardingCompleted(completed: Boolean) { state.update { it.copy(onboardingCompleted = completed) } }
        override suspend fun setScanQuality(quality: ScanQuality) { state.update { it.copy(scanQuality = quality) } }
        override suspend fun setDefaultPageSize(pageSize: PdfPageSize) { state.update { it.copy(defaultPageSize = pageSize) } }
        override suspend fun setAutoEnhance(enabled: Boolean) { state.update { it.copy(autoEnhance = enabled) } }
        override suspend fun setAppLockEnabled(enabled: Boolean) { state.update { it.copy(appLockEnabled = enabled) } }
        override suspend fun setBiometricUnlockEnabled(enabled: Boolean) { state.update { it.copy(biometricUnlockEnabled = enabled) } }
        override suspend fun setEncryptSensitiveFiles(enabled: Boolean) { state.update { it.copy(encryptSensitiveFiles = enabled) } }
        override suspend fun setSealedPinRecord(record: String?) { state.update { it.copy(sealedPinRecord = record) } }
        override suspend fun updateLastBackupAt(timestamp: Long) { state.update { it.copy(lastBackupAt = timestamp) } }
    }

    private fun createCrispTextBitmap(text: String): Bitmap {
        val w = 900
        val h = 320
        val bmp = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888)
        val pixels = IntArray(w * h) { Color.WHITE }
        // Crisp black document bars matching printed text lines (high contrast & sharp edges)
        for (y in 60 until 90) for (x in 60 until 540) pixels[y * w + x] = Color.BLACK
        for (y in 120 until 150) for (x in 60 until 780) pixels[y * w + x] = Color.BLACK
        for (y in 180 until 210) for (x in 60 until 640) pixels[y * w + x] = Color.BLACK
        bmp.setPixels(pixels, 0, w, 0, 0, w, h)
        val canvas = Canvas(bmp)
        val textPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = Color.BLACK
            textSize = 48f
        }
        canvas.drawText(text, 60f, 275f, textPaint)
        return bmp
    }

    private fun createBlurryLowContrastBitmap(): Bitmap {
        val w = 240
        val h = 160
        val bmp = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888)
        val pixels = IntArray(w * h)
        // Continuous smooth defocused luminance ramp (per-pixel step <= 1.5) with wide overall tonal variance
        for (y in 0 until h) {
            for (x in 0 until w) {
                val phase = kotlin.math.abs(x - 120) / 120f
                val shade = (140 + (phase * 90f)).toInt().coerceIn(140, 230)
                pixels[y * w + x] = Color.rgb(shade, shade, shade)
            }
        }
        bmp.setPixels(pixels, 0, w, 0, 0, w, h)
        return bmp
    }

    private fun createDetailedCardBitmap(width: Int, height: Int, accent: Int): Bitmap {
        val bmp = Bitmap.createBitmap(width, height, Bitmap.Config.ARGB_8888)
        val canvas = Canvas(bmp)
        canvas.drawColor(Color.WHITE)
        val borderPaint = Paint().apply {
            color = Color.DKGRAY
            style = Paint.Style.STROKE
            strokeWidth = 10f
        }
        canvas.drawRect(24f, 24f, width - 24f, height - 24f, borderPaint)
        val blockPaint = Paint().apply { color = accent }
        canvas.drawRect(56f, 70f, width / 3f, height - 80f, blockPaint)
        return bmp
    }

    private fun createBlankishCardWithBorder(width: Int, height: Int): Bitmap {
        val bmp = Bitmap.createBitmap(width, height, Bitmap.Config.ARGB_8888)
        val canvas = Canvas(bmp)
        canvas.drawColor(Color.WHITE)
        val paint = Paint().apply {
            color = Color.LTGRAY
            style = Paint.Style.STROKE
            strokeWidth = 4f
        }
        canvas.drawRect(30f, 30f, width - 30f, height - 30f, paint)
        return bmp
    }

    private fun saveBitmapJpeg(file: File, bmp: Bitmap): File {
        FileOutputStream(file).use { out ->
            bmp.compress(Bitmap.CompressFormat.JPEG, 92, out)
        }
        bmp.recycle()
        return file
    }

    private fun createTransparentSignaturePngBytes(): ByteArray {
        val bmp = Bitmap.createBitmap(320, 140, Bitmap.Config.ARGB_8888)
        val canvas = Canvas(bmp)
        canvas.drawColor(Color.TRANSPARENT)
        val paint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = Color.BLUE
            strokeWidth = 10f
            style = Paint.Style.STROKE
        }
        canvas.drawLine(30f, 95f, 140f, 35f, paint)
        canvas.drawLine(140f, 35f, 280f, 90f, paint)
        val out = ByteArrayOutputStream()
        bmp.compress(Bitmap.CompressFormat.PNG, 100, out)
        bmp.recycle()
        return out.toByteArray()
    }
}
