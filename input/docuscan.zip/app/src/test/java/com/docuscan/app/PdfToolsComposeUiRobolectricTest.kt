package com.docuscan.app

import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.compose.ui.test.assertIsDisplayed
import androidx.compose.ui.test.hasTestTag
import androidx.compose.ui.test.junit4.createComposeRule
import androidx.compose.ui.test.onNodeWithTag
import androidx.compose.ui.test.onNodeWithText
import androidx.compose.ui.test.performClick
import androidx.compose.ui.test.performScrollTo
import androidx.compose.ui.test.performScrollToNode
import androidx.compose.ui.test.performTextReplacement
import com.docuscan.app.domain.model.DocumentItem
import com.docuscan.app.domain.model.SignatureItem
import com.docuscan.app.ui.screens.OcrExtractorScreen
import com.docuscan.app.ui.screens.PdfToolId
import com.docuscan.app.ui.screens.PdfToolsScreen
import com.docuscan.app.ui.screens.SignPdfScreen
import com.docuscan.app.ui.theme.DocuScanTheme
import com.docuscan.app.ui.viewmodel.OcrUiState
import com.docuscan.app.ui.viewmodel.PdfToolResult
import com.docuscan.app.ui.viewmodel.PdfToolsUiState
import com.docuscan.app.ui.viewmodel.SignPdfUiState
import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Rule
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config
import java.io.File

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [36])
class PdfToolsComposeUiRobolectricTest {

    @get:Rule
    val composeRule = createComposeRule()

    @Test
    fun `every tool card responds to tap and exposes Select from Device option`() {
        val openedSuites = mutableListOf<String>()

        composeRule.setContent {
            DocuScanTheme {
                PdfToolsScreen(
                    pdfDocuments = emptyList(),
                    activeSessionPageCount = 0,
                    uiState = PdfToolsUiState(),
                    onDismissError = {},
                    onDismissResult = {},
                    onOpenIdScanner = { openedSuites += "id_scanner" },
                    onOpenSignatureCreator = { openedSuites += "sig_creator" },
                    onOpenSignPdf = { openedSuites += "sign_pdf" },
                    onOpenOcrExtractor = { openedSuites += "ocr" },
                    onOpenPageManager = { openedSuites += "page_manager" },
                    onImportMultipleGalleryImages = {},
                    onImportExternalPdf = { _, _ -> },
                    onOpenExternalPdfUri = {},
                    onOpenDocument = {},
                    onRenamePdf = { _, _ -> },
                    onDeletePdf = { _, _ -> },
                    onSharePdf = {},
                    onPrintPdf = { _, _ -> },
                    onDuplicatePdf = { _, _ -> },
                    onInspectInfo = { _, _ -> },
                    onMergePdfs = { _, _ -> },
                    onSplitPdf = { _, _, _, _, _ -> },
                    onExtractPages = { _, _, _, _ -> },
                    onReorderPages = { _, _, _, _, _ -> },
                    onRotatePages = { _, _, _, _, _ -> },
                    onDeletePages = { _, _, _, _ -> },
                    onDuplicatePages = { _, _, _, _, _ -> },
                    onExportPdfToImages = { _, _, _, _, _, _ -> },
                    onReadTextFromUri = { _, _ -> },
                    onCreatePdfFromText = { _, _, _, _, _, _, _, _ -> },
                    onConvertPdfToDocx = { _, _, _, _ -> },
                    onExtractTextFromPdf = { _, _, _, _ -> },
                    onProtectPdf = { _, _, _, _ -> },
                    onUnlockPdf = { _, _, _ -> },
                    onWatermarkPdf = { _, _, _, _ -> },
                    onRemoveWatermark = { _, _, _, _ -> },
                    onAddPageNumbers = { _, _, _, _, _, _ -> },
                    onAddHeaderFooter = { _, _, _, _, _, _, _ -> },
                    onCompressPdf = { _, _, _, _ -> },
                    onReducePdfSize = { _, _, _, _, _, _ -> },
                    onRepairPdf = { _, _, _ -> },
                    onRepairExternalPdfUri = { _, _, _ -> },
                    onExportPdfToSaf = { _, _ -> },
                    onExportLocalFileToSaf = { _, _, _ -> },
                    onExportTextToSaf = { _, _ -> },
                    onExportImagesToSafTree = { _, _, _ -> },
                    onShareLocalFile = { _, _, _ -> }
                )
            }
        }

        val suiteMappings = listOf(
            PdfToolId.ID_SCANNER to "id_scanner",
            PdfToolId.SIGNATURE_CREATOR to "sig_creator",
            PdfToolId.SIGN_PDF to "sign_pdf",
            PdfToolId.OCR_EXTRACTOR to "ocr"
        )
        suiteMappings.forEach { (tool, expectedKey) ->
            composeRule.onNodeWithTag("pdf_tools_list").performScrollToNode(hasTestTag(tool.testTag))
            composeRule.onNodeWithTag(tool.testTag).performClick()
            composeRule.waitForIdle()
            assertTrue("Expected $expectedKey to open", expectedKey in openedSuites)
        }

        // Text to PDF exposes Select .TXT from Device
        composeRule.onNodeWithTag("pdf_tools_list").performScrollToNode(hasTestTag(PdfToolId.TEXT_TO_PDF.testTag))
        composeRule.onNodeWithTag(PdfToolId.TEXT_TO_PDF.testTag).performClick()
        composeRule.onNodeWithTag("text_to_pdf_select_device_btn").assertIsDisplayed()
        composeRule.onNodeWithText("Cancel").performClick()

        // Merge PDF exposes Select PDFs from Device
        composeRule.onNodeWithTag("pdf_tools_list").performScrollToNode(hasTestTag(PdfToolId.MERGE_PDF.testTag))
        composeRule.onNodeWithTag(PdfToolId.MERGE_PDF.testTag).performClick()
        composeRule.onNodeWithTag("merge_select_device_btn").assertIsDisplayed()
        composeRule.onNodeWithText("Cancel").performClick()

        // Images to PDF exposes Select Images from Device
        composeRule.onNodeWithTag("pdf_tools_list").performScrollToNode(hasTestTag(PdfToolId.IMAGES_TO_PDF.testTag))
        composeRule.onNodeWithTag(PdfToolId.IMAGES_TO_PDF.testTag).performClick()
        composeRule.onNodeWithTag("images_to_pdf_pick_gallery_btn").assertIsDisplayed()
        composeRule.onNodeWithTag("images_to_pdf_open_manager_btn").performClick()
        composeRule.waitForIdle()
        assertTrue("page_manager" in openedSuites)

        // Every workspace PDF tool dialog exposes Select PDF from Device
        val workspaceTools = PdfToolId.entries.filter {
            it !in setOf(
                PdfToolId.MERGE_PDF,
                PdfToolId.IMAGES_TO_PDF,
                PdfToolId.TEXT_TO_PDF,
                PdfToolId.ID_SCANNER,
                PdfToolId.SIGNATURE_CREATOR,
                PdfToolId.SIGN_PDF,
                PdfToolId.OCR_EXTRACTOR
            )
        }
        workspaceTools.forEach { tool ->
            composeRule.onNodeWithTag("pdf_tools_list").performScrollToNode(hasTestTag(tool.testTag))
            composeRule.onNodeWithTag(tool.testTag).performClick()
            composeRule.onNodeWithTag("tool_dialog_pick_saf_btn").assertIsDisplayed()
            composeRule.onNodeWithText("Cancel").performClick()
        }
    }

    @Test
    fun `text to pdf creation displays open save and share result actions`() {
        var createdDocIdOpened: Long? = null
        var lastGeneratedTitle: String? = null
        var lastGeneratedText: String? = null
        val sampleDoc = DocumentItem(
            id = 42L,
            title = "Generated_Notes",
            filePath = "/tmp/generated_notes.pdf",
            pageCount = 2,
            sizeBytes = 12345L
        )
        val currentState = StateHolder(PdfToolsUiState())

        composeRule.setContent {
            DocuScanTheme {
                PdfToolsScreen(
                    pdfDocuments = emptyList(),
                    activeSessionPageCount = 0,
                    uiState = currentState.state,
                    onDismissError = {},
                    onDismissResult = { currentState.state = PdfToolsUiState() },
                    onOpenIdScanner = {},
                    onOpenSignatureCreator = {},
                    onOpenSignPdf = {},
                    onOpenOcrExtractor = {},
                    onOpenPageManager = {},
                    onImportMultipleGalleryImages = {},
                    onImportExternalPdf = { _, _ -> },
                    onOpenExternalPdfUri = {},
                    onOpenDocument = { id -> createdDocIdOpened = id },
                    onRenamePdf = { _, _ -> },
                    onDeletePdf = { _, _ -> },
                    onSharePdf = {},
                    onPrintPdf = { _, _ -> },
                    onDuplicatePdf = { _, _ -> },
                    onInspectInfo = { _, _ -> },
                    onMergePdfs = { _, _ -> },
                    onSplitPdf = { _, _, _, _, _ -> },
                    onExtractPages = { _, _, _, _ -> },
                    onReorderPages = { _, _, _, _, _ -> },
                    onRotatePages = { _, _, _, _, _ -> },
                    onDeletePages = { _, _, _, _ -> },
                    onDuplicatePages = { _, _, _, _, _ -> },
                    onExportPdfToImages = { _, _, _, _, _, _ -> },
                    onReadTextFromUri = { _, _ -> },
                    onCreatePdfFromText = { title, body, _, _, _, _, _, _ ->
                        lastGeneratedTitle = title
                        lastGeneratedText = body
                        currentState.state = PdfToolsUiState(
                            result = PdfToolResult.PdfCreated(
                                document = sampleDoc.copy(title = title),
                                toolTitle = "Text Converted to PDF",
                                detailMessage = "Generated 2 pages"
                            )
                        )
                    },
                    onConvertPdfToDocx = { _, _, _, _ -> },
                    onExtractTextFromPdf = { _, _, _, _ -> },
                    onProtectPdf = { _, _, _, _ -> },
                    onUnlockPdf = { _, _, _ -> },
                    onWatermarkPdf = { _, _, _, _ -> },
                    onRemoveWatermark = { _, _, _, _ -> },
                    onAddPageNumbers = { _, _, _, _, _, _ -> },
                    onAddHeaderFooter = { _, _, _, _, _, _, _ -> },
                    onCompressPdf = { _, _, _, _ -> },
                    onReducePdfSize = { _, _, _, _, _, _ -> },
                    onRepairPdf = { _, _, _ -> },
                    onRepairExternalPdfUri = { _, _, _ -> },
                    onExportPdfToSaf = { _, _ -> },
                    onExportLocalFileToSaf = { _, _, _ -> },
                    onExportTextToSaf = { _, _ -> },
                    onExportImagesToSafTree = { _, _, _ -> },
                    onShareLocalFile = { _, _, _ -> }
                )
            }
        }

        composeRule.onNodeWithTag("pdf_tools_list").performScrollToNode(hasTestTag(PdfToolId.TEXT_TO_PDF.testTag))
        composeRule.onNodeWithTag(PdfToolId.TEXT_TO_PDF.testTag).performClick()
        composeRule.onNodeWithTag("text_to_pdf_title_input").performTextReplacement("Hello_TextPdf")
        composeRule.onNodeWithTag("text_to_pdf_body_input").performTextReplacement("Sample text paragraph")
        composeRule.onNodeWithTag("text_to_pdf_confirm_btn").performClick()
        composeRule.waitForIdle()

        assertEquals("Hello_TextPdf", lastGeneratedTitle)
        assertEquals("Sample text paragraph", lastGeneratedText)

        composeRule.onNodeWithTag("pdf_tools_list").performScrollToNode(hasTestTag("pdf_tool_result_card"))
        composeRule.onNodeWithTag("pdf_tool_result_card").assertIsDisplayed()
        composeRule.onNodeWithTag("result_open_pdf_btn").assertIsDisplayed()
        composeRule.onNodeWithTag("result_save_pdf_saf_btn").assertIsDisplayed()
        composeRule.onNodeWithTag("result_share_pdf_btn").assertIsDisplayed()
        composeRule.onNodeWithTag("result_open_pdf_btn").performClick()
        assertEquals(42L, createdDocIdOpened)
    }

    @Test
    fun `ocr extractor and sign pdf screens expose Select PDF from Device buttons`() {
        composeRule.setContent {
            DocuScanTheme {
                OcrExtractorScreen(
                    documents = emptyList(),
                    activeSessionPages = emptyList(),
                    initialDocumentId = -1L,
                    uiState = OcrUiState(),
                    createCameraTempFile = { File("/tmp/ocr_cam.jpg") },
                    onInitializeDocument = {},
                    onSelectDocument = {},
                    onImportImageUri = {},
                    onImportPdfUri = {},
                    onCapturedImageFile = {},
                    onSelectScanSession = {},
                    onSelectScript = {},
                    onUpdatePdfPassword = {},
                    onRunExtraction = {},
                    onUpdateEditableText = {},
                    onUpdateSearchQuery = {},
                    onSaveNotesToDocument = {},
                    onSaveAsTxtToUri = {},
                    onClearStatusMessage = {},
                    onScanFirstDocument = {},
                    onBack = {}
                )
            }
        }

        composeRule.onNodeWithTag("ocr_pick_image_btn").performScrollTo().assertIsDisplayed()
        composeRule.onNodeWithTag("ocr_pick_pdf_btn").performScrollTo().assertIsDisplayed()
    }

    @Test
    fun `sign pdf screen exposes Select from Device when documents exist and when empty`() {
        val sampleDoc = DocumentItem(id = 1L, title = "Agreement", filePath = "/tmp/agreement.pdf", pageCount = 1)
        val sampleSig = SignatureItem(id = 1L, name = "MySig", filePath = "/tmp/sig.png")

        composeRule.setContent {
            DocuScanTheme {
                SignPdfScreen(
                    initialDocumentId = 1L,
                    initialSignatureId = 1L,
                    pdfDocuments = listOf(sampleDoc),
                    savedSignatures = listOf(sampleSig),
                    uiState = SignPdfUiState(selectedDocument = sampleDoc, selectedSignatureId = 1L),
                    statusMessage = null,
                    onInitSession = { _, _ -> },
                    onSelectDocument = {},
                    onImportPdfFromDevice = {},
                    onUnlockPassword = {},
                    onSelectSignature = {},
                    onSelectPage = {},
                    onUpdatePlacement = { _, _, _ -> },
                    onApplySignature = { _, _ -> },
                    onDrawNewSignature = {},
                    onClearMessage = {},
                    onSignedPdfCreated = {},
                    onBack = {}
                )
            }
        }

        composeRule.onNodeWithTag("sign_pdf_select_device_btn").performScrollTo().assertIsDisplayed()
    }

    private class StateHolder(initial: PdfToolsUiState) {
        var state by mutableStateOf(initial)
    }
}
