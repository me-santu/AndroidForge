package com.example

import android.app.Application
import android.content.Context
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Color
import android.net.Uri
import androidx.room.Room
import androidx.test.core.app.ApplicationProvider
import com.example.database.DocuScanDatabase
import com.example.domain.model.DocumentItem
import com.example.domain.model.PageNumberFormat
import com.example.domain.model.PageNumberPosition
import com.example.domain.model.PdfCompressionLevel
import com.example.domain.model.PdfCreationOptions
import com.example.domain.model.PdfImageFormat
import com.example.domain.model.PdfOrientation
import com.example.domain.model.PdfPageSize
import com.example.domain.model.ScanFilter
import com.example.domain.model.ScanPage
import com.example.domain.model.ScanQuality
import com.example.pdf.PdfAdvancedEngine
import com.example.pdf.PdfConversionEngine
import com.example.pdf.PdfGenerator
import com.example.pdf.PdfRendererHelper
import com.example.repository.LocalDocumentRepository
import com.example.ui.viewmodel.PdfToolResult
import com.example.ui.viewmodel.PdfToolsViewModel
import com.example.util.LocalFileManager
import com.tom_roush.pdfbox.android.PDFBoxResourceLoader
import com.tom_roush.pdfbox.pdmodel.PDDocument
import com.tom_roush.pdfbox.pdmodel.PDDocumentInformation
import com.tom_roush.pdfbox.pdmodel.PDPage
import com.tom_roush.pdfbox.pdmodel.PDPageContentStream
import com.tom_roush.pdfbox.pdmodel.font.PDType1Font
import com.tom_roush.pdfbox.text.PDFTextStripper
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.ExperimentalCoroutinesApi
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.test.StandardTestDispatcher
import kotlinx.coroutines.test.advanceUntilIdle
import kotlinx.coroutines.test.resetMain
import kotlinx.coroutines.test.runTest
import kotlinx.coroutines.test.setMain
import org.junit.After
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertTrue
import org.junit.Before
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.Shadows
import org.robolectric.annotation.Config
import java.io.File
import java.io.FileOutputStream
import java.util.zip.ZipFile

@OptIn(ExperimentalCoroutinesApi::class)
@RunWith(RobolectricTestRunner::class)
@Config(sdk = [36])
class PdfToolsCompleteRobolectricTest {

    private lateinit var context: Context
    private lateinit var fileManager: LocalFileManager
    private lateinit var pdfGenerator: PdfGenerator
    private lateinit var pdfRendererHelper: PdfRendererHelper
    private lateinit var pdfAdvancedEngine: PdfAdvancedEngine
    private lateinit var pdfConversionEngine: PdfConversionEngine
    private lateinit var db: DocuScanDatabase
    private lateinit var repository: LocalDocumentRepository
    private lateinit var viewModel: PdfToolsViewModel
    private val testDispatcher = StandardTestDispatcher()

    @Before
    fun setup() {
        runCatching {
            val cacheField = androidx.core.content.FileProvider::class.java.getDeclaredField("sCache")
            cacheField.isAccessible = true
            (cacheField.get(null) as? MutableMap<*, *>)?.clear()
        }
        Dispatchers.setMain(testDispatcher)
        context = ApplicationProvider.getApplicationContext()
        if (!PDFBoxResourceLoader.isReady()) {
            PDFBoxResourceLoader.init(context)
        }
        fileManager = LocalFileManager(context, ioDispatcher = testDispatcher)
        pdfGenerator = PdfGenerator(context = context, ioDispatcher = testDispatcher)
        pdfRendererHelper = PdfRendererHelper(context = context, ioDispatcher = testDispatcher)
        pdfAdvancedEngine = PdfAdvancedEngine(context = context, ioDispatcher = testDispatcher)
        pdfConversionEngine = PdfConversionEngine(
            context = context,
            rendererHelper = pdfRendererHelper,
            ioDispatcher = testDispatcher
        )
        db = Room.databaseBuilder(context, DocuScanDatabase::class.java, "pdf_tools_complete_test.db")
            .allowMainThreadQueries()
            .setQueryExecutor { it.run() }
            .setTransactionExecutor { it.run() }
            .build()
        repository = LocalDocumentRepository(
            documentDao = db.documentDao(),
            folderDao = db.folderDao(),
            signatureDao = db.signatureDao(),
            fileManager = fileManager,
            pdfGenerator = pdfGenerator,
            deletedDocumentDao = db.deletedDocumentDao(),
            ioDispatcher = testDispatcher,
            pdfAdvancedEngine = pdfAdvancedEngine,
            pdfConversionEngine = pdfConversionEngine
        )
        viewModel = PdfToolsViewModel(
            documentRepository = repository,
            pdfRendererHelper = pdfRendererHelper,
            fileManager = fileManager
        )
    }

    @After
    fun tearDown() {
        db.close()
        context.deleteDatabase("pdf_tools_complete_test.db")
        fileManager.scansDir.deleteRecursively()
        fileManager.documentsDir.deleteRecursively()
        fileManager.appCacheDir.listFiles()?.forEach { it.deleteRecursively() }
        Dispatchers.resetMain()
    }

    @Test
    fun `management tools - validate import, rename, duplicate, inspect info, share and delete`() =
        runTest(testDispatcher) {
            val workDir = File(context.cacheDir, "mgmt_work").apply { mkdirs() }
            val samplePdf = createRichTextPdf(
                file = File(workDir, "contract.pdf"),
                pages = listOf("Page One Content", "Page Two Content"),
                author = "DocuScan Legal",
                title = "Master Service Agreement"
            )
            val invalidFile = File(workDir, "not_a_pdf.bin").apply { writeText("NOT_PDF_BYTES_12345") }

            // 1. Corrupt non-PDF rejected cleanly on import
            val badImport = repository.importExternalPdfUri(Uri.fromFile(invalidFile))
            assertTrue(badImport.isFailure)

            // 2. Open/Import valid PDF
            val doc = repository.importExternalPdfUri(Uri.fromFile(samplePdf)).getOrThrow()
            assertEquals(2, doc.pageCount)
            assertFalse(doc.isPasswordProtected)

            // 3. Rename PDF
            viewModel.renamePdf(doc.id, "Contract_Renamed")
            advanceUntilIdle()
            assertEquals("Contract_Renamed", repository.getDocumentById(doc.id)?.title)
            assertTrue(viewModel.uiState.value.result is PdfToolResult.ActionCompleted)

            // 4. Duplicate PDF
            viewModel.duplicatePdf(doc.id, "Contract_Copy")
            advanceUntilIdle()
            val dupResult = viewModel.uiState.value.result as PdfToolResult.PdfCreated
            assertEquals("Contract_Copy", dupResult.document.title)
            assertEquals(2, dupResult.document.pageCount)
            assertTrue(dupResult.document.filePath != doc.filePath)

            // 5. PDF Information
            viewModel.inspectPdfInfo(doc.id, null)
            advanceUntilIdle()
            val infoRes = viewModel.uiState.value.result as PdfToolResult.InfoInspected
            assertEquals(2, infoRes.info.pageCount)
            assertEquals("DocuScan Legal", infoRes.info.author)
            assertEquals("Master Service Agreement", infoRes.info.title)
            assertFalse(infoRes.info.isEncrypted)

            // 6. Share PDF
            assertTrue("Duplicate file must exist", File(dupResult.document.filePath).exists())
            viewModel.sharePdf(dupResult.document)
            assertEquals(
                "Unexpected sharePdf error: ${viewModel.uiState.value.errorMessage}",
                null,
                viewModel.uiState.value.errorMessage
            )
            val chooser = Shadows.shadowOf(context as Application).nextStartedActivity
            assertNotNull("Expected ACTION_CHOOSER intent from sharePdf", chooser)
            assertEquals(Intent.ACTION_CHOOSER, chooser.action)

            // 7. Delete PDF (trash + permanent)
            val dupPath = dupResult.document.filePath
            viewModel.deletePdf(dupResult.document.id, permanently = true)
            advanceUntilIdle()
            assertFalse(File(dupPath).exists())
            assertTrue(File(doc.filePath).exists()) // Original intact
        }

    @Test
    fun `editing tools - reorder, rearrange, duplicate pages, merge, split, extract, rotate, delete`() =
        runTest(testDispatcher) {
            val workDir = File(context.cacheDir, "edit_work").apply { mkdirs() }
            val pdfA = createRichTextPdf(
                File(workDir, "alpha.pdf"),
                listOf("ALPHA_1", "ALPHA_2", "ALPHA_3")
            )
            val pdfB = createRichTextPdf(
                File(workDir, "beta.pdf"),
                listOf("BETA_1", "BETA_2")
            )
            val docA = repository.importExternalPdfUri(Uri.fromFile(pdfA)).getOrThrow()
            val docB = repository.importExternalPdfUri(Uri.fromFile(pdfB)).getOrThrow()

            // Reorder / Rearrange [3, 1, 2]
            viewModel.reorderPages(docA.id, "Alpha_Reordered", listOf(3, 1, 2), "Reorder Pages", null)
            advanceUntilIdle()
            val reordered = (viewModel.uiState.value.result as PdfToolResult.PdfCreated).document
            assertEquals(listOf("ALPHA_3", "ALPHA_1", "ALPHA_2"), readPageTexts(File(reordered.filePath)))

            // Duplicate Page 1 adjacent -> [ALPHA_1, ALPHA_1, ALPHA_2, ALPHA_3]
            viewModel.duplicatePages(docA.id, "Alpha_DupAdj", listOf(1), insertAdjacent = true, null)
            advanceUntilIdle()
            val dupAdj = (viewModel.uiState.value.result as PdfToolResult.PdfCreated).document
            assertEquals(
                listOf("ALPHA_1", "ALPHA_1", "ALPHA_2", "ALPHA_3"),
                readPageTexts(File(dupAdj.filePath))
            )

            // Merge A + B -> 5 pages
            viewModel.mergePdfs("Merged_AB", listOf(docA.id, docB.id))
            advanceUntilIdle()
            val merged = (viewModel.uiState.value.result as PdfToolResult.PdfCreated).document
            assertEquals(5, merged.pageCount)

            // Split 2..4 -> 3 pages
            viewModel.splitPdf(merged.id, "Split_2_4", 2, 4, null)
            advanceUntilIdle()
            val split = (viewModel.uiState.value.result as PdfToolResult.PdfCreated).document
            assertEquals(listOf("ALPHA_2", "ALPHA_3", "BETA_1"), readPageTexts(File(split.filePath)))

            // Extract 1, 5 -> 2 pages
            viewModel.extractPages(merged.id, "Extract_1_5", listOf(1, 5), null)
            advanceUntilIdle()
            val extracted = (viewModel.uiState.value.result as PdfToolResult.PdfCreated).document
            assertEquals(listOf("ALPHA_1", "BETA_2"), readPageTexts(File(extracted.filePath)))

            // Rotate page 2 by 180°
            viewModel.rotatePages(extracted.id, "Rotated_P2", setOf(2), 180, null)
            advanceUntilIdle()
            val rotated = (viewModel.uiState.value.result as PdfToolResult.PdfCreated).document
            PDDocument.load(File(rotated.filePath)).use { pd ->
                assertEquals(0, pd.getPage(0).rotation)
                assertEquals(180, pd.getPage(1).rotation)
            }

            // Delete page 1 -> [BETA_2]
            viewModel.deletePages(extracted.id, "Trimmed_P1", setOf(1), null)
            advanceUntilIdle()
            val trimmed = (viewModel.uiState.value.result as PdfToolResult.PdfCreated).document
            assertEquals(listOf("BETA_2"), readPageTexts(File(trimmed.filePath)))
        }

    @Test
    fun `conversion tools - text to pdf, pdf to text, pdf to docx, pdf to jpg and png`() =
        runTest(testDispatcher) {
            // 1. Text to PDF (multi-page landscape)
            val longBody = (1..75).joinToString("\n") { idx ->
                "Paragraph $idx: DocuScan converts plain text into clean multi-page PDF files."
            }
            viewModel.createPdfFromText(
                title = "Notes_Export",
                text = longBody,
                pageSize = PdfPageSize.LETTER,
                orientation = PdfOrientation.PORTRAIT,
                marginPt = 36f,
                fontSizePt = 12f,
                includePageNumbers = true,
                password = ""
            )
            advanceUntilIdle()
            val textPdfDoc = (viewModel.uiState.value.result as PdfToolResult.PdfCreated).document
            assertTrue("Expected multi-page text PDF", textPdfDoc.pageCount >= 2)

            // 2. PDF to Text
            viewModel.extractTextFromPdf(textPdfDoc.id, 1, textPdfDoc.pageCount, null)
            advanceUntilIdle()
            val txtRes = viewModel.uiState.value.result as PdfToolResult.TextExtracted
            assertTrue(txtRes.extraction.hasEmbeddedText)
            assertTrue(txtRes.extraction.fullText.contains("Paragraph 1:"))
            assertTrue(txtRes.extraction.fullText.contains("Paragraph 75:"))

            // Export TXT via SAF
            val safTxtOut = File(context.cacheDir, "out_extracted.txt")
            viewModel.exportTextToSafUri(txtRes.extraction.fullText, Uri.fromFile(safTxtOut))
            advanceUntilIdle()
            assertTrue(safTxtOut.exists() && safTxtOut.readText().contains("Paragraph 1:"))

            // 3. PDF to Word (.docx)
            viewModel.convertPdfToDocx(textPdfDoc.id, "Notes_Word", includePageImagesFallback = true, password = null)
            advanceUntilIdle()
            val docxRes = viewModel.uiState.value.result as PdfToolResult.DocxConverted
            val docxFile = File(docxRes.conversion.outputFilePath)
            assertTrue(docxFile.exists() && docxFile.length() > 0L)
            assertEquals(0, docxRes.conversion.imageFallbackPages)
            ZipFile(docxFile).use { zip ->
                assertNotNull(zip.getEntry("[Content_Types].xml"))
                assertNotNull(zip.getEntry("_rels/.rels"))
                assertNotNull(zip.getEntry("word/_rels/document.xml.rels"))
                assertNotNull(zip.getEntry("word/styles.xml"))
                val docXml = zip.getInputStream(zip.getEntry("word/document.xml")).bufferedReader().readText()
                assertTrue(docXml.contains("Paragraph 1:"))
                assertTrue(docXml.contains("<w:br w:type=\"page\"/>"))
            }

            // Also verify DOCX image fallback for scanned image-only PDF
            val imgFile = createNoiseJpeg(File(context.cacheDir, "scan_p1.jpg"), 400, 600)
            val scanPdf = repository.createPdfDocument(
                title = "Scanned_Only",
                pages = listOf(ScanPage("p1", imgFile.absolutePath, ScanFilter.ORIGINAL, 0, 0)),
                folderId = null,
                options = PdfCreationOptions(pageSize = PdfPageSize.A4, quality = ScanQuality.STANDARD)
            ).getOrThrow()
            viewModel.convertPdfToDocx(scanPdf.id, "Scanned_Word", includePageImagesFallback = true, password = null)
            advanceUntilIdle()
            val scannedDocxRes = viewModel.uiState.value.result as PdfToolResult.DocxConverted
            assertEquals(1, scannedDocxRes.conversion.imageFallbackPages)
            ZipFile(File(scannedDocxRes.conversion.outputFilePath)).use { zip ->
                assertNotNull(zip.getEntry("word/media/page_1.jpg"))
            }

            // 4. PDF to JPG & PDF to PNG
            viewModel.exportPdfToImages(
                sourceId = scanPdf.id,
                format = PdfImageFormat.JPG,
                pageIndicesOneBased = listOf(1),
                quality = 90,
                saveToLibrary = true,
                password = null
            )
            advanceUntilIdle()
            val jpgExport = (viewModel.uiState.value.result as PdfToolResult.ImagesExported).export
            assertEquals(1, jpgExport.imageFilePaths.size)
            assertTrue(jpgExport.imageFilePaths.first().endsWith(".jpg"))
            assertNotNull(BitmapFactory.decodeFile(jpgExport.imageFilePaths.first()))
            assertEquals(1, jpgExport.savedDocumentIds.size)

            viewModel.exportPdfToImages(
                sourceId = scanPdf.id,
                format = PdfImageFormat.PNG,
                pageIndicesOneBased = listOf(1),
                quality = 100,
                saveToLibrary = false,
                password = null
            )
            advanceUntilIdle()
            val pngExport = (viewModel.uiState.value.result as PdfToolResult.ImagesExported).export
            assertEquals(1, pngExport.imageFilePaths.size)
            assertTrue(pngExport.imageFilePaths.first().endsWith(".png"))
            assertNotNull(BitmapFactory.decodeFile(pngExport.imageFilePaths.first()))
        }

    @Test
    fun `security tools - protect, unlock, add and remove watermark, page numbers, header and footer`() =
        runTest(testDispatcher) {
            val workDir = File(context.cacheDir, "sec_work").apply { mkdirs() }
            val plainPdf = createRichTextPdf(
                File(workDir, "policy.pdf"),
                listOf("Policy Clause Alpha", "Policy Clause Beta")
            )
            val doc = repository.importExternalPdfUri(Uri.fromFile(plainPdf)).getOrThrow()

            // 1. Protect PDF with AES-128 password
            viewModel.protectPdf(doc.id, "Policy_Locked", "pass99", null)
            advanceUntilIdle()
            val locked = (viewModel.uiState.value.result as PdfToolResult.PdfCreated).document
            assertTrue(locked.isPasswordProtected)

            // Unlock with WRONG password fails honestly
            viewModel.unlockPdf(locked.id, "Policy_BadUnlock", "wrongpass")
            advanceUntilIdle()
            assertNotNull(viewModel.uiState.value.errorMessage)
            viewModel.clearError()

            // Merge rejects locked PDF cleanly
            viewModel.mergePdfs("BadMerge", listOf(doc.id, locked.id))
            advanceUntilIdle()
            assertTrue(viewModel.uiState.value.errorMessage!!.contains("password protected", ignoreCase = true))
            viewModel.clearError()

            // Unlock with KNOWN password succeeds cleanly
            viewModel.unlockPdf(locked.id, "Policy_Unlocked", "pass99")
            advanceUntilIdle()
            val unlocked = (viewModel.uiState.value.result as PdfToolResult.PdfCreated).document
            assertFalse(unlocked.isPasswordProtected)
            assertEquals(2, unlocked.pageCount)

            // 2. Add Watermark & Remove Watermark
            viewModel.watermarkPdf(doc.id, "Policy_Watermarked", "CONFIDENTIAL", null)
            advanceUntilIdle()
            val wmDoc = (viewModel.uiState.value.result as PdfToolResult.PdfCreated).document
            assertTrue(readPageTexts(File(wmDoc.filePath)).all { it.contains("CONFIDENTIAL") })

            viewModel.removeWatermark(wmDoc.id, "Policy_Clean", "CONFIDENTIAL", null)
            advanceUntilIdle()
            val cleanedDoc = (viewModel.uiState.value.result as PdfToolResult.PdfCreated).document
            val cleanedTexts = readPageTexts(File(cleanedDoc.filePath))
            assertTrue(cleanedTexts.none { it.contains("CONFIDENTIAL") })
            assertTrue(cleanedTexts.first().contains("Policy Clause Alpha"))

            // Attempting watermark removal on plain non-watermarked PDF explains honest limitation
            viewModel.removeWatermark(doc.id, "Policy_NoWm", null, null)
            advanceUntilIdle()
            assertTrue(viewModel.uiState.value.errorMessage!!.contains("watermark", ignoreCase = true))
            viewModel.clearError()

            // 3. Add Page Numbers
            viewModel.addPageNumbers(
                sourceId = doc.id,
                title = "Policy_Numbered",
                position = PageNumberPosition.BOTTOM_CENTER,
                format = PageNumberFormat.PAGE_X_OF_N,
                startNumber = 1,
                password = null
            )
            advanceUntilIdle()
            val numbered = (viewModel.uiState.value.result as PdfToolResult.PdfCreated).document
            val numberedTexts = readPageTexts(File(numbered.filePath))
            assertTrue(numberedTexts[0].contains("Page 1 of 2"))
            assertTrue(numberedTexts[1].contains("Page 2 of 2"))

            // 4. Add Header & Footer
            viewModel.addHeaderFooter(
                sourceId = doc.id,
                title = "Policy_HeaderFooter",
                headerText = "ACME Internal",
                footerText = "Strictly Private",
                includeDate = true,
                fontSizePt = 10f,
                password = null
            )
            advanceUntilIdle()
            val hfDoc = (viewModel.uiState.value.result as PdfToolResult.PdfCreated).document
            val hfTexts = readPageTexts(File(hfDoc.filePath))
            assertTrue(hfTexts[0].contains("ACME Internal"))
            assertTrue(hfTexts[0].contains("Strictly Private"))
        }

    @Test
    fun `optimization tools - compress pdf, reduce pdf size, and repair damaged pdf`() =
        runTest(testDispatcher) {
            val workDir = File(context.cacheDir, "opt_work").apply { mkdirs() }
            val noisy1 = createNoiseJpeg(File(workDir, "n1.jpg"), 1800, 2400)
            val noisy2 = createNoiseJpeg(File(workDir, "n2.jpg"), 1800, 2400)
            val original = repository.createPdfDocument(
                title = "Huge_Scan",
                pages = listOf(
                    ScanPage("1", noisy1.absolutePath, ScanFilter.ORIGINAL, 0, 0),
                    ScanPage("2", noisy2.absolutePath, ScanFilter.ORIGINAL, 0, 1)
                ),
                folderId = null,
                options = PdfCreationOptions(pageSize = PdfPageSize.A4, quality = ScanQuality.ULTRA)
            ).getOrThrow()

            // 1. Compress PDF
            viewModel.compressPdf(original.id, "Huge_Compressed", PdfCompressionLevel.HIGH, null)
            advanceUntilIdle()
            val compressed = (viewModel.uiState.value.result as PdfToolResult.PdfCreated).document
            assertTrue(compressed.sizeBytes < original.sizeBytes)

            // 2. Reduce PDF Size (custom resolution & quality + metadata stripping)
            viewModel.reducePdfSize(
                sourceId = original.id,
                title = "Huge_Reduced",
                maxImageDimension = 900,
                jpegQuality = 0.45f,
                stripMetadata = true,
                password = null
            )
            advanceUntilIdle()
            val reduced = (viewModel.uiState.value.result as PdfToolResult.PdfCreated).document
            assertTrue(reduced.sizeBytes < original.sizeBytes)

            // 3. Repair PDF with corrupt junk header bytes via external SAF URI
            val validBytes = createRichTextPdf(
                File(workDir, "valid_src.pdf"),
                listOf("Recovered Page 1", "Recovered Page 2")
            ).readBytes()
            val damagedFile = File(workDir, "damaged_prefix.pdf").apply {
                FileOutputStream(this).use { out ->
                    out.write("GARBAGE_CORRUPT_HEADER_00000".toByteArray(Charsets.US_ASCII))
                    out.write(validBytes)
                }
            }
            viewModel.repairExternalPdfUri(Uri.fromFile(damagedFile), "Fixed_External", null)
            advanceUntilIdle()
            val repaired = (viewModel.uiState.value.result as PdfToolResult.PdfCreated).document
            assertEquals(2, repaired.pageCount)
            assertEquals(
                listOf("Recovered Page 1", "Recovered Page 2"),
                readPageTexts(File(repaired.filePath))
            )
        }

    private fun readPageTexts(file: File): List<String> =
        PDDocument.load(file).use { doc ->
            val stripper = PDFTextStripper()
            (1..doc.numberOfPages).map { p ->
                stripper.startPage = p
                stripper.endPage = p
                stripper.getText(doc).trim()
            }
        }

    private fun createRichTextPdf(
        file: File,
        pages: List<String>,
        author: String = "",
        title: String = ""
    ): File {
        PDDocument().use { doc ->
            if (author.isNotBlank() || title.isNotBlank()) {
                doc.documentInformation = PDDocumentInformation().apply {
                    this.author = author
                    this.title = title
                }
            }
            pages.forEach { text ->
                val page = PDPage()
                doc.addPage(page)
                PDPageContentStream(doc, page).use { stream ->
                    stream.beginText()
                    stream.setFont(PDType1Font.HELVETICA, 14f)
                    stream.newLineAtOffset(64f, 700f)
                    stream.showText(text)
                    stream.endText()
                }
            }
            doc.save(file)
        }
        return file
    }

    private fun createNoiseJpeg(file: File, width: Int, height: Int): File {
        val bmp = Bitmap.createBitmap(width, height, Bitmap.Config.ARGB_8888)
        val pixels = IntArray(width * height)
        var seed = 1337
        for (i in pixels.indices) {
            seed = seed * 1664525 + 1013904223
            pixels[i] = Color.rgb((seed ushr 16) and 0xFF, (seed ushr 8) and 0xFF, seed and 0xFF)
        }
        bmp.setPixels(pixels, 0, width, 0, 0, width, height)
        FileOutputStream(file).use { out -> bmp.compress(Bitmap.CompressFormat.JPEG, 98, out) }
        bmp.recycle()
        return file
    }
}
