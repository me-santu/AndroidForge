package com.example

import android.app.Activity
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.Color
import android.net.Uri
import androidx.compose.ui.test.junit4.createComposeRule
import androidx.compose.ui.test.onNodeWithTag
import androidx.compose.ui.test.performClick
import androidx.room.Room
import androidx.test.core.app.ApplicationProvider
import com.example.database.DocuScanDatabase
import com.example.domain.model.AppLanguage
import com.example.domain.model.PdfPageSize
import com.example.domain.model.ScanQuality
import com.example.domain.model.StorageSummary
import com.example.domain.model.ThemeMode
import com.example.domain.model.UserPreferences
import com.example.domain.repository.SettingsRepository
import com.example.pdf.PdfGenerator
import com.example.pdf.PdfRendererHelper
import com.example.repository.LocalDocumentRepository
import com.example.scanner.DocumentScannerGateway
import com.example.scanner.MlKitDocumentScannerManager
import com.example.scanner.ParsedScanResult
import com.example.scanner.ScanSessionManager
import com.example.scanner.ScannerActivityOutcome
import com.example.scanner.ScannerStartOutcome
import com.example.ui.screens.HomeScreen
import com.example.ui.theme.DocuScanTheme
import com.example.ui.viewmodel.MlKitScanUiState
import com.example.ui.viewmodel.ScannerViewModel
import com.example.util.LocalFileManager
import com.google.mlkit.vision.documentscanner.GmsDocumentScannerOptions
import com.tom_roush.pdfbox.android.PDFBoxResourceLoader
import com.tom_roush.pdfbox.pdmodel.PDDocument
import com.tom_roush.pdfbox.pdmodel.PDPage
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.ExperimentalCoroutinesApi
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.test.StandardTestDispatcher
import kotlinx.coroutines.test.advanceUntilIdle
import kotlinx.coroutines.test.resetMain
import kotlinx.coroutines.test.runTest
import kotlinx.coroutines.test.setMain
import org.junit.After
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertTrue
import org.junit.Before
import org.junit.Rule
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.Robolectric
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config
import java.io.File
import java.io.FileOutputStream

@OptIn(ExperimentalCoroutinesApi::class)
@RunWith(RobolectricTestRunner::class)
@Config(sdk = [36])
class DocumentScannerRobolectricTest {

    @get:Rule
    val composeTestRule = createComposeRule()

    private lateinit var context: Context
    private lateinit var fileManager: LocalFileManager
    private lateinit var pdfGenerator: PdfGenerator
    private lateinit var pdfRendererHelper: PdfRendererHelper
    private lateinit var db: DocuScanDatabase
    private lateinit var repository: LocalDocumentRepository
    private lateinit var settingsRepository: SettingsRepository
    private val testDispatcher = StandardTestDispatcher()

    @Before
    fun setup() {
        Dispatchers.setMain(testDispatcher)
        context = ApplicationProvider.getApplicationContext()
        if (!PDFBoxResourceLoader.isReady()) {
            PDFBoxResourceLoader.init(context)
        }
        fileManager = LocalFileManager(context, ioDispatcher = testDispatcher)
        pdfGenerator = PdfGenerator(context = context, ioDispatcher = testDispatcher)
        pdfRendererHelper = PdfRendererHelper(context = context, ioDispatcher = testDispatcher)
        db = Room.databaseBuilder(context, DocuScanDatabase::class.java, "scanner_test.db")
            .allowMainThreadQueries()
            .setQueryExecutor { it.run() }
            .setTransactionExecutor { it.run() }
            .build()
        repository = LocalDocumentRepository(
            documentDao = db.documentDao(),
            folderDao = db.folderDao(),
            signatureDao = db.signatureDao(),
            fileManager = fileManager,
            pdfGenerator = pdfGenerator,
            deletedDocumentDao = db.deletedDocumentDao(),
            ioDispatcher = testDispatcher
        )
        settingsRepository = FakeSettingsRepository()
    }

    @After
    fun tearDown() {
        db.close()
        context.deleteDatabase("scanner_test.db")
        fileManager.scansDir.deleteRecursively()
        fileManager.documentsDir.deleteRecursively()
        Dispatchers.resetMain()
    }

    @Test
    fun `mlkit options configure full mode gallery import multi page jpeg and pdf`() {
        val manager = MlKitDocumentScannerManager(context)
        val actual = manager.buildDefaultOptions(pageLimit = 50)
        val expected = GmsDocumentScannerOptions.Builder()
            .setScannerMode(GmsDocumentScannerOptions.SCANNER_MODE_FULL)
            .setGalleryImportAllowed(true)
            .setPageLimit(50)
            .setResultFormats(
                GmsDocumentScannerOptions.RESULT_FORMAT_JPEG,
                GmsDocumentScannerOptions.RESULT_FORMAT_PDF
            )
            .build()

        assertEquals(expected, actual)
    }

    @Test
    fun `home scan button triggers scan launch`() {
        var scanClicked = false
        composeTestRule.setContent {
            DocuScanTheme {
                HomeScreen(
                    searchQuery = "",
                    recentDocuments = emptyList(),
                    storageSummary = StorageSummary(),
                    activeSessionPageCount = 0,
                    onSearchQueryChange = {},
                    onScanDocument = { scanClicked = true },
                    onImportImageUri = {},
                    onCreatePdf = {},
                    onExtractText = {},
                    onOpenIdScanner = {},
                    onOpenSignatureCreator = {},
                    onOpenPdfTools = {},
                    onOpenRecycleBin = {},
                    onOpenBackup = {},
                    onOpenAllDocuments = {},
                    onOpenDocument = {}
                )
            }
        }

        composeTestRule.onNodeWithTag("home_action_scan").performClick()
        composeTestRule.waitForIdle()
        assertTrue(scanClicked)
    }

    @Test
    fun `scan cancellation sets Cancelled state and creates no document`() = runTest(testDispatcher) {
        val fakeGateway = FakeScannerGateway(
            activityOutcome = ScannerActivityOutcome.Cancelled
        )
        val vm = createViewModel(fakeGateway)
        var pageManagerOpened = false

        vm.handleMlKitActivityResult(
            resultCode = Activity.RESULT_CANCELED,
            data = null,
            appendToCurrentSession = false,
            onCompletedOpenPageManager = { pageManagerOpened = true }
        )
        advanceUntilIdle()

        assertFalse(pageManagerOpened)
        assertTrue(vm.mlKitScanUiState.value is MlKitScanUiState.Cancelled)
        assertTrue(repository.observeActiveDocuments().first().isEmpty())
    }

    @Test
    fun `play services unavailable produces meaningful error with camera fallback`() = runTest(testDispatcher) {
        val activity = Robolectric.buildActivity(Activity::class.java).create().get()
        val fakeGateway = FakeScannerGateway(
            startOutcome = ScannerStartOutcome.Error(
                message = "Google Play Services is unavailable on this device.",
                isPlayServicesUnavailable = true
            )
        )
        val vm = createViewModel(fakeGateway)
        var launchedIntentSender = false

        vm.prepareMlKitScan(activity) { launchedIntentSender = true }
        advanceUntilIdle()

        assertFalse(launchedIntentSender)
        val state = vm.mlKitScanUiState.value as? MlKitScanUiState.Error
        assertNotNull(state)
        assertTrue(state!!.canFallbackToCamera)
        assertTrue(state.message.contains("Play Services"))
    }

    @Test
    fun `multi page jpeg and pdf retrieval stores permanent copies preserves order and persists after restart`() = runTest(testDispatcher) {
        val tempDir = File(context.cacheDir, "mlkit_sim").apply { mkdirs() }
        val srcPage1 = createTempJpeg(File(tempDir, "p1.jpg"), Color.RED)
        val srcPage2 = createTempJpeg(File(tempDir, "p2.jpg"), Color.GREEN)
        val srcPage3 = createTempJpeg(File(tempDir, "p3.jpg"), Color.BLUE)
        val srcPdf = createTempRealPdf(File(tempDir, "scanned.pdf"), 3)

        val fakeGateway = FakeScannerGateway(
            activityOutcome = ScannerActivityOutcome.Success(
                ParsedScanResult(
                    pageImageUris = listOf(Uri.fromFile(srcPage1), Uri.fromFile(srcPage2), Uri.fromFile(srcPage3)),
                    pdfUri = Uri.fromFile(srcPdf),
                    pdfPageCount = 3
                )
            )
        )

        val vm = createViewModel(fakeGateway)
        var pageManagerOpened = false

        vm.handleMlKitActivityResult(
            resultCode = Activity.RESULT_OK,
            data = Intent(),
            appendToCurrentSession = false,
            onCompletedOpenPageManager = { pageManagerOpened = true }
        )
        advanceUntilIdle()

        assertTrue(pageManagerOpened)
        val pages = vm.sessionPages.value
        assertEquals(3, pages.size)
        assertEquals(listOf(0, 1, 2), pages.map { it.orderIndex })

        srcPage1.delete()
        srcPage2.delete()
        srcPage3.delete()
        srcPdf.delete()

        pages.forEach { page ->
            val copied = File(page.sourcePath)
            assertTrue(copied.exists())
            assertTrue(copied.length() > 0L)
            assertTrue(copied.absolutePath.startsWith(fileManager.scansDir.absolutePath))
        }

        val activeDocs = repository.observeActiveDocuments().first()
        assertEquals(1, activeDocs.size)
        val savedDoc = activeDocs.first()
        assertEquals(3, savedDoc.pageCount)
        assertTrue(savedDoc.sizeBytes > 0L)
        assertTrue(File(savedDoc.filePath).exists())

        db.close()
        val restartedDb = Room.databaseBuilder(context, DocuScanDatabase::class.java, "scanner_test.db")
            .allowMainThreadQueries()
            .setQueryExecutor { it.run() }
            .setTransactionExecutor { it.run() }
            .build()
        val restartedRepo = LocalDocumentRepository(
            documentDao = restartedDb.documentDao(),
            folderDao = restartedDb.folderDao(),
            signatureDao = restartedDb.signatureDao(),
            fileManager = fileManager,
            pdfGenerator = pdfGenerator,
            deletedDocumentDao = restartedDb.deletedDocumentDao(),
            ioDispatcher = testDispatcher
        )

        val persistedDocs = restartedRepo.observeActiveDocuments().first()
        assertEquals(1, persistedDocs.size)
        assertEquals(savedDoc.id, persistedDocs.first().id)
        assertEquals(3, persistedDocs.first().pageCount)
        assertEquals(savedDoc.sizeBytes, persistedDocs.first().sizeBytes)
        assertTrue(File(persistedDocs.first().filePath).exists())

        val persistedPages = restartedRepo.getDocumentPages(savedDoc.id)
        assertEquals(3, persistedPages.size)
        assertEquals(listOf(0, 1, 2), persistedPages.map { it.orderIndex })
        restartedDb.close()
    }

    @Test
    fun `gallery import and page manager reorder rotate delete and export final pdf`() = runTest(testDispatcher) {
        val tempDir = File(context.cacheDir, "gallery_sim").apply { mkdirs() }
        val img1 = createTempJpeg(File(tempDir, "g1.jpg"), Color.YELLOW)
        val img2 = createTempJpeg(File(tempDir, "g2.jpg"), Color.CYAN)
        val img3 = createTempJpeg(File(tempDir, "g3.jpg"), Color.MAGENTA)

        val vm = createViewModel(FakeScannerGateway())
        vm.importMediaUri(Uri.fromFile(img1))
        vm.importMediaUri(Uri.fromFile(img2))
        vm.importMediaUri(Uri.fromFile(img3))
        advanceUntilIdle()

        assertEquals(3, vm.sessionPages.value.size)
        val firstId = vm.sessionPages.value[0].id
        val secondId = vm.sessionPages.value[1].id
        val thirdId = vm.sessionPages.value[2].id

        vm.movePage(secondId, -1)
        vm.rotatePage(firstId, 90)
        vm.removePage(thirdId)

        val updated = vm.sessionPages.value
        assertEquals(2, updated.size)
        assertEquals(secondId, updated[0].id)
        assertEquals(firstId, updated[1].id)
        assertEquals(90, updated[1].rotationDegrees)

        var exportedTitle = ""
        var exportedPages = 0
        var exportedPath = ""
        vm.generatePdf("Final_Batch", null, PdfPageSize.FIT_IMAGE) { doc ->
            exportedTitle = doc.title
            exportedPages = doc.pageCount
            exportedPath = doc.filePath
            assertTrue(File(doc.filePath).exists())
        }
        advanceUntilIdle()

        assertEquals("Final_Batch", exportedTitle)
        assertEquals(2, exportedPages)
        assertEquals(2, pdfRendererHelper.getPageCount(exportedPath))
        // Verify rotated page 2 (index 1, originally 120x160) became landscape 160x120 in FIT_IMAGE PDF
        PDDocument.load(File(exportedPath)).use { pdDoc ->
            val p2Box = pdDoc.getPage(1).mediaBox
            assertTrue("Expected rotated width > height", p2Box.width > p2Box.height)
        }
    }

    private fun createViewModel(gateway: DocumentScannerGateway): ScannerViewModel {
        return ScannerViewModel(
            documentRepository = repository,
            settingsRepository = settingsRepository,
            sessionManager = ScanSessionManager(),
            fileManager = fileManager,
            scannerGateway = gateway
        )
    }

    private fun createTempJpeg(file: File, color: Int): File {
        val bmp = Bitmap.createBitmap(120, 160, Bitmap.Config.ARGB_8888)
        bmp.eraseColor(color)
        FileOutputStream(file).use { out ->
            bmp.compress(Bitmap.CompressFormat.JPEG, 90, out)
        }
        bmp.recycle()
        return file
    }

    private fun createTempRealPdf(file: File, pageCount: Int): File {
        PDDocument().use { doc ->
            repeat(pageCount) { doc.addPage(PDPage()) }
            doc.save(file)
        }
        return file
    }

    private class FakeScannerGateway(
        private val startOutcome: ScannerStartOutcome? = null,
        private val activityOutcome: ScannerActivityOutcome = ScannerActivityOutcome.Cancelled
    ) : DocumentScannerGateway {
        override fun buildDefaultOptions(pageLimit: Int): GmsDocumentScannerOptions {
            return GmsDocumentScannerOptions.Builder()
                .setScannerMode(GmsDocumentScannerOptions.SCANNER_MODE_FULL)
                .setGalleryImportAllowed(true)
                .setPageLimit(pageLimit)
                .setResultFormats(
                    GmsDocumentScannerOptions.RESULT_FORMAT_JPEG,
                    GmsDocumentScannerOptions.RESULT_FORMAT_PDF
                )
                .build()
        }

        override fun prepareScanIntent(
            activity: Activity,
            pageLimit: Int,
            onResult: (ScannerStartOutcome) -> Unit
        ) {
            if (startOutcome != null) {
                onResult(startOutcome)
            } else {
                val pending = PendingIntent.getActivity(
                    activity,
                    0,
                    Intent(activity, Activity::class.java),
                    PendingIntent.FLAG_IMMUTABLE
                )
                onResult(ScannerStartOutcome.Ready(pending.intentSender))
            }
        }

        override fun parseActivityResult(resultCode: Int, data: Intent?): ScannerActivityOutcome {
            return activityOutcome
        }
    }

    private class FakeSettingsRepository : SettingsRepository {
        private val state = MutableStateFlow(UserPreferences())
        override val preferences: Flow<UserPreferences> = state
        override suspend fun setThemeMode(mode: ThemeMode) { state.value = state.value.copy(themeMode = mode) }
        override suspend fun setAppLanguage(language: AppLanguage) { state.value = state.value.copy(appLanguage = language) }
        override suspend fun setOnboardingCompleted(completed: Boolean) { state.value = state.value.copy(onboardingCompleted = completed) }
        override suspend fun setScanQuality(quality: ScanQuality) { state.value = state.value.copy(scanQuality = quality) }
        override suspend fun setDefaultPageSize(pageSize: PdfPageSize) { state.value = state.value.copy(defaultPageSize = pageSize) }
        override suspend fun setAutoEnhance(enabled: Boolean) { state.value = state.value.copy(autoEnhance = enabled) }
        override suspend fun setAppLockEnabled(enabled: Boolean) { state.value = state.value.copy(appLockEnabled = enabled) }
        override suspend fun setBiometricUnlockEnabled(enabled: Boolean) { state.value = state.value.copy(biometricUnlockEnabled = enabled) }
        override suspend fun setEncryptSensitiveFiles(enabled: Boolean) { state.value = state.value.copy(encryptSensitiveFiles = enabled) }
        override suspend fun setSealedPinRecord(record: String?) { state.value = state.value.copy(sealedPinRecord = record) }
        override suspend fun updateLastBackupAt(timestamp: Long) { state.value = state.value.copy(lastBackupAt = timestamp) }
    }
}
