package com.example.ui.screens

import android.Manifest
import android.content.pm.PackageManager
import android.view.Surface
import android.view.ViewGroup
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.camera.core.Camera
import androidx.camera.core.CameraSelector
import androidx.camera.core.ImageCapture
import androidx.camera.core.ImageCaptureException
import androidx.camera.core.Preview
import androidx.camera.lifecycle.ProcessCameraProvider
import androidx.camera.view.PreviewView
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.minimumInteractiveComponentSize
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import androidx.core.content.ContextCompat
import androidx.lifecycle.compose.LocalLifecycleOwner
import com.example.ui.components.DocuScanCard
import com.example.ui.icons.LucideIcons
import java.io.File
import kotlin.math.min

/**
 * Full-screen in-app CameraX guided ID card capture overlay for both Front and Back sides.
 * Handles runtime CAMERA permission cleanly, binds CameraX once via DisposableEffect,
 * draws a crisp ID aspect-ratio guide mask, and provides System Camera & Device Gallery fallbacks.
 */
@Composable
fun IdCardCameraOverlay(
    sideTitle: String,
    documentName: String,
    aspectRatio: Float,
    createCameraTempFile: () -> File,
    onCapturedFile: (File) -> Unit,
    onLaunchSystemCameraFallback: () -> Unit,
    onPickFromDeviceFallback: () -> Unit,
    onDismiss: () -> Unit
) {
    val context = LocalContext.current
    val lifecycleOwner = LocalLifecycleOwner.current

    var hasCameraPermission by remember {
        mutableStateOf(
            ContextCompat.checkSelfPermission(context, Manifest.permission.CAMERA) ==
                PackageManager.PERMISSION_GRANTED
        )
    }
    var permissionRequested by remember { mutableStateOf(false) }

    val permissionLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.RequestPermission()
    ) { granted ->
        hasCameraPermission = granted
    }

    LaunchedEffect(hasCameraPermission) {
        if (!hasCameraPermission && !permissionRequested) {
            permissionRequested = true
            permissionLauncher.launch(Manifest.permission.CAMERA)
        }
    }

    var imageCapture by remember { mutableStateOf<ImageCapture?>(null) }
    var boundCamera by remember { mutableStateOf<Camera?>(null) }
    var torchEnabled by remember { mutableStateOf(false) }
    var isCapturing by remember { mutableStateOf(false) }
    var cameraError by remember { mutableStateOf<String?>(null) }
    var cameraReady by remember { mutableStateOf(false) }

    val previewView = remember {
        PreviewView(context).apply {
            layoutParams = ViewGroup.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.MATCH_PARENT
            )
            scaleType = PreviewView.ScaleType.FILL_CENTER
        }
    }

    DisposableEffect(lifecycleOwner, previewView, hasCameraPermission) {
        if (!hasCameraPermission) {
            return@DisposableEffect onDispose {}
        }

        var disposed = false
        var activeProvider: ProcessCameraProvider? = null
        val providerFuture = ProcessCameraProvider.getInstance(context)

        providerFuture.addListener(
            {
                if (disposed) return@addListener
                runCatching {
                    val provider = providerFuture.get()
                    activeProvider = provider
                    val preview = Preview.Builder().build().also {
                        it.surfaceProvider = previewView.surfaceProvider
                    }
                    val capture = ImageCapture.Builder()
                        .setCaptureMode(ImageCapture.CAPTURE_MODE_MAXIMIZE_QUALITY)
                        .build()

                    val selector = when {
                        provider.hasCamera(CameraSelector.DEFAULT_BACK_CAMERA) -> CameraSelector.DEFAULT_BACK_CAMERA
                        provider.hasCamera(CameraSelector.DEFAULT_FRONT_CAMERA) -> CameraSelector.DEFAULT_FRONT_CAMERA
                        else -> throw IllegalStateException("No camera hardware available on this device.")
                    }

                    provider.unbindAll()
                    val camera = provider.bindToLifecycle(lifecycleOwner, selector, preview, capture)
                    boundCamera = camera
                    imageCapture = capture
                    cameraReady = true
                    cameraError = null
                }.onFailure { err ->
                    cameraReady = false
                    cameraError = err.message ?: "Unable to start camera preview."
                }
            },
            ContextCompat.getMainExecutor(context)
        )

        onDispose {
            disposed = true
            runCatching { boundCamera?.cameraControl?.enableTorch(false) }
            runCatching { activeProvider?.unbindAll() }
            boundCamera = null
            imageCapture = null
            cameraReady = false
        }
    }

    LaunchedEffect(boundCamera, torchEnabled) {
        val cam = boundCamera ?: return@LaunchedEffect
        if (cam.cameraInfo.hasFlashUnit()) {
            runCatching { cam.cameraControl.enableTorch(torchEnabled) }
        }
    }

    Dialog(
        onDismissRequest = onDismiss,
        properties = DialogProperties(
            usePlatformDefaultWidth = false,
            decorFitsSystemWindows = false
        )
    ) {
        Box(
            modifier = Modifier
                .fillMaxSize()
                .background(Color(0xFF0A0A0A))
                .testTag("id_camera_overlay")
        ) {
            if (!hasCameraPermission) {
                PermissionFallbackContent(
                    sideTitle = sideTitle,
                    documentName = documentName,
                    onRequestPermission = { permissionLauncher.launch(Manifest.permission.CAMERA) },
                    onPickFromDevice = onPickFromDeviceFallback,
                    onDismiss = onDismiss
                )
            } else {
                // Live CameraX viewfinder
                AndroidView(
                    factory = { previewView },
                    modifier = Modifier.fillMaxSize()
                )

                // Darkened framing scrim + golden ID card brackets
                IdCardGuideCanvas(
                    aspectRatio = aspectRatio,
                    accentColor = MaterialTheme.colorScheme.primary,
                    modifier = Modifier.fillMaxSize()
                )

                // Top Header Bar (Close, Side & Doc Pill, Flash Toggle)
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .statusBarsPadding()
                        .padding(horizontal = 16.dp, vertical = 12.dp)
                        .align(Alignment.TopCenter),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Surface(
                        shape = CircleShape,
                        color = Color.Black.copy(alpha = 0.62f)
                    ) {
                        IconButton(
                            onClick = onDismiss,
                            modifier = Modifier
                                .minimumInteractiveComponentSize()
                                .testTag("id_camera_close_btn")
                        ) {
                            Icon(
                                imageVector = LucideIcons.X,
                                contentDescription = "Close camera",
                                tint = Color.White
                            )
                        }
                    }

                    Surface(
                        shape = RoundedCornerShape(999.dp),
                        color = Color.Black.copy(alpha = 0.68f),
                        border = BorderStroke(1.dp, MaterialTheme.colorScheme.primary.copy(alpha = 0.7f))
                    ) {
                        Column(
                            modifier = Modifier.padding(horizontal = 16.dp, vertical = 6.dp),
                            horizontalAlignment = Alignment.CenterHorizontally
                        ) {
                            Text(
                                text = sideTitle.uppercase(),
                                style = MaterialTheme.typography.labelMedium,
                                fontWeight = FontWeight.Bold,
                                color = MaterialTheme.colorScheme.primary
                            )
                            Text(
                                text = documentName,
                                style = MaterialTheme.typography.labelSmall,
                                color = Color.White.copy(alpha = 0.9f)
                            )
                        }
                    }

                    val hasFlash = boundCamera?.cameraInfo?.hasFlashUnit() == true
                    if (hasFlash) {
                        Surface(
                            shape = CircleShape,
                            color = if (torchEnabled) {
                                MaterialTheme.colorScheme.primary
                            } else {
                                Color.Black.copy(alpha = 0.62f)
                            }
                        ) {
                            IconButton(
                                onClick = { torchEnabled = !torchEnabled },
                                modifier = Modifier
                                    .minimumInteractiveComponentSize()
                                    .testTag("id_camera_flash_btn")
                            ) {
                                Icon(
                                    imageVector = if (torchEnabled) LucideIcons.Zap else LucideIcons.ZapOff,
                                    contentDescription = if (torchEnabled) "Turn flash off" else "Turn flash on",
                                    tint = if (torchEnabled) Color.Black else Color.White
                                )
                            }
                        }
                    } else {
                        Spacer(modifier = Modifier.size(48.dp))
                    }
                }

                // Bottom Capture Controls & Error/Hint Banner
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .align(Alignment.BottomCenter)
                        .background(Color.Black.copy(alpha = 0.74f))
                        .navigationBarsPadding()
                        .padding(horizontal = 20.dp, vertical = 16.dp),
                    horizontalAlignment = Alignment.CenterHorizontally,
                    verticalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    val errorMsg = cameraError
                    if (errorMsg != null) {
                        Surface(
                            shape = RoundedCornerShape(12.dp),
                            color = MaterialTheme.colorScheme.errorContainer,
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Text(
                                text = "$errorMsg Use System Camera or pick from device below.",
                                style = MaterialTheme.typography.bodySmall,
                                color = MaterialTheme.colorScheme.onErrorContainer,
                                modifier = Modifier.padding(horizontal = 12.dp, vertical = 8.dp),
                                textAlign = TextAlign.Center
                            )
                        }
                    } else {
                        Text(
                            text = "Place $sideTitle flat inside the golden frame. Crop studio opens next.",
                            style = MaterialTheme.typography.bodySmall,
                            color = Color.White.copy(alpha = 0.88f),
                            textAlign = TextAlign.Center
                        )
                    }

                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .widthIn(max = 420.dp),
                        horizontalArrangement = Arrangement.SpaceEvenly,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        // Device Gallery shortcut
                        Column(
                            horizontalAlignment = Alignment.CenterHorizontally,
                            modifier = Modifier
                                .clip(RoundedCornerShape(12.dp))
                                .clickable(enabled = !isCapturing, onClick = onPickFromDeviceFallback)
                                .padding(horizontal = 12.dp, vertical = 8.dp)
                                .testTag("id_camera_gallery_fallback_btn")
                        ) {
                            Icon(
                                imageVector = LucideIcons.Images,
                                contentDescription = "Pick from device",
                                tint = Color.White,
                                modifier = Modifier.size(22.dp)
                            )
                            Spacer(modifier = Modifier.height(4.dp))
                            Text(
                                text = "Device",
                                style = MaterialTheme.typography.labelSmall,
                                color = Color.White
                            )
                        }

                        // Primary Shutter Button
                        Box(
                            modifier = Modifier
                                .size(76.dp)
                                .clip(CircleShape)
                                .border(3.dp, Color.White, CircleShape)
                                .padding(6.dp)
                                .clip(CircleShape)
                                .background(
                                    if (cameraReady && !isCapturing) {
                                        MaterialTheme.colorScheme.primary
                                    } else {
                                        MaterialTheme.colorScheme.primary.copy(alpha = 0.45f)
                                    }
                                )
                                .clickable(enabled = cameraReady && !isCapturing) {
                                    val capture = imageCapture ?: return@clickable
                                    isCapturing = true
                                    cameraError = null
                                    val outFile = createCameraTempFile()
                                    val rotation = previewView.display?.rotation ?: Surface.ROTATION_0
                                    capture.targetRotation = rotation
                                    val outputOptions = ImageCapture.OutputFileOptions.Builder(outFile).build()
                                    capture.takePicture(
                                        outputOptions,
                                        ContextCompat.getMainExecutor(context),
                                        object : ImageCapture.OnImageSavedCallback {
                                            override fun onImageSaved(outputFileResults: ImageCapture.OutputFileResults) {
                                                isCapturing = false
                                                if (outFile.exists() && outFile.length() > 0L) {
                                                    onCapturedFile(outFile)
                                                } else {
                                                    cameraError = "Captured photo was empty. Please try again."
                                                }
                                            }

                                            override fun onError(exception: ImageCaptureException) {
                                                isCapturing = false
                                                cameraError = exception.message ?: "Capture failed."
                                            }
                                        }
                                    )
                                }
                                .testTag("id_camera_shutter_btn"),
                            contentAlignment = Alignment.Center
                        ) {
                            if (isCapturing) {
                                CircularProgressIndicator(
                                    color = Color.Black,
                                    strokeWidth = 3.dp,
                                    modifier = Modifier.size(28.dp)
                                )
                            } else {
                                Icon(
                                    imageVector = LucideIcons.Camera,
                                    contentDescription = "Capture $sideTitle",
                                    tint = Color.Black,
                                    modifier = Modifier.size(28.dp)
                                )
                            }
                        }

                        // Native System Camera Fallback
                        Column(
                            horizontalAlignment = Alignment.CenterHorizontally,
                            modifier = Modifier
                                .clip(RoundedCornerShape(12.dp))
                                .clickable(enabled = !isCapturing, onClick = onLaunchSystemCameraFallback)
                                .padding(horizontal = 12.dp, vertical = 8.dp)
                                .testTag("id_camera_system_fallback_btn")
                        ) {
                            Icon(
                                imageVector = LucideIcons.ExternalLink,
                                contentDescription = "Open system camera",
                                tint = Color.White,
                                modifier = Modifier.size(22.dp)
                            )
                            Spacer(modifier = Modifier.height(4.dp))
                            Text(
                                text = "System Cam",
                                style = MaterialTheme.typography.labelSmall,
                                color = Color.White
                            )
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun PermissionFallbackContent(
    sideTitle: String,
    documentName: String,
    onRequestPermission: () -> Unit,
    onPickFromDevice: () -> Unit,
    onDismiss: () -> Unit
) {
    Column(
        modifier = Modifier
            .fillMaxSize()
            .statusBarsPadding()
            .navigationBarsPadding()
            .padding(24.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center
    ) {
        DocuScanCard(
            modifier = Modifier
                .fillMaxWidth()
                .widthIn(max = 420.dp)
        ) {
            Column(
                horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                Icon(
                    imageVector = LucideIcons.Camera,
                    contentDescription = null,
                    tint = MaterialTheme.colorScheme.primary,
                    modifier = Modifier.size(44.dp)
                )
                Text(
                    text = "Camera Access Required",
                    style = MaterialTheme.typography.titleMedium,
                    fontWeight = FontWeight.SemiBold,
                    textAlign = TextAlign.Center
                )
                Text(
                    text = "Grant camera permission to capture the $sideTitle of your $documentName, or choose an existing photo from your device.",
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                    textAlign = TextAlign.Center
                )
                Button(
                    onClick = onRequestPermission,
                    colors = ButtonDefaults.buttonColors(
                        containerColor = MaterialTheme.colorScheme.primary,
                        contentColor = MaterialTheme.colorScheme.onPrimary
                    ),
                    modifier = Modifier
                        .fillMaxWidth()
                        .minimumInteractiveComponentSize()
                        .testTag("id_camera_grant_permission_btn")
                ) {
                    Icon(LucideIcons.Camera, contentDescription = null, modifier = Modifier.size(18.dp))
                    Spacer(modifier = Modifier.size(8.dp))
                    Text("Allow Camera")
                }
                OutlinedButton(
                    onClick = onPickFromDevice,
                    modifier = Modifier
                        .fillMaxWidth()
                        .minimumInteractiveComponentSize()
                        .testTag("id_camera_gallery_fallback_btn")
                ) {
                    Icon(LucideIcons.Images, contentDescription = null, modifier = Modifier.size(18.dp))
                    Spacer(modifier = Modifier.size(8.dp))
                    Text("Select Photo From Device")
                }
                OutlinedButton(
                    onClick = onDismiss,
                    modifier = Modifier
                        .fillMaxWidth()
                        .minimumInteractiveComponentSize()
                        .testTag("id_camera_close_btn")
                ) {
                    Text("Cancel")
                }
            }
        }
    }
}

@Composable
private fun IdCardGuideCanvas(
    aspectRatio: Float,
    accentColor: Color,
    modifier: Modifier = Modifier
) {
    Canvas(modifier = modifier) {
        val safeRatio = aspectRatio.coerceIn(1.0f, 2.2f)
        val maxFrameW = size.width * 0.88f
        val maxFrameH = size.height * 0.48f
        val frameW = min(maxFrameW, maxFrameH * safeRatio)
        val frameH = frameW / safeRatio

        val left = (size.width - frameW) / 2f
        val top = (size.height - frameH) * 0.44f
        val right = left + frameW
        val bottom = top + frameH

        val scrim = Color.Black.copy(alpha = 0.56f)
        // Four-strip mask around the ID guide box
        drawRect(scrim, topLeft = Offset.Zero, size = Size(size.width, top))
        drawRect(scrim, topLeft = Offset(0f, bottom), size = Size(size.width, size.height - bottom))
        drawRect(scrim, topLeft = Offset(0f, top), size = Size(left, frameH))
        drawRect(scrim, topLeft = Offset(right, top), size = Size(size.width - right, frameH))

        // Subtle inner guide outline
        drawRect(
            color = Color.White.copy(alpha = 0.45f),
            topLeft = Offset(left, top),
            size = Size(frameW, frameH),
            style = androidx.compose.ui.graphics.drawscope.Stroke(width = 1.5.dp.toPx())
        )

        // Crisp golden corner brackets
        val cornerLen = 28.dp.toPx()
        val stroke = 4.dp.toPx()
        // Top-Left
        drawLine(accentColor, Offset(left, top), Offset(left + cornerLen, top), stroke, StrokeCap.Round)
        drawLine(accentColor, Offset(left, top), Offset(left, top + cornerLen), stroke, StrokeCap.Round)
        // Top-Right
        drawLine(accentColor, Offset(right, top), Offset(right - cornerLen, top), stroke, StrokeCap.Round)
        drawLine(accentColor, Offset(right, top), Offset(right, top + cornerLen), stroke, StrokeCap.Round)
        // Bottom-Left
        drawLine(accentColor, Offset(left, bottom), Offset(left + cornerLen, bottom), stroke, StrokeCap.Round)
        drawLine(accentColor, Offset(left, bottom), Offset(left, bottom - cornerLen), stroke, StrokeCap.Round)
        // Bottom-Right
        drawLine(accentColor, Offset(right, bottom), Offset(right - cornerLen, bottom), stroke, StrokeCap.Round)
        drawLine(accentColor, Offset(right, bottom), Offset(right, bottom - cornerLen), stroke, StrokeCap.Round)
    }
}
