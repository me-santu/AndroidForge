package com.example.repository

import com.example.data.datastore.UserPreferencesDataSource
import com.example.domain.model.AppFontStyle
import com.example.domain.model.AppLanguage
import com.example.domain.model.PdfPageSize
import com.example.domain.model.ScanQuality
import com.example.domain.model.ThemeMode
import com.example.domain.model.UserPreferences
import com.example.domain.repository.SettingsRepository
import kotlinx.coroutines.flow.Flow

class LocalSettingsRepository(
    private val dataSource: UserPreferencesDataSource
) : SettingsRepository {

    override val preferences: Flow<UserPreferences> = dataSource.preferences

    override suspend fun setThemeMode(mode: ThemeMode) = dataSource.setThemeMode(mode)

    override suspend fun setAppLanguage(language: AppLanguage) =
        dataSource.setAppLanguage(language)

    override suspend fun setFontStyle(fontStyle: AppFontStyle) =
        dataSource.setFontStyle(fontStyle)

    override suspend fun setOnboardingCompleted(completed: Boolean) =
        dataSource.setOnboardingCompleted(completed)

    override suspend fun setScanQuality(quality: ScanQuality) =
        dataSource.setScanQuality(quality)

    override suspend fun setDefaultPageSize(pageSize: PdfPageSize) =
        dataSource.setDefaultPageSize(pageSize)

    override suspend fun setAutoEnhance(enabled: Boolean) =
        dataSource.setAutoEnhance(enabled)

    override suspend fun setAppLockEnabled(enabled: Boolean) =
        dataSource.setAppLockEnabled(enabled)

    override suspend fun setBiometricUnlockEnabled(enabled: Boolean) =
        dataSource.setBiometricUnlockEnabled(enabled)

    override suspend fun setEncryptSensitiveFiles(enabled: Boolean) =
        dataSource.setEncryptSensitiveFiles(enabled)

    override suspend fun setSealedPinRecord(record: String?) =
        dataSource.setSealedPinRecord(record)

    override suspend fun updateLastBackupAt(timestamp: Long) =
        dataSource.updateLastBackupAt(timestamp)
}
