package com.example.scanner

import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Canvas
import android.graphics.ColorMatrix
import android.graphics.ColorMatrixColorFilter
import android.graphics.Matrix
import android.graphics.Paint
import com.example.domain.model.NormalizedCropRect
import com.example.domain.model.ScanFilter
import kotlin.math.abs
import kotlin.math.max
import kotlin.math.roundToInt

data class ImageQualityReport(
    val isBlankOrUniform: Boolean,
    val isLikelyBlurry: Boolean,
    val sharpnessScore: Double
)

object BitmapFilterEngine {

    fun decodeSampledBitmap(filePath: String, maxDimension: Int = 1800): Bitmap? {
        val options = BitmapFactory.Options().apply { inJustDecodeBounds = true }
        BitmapFactory.decodeFile(filePath, options)
        val rawW = options.outWidth
        val rawH = options.outHeight
        if (rawW <= 0 || rawH <= 0) return null

        var inSampleSize = 1
        val largest = max(rawW, rawH)
        while (largest / inSampleSize > maxDimension) {
            inSampleSize *= 2
        }

        val decodeOptions = BitmapFactory.Options().apply {
            this.inSampleSize = inSampleSize
            inPreferredConfig = Bitmap.Config.ARGB_8888
        }
        return BitmapFactory.decodeFile(filePath, decodeOptions)
    }

    fun applyTransformAndFilter(
        source: Bitmap,
        rotationDegrees: Int,
        filter: ScanFilter
    ): Bitmap = cropAndTransform(
        source = source,
        cropRect = NormalizedCropRect(),
        rotationDegrees = rotationDegrees,
        filter = filter
    )

    fun cropAndTransform(
        source: Bitmap,
        cropRect: NormalizedCropRect,
        rotationDegrees: Int,
        filter: ScanFilter
    ): Bitmap {
        val rotated = if (rotationDegrees % 360 != 0) {
            val matrix = Matrix().apply { postRotate((rotationDegrees % 360).toFloat()) }
            Bitmap.createBitmap(source, 0, 0, source.width, source.height, matrix, true)
        } else {
            source
        }

        val cleanCrop = cropRect.sanitized()
        val cropped = if (!cleanCrop.isFullFrame && rotated.width >= 20 && rotated.height >= 20) {
            val cropX = (cleanCrop.left * rotated.width).roundToInt().coerceIn(0, rotated.width - 10)
            val cropY = (cleanCrop.top * rotated.height).roundToInt().coerceIn(0, rotated.height - 10)
            val cropW = ((cleanCrop.right - cleanCrop.left) * rotated.width).roundToInt()
                .coerceIn(10, rotated.width - cropX)
            val cropH = ((cleanCrop.bottom - cleanCrop.top) * rotated.height).roundToInt()
                .coerceIn(10, rotated.height - cropY)
            val result = Bitmap.createBitmap(rotated, cropX, cropY, cropW, cropH)
            if (rotated !== source && !rotated.isRecycled) {
                rotated.recycle()
            }
            result
        } else {
            rotated
        }

        if (filter == ScanFilter.ORIGINAL) return cropped

        val result = Bitmap.createBitmap(cropped.width, cropped.height, Bitmap.Config.ARGB_8888)
        val canvas = Canvas(result)
        val paint = Paint(Paint.ANTI_ALIAS_FLAG)
        val colorMatrix = when (filter) {
            ScanFilter.ORIGINAL -> ColorMatrix()
            ScanFilter.DOCUMENT_BW -> {
                ColorMatrix().apply {
                    setSaturation(0f)
                    val contrast = 1.45f
                    val translate = (-0.5f * contrast + 0.5f) * 255f
                    postConcat(
                        ColorMatrix(
                            floatArrayOf(
                                contrast, 0f, 0f, 0f, translate,
                                0f, contrast, 0f, 0f, translate,
                                0f, 0f, contrast, 0f, translate,
                                0f, 0f, 0f, 1f, 0f
                            )
                        )
                    )
                }
            }
            ScanFilter.HIGH_CONTRAST -> {
                val contrast = 1.3f
                val translate = (-0.5f * contrast + 0.5f) * 255f + 10f
                ColorMatrix(
                    floatArrayOf(
                        contrast, 0f, 0f, 0f, translate,
                        0f, contrast, 0f, 0f, translate,
                        0f, 0f, contrast, 0f, translate,
                        0f, 0f, 0f, 1f, 0f
                    )
                )
            }
            ScanFilter.WARM_PAPER -> {
                ColorMatrix(
                    floatArrayOf(
                        1.06f, 0f, 0f, 0f, 8f,
                        0f, 1.02f, 0f, 0f, 4f,
                        0f, 0f, 0.90f, 0f, -4f,
                        0f, 0f, 0f, 1f, 0f
                    )
                )
            }
        }
        paint.colorFilter = ColorMatrixColorFilter(colorMatrix)
        canvas.drawBitmap(cropped, 0f, 0f, paint)
        if (cropped !== source && !cropped.isRecycled) {
            cropped.recycle()
        }
        return result
    }

    fun assessImageQuality(bitmap: Bitmap): ImageQualityReport {
        val maxDim = 220
        val scaleRatio = minOf(
            1f,
            maxDim.toFloat() / max(bitmap.width, bitmap.height).coerceAtLeast(1)
        )
        val sampleW = (bitmap.width * scaleRatio).roundToInt().coerceAtLeast(1)
        val sampleH = (bitmap.height * scaleRatio).roundToInt().coerceAtLeast(1)
        val scaled = if (sampleW != bitmap.width || sampleH != bitmap.height) {
            Bitmap.createScaledBitmap(bitmap, sampleW, sampleH, false)
        } else {
            bitmap
        }

        val count = sampleW * sampleH
        val pixels = IntArray(count)
        scaled.getPixels(pixels, 0, sampleW, 0, 0, sampleW, sampleH)
        if (scaled !== bitmap && !scaled.isRecycled) {
            scaled.recycle()
        }

        val luma = DoubleArray(count)
        var sum = 0.0
        var minLuma = 255.0
        var maxLuma = 0.0
        for (i in 0 until count) {
            val px = pixels[i]
            val r = (px shr 16) and 0xFF
            val g = (px shr 8) and 0xFF
            val b = px and 0xFF
            val y = 0.299 * r + 0.587 * g + 0.114 * b
            luma[i] = y
            sum += y
            if (y < minLuma) minLuma = y
            if (y > maxLuma) maxLuma = y
        }
        val mean = sum / count.coerceAtLeast(1)
        var varSum = 0.0
        for (i in 0 until count) {
            val d = luma[i] - mean
            varSum += d * d
        }
        val variance = varSum / count.coerceAtLeast(1)
        val contrastRange = maxLuma - minLuma
        val isBlank = variance < 10.0 && contrastRange < 28.0

        var edgeSum = 0.0
        var edgeMax = 0.0
        var edgeSamples = 0
        for (y in 1 until sampleH - 1) {
            for (x in 1 until sampleW - 1) {
                val idx = y * sampleW + x
                val gx = abs(luma[idx + 1] - luma[idx - 1])
                val gy = abs(luma[idx + sampleW] - luma[idx - sampleW])
                val mag = gx + gy
                edgeSum += mag
                if (mag > edgeMax) edgeMax = mag
                edgeSamples++
            }
        }
        val avgEdge = if (edgeSamples > 0) edgeSum / edgeSamples else 0.0
        // Crisp text/high-contrast document has strong peak edges; heavily blurred document has low peak gradient
        val isBlurry = !isBlank && edgeMax < 42.0 && avgEdge < 6.0

        return ImageQualityReport(
            isBlankOrUniform = isBlank,
            isLikelyBlurry = isBlurry,
            sharpnessScore = edgeMax
        )
    }
}
