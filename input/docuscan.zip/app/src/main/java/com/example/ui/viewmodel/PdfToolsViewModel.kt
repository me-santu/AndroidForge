package com.example.ui.viewmodel

import android.content.Context
import android.net.Uri
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.example.domain.model.DocumentFileType
import com.example.domain.model.DocumentItem
import com.example.domain.model.PageNumberFormat
import com.example.domain.model.PageNumberPosition
import com.example.domain.model.PdfCompressionLevel
import com.example.domain.model.PdfDocumentInfo
import com.example.domain.model.PdfDocxConversionResult
import com.example.domain.model.PdfImageFormat
import com.example.domain.model.PdfImagesExportResult
import com.example.domain.model.PdfOrientation
import com.example.domain.model.PdfPageSize
import com.example.domain.model.PdfTextExtractionResult
import com.example.domain.repository.DocumentRepository
import com.example.pdf.PdfRendererHelper
import com.example.security.SecurityManager
import com.example.util.FormatUtils
import com.example.util.LocalFileManager
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.File

sealed interface PdfToolResult {
    data class PdfCreated(
        val document: DocumentItem,
        val toolTitle: String,
        val detailMessage: String
    ) : PdfToolResult

    data class InfoInspected(
        val document: DocumentItem,
        val info: PdfDocumentInfo
    ) : PdfToolResult

    data class TextExtracted(
        val document: DocumentItem,
        val extraction: PdfTextExtractionResult
    ) : PdfToolResult

    data class DocxConverted(
        val conversion: PdfDocxConversionResult,
        val sourceDocument: DocumentItem
    ) : PdfToolResult

    data class ImagesExported(
        val export: PdfImagesExportResult,
        val sourceTitle: String
    ) : PdfToolResult

    data class ActionCompleted(
        val title: String,
        val message: String,
        val affectedDocumentId: Long? = null
    ) : PdfToolResult
}

data class PdfToolsUiState(
    val isWorking: Boolean = false,
    val workingMessage: String = "Processing PDF...",
    val errorMessage: String? = null,
    val result: PdfToolResult? = null
)

class PdfToolsViewModel(
    private val documentRepository: DocumentRepository,
    private val pdfRendererHelper: PdfRendererHelper,
    private val fileManager: LocalFileManager,
    private val securityManager: SecurityManager? = null
) : ViewModel() {

    val pdfDocuments: StateFlow<List<DocumentItem>> = documentRepository.observeActiveDocuments()
        .map { docs ->
            docs.filter { it.fileType == DocumentFileType.PDF || it.fileType == DocumentFileType.ID_CARD }
        }
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    private val _uiState = MutableStateFlow(PdfToolsUiState())
    val uiState: StateFlow<PdfToolsUiState> = _uiState.asStateFlow()

    fun clearError() {
        _uiState.value = _uiState.value.copy(errorMessage = null)
    }

    fun clearResult() {
        _uiState.value = _uiState.value.copy(result = null)
    }

    fun resetState() {
        _uiState.value = PdfToolsUiState()
    }

    private fun startWork(message: String) {
        _uiState.value = PdfToolsUiState(isWorking = true, workingMessage = message)
    }

    private fun fail(err: Throwable, fallback: String) {
        _uiState.value = PdfToolsUiState(
            isWorking = false,
            errorMessage = err.message?.takeIf { it.isNotBlank() } ?: fallback
        )
    }

    fun importExternalPdfUri(uri: Uri, onImported: (DocumentItem) -> Unit = {}) {
        viewModelScope.launch {
            startWork("Importing PDF from storage...")
            documentRepository.importExternalPdfUri(uri)
                .onSuccess { doc ->
                    _uiState.value = PdfToolsUiState()
                    onImported(doc)
                }
                .onFailure { fail(it, "Could not import selected PDF file.") }
        }
    }

    fun importMultipleExternalPdfUris(uris: List<Uri>, onImported: (List<DocumentItem>) -> Unit = {}) {
        if (uris.isEmpty()) return
        viewModelScope.launch {
            startWork("Importing ${uris.size} PDF(s) from device...")
            val imported = mutableListOf<DocumentItem>()
            var lastError: Throwable? = null
            for (uri in uris) {
                documentRepository.importExternalPdfUri(uri)
                    .onSuccess { imported.add(it) }
                    .onFailure { lastError = it }
            }
            if (imported.isNotEmpty()) {
                _uiState.value = PdfToolsUiState()
                onImported(imported)
            } else {
                fail(
                    lastError ?: IllegalStateException("Could not import selected PDF files."),
                    "Could not import selected PDF files."
                )
            }
        }
    }

    fun openExternalPdfUri(uri: Uri, onOpenViewer: (Long) -> Unit) {
        viewModelScope.launch {
            startWork("Validating & opening PDF...")
            documentRepository.importExternalPdfUri(uri)
                .onSuccess { doc ->
                    _uiState.value = PdfToolsUiState()
                    onOpenViewer(doc.id)
                }
                .onFailure { fail(it, "Selected file is not a valid PDF.") }
        }
    }

    fun readTextFromUri(uri: Uri, onLoaded: (String) -> Unit) {
        viewModelScope.launch {
            runCatching { fileManager.readTextFromUri(uri) }
                .onSuccess(onLoaded)
                .onFailure { fail(it, "Could not read text from selected file.") }
        }
    }

    fun renamePdf(documentId: Long, newTitle: String) {
        viewModelScope.launch {
            startWork("Renaming PDF...")
            documentRepository.renameDocument(documentId, newTitle)
                .onSuccess {
                    _uiState.value = PdfToolsUiState(
                        result = PdfToolResult.ActionCompleted(
                            title = "PDF Renamed",
                            message = "Updated title to '${newTitle.trim()}'.",
                            affectedDocumentId = documentId
                        )
                    )
                }
                .onFailure { fail(it, "Failed to rename PDF.") }
        }
    }

    fun duplicatePdf(sourceId: Long, newTitle: String) {
        viewModelScope.launch {
            startWork("Duplicating PDF...")
            documentRepository.duplicatePdfDocument(sourceId, newTitle)
                .onSuccess { created ->
                    _uiState.value = PdfToolsUiState(
                        result = PdfToolResult.PdfCreated(
                            document = created,
                            toolTitle = "PDF Duplicated",
                            detailMessage = "Created independent copy '${created.title}' (${created.pageCount}p)."
                        )
                    )
                }
                .onFailure { fail(it, "Failed to duplicate PDF.") }
        }
    }

    fun deletePdf(documentId: Long, permanently: Boolean) {
        viewModelScope.launch {
            startWork(if (permanently) "Permanently deleting PDF..." else "Moving PDF to Recycle Bin...")
            val op = if (permanently) {
                documentRepository.permanentlyDeleteDocument(documentId)
            } else {
                documentRepository.moveDocumentToTrash(documentId)
            }
            op.onSuccess {
                _uiState.value = PdfToolsUiState(
                    result = PdfToolResult.ActionCompleted(
                        title = if (permanently) "PDF Permanently Deleted" else "Moved to Recycle Bin",
                        message = if (permanently) {
                            "The file and its records have been erased from storage."
                        } else {
                            "You can restore this PDF anytime from Recycle Bin."
                        }
                    )
                )
            }.onFailure { fail(it, "Failed to delete PDF.") }
        }
    }

    fun sharePdf(document: DocumentItem) {
        runCatching {
            fileManager.shareFile(document.filePath, "application/pdf", "Share ${document.title}", securityManager)
        }.onFailure { fail(it, "Could not open share sheet.") }
    }

    fun printPdf(context: Context, document: DocumentItem) {
        viewModelScope.launch {
            startWork("Preparing document for printing...")
            runCatching {
                val printablePath = withContext(fileManager.ioDispatcher) {
                    val raw = File(document.filePath)
                    require(raw.exists() && raw.length() > 0L) { "PDF file missing on device." }
                    if (securityManager != null && securityManager.isVaultEncryptedFile(raw)) {
                        val temp = File(fileManager.appCacheDir, "print_${document.id}_${System.currentTimeMillis()}.pdf")
                        val plain = securityManager.readFilePlainBytes(raw)
                        temp.writeBytes(plain)
                        plain.fill(0)
                        temp.absolutePath
                    } else {
                        raw.absolutePath
                    }
                }
                val started = pdfRendererHelper.printPdf(context, printablePath, document.title)
                require(started) { "Android Print service is unavailable on this device." }
            }.onSuccess {
                _uiState.value = PdfToolsUiState(
                    result = PdfToolResult.ActionCompleted(
                        title = "Print Dialog Opened",
                        message = if (document.isPasswordProtected) {
                            "Sent '${document.title}' to system Print spooler. If printer requires unlocking, use Unlock PDF first."
                        } else {
                            "Sent '${document.title}' to Android Print Manager."
                        },
                        affectedDocumentId = document.id
                    )
                )
            }.onFailure { fail(it, "Failed to print PDF.") }
        }
    }

    fun inspectPdfInfo(sourceId: Long, password: String?) {
        viewModelScope.launch {
            startWork("Inspecting PDF metadata & structure...")
            val doc = documentRepository.getDocumentById(sourceId)
            documentRepository.inspectPdfInfo(sourceId, password)
                .onSuccess { info ->
                    val resolved = doc ?: DocumentItem(title = info.title.ifBlank { "PDF" }, filePath = info.filePath)
                    _uiState.value = PdfToolsUiState(
                        result = PdfToolResult.InfoInspected(resolved, info)
                    )
                }
                .onFailure { fail(it, "Failed to read PDF information.") }
        }
    }

    fun mergePdfs(title: String, selectedIds: List<Long>) {
        viewModelScope.launch {
            startWork("Merging ${selectedIds.size} PDFs...")
            documentRepository.mergePdfDocuments(title, selectedIds, null)
                .onSuccess { created ->
                    _uiState.value = PdfToolsUiState(
                        result = PdfToolResult.PdfCreated(
                            document = created,
                            toolTitle = "PDFs Merged",
                            detailMessage = "Combined ${selectedIds.size} files into '${created.title}' (${created.pageCount} pages)."
                        )
                    )
                }
                .onFailure { fail(it, "Failed to merge selected PDFs.") }
        }
    }

    fun splitPdf(sourceId: Long, title: String, startPage: Int, endPage: Int, password: String?) {
        viewModelScope.launch {
            startWork("Splitting pages $startPage..$endPage...")
            documentRepository.splitPdfDocument(sourceId, title, startPage, endPage, password)
                .onSuccess { created ->
                    _uiState.value = PdfToolsUiState(
                        result = PdfToolResult.PdfCreated(
                            document = created,
                            toolTitle = "PDF Split Complete",
                            detailMessage = "Extracted pages $startPage–$endPage into '${created.title}' (${created.pageCount}p)."
                        )
                    )
                }
                .onFailure { fail(it, "Failed to split PDF.") }
        }
    }

    fun extractPages(sourceId: Long, title: String, pages: List<Int>, password: String?) {
        viewModelScope.launch {
            startWork("Extracting selected pages...")
            documentRepository.extractPdfPages(sourceId, title, pages, password)
                .onSuccess { created ->
                    _uiState.value = PdfToolsUiState(
                        result = PdfToolResult.PdfCreated(
                            document = created,
                            toolTitle = "Pages Extracted",
                            detailMessage = "Saved ${created.pageCount} extracted page(s) as '${created.title}'."
                        )
                    )
                }
                .onFailure { fail(it, "Failed to extract pages.") }
        }
    }

    fun reorderPages(sourceId: Long, title: String, oneBasedNewOrder: List<Int>, toolTitle: String, password: String?) {
        viewModelScope.launch {
            startWork("Applying new page arrangement...")
            documentRepository.reorderPdfPages(sourceId, title, oneBasedNewOrder, password)
                .onSuccess { created ->
                    _uiState.value = PdfToolsUiState(
                        result = PdfToolResult.PdfCreated(
                            document = created,
                            toolTitle = toolTitle,
                            detailMessage = "Saved ${created.pageCount} page(s) in updated order as '${created.title}'."
                        )
                    )
                }
                .onFailure { fail(it, "Failed to reorder pages.") }
        }
    }

    fun rotatePages(sourceId: Long, title: String, pages: Set<Int>, degrees: Int, password: String?) {
        viewModelScope.launch {
            startWork("Rotating pages by $degrees°...")
            documentRepository.rotatePdfPages(sourceId, title, pages, degrees, password)
                .onSuccess { created ->
                    _uiState.value = PdfToolsUiState(
                        result = PdfToolResult.PdfCreated(
                            document = created,
                            toolTitle = "Pages Rotated ($degrees°)",
                            detailMessage = "Saved rotated copy '${created.title}' (${created.pageCount}p)."
                        )
                    )
                }
                .onFailure { fail(it, "Failed to rotate PDF pages.") }
        }
    }

    fun deletePages(sourceId: Long, title: String, pagesToDelete: Set<Int>, password: String?) {
        viewModelScope.launch {
            startWork("Removing selected pages...")
            documentRepository.deletePdfPages(sourceId, title, pagesToDelete, password)
                .onSuccess { created ->
                    _uiState.value = PdfToolsUiState(
                        result = PdfToolResult.PdfCreated(
                            document = created,
                            toolTitle = "Pages Removed",
                            detailMessage = "Remaining ${created.pageCount} page(s) saved as '${created.title}'."
                        )
                    )
                }
                .onFailure { fail(it, "Failed to remove pages.") }
        }
    }

    fun duplicatePages(
        sourceId: Long,
        title: String,
        pagesToDuplicate: List<Int>,
        insertAdjacent: Boolean,
        password: String?
    ) {
        viewModelScope.launch {
            startWork("Duplicating selected pages...")
            documentRepository.duplicatePdfPages(sourceId, title, pagesToDuplicate, insertAdjacent, password)
                .onSuccess { created ->
                    _uiState.value = PdfToolsUiState(
                        result = PdfToolResult.PdfCreated(
                            document = created,
                            toolTitle = "Pages Duplicated",
                            detailMessage = "Created '${created.title}' with ${created.pageCount} total page(s)."
                        )
                    )
                }
                .onFailure { fail(it, "Failed to duplicate pages.") }
        }
    }

    fun exportPdfToImages(
        sourceId: Long,
        format: PdfImageFormat,
        pageIndicesOneBased: List<Int>,
        quality: Int,
        saveToLibrary: Boolean,
        password: String?
    ) {
        viewModelScope.launch {
            startWork("Rendering PDF pages to ${format.label}...")
            val doc = documentRepository.getDocumentById(sourceId)
            documentRepository.exportPdfToImages(sourceId, format, pageIndicesOneBased, quality, saveToLibrary, password)
                .onSuccess { export ->
                    _uiState.value = PdfToolsUiState(
                        result = PdfToolResult.ImagesExported(export, doc?.title ?: "PDF")
                    )
                }
                .onFailure { fail(it, "Failed to convert PDF to ${format.label}.") }
        }
    }

    fun createPdfFromText(
        title: String,
        text: String,
        pageSize: PdfPageSize,
        orientation: PdfOrientation,
        marginPt: Float,
        fontSizePt: Float,
        includePageNumbers: Boolean,
        password: String
    ) {
        viewModelScope.launch {
            startWork("Generating multi-page PDF from text...")
            documentRepository.createPdfFromText(
                title = title,
                text = text,
                folderId = null,
                pageSize = pageSize,
                orientation = orientation,
                marginPt = marginPt,
                fontSizePt = fontSizePt,
                includePageNumbers = includePageNumbers,
                password = password
            ).onSuccess { created ->
                _uiState.value = PdfToolsUiState(
                    result = PdfToolResult.PdfCreated(
                        document = created,
                        toolTitle = "Text Converted to PDF",
                        detailMessage = "Generated '${created.title}' (${created.pageCount} page(s), ${FormatUtils.formatBytes(created.sizeBytes)})."
                    )
                )
            }.onFailure { fail(it, "Failed to generate PDF from text.") }
        }
    }

    fun extractTextFromPdf(sourceId: Long, startPage: Int, endPage: Int, password: String?) {
        viewModelScope.launch {
            startWork("Extracting embedded text from PDF...")
            val doc = documentRepository.getDocumentById(sourceId)
            documentRepository.extractTextFromPdf(sourceId, startPage, endPage, password)
                .onSuccess { extraction ->
                    val resolved = doc ?: DocumentItem(title = "PDF", filePath = "")
                    _uiState.value = PdfToolsUiState(
                        result = PdfToolResult.TextExtracted(resolved, extraction)
                    )
                }
                .onFailure { fail(it, "Failed to extract text from PDF.") }
        }
    }

    fun convertPdfToDocx(
        sourceId: Long,
        outputTitle: String,
        includePageImagesFallback: Boolean,
        password: String?
    ) {
        viewModelScope.launch {
            startWork("Converting PDF to Word (.docx)...")
            val doc = documentRepository.getDocumentById(sourceId)
            documentRepository.convertPdfToDocx(sourceId, outputTitle, includePageImagesFallback, password)
                .onSuccess { conversion ->
                    val resolved = doc ?: DocumentItem(title = conversion.title, filePath = conversion.outputFilePath)
                    _uiState.value = PdfToolsUiState(
                        result = PdfToolResult.DocxConverted(conversion, resolved)
                    )
                }
                .onFailure { fail(it, "Failed to convert PDF to DOCX.") }
        }
    }

    fun protectPdf(sourceId: Long, title: String, userPassword: String, existingPassword: String?) {
        viewModelScope.launch {
            startWork("Encrypting PDF with AES-128...")
            documentRepository.protectPdfDocument(sourceId, title, userPassword, existingPassword)
                .onSuccess { created ->
                    _uiState.value = PdfToolsUiState(
                        result = PdfToolResult.PdfCreated(
                            document = created,
                            toolTitle = "PDF Password Protected",
                            detailMessage = "AES-128 encryption applied to '${created.title}'."
                        )
                    )
                }
                .onFailure { fail(it, "Failed to password-protect PDF.") }
        }
    }

    fun unlockPdf(sourceId: Long, title: String, password: String) {
        viewModelScope.launch {
            startWork("Verifying password & unlocking PDF...")
            documentRepository.unlockPdfDocument(sourceId, title, password)
                .onSuccess { created ->
                    _uiState.value = PdfToolsUiState(
                        result = PdfToolResult.PdfCreated(
                            document = created,
                            toolTitle = "PDF Unlocked",
                            detailMessage = "Created unencrypted copy '${created.title}' (${created.pageCount}p)."
                        )
                    )
                }
                .onFailure { fail(it, "Incorrect password or unable to unlock PDF.") }
        }
    }

    fun watermarkPdf(sourceId: Long, title: String, watermarkText: String, password: String?) {
        viewModelScope.launch {
            startWork("Adding diagonal watermark...")
            documentRepository.watermarkPdfDocument(sourceId, title, watermarkText, password)
                .onSuccess { created ->
                    _uiState.value = PdfToolsUiState(
                        result = PdfToolResult.PdfCreated(
                            document = created,
                            toolTitle = "Watermark Added",
                            detailMessage = "Stamped '$watermarkText' across ${created.pageCount} page(s)."
                        )
                    )
                }
                .onFailure { fail(it, "Failed to add watermark.") }
        }
    }

    fun removeWatermark(sourceId: Long, title: String, matchText: String?, password: String?) {
        viewModelScope.launch {
            startWork("Scanning streams & annotations for removable watermarks...")
            documentRepository.removeWatermarkFromPdf(sourceId, title, matchText, password)
                .onSuccess { res ->
                    _uiState.value = PdfToolsUiState(
                        result = PdfToolResult.PdfCreated(
                            document = res.document,
                            toolTitle = "Watermark Removed",
                            detailMessage = "Stripped ${res.removedTextBlocks} text overlay(s), " +
                                "${res.removedAnnotations} annotation(s), and ${res.removedOcgCount} layer(s)."
                        )
                    )
                }
                .onFailure { fail(it, "No removable watermark elements were detected.") }
        }
    }

    fun addPageNumbers(
        sourceId: Long,
        title: String,
        position: PageNumberPosition,
        format: PageNumberFormat,
        startNumber: Int,
        password: String?
    ) {
        viewModelScope.launch {
            startWork("Stamping page numbers...")
            documentRepository.addPageNumbersToPdf(sourceId, title, position, format, startNumber, password)
                .onSuccess { created ->
                    _uiState.value = PdfToolsUiState(
                        result = PdfToolResult.PdfCreated(
                            document = created,
                            toolTitle = "Page Numbers Added",
                            detailMessage = "Numbered ${created.pageCount} page(s) (${position.label}, ${format.label})."
                        )
                    )
                }
                .onFailure { fail(it, "Failed to add page numbers.") }
        }
    }

    fun addHeaderFooter(
        sourceId: Long,
        title: String,
        headerText: String,
        footerText: String,
        includeDate: Boolean,
        fontSizePt: Float,
        password: String?
    ) {
        viewModelScope.launch {
            startWork("Adding header & footer...")
            documentRepository.addHeaderFooterToPdf(
                sourceId,
                title,
                headerText,
                footerText,
                includeDate,
                fontSizePt,
                password
            ).onSuccess { created ->
                _uiState.value = PdfToolsUiState(
                    result = PdfToolResult.PdfCreated(
                        document = created,
                        toolTitle = "Header & Footer Added",
                        detailMessage = "Applied header/footer across ${created.pageCount} page(s) in '${created.title}'."
                    )
                )
            }.onFailure { fail(it, "Failed to add header & footer.") }
        }
    }

    fun compressPdf(sourceId: Long, title: String, level: PdfCompressionLevel, password: String?) {
        viewModelScope.launch {
            startWork("Compressing PDF (${level.label})...")
            val origBytes = documentRepository.getDocumentById(sourceId)?.sizeBytes ?: 0L
            documentRepository.compressPdfDocument(sourceId, title, level, password)
                .onSuccess { created ->
                    val diffMsg = if (origBytes > 0L) {
                        "${FormatUtils.formatBytes(origBytes)} -> ${FormatUtils.formatBytes(created.sizeBytes)}"
                    } else {
                        FormatUtils.formatBytes(created.sizeBytes)
                    }
                    _uiState.value = PdfToolsUiState(
                        result = PdfToolResult.PdfCreated(
                            document = created,
                            toolTitle = "PDF Compressed",
                            detailMessage = "Size: $diffMsg (${created.pageCount}p)."
                        )
                    )
                }
                .onFailure { fail(it, "Failed to compress PDF.") }
        }
    }

    fun reducePdfSize(
        sourceId: Long,
        title: String,
        maxImageDimension: Int,
        jpegQuality: Float,
        stripMetadata: Boolean,
        password: String?
    ) {
        viewModelScope.launch {
            startWork("Optimizing images & stripping overhead metadata...")
            documentRepository.reducePdfSizeDocument(
                sourceId,
                title,
                maxImageDimension,
                jpegQuality,
                stripMetadata,
                password
            ).onSuccess { res ->
                val summary = "${FormatUtils.formatBytes(res.originalBytes)} -> " +
                    "${FormatUtils.formatBytes(res.outputBytes)} (${res.savingsPercent}% saved)"
                _uiState.value = PdfToolsUiState(
                    result = PdfToolResult.PdfCreated(
                        document = res.document,
                        toolTitle = "PDF Size Reduced",
                        detailMessage = summary
                    )
                )
            }.onFailure { fail(it, "Failed to reduce PDF size.") }
        }
    }

    fun repairPdf(sourceId: Long, title: String, password: String?) {
        viewModelScope.launch {
            startWork("Rebuilding PDF XRef & page structure...")
            documentRepository.repairPdfDocument(sourceId, title, password)
                .onSuccess { res ->
                    _uiState.value = PdfToolsUiState(
                        result = PdfToolResult.PdfCreated(
                            document = res.document,
                            toolTitle = "PDF Repaired",
                            detailMessage = "${res.methodSummary}."
                        )
                    )
                }
                .onFailure { fail(it, "Could not repair PDF structure.") }
        }
    }

    fun repairExternalPdfUri(uri: Uri, title: String, password: String?) {
        viewModelScope.launch {
            startWork("Recovering damaged external PDF...")
            documentRepository.repairExternalPdfUri(uri, title, password)
                .onSuccess { res ->
                    _uiState.value = PdfToolsUiState(
                        result = PdfToolResult.PdfCreated(
                            document = res.document,
                            toolTitle = "External PDF Repaired",
                            detailMessage = "${res.methodSummary}."
                        )
                    )
                }
                .onFailure { fail(it, "External file could not be repaired.") }
        }
    }

    fun exportDocumentToSafUri(documentId: Long, destinationUri: Uri) {
        viewModelScope.launch {
            documentRepository.exportDocumentToUri(documentId, destinationUri)
                .onSuccess { bytes ->
                    _uiState.value = _uiState.value.copy(
                        errorMessage = null,
                        result = PdfToolResult.ActionCompleted(
                            title = "Saved to Device Storage",
                            message = "Wrote ${FormatUtils.formatBytes(bytes)} via Android Storage Access Framework.",
                            affectedDocumentId = documentId
                        )
                    )
                }
                .onFailure { fail(it, "Failed to save copy to selected location.") }
        }
    }

    fun exportLocalFileToSafUri(localFilePath: String, destinationUri: Uri, label: String) {
        viewModelScope.launch {
            runCatching { fileManager.copyFileToContentUri(localFilePath, destinationUri, securityManager) }
                .onSuccess { bytes ->
                    _uiState.value = _uiState.value.copy(
                        errorMessage = null,
                        result = PdfToolResult.ActionCompleted(
                            title = "$label Saved",
                            message = "Exported ${FormatUtils.formatBytes(bytes)} to selected location."
                        )
                    )
                }
                .onFailure { fail(it, "Failed to export $label.") }
        }
    }

    fun exportTextToSafUri(text: String, destinationUri: Uri) {
        viewModelScope.launch {
            runCatching { fileManager.writeTextToUri(text, destinationUri) }
                .onSuccess { bytes ->
                    _uiState.value = _uiState.value.copy(
                        errorMessage = null,
                        result = PdfToolResult.ActionCompleted(
                            title = "TXT Saved",
                            message = "Saved ${FormatUtils.formatBytes(bytes)} to selected .txt file."
                        )
                    )
                }
                .onFailure { fail(it, "Failed to write TXT file.") }
        }
    }

    fun exportImagesToSafTree(imagePaths: List<String>, format: PdfImageFormat, treeUri: Uri) {
        viewModelScope.launch {
            startWork("Writing ${imagePaths.size} ${format.label} file(s) to folder...")
            runCatching {
                fileManager.exportFilesToSafTree(
                    treeUri = treeUri,
                    files = imagePaths.map { File(it) },
                    mimeType = format.mimeType
                )
            }.onSuccess { count ->
                _uiState.value = PdfToolsUiState(
                    result = PdfToolResult.ActionCompleted(
                        title = "Images Exported",
                        message = "Saved $count ${format.label} image(s) to selected folder."
                    )
                )
            }.onFailure { fail(it, "Failed to write images to selected folder.") }
        }
    }

    fun shareLocalFile(localFilePath: String, mimeType: String, chooserTitle: String) {
        runCatching {
            fileManager.shareFile(localFilePath, mimeType, chooserTitle, securityManager)
        }.onFailure { fail(it, "Unable to share file.") }
    }
}
