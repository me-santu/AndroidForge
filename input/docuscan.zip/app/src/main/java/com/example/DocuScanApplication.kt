package com.example

import android.app.Application
import com.example.util.AppContainer
import com.tom_roush.pdfbox.android.PDFBoxResourceLoader

class DocuScanApplication : Application() {
    lateinit var container: AppContainer
        private set

    override fun onCreate() {
        super.onCreate()
        if (!PDFBoxResourceLoader.isReady()) {
            PDFBoxResourceLoader.init(applicationContext)
        }
        container = AppContainer(this)
    }
}
