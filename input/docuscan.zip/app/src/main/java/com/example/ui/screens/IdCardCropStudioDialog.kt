package com.example.ui.screens

import android.graphics.Bitmap
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FilterChipDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.minimumInteractiveComponentSize
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.produceState
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberUpdatedState
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Rect
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.layout.onSizeChanged
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.IntSize
import androidx.compose.ui.unit.dp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import com.example.domain.model.IdSideScanState
import com.example.domain.model.NormalizedCropRect
import com.example.domain.model.ScanFilter
import com.example.scanner.BitmapFilterEngine
import com.example.ui.icons.LucideIcons
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import kotlin.math.abs
import kotlin.math.hypot
import kotlin.math.min
import kotlin.math.roundToInt

private enum class CropDragHandle {
    NONE,
    TOP_LEFT,
    TOP_RIGHT,
    BOTTOM_LEFT,
    BOTTOM_RIGHT,
    LEFT,
    RIGHT,
    TOP,
    BOTTOM,
    MOVE
}

private const val MIN_CROP_SPAN = 0.14f

/**
 * Full-screen interactive visual Crop Studio for Front & Back ID cards.
 * Supports direct dragging of all 4 corners, all 4 edges, moving the crop box,
 * optional ID Card Aspect Ratio Lock, live 90-degree rotation, and quick presets.
 */
@Composable
fun IdCardCropStudioDialog(
    title: String,
    sideState: IdSideScanState,
    aspectRatio: Float,
    onRotate90: () -> Unit,
    onDismiss: () -> Unit,
    onApplyCrop: (NormalizedCropRect) -> Unit
) {
    var cropRect by remember(sideState.imagePath) {
        mutableStateOf(sideState.cropRect.sanitized())
    }
    var lockAspectRatio by remember { mutableStateOf(false) }
    var containerSize by remember { mutableStateOf(IntSize.Zero) }
    var activeHandle by remember { mutableStateOf(CropDragHandle.NONE) }

    val sourceBitmap by produceState<Bitmap?>(
        initialValue = null,
        key1 = sideState.imagePath,
        key2 = sideState.rotationDegrees
    ) {
        val path = sideState.imagePath ?: return@produceState
        value = withContext(Dispatchers.IO) {
            val raw = BitmapFilterEngine.decodeSampledBitmap(path, maxDimension = 1400)
            raw?.let {
                BitmapFilterEngine.applyTransformAndFilter(
                    source = it,
                    rotationDegrees = sideState.rotationDegrees,
                    filter = ScanFilter.ORIGINAL
                )
            }
        }
    }

    val imageBounds = remember(containerSize, sourceBitmap) {
        computeFittedImageBounds(containerSize, sourceBitmap)
    }

    val density = LocalDensity.current
    val cornerHitRadiusPx = with(density) { 36.dp.toPx() }
    val edgeHitRadiusPx = with(density) { 26.dp.toPx() }

    val latestCrop by rememberUpdatedState(cropRect)
    val latestBounds by rememberUpdatedState(imageBounds)
    val latestBitmap by rememberUpdatedState(sourceBitmap)
    val latestLockRatio by rememberUpdatedState(lockAspectRatio)

    val normWidthPct = ((cropRect.right - cropRect.left) * 100f).roundToInt().coerceIn(1, 100)
    val normHeightPct = ((cropRect.bottom - cropRect.top) * 100f).roundToInt().coerceIn(1, 100)

    Dialog(
        onDismissRequest = onDismiss,
        properties = DialogProperties(
            usePlatformDefaultWidth = false,
            decorFitsSystemWindows = false
        )
    ) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .background(Color(0xFF0E0E0E))
                .statusBarsPadding()
                .navigationBarsPadding()
                .testTag("id_crop_studio_dialog")
        ) {
            // Top Bar
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .background(Color(0xFF161616))
                    .padding(horizontal = 8.dp, vertical = 8.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                IconButton(
                    onClick = onDismiss,
                    modifier = Modifier
                        .minimumInteractiveComponentSize()
                        .testTag("id_crop_cancel_btn")
                ) {
                    Icon(
                        imageVector = LucideIcons.X,
                        contentDescription = "Cancel crop",
                        tint = Color.White
                    )
                }

                Column(
                    modifier = Modifier.weight(1f),
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    Text(
                        text = title,
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.SemiBold,
                        color = Color.White
                    )
                    Text(
                        text = "$normWidthPct% × $normHeightPct% · ${if (lockAspectRatio) "ID Ratio Locked" else "Freeform"}",
                        style = MaterialTheme.typography.labelSmall,
                        color = MaterialTheme.colorScheme.primary
                    )
                }

                TextButton(
                    onClick = {
                        lockAspectRatio = false
                        cropRect = NormalizedCropRect(0f, 0f, 1f, 1f)
                    },
                    modifier = Modifier.testTag("id_crop_reset_btn")
                ) {
                    Text("Reset", color = Color.White)
                }
            }

            // Interactive Visual Crop Canvas Workspace
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .weight(1f)
                    .padding(horizontal = 16.dp, vertical = 14.dp)
                    .onSizeChanged { containerSize = it },
                contentAlignment = Alignment.Center
            ) {
                val bmp = sourceBitmap
                if (bmp == null) {
                    CircularProgressIndicator(color = MaterialTheme.colorScheme.primary)
                } else {
                    Image(
                        bitmap = bmp.asImageBitmap(),
                        contentDescription = "ID photo to crop",
                        contentScale = ContentScale.Fit,
                        modifier = Modifier.fillMaxSize()
                    )

                    val accentColor = MaterialTheme.colorScheme.primary
                    Canvas(
                        modifier = Modifier
                            .fillMaxSize()
                            .pointerInput(Unit) {
                                detectDragGestures(
                                    onDragStart = { startOffset ->
                                        activeHandle = detectCropHandle(
                                            point = startOffset,
                                            imageBounds = latestBounds,
                                            crop = latestCrop,
                                            cornerRadiusPx = cornerHitRadiusPx,
                                            edgeRadiusPx = edgeHitRadiusPx
                                        )
                                    },
                                    onDragEnd = { activeHandle = CropDragHandle.NONE },
                                    onDragCancel = { activeHandle = CropDragHandle.NONE },
                                    onDrag = { change, dragAmount ->
                                        if (activeHandle == CropDragHandle.NONE) return@detectDragGestures
                                        val bounds = latestBounds
                                        if (bounds.width <= 1f || bounds.height <= 1f) return@detectDragGestures
                                        change.consume()

                                        val dx = dragAmount.x / bounds.width
                                        val dy = dragAmount.y / bounds.height
                                        val currentBmp = latestBitmap
                                        val normAspect = if (
                                            latestLockRatio &&
                                            currentBmp != null &&
                                            currentBmp.width > 0 &&
                                            currentBmp.height > 0
                                        ) {
                                            aspectRatio * (currentBmp.height.toFloat() / currentBmp.width.toFloat())
                                        } else {
                                            null
                                        }

                                        cropRect = applyCropDrag(
                                            current = latestCrop,
                                            handle = activeHandle,
                                            dx = dx,
                                            dy = dy,
                                            lockedNormalizedRatio = normAspect
                                        )
                                    }
                                )
                            }
                            .testTag("id_crop_interactive_canvas")
                    ) {
                        val bounds = imageBounds
                        if (bounds.width <= 1f || bounds.height <= 1f) return@Canvas

                        val cLeft = bounds.left + cropRect.left * bounds.width
                        val cTop = bounds.top + cropRect.top * bounds.height
                        val cRight = bounds.left + cropRect.right * bounds.width
                        val cBottom = bounds.top + cropRect.bottom * bounds.height
                        val cW = (cRight - cLeft).coerceAtLeast(1f)
                        val cH = (cBottom - cTop).coerceAtLeast(1f)

                        // Darkened scrim outside crop rectangle (within fitted image area)
                        val scrimColor = Color.Black.copy(alpha = 0.64f)
                        drawRect(
                            color = scrimColor,
                            topLeft = Offset(bounds.left, bounds.top),
                            size = Size(bounds.width, (cTop - bounds.top).coerceAtLeast(0f))
                        )
                        drawRect(
                            color = scrimColor,
                            topLeft = Offset(bounds.left, cBottom),
                            size = Size(bounds.width, (bounds.bottom - cBottom).coerceAtLeast(0f))
                        )
                        drawRect(
                            color = scrimColor,
                            topLeft = Offset(bounds.left, cTop),
                            size = Size((cLeft - bounds.left).coerceAtLeast(0f), cH)
                        )
                        drawRect(
                            color = scrimColor,
                            topLeft = Offset(cRight, cTop),
                            size = Size((bounds.right - cRight).coerceAtLeast(0f), cH)
                        )

                        // Rule-of-thirds guide grid inside crop region
                        val gridColor = Color.White.copy(alpha = 0.42f)
                        val gridStroke = 1.dp.toPx()
                        drawLine(gridColor, Offset(cLeft + cW / 3f, cTop), Offset(cLeft + cW / 3f, cBottom), gridStroke)
                        drawLine(gridColor, Offset(cLeft + 2f * cW / 3f, cTop), Offset(cLeft + 2f * cW / 3f, cBottom), gridStroke)
                        drawLine(gridColor, Offset(cLeft, cTop + cH / 3f), Offset(cRight, cTop + cH / 3f), gridStroke)
                        drawLine(gridColor, Offset(cLeft, cTop + 2f * cH / 3f), Offset(cRight, cTop + 2f * cH / 3f), gridStroke)

                        // Crop rectangle border
                        drawRect(
                            color = accentColor,
                            topLeft = Offset(cLeft, cTop),
                            size = Size(cW, cH),
                            style = Stroke(width = 2.dp.toPx())
                        )

                        // Corner L-brackets + circular touch grips
                        val bracketLen = min(22.dp.toPx(), min(cW, cH) * 0.32f)
                        val bracketStroke = 4.dp.toPx()
                        val knobRadius = 7.dp.toPx()

                        // Top-Left
                        drawLine(accentColor, Offset(cLeft, cTop), Offset(cLeft + bracketLen, cTop), bracketStroke, StrokeCap.Round)
                        drawLine(accentColor, Offset(cLeft, cTop), Offset(cLeft, cTop + bracketLen), bracketStroke, StrokeCap.Round)
                        // Top-Right
                        drawLine(accentColor, Offset(cRight, cTop), Offset(cRight - bracketLen, cTop), bracketStroke, StrokeCap.Round)
                        drawLine(accentColor, Offset(cRight, cTop), Offset(cRight, cTop + bracketLen), bracketStroke, StrokeCap.Round)
                        // Bottom-Left
                        drawLine(accentColor, Offset(cLeft, cBottom), Offset(cLeft + bracketLen, cBottom), bracketStroke, StrokeCap.Round)
                        drawLine(accentColor, Offset(cLeft, cBottom), Offset(cLeft, cBottom - bracketLen), bracketStroke, StrokeCap.Round)
                        // Bottom-Right
                        drawLine(accentColor, Offset(cRight, cBottom), Offset(cRight - bracketLen, cBottom), bracketStroke, StrokeCap.Round)
                        drawLine(accentColor, Offset(cRight, cBottom), Offset(cRight, cBottom - bracketLen), bracketStroke, StrokeCap.Round)

                        // Corner anchor dots
                        listOf(
                            Offset(cLeft, cTop),
                            Offset(cRight, cTop),
                            Offset(cLeft, cBottom),
                            Offset(cRight, cBottom)
                        ).forEach { corner ->
                            drawCircle(Color.White, radius = knobRadius, center = corner)
                            drawCircle(accentColor, radius = knobRadius - 2.dp.toPx(), center = corner)
                        }

                        // Mid-edge drag bars (Top, Bottom, Left, Right)
                        val edgeHalf = min(14.dp.toPx(), min(cW, cH) * 0.18f)
                        val edgeStroke = 4.dp.toPx()
                        val midX = (cLeft + cRight) / 2f
                        val midY = (cTop + cBottom) / 2f
                        drawLine(Color.White, Offset(midX - edgeHalf, cTop), Offset(midX + edgeHalf, cTop), edgeStroke, StrokeCap.Round)
                        drawLine(Color.White, Offset(midX - edgeHalf, cBottom), Offset(midX + edgeHalf, cBottom), edgeStroke, StrokeCap.Round)
                        drawLine(Color.White, Offset(cLeft, midY - edgeHalf), Offset(cLeft, midY + edgeHalf), edgeStroke, StrokeCap.Round)
                        drawLine(Color.White, Offset(cRight, midY - edgeHalf), Offset(cRight, midY + edgeHalf), edgeStroke, StrokeCap.Round)
                    }
                }
            }

            // Bottom Control Dock
            Surface(
                color = Color(0xFF181818),
                shape = RoundedCornerShape(topStart = 20.dp, topEnd = 20.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 16.dp, vertical = 14.dp),
                    verticalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    Text(
                        text = "Drag any corner, edge, or inside frame to align card boundaries.",
                        style = MaterialTheme.typography.bodySmall,
                        color = Color(0xFFB8B8B8)
                    )

                    // Quick Presets + Ratio Lock Toggle
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .horizontalScroll(rememberScrollState()),
                        horizontalArrangement = Arrangement.spacedBy(8.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        FilterChip(
                            selected = cropRect.isFullFrame && !lockAspectRatio,
                            onClick = {
                                lockAspectRatio = false
                                cropRect = NormalizedCropRect(0f, 0f, 1f, 1f)
                            },
                            label = { Text("Full") },
                            leadingIcon = {
                                Icon(LucideIcons.Maximize2, contentDescription = null, modifier = Modifier.size(14.dp))
                            },
                            colors = FilterChipDefaults.filterChipColors(
                                selectedContainerColor = MaterialTheme.colorScheme.primary,
                                selectedLabelColor = MaterialTheme.colorScheme.onPrimary,
                                selectedLeadingIconColor = MaterialTheme.colorScheme.onPrimary
                            ),
                            modifier = Modifier.testTag("id_crop_preset_full")
                        )

                        FilterChip(
                            selected = false,
                            onClick = {
                                val bmp = sourceBitmap
                                cropRect = if (bmp != null) {
                                    BitmapFilterEngine.computeCenteredAspectCrop(
                                        imageWidth = bmp.width,
                                        imageHeight = bmp.height,
                                        targetAspectRatio = aspectRatio,
                                        fillFraction = 0.88f
                                    )
                                } else {
                                    NormalizedCropRect(0.06f, 0.14f, 0.94f, 0.86f)
                                }
                            },
                            label = { Text("Card Fit") },
                            leadingIcon = {
                                Icon(LucideIcons.IdCard, contentDescription = null, modifier = Modifier.size(14.dp))
                            },
                            modifier = Modifier.testTag("id_crop_preset_card_fit")
                        )

                        FilterChip(
                            selected = false,
                            onClick = {
                                val bmp = sourceBitmap
                                cropRect = if (bmp != null) {
                                    BitmapFilterEngine.computeCenteredAspectCrop(
                                        imageWidth = bmp.width,
                                        imageHeight = bmp.height,
                                        targetAspectRatio = aspectRatio,
                                        fillFraction = 0.76f
                                    )
                                } else {
                                    NormalizedCropRect(0.12f, 0.20f, 0.88f, 0.80f)
                                }
                            },
                            label = { Text("Tight") },
                            leadingIcon = {
                                Icon(LucideIcons.Minimize2, contentDescription = null, modifier = Modifier.size(14.dp))
                            },
                            modifier = Modifier.testTag("id_crop_preset_tight")
                        )

                        FilterChip(
                            selected = lockAspectRatio,
                            onClick = {
                                val nextLocked = !lockAspectRatio
                                lockAspectRatio = nextLocked
                                if (nextLocked) {
                                    val bmp = sourceBitmap
                                    if (bmp != null && bmp.width > 0 && bmp.height > 0) {
                                        cropRect = fitCropToAspectRatio(
                                            current = cropRect,
                                            lockedNormalizedRatio = aspectRatio * (bmp.height.toFloat() / bmp.width.toFloat())
                                        )
                                    }
                                }
                            },
                            label = { Text(if (lockAspectRatio) "ID Ratio Locked" else "Lock ID Ratio") },
                            leadingIcon = {
                                Icon(
                                    imageVector = if (lockAspectRatio) LucideIcons.Lock else LucideIcons.LockOpen,
                                    contentDescription = null,
                                    modifier = Modifier.size(14.dp)
                                )
                            },
                            colors = FilterChipDefaults.filterChipColors(
                                selectedContainerColor = MaterialTheme.colorScheme.primary,
                                selectedLabelColor = MaterialTheme.colorScheme.onPrimary,
                                selectedLeadingIconColor = MaterialTheme.colorScheme.onPrimary
                            ),
                            modifier = Modifier.testTag("id_crop_ratio_lock_btn")
                        )
                    }

                    // Bottom Action Row: Rotate 90° + Apply Crop
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        OutlinedButton(
                            onClick = {
                                // Rotate crop rectangle 90 degrees clockwise to stay aligned with rotated image
                                cropRect = NormalizedCropRect(
                                    left = 1f - cropRect.bottom,
                                    top = cropRect.left,
                                    right = 1f - cropRect.top,
                                    bottom = cropRect.right
                                ).sanitized()
                                onRotate90()
                            },
                            modifier = Modifier
                                .weight(1f)
                                .height(48.dp)
                                .testTag("id_crop_rotate_btn")
                        ) {
                            Icon(LucideIcons.RotateCw, contentDescription = null, modifier = Modifier.size(18.dp))
                            Spacer(modifier = Modifier.size(6.dp))
                            Text("Rotate 90°")
                        }

                        Button(
                            onClick = { onApplyCrop(cropRect.sanitized()) },
                            colors = ButtonDefaults.buttonColors(
                                containerColor = MaterialTheme.colorScheme.primary,
                                contentColor = MaterialTheme.colorScheme.onPrimary
                            ),
                            modifier = Modifier
                                .weight(1.4f)
                                .height(48.dp)
                                .testTag("id_crop_apply_btn")
                        ) {
                            Icon(LucideIcons.Check, contentDescription = null, modifier = Modifier.size(18.dp))
                            Spacer(modifier = Modifier.size(6.dp))
                            Text("Apply Crop", fontWeight = FontWeight.SemiBold)
                        }
                    }
                }
            }
        }
    }
}

private fun computeFittedImageBounds(containerSize: IntSize, bitmap: Bitmap?): Rect {
    if (containerSize.width <= 0 || containerSize.height <= 0 || bitmap == null || bitmap.width <= 0 || bitmap.height <= 0) {
        return Rect.Zero
    }
    val cw = containerSize.width.toFloat()
    val ch = containerSize.height.toFloat()
    val bw = bitmap.width.toFloat()
    val bh = bitmap.height.toFloat()
    val scale = min(cw / bw, ch / bh)
    val drawW = bw * scale
    val drawH = bh * scale
    val left = (cw - drawW) / 2f
    val top = (ch - drawH) / 2f
    return Rect(left, top, left + drawW, top + drawH)
}

private fun detectCropHandle(
    point: Offset,
    imageBounds: Rect,
    crop: NormalizedCropRect,
    cornerRadiusPx: Float,
    edgeRadiusPx: Float
): CropDragHandle {
    if (imageBounds.width <= 1f || imageBounds.height <= 1f) return CropDragHandle.NONE

    val cL = imageBounds.left + crop.left * imageBounds.width
    val cT = imageBounds.top + crop.top * imageBounds.height
    val cR = imageBounds.left + crop.right * imageBounds.width
    val cB = imageBounds.top + crop.bottom * imageBounds.height

    val cornerDistances = listOf(
        CropDragHandle.TOP_LEFT to hypot(point.x - cL, point.y - cT),
        CropDragHandle.TOP_RIGHT to hypot(point.x - cR, point.y - cT),
        CropDragHandle.BOTTOM_LEFT to hypot(point.x - cL, point.y - cB),
        CropDragHandle.BOTTOM_RIGHT to hypot(point.x - cR, point.y - cB)
    )
    val nearestCorner = cornerDistances.minByOrNull { it.second }
    if (nearestCorner != null && nearestCorner.second <= cornerRadiusPx) {
        return nearestCorner.first
    }

    val withinY = point.y in (cT - edgeRadiusPx)..(cB + edgeRadiusPx)
    val withinX = point.x in (cL - edgeRadiusPx)..(cR + edgeRadiusPx)
    if (withinY && abs(point.x - cL) <= edgeRadiusPx) return CropDragHandle.LEFT
    if (withinY && abs(point.x - cR) <= edgeRadiusPx) return CropDragHandle.RIGHT
    if (withinX && abs(point.y - cT) <= edgeRadiusPx) return CropDragHandle.TOP
    if (withinX && abs(point.y - cB) <= edgeRadiusPx) return CropDragHandle.BOTTOM

    if (point.x in cL..cR && point.y in cT..cB) return CropDragHandle.MOVE
    return CropDragHandle.NONE
}

private fun applyCropDrag(
    current: NormalizedCropRect,
    handle: CropDragHandle,
    dx: Float,
    dy: Float,
    lockedNormalizedRatio: Float?
): NormalizedCropRect {
    if (handle == CropDragHandle.MOVE) {
        val w = current.right - current.left
        val h = current.bottom - current.top
        val nextLeft = (current.left + dx).coerceIn(0f, 1f - w)
        val nextTop = (current.top + dy).coerceIn(0f, 1f - h)
        return NormalizedCropRect(nextLeft, nextTop, nextLeft + w, nextTop + h).sanitized()
    }

    if (lockedNormalizedRatio == null || lockedNormalizedRatio <= 0.05f) {
        var l = current.left
        var t = current.top
        var r = current.right
        var b = current.bottom
        when (handle) {
            CropDragHandle.TOP_LEFT -> {
                l = (l + dx).coerceIn(0f, r - MIN_CROP_SPAN)
                t = (t + dy).coerceIn(0f, b - MIN_CROP_SPAN)
            }
            CropDragHandle.TOP_RIGHT -> {
                r = (r + dx).coerceIn(l + MIN_CROP_SPAN, 1f)
                t = (t + dy).coerceIn(0f, b - MIN_CROP_SPAN)
            }
            CropDragHandle.BOTTOM_LEFT -> {
                l = (l + dx).coerceIn(0f, r - MIN_CROP_SPAN)
                b = (b + dy).coerceIn(t + MIN_CROP_SPAN, 1f)
            }
            CropDragHandle.BOTTOM_RIGHT -> {
                r = (r + dx).coerceIn(l + MIN_CROP_SPAN, 1f)
                b = (b + dy).coerceIn(t + MIN_CROP_SPAN, 1f)
            }
            CropDragHandle.LEFT -> l = (l + dx).coerceIn(0f, r - MIN_CROP_SPAN)
            CropDragHandle.RIGHT -> r = (r + dx).coerceIn(l + MIN_CROP_SPAN, 1f)
            CropDragHandle.TOP -> t = (t + dy).coerceIn(0f, b - MIN_CROP_SPAN)
            CropDragHandle.BOTTOM -> b = (b + dy).coerceIn(t + MIN_CROP_SPAN, 1f)
            else -> Unit
        }
        return NormalizedCropRect(l, t, r, b).sanitized()
    }

    // Aspect-ratio locked dragging
    val ratio = lockedNormalizedRatio
    val minW = maxOf(MIN_CROP_SPAN, MIN_CROP_SPAN * ratio)
    val minH = maxOf(MIN_CROP_SPAN, MIN_CROP_SPAN / ratio)

    return when (handle) {
        CropDragHandle.BOTTOM_RIGHT -> {
            val maxW = min(1f - current.left, (1f - current.top) * ratio)
            val desiredW = ((current.right + dx) - current.left).coerceIn(minW.coerceAtMost(maxW), maxW)
            val desiredH = (desiredW / ratio).coerceIn(minH.coerceAtMost(1f - current.top), 1f - current.top)
            NormalizedCropRect(current.left, current.top, current.left + desiredH * ratio, current.top + desiredH).sanitized()
        }
        CropDragHandle.BOTTOM_LEFT -> {
            val maxW = min(current.right, (1f - current.top) * ratio)
            val desiredW = (current.right - (current.left + dx)).coerceIn(minW.coerceAtMost(maxW), maxW)
            val desiredH = (desiredW / ratio).coerceIn(minH.coerceAtMost(1f - current.top), 1f - current.top)
            NormalizedCropRect(current.right - desiredH * ratio, current.top, current.right, current.top + desiredH).sanitized()
        }
        CropDragHandle.TOP_RIGHT -> {
            val maxW = min(1f - current.left, current.bottom * ratio)
            val desiredW = ((current.right + dx) - current.left).coerceIn(minW.coerceAtMost(maxW), maxW)
            val desiredH = (desiredW / ratio).coerceIn(minH.coerceAtMost(current.bottom), current.bottom)
            NormalizedCropRect(current.left, current.bottom - desiredH, current.left + desiredH * ratio, current.bottom).sanitized()
        }
        CropDragHandle.TOP_LEFT -> {
            val maxW = min(current.right, current.bottom * ratio)
            val desiredW = (current.right - (current.left + dx)).coerceIn(minW.coerceAtMost(maxW), maxW)
            val desiredH = (desiredW / ratio).coerceIn(minH.coerceAtMost(current.bottom), current.bottom)
            NormalizedCropRect(current.right - desiredH * ratio, current.bottom - desiredH, current.right, current.bottom).sanitized()
        }
        CropDragHandle.LEFT, CropDragHandle.RIGHT -> {
            val rawW = if (handle == CropDragHandle.LEFT) {
                current.right - (current.left + dx)
            } else {
                (current.right + dx) - current.left
            }
            val centerY = (current.top + current.bottom) / 2f
            val maxHalfH = min(centerY, 1f - centerY)
            val maxWByEdge = if (handle == CropDragHandle.LEFT) current.right else 1f - current.left
            val maxW = min(maxWByEdge, maxHalfH * 2f * ratio)
            val nextW = rawW.coerceIn(minW.coerceAtMost(maxW), maxW)
            val nextH = nextW / ratio
            val nextL = if (handle == CropDragHandle.LEFT) current.right - nextW else current.left
            val nextR = if (handle == CropDragHandle.LEFT) current.right else current.left + nextW
            NormalizedCropRect(nextL, centerY - nextH / 2f, nextR, centerY + nextH / 2f).sanitized()
        }
        CropDragHandle.TOP, CropDragHandle.BOTTOM -> {
            val rawH = if (handle == CropDragHandle.TOP) {
                current.bottom - (current.top + dy)
            } else {
                (current.bottom + dy) - current.top
            }
            val centerX = (current.left + current.right) / 2f
            val maxHalfW = min(centerX, 1f - centerX)
            val maxHByEdge = if (handle == CropDragHandle.TOP) current.bottom else 1f - current.top
            val maxH = min(maxHByEdge, (maxHalfW * 2f) / ratio)
            val nextH = rawH.coerceIn(minH.coerceAtMost(maxH), maxH)
            val nextW = nextH * ratio
            val nextT = if (handle == CropDragHandle.TOP) current.bottom - nextH else current.top
            val nextB = if (handle == CropDragHandle.TOP) current.bottom else current.top + nextH
            NormalizedCropRect(centerX - nextW / 2f, nextT, centerX + nextW / 2f, nextB).sanitized()
        }
        else -> current
    }
}

private fun fitCropToAspectRatio(
    current: NormalizedCropRect,
    lockedNormalizedRatio: Float
): NormalizedCropRect {
    if (lockedNormalizedRatio <= 0.05f) return current
    val cx = (current.left + current.right) / 2f
    val cy = (current.top + current.bottom) / 2f
    val curW = (current.right - current.left).coerceAtLeast(MIN_CROP_SPAN)
    val curH = (current.bottom - current.top).coerceAtLeast(MIN_CROP_SPAN)

    var newW = curW
    var newH = newW / lockedNormalizedRatio
    if (newH > curH) {
        newH = curH
        newW = newH * lockedNormalizedRatio
    }
    if (newW > 1f) {
        newW = 1f
        newH = newW / lockedNormalizedRatio
    }
    if (newH > 1f) {
        newH = 1f
        newW = newH * lockedNormalizedRatio
    }
    val left = (cx - newW / 2f).coerceIn(0f, (1f - newW).coerceAtLeast(0f))
    val top = (cy - newH / 2f).coerceIn(0f, (1f - newH).coerceAtLeast(0f))
    return NormalizedCropRect(left, top, (left + newW).coerceAtMost(1f), (top + newH).coerceAtMost(1f)).sanitized()
}
