package com.example.ui.icons

import androidx.compose.ui.graphics.vector.ImageVector

/**
 * Unified Lucide icon facade (24x24 viewport, 2px stroke, rounded caps & joins)
 * used consistently across the entire DocuScan app.
 */
object LucideIcons {
    // Navigation & Core Actions
    val Home: ImageVector get() = LucideNavIcons.Home
    val Settings: ImageVector get() = LucideNavIcons.Settings
    val Wrench: ImageVector get() = LucideNavIcons.Wrench
    val Search: ImageVector get() = LucideNavIcons.Search
    val X: ImageVector get() = LucideNavIcons.X
    val Check: ImageVector get() = LucideNavIcons.Check
    val CircleCheck: ImageVector get() = LucideNavIcons.CircleCheck
    val CheckSquare: ImageVector get() = LucideNavIcons.CheckSquare
    val ArrowLeft: ImageVector get() = LucideNavIcons.ArrowLeft
    val ArrowRight: ImageVector get() = LucideNavIcons.ArrowRight
    val ArrowUp: ImageVector get() = LucideNavIcons.ArrowUp
    val ArrowDown: ImageVector get() = LucideNavIcons.ArrowDown
    val ChevronLeft: ImageVector get() = LucideNavIcons.ChevronLeft
    val ChevronRight: ImageVector get() = LucideNavIcons.ChevronRight
    val Delete: ImageVector get() = LucideNavIcons.Delete
    val MoreVertical: ImageVector get() = LucideNavIcons.MoreVertical
    val Share2: ImageVector get() = LucideNavIcons.Share2
    val Download: ImageVector get() = LucideNavIcons.Download
    val Save: ImageVector get() = LucideNavIcons.Save
    val Trash2: ImageVector get() = LucideNavIcons.Trash2
    val RotateCw: ImageVector get() = LucideNavIcons.RotateCw
    val RotateCcw: ImageVector get() = LucideNavIcons.RotateCcw
    val RefreshCw: ImageVector get() = LucideNavIcons.RefreshCw
    val Undo2: ImageVector get() = LucideNavIcons.Undo2
    val Pencil: ImageVector get() = LucideNavIcons.Pencil
    val Copy: ImageVector get() = LucideNavIcons.Copy
    val CopyPlus: ImageVector get() = LucideNavIcons.CopyPlus
    val ExternalLink: ImageVector get() = LucideNavIcons.ExternalLink
    val ArrowUpDown: ImageVector get() = LucideNavIcons.ArrowUpDown
    val LayoutGrid: ImageVector get() = LucideNavIcons.LayoutGrid
    val List: ImageVector get() = LucideNavIcons.List
    val ListOrdered: ImageVector get() = LucideNavIcons.ListOrdered
    val ZoomIn: ImageVector get() = LucideNavIcons.ZoomIn
    val ZoomOut: ImageVector get() = LucideNavIcons.ZoomOut

    // Documents, Scanning & Media
    val ScanLine: ImageVector get() = LucideDocIcons.ScanLine
    val FileText: ImageVector get() = LucideDocIcons.FileText
    val FileUp: ImageVector get() = LucideDocIcons.FileUp
    val FilePen: ImageVector get() = LucideDocIcons.FilePen
    val Folder: ImageVector get() = LucideDocIcons.Folder
    val FolderOpen: ImageVector get() = LucideDocIcons.FolderOpen
    val FolderPlus: ImageVector get() = LucideDocIcons.FolderPlus
    val FolderInput: ImageVector get() = LucideDocIcons.FolderInput
    val Folders: ImageVector get() = LucideDocIcons.Folders
    val Image: ImageVector get() = LucideDocIcons.Image
    val Images: ImageVector get() = LucideDocIcons.Images
    val ImagePlus: ImageVector get() = LucideDocIcons.ImagePlus
    val Camera: ImageVector get() = LucideDocIcons.Camera
    val IdCard: ImageVector get() = LucideDocIcons.IdCard
    val PenTool: ImageVector get() = LucideDocIcons.PenTool
    val Printer: ImageVector get() = LucideDocIcons.Printer
    val Layers: ImageVector get() = LucideDocIcons.Layers
    val LayersOff: ImageVector get() = LucideDocIcons.LayersOff
    val Scissors: ImageVector get() = LucideDocIcons.Scissors
    val Merge: ImageVector get() = LucideDocIcons.Merge
    val Archive: ImageVector get() = LucideDocIcons.Archive
    val Star: ImageVector get() = LucideDocIcons.Star
    val StarFilled: ImageVector get() = LucideDocIcons.StarFilled
    val Bookmark: ImageVector get() = LucideDocIcons.Bookmark
    val BookmarkFilled: ImageVector get() = LucideDocIcons.BookmarkFilled
    val Pin: ImageVector get() = LucideDocIcons.Pin

    // Security, Settings & PDF Utilities
    val Lock: ImageVector get() = LucideSecurityAndToolIcons.Lock
    val LockOpen: ImageVector get() = LucideSecurityAndToolIcons.LockOpen
    val Shield: ImageVector get() = LucideSecurityAndToolIcons.Shield
    val ShieldCheck: ImageVector get() = LucideSecurityAndToolIcons.ShieldCheck
    val Fingerprint: ImageVector get() = LucideSecurityAndToolIcons.Fingerprint
    val KeyRound: ImageVector get() = LucideSecurityAndToolIcons.KeyRound
    val Eye: ImageVector get() = LucideSecurityAndToolIcons.Eye
    val Palette: ImageVector get() = LucideSecurityAndToolIcons.Palette
    val Globe: ImageVector get() = LucideSecurityAndToolIcons.Globe
    val Languages: ImageVector get() = LucideSecurityAndToolIcons.Languages
    val Type: ImageVector get() = LucideSecurityAndToolIcons.Type
    val Sparkles: ImageVector get() = LucideSecurityAndToolIcons.Sparkles
    val SlidersHorizontal: ImageVector get() = LucideSecurityAndToolIcons.SlidersHorizontal
    val HardDrive: ImageVector get() = LucideSecurityAndToolIcons.HardDrive
    val DatabaseBackup: ImageVector get() = LucideSecurityAndToolIcons.DatabaseBackup
    val CloudOff: ImageVector get() = LucideSecurityAndToolIcons.CloudOff
    val Info: ImageVector get() = LucideSecurityAndToolIcons.Info
    val CircleAlert: ImageVector get() = LucideSecurityAndToolIcons.CircleAlert
    val TriangleAlert: ImageVector get() = LucideSecurityAndToolIcons.TriangleAlert
    val Crop: ImageVector get() = LucideSecurityAndToolIcons.Crop
    val Move: ImageVector get() = LucideSecurityAndToolIcons.Move
    val Maximize2: ImageVector get() = LucideSecurityAndToolIcons.Maximize2
    val Minimize2: ImageVector get() = LucideSecurityAndToolIcons.Minimize2
    val Droplet: ImageVector get() = LucideSecurityAndToolIcons.Droplet
    val Eraser: ImageVector get() = LucideSecurityAndToolIcons.Eraser
    val Gauge: ImageVector get() = LucideSecurityAndToolIcons.Gauge
}
