package com.example.ui.screens

import android.Manifest
import android.content.pm.PackageManager
import android.graphics.Bitmap
import android.net.Uri
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.PickVisualMediaRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.WindowInsetsSides
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.only
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.safeDrawing
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Checkbox
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FilterChipDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.SnackbarHost
import androidx.compose.material3.SnackbarHostState
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.minimumInteractiveComponentSize
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.produceState
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.unit.dp
import androidx.core.content.ContextCompat
import androidx.core.content.FileProvider
import com.example.domain.model.DocumentItem
import com.example.domain.model.IdDocumentType
import com.example.domain.model.IdSideScanState
import com.example.domain.model.NormalizedCropRect
import com.example.domain.model.ScanFilter
import com.example.scanner.BitmapFilterEngine
import com.example.ui.components.DocuScanCard
import com.example.ui.components.DocuScanTopBar
import com.example.ui.icons.LucideIcons
import com.example.ui.viewmodel.OperationState
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.File

private const val SIDE_FRONT = "FRONT"
private const val SIDE_BACK = "BACK"

@Composable
fun IdScannerScreen(
    selectedType: IdDocumentType,
    frontSide: IdSideScanState,
    backSide: IdSideScanState,
    singleCombinedSheet: Boolean,
    operationState: OperationState,
    createCameraTempFile: () -> File,
    onSelectDocumentType: (IdDocumentType) -> Unit,
    onSetSingleCombinedSheet: (Boolean) -> Unit,
    onPickFrontUri: (Uri) -> Unit,
    onPickBackUri: (Uri) -> Unit,
    onCaptureFrontFile: (File) -> Unit,
    onCaptureBackFile: (File) -> Unit,
    onUpdateSideCrop: (isFront: Boolean, NormalizedCropRect) -> Unit,
    onUpdateSideFilter: (isFront: Boolean, ScanFilter) -> Unit,
    onRotateSide: (isFront: Boolean) -> Unit,
    onClearSide: (isFront: Boolean) -> Unit,
    onGenerateIdPdf: (title: String, password: String?, onCreated: (DocumentItem) -> Unit) -> Unit,
    onPdfCreated: (Long) -> Unit,
    onClearOperationError: () -> Unit,
    onBack: () -> Unit
) {
    val context = LocalContext.current
    val snackbarHostState = remember { SnackbarHostState() }
    val coroutineScope = rememberCoroutineScope()

    var filename by remember(selectedType) {
        mutableStateOf("${selectedType.displayName.replace(" ", "_")}_Scan_${System.currentTimeMillis() % 10000}")
    }
    var protectWithPassword by rememberSaveable { mutableStateOf(false) }
    var pdfPassword by rememberSaveable { mutableStateOf("") }

    var activeCameraSide by rememberSaveable { mutableStateOf<String?>(null) }
    var cropTargetSide by rememberSaveable { mutableStateOf<String?>(null) }

    // Persist pending system-camera path across configuration changes & external activity launches
    var pendingSystemCameraPath by rememberSaveable { mutableStateOf<String?>(null) }
    var pendingSystemCameraSide by rememberSaveable { mutableStateOf<String?>(null) }
    var pendingPermissionSide by rememberSaveable { mutableStateOf<String?>(null) }

    val frontGalleryPicker = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.PickVisualMedia(),
        onResult = { uri ->
            if (uri != null) {
                onPickFrontUri(uri)
            }
        }
    )
    val backGalleryPicker = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.PickVisualMedia(),
        onResult = { uri ->
            if (uri != null) {
                onPickBackUri(uri)
            }
        }
    )

    val systemCameraLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.TakePicture()
    ) { saved ->
        val path = pendingSystemCameraPath
        val side = pendingSystemCameraSide
        pendingSystemCameraPath = null
        pendingSystemCameraSide = null

        val capturedFile = path?.let { File(it) }
        if (saved && capturedFile != null && capturedFile.exists() && capturedFile.length() > 0L) {
            if (side == SIDE_BACK) {
                onCaptureBackFile(capturedFile)
                cropTargetSide = SIDE_BACK
            } else {
                onCaptureFrontFile(capturedFile)
                cropTargetSide = SIDE_FRONT
            }
        } else if (saved) {
            coroutineScope.launch {
                snackbarHostState.showSnackbar("Camera photo could not be saved. Please try again.")
            }
        }
    }

    fun launchSystemCameraNow(side: String) {
        runCatching {
            val temp = createCameraTempFile()
            pendingSystemCameraPath = temp.absolutePath
            pendingSystemCameraSide = side
            val uri = FileProvider.getUriForFile(context, "${context.packageName}.fileprovider", temp)
            systemCameraLauncher.launch(uri)
        }.onFailure { err ->
            pendingSystemCameraPath = null
            pendingSystemCameraSide = null
            coroutineScope.launch {
                snackbarHostState.showSnackbar(err.message ?: "No system camera app available on this device.")
            }
        }
    }

    val systemCameraPermissionLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.RequestPermission()
    ) { granted ->
        val side = pendingPermissionSide
        pendingPermissionSide = null
        if (granted && side != null) {
            launchSystemCameraNow(side)
        } else if (!granted) {
            coroutineScope.launch {
                snackbarHostState.showSnackbar("Camera permission is required to take a photo.")
            }
        }
    }

    fun requestAndLaunchSystemCamera(side: String) {
        val granted = ContextCompat.checkSelfPermission(context, Manifest.permission.CAMERA) ==
            PackageManager.PERMISSION_GRANTED
        if (granted) {
            launchSystemCameraNow(side)
        } else {
            pendingPermissionSide = side
            systemCameraPermissionLauncher.launch(Manifest.permission.CAMERA)
        }
    }

    LaunchedEffect(operationState) {
        if (operationState is OperationState.Error) {
            snackbarHostState.showSnackbar(operationState.message)
            onClearOperationError()
        }
    }

    Box(modifier = Modifier.fillMaxSize()) {
        Scaffold(
            modifier = Modifier.fillMaxSize(),
            containerColor = MaterialTheme.colorScheme.background,
            contentWindowInsets = WindowInsets.safeDrawing.only(
                WindowInsetsSides.Bottom + WindowInsetsSides.Horizontal
            ),
            snackbarHost = { SnackbarHost(snackbarHostState) },
        topBar = {
            DocuScanTopBar(
                title = "ID Document Scanner",
                subtitle = "${selectedType.displayName} · Local PDF Builder",
                onBack = onBack
            )
        }
    ) { innerPadding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
                .verticalScroll(rememberScrollState())
                .padding(horizontal = 16.dp, vertical = 12.dp),
            verticalArrangement = Arrangement.spacedBy(14.dp)
        ) {
            // Local-only privacy disclaimer
            DocuScanCard(highlighted = true) {
                Row(
                    horizontalArrangement = Arrangement.spacedBy(10.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Icon(
                        imageVector = LucideIcons.Shield,
                        contentDescription = "Local Storage Privacy",
                        tint = MaterialTheme.colorScheme.primary
                    )
                    Column(verticalArrangement = Arrangement.spacedBy(2.dp)) {
                        Text("Offline Local Storage Only", style = MaterialTheme.typography.titleSmall)
                        Text(
                            text = "DocuScan saves cropped, enhanced ID scans privately on your device. No auto-extraction, no cloud upload, and no identity verification are performed.",
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                }
            }

            // Document Type Workflow Picker
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Text("Select ID Workflow", style = MaterialTheme.typography.titleSmall)
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .horizontalScroll(rememberScrollState()),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    IdDocumentType.entries.forEach { docType ->
                        FilterChip(
                            selected = selectedType == docType,
                            onClick = { onSelectDocumentType(docType) },
                            label = { Text(docType.displayName) },
                            colors = FilterChipDefaults.filterChipColors(
                                selectedContainerColor = MaterialTheme.colorScheme.primary,
                                selectedLabelColor = MaterialTheme.colorScheme.onPrimary
                            ),
                            modifier = Modifier.testTag("id_type_${docType.name.lowercase()}")
                        )
                    }
                }
                Text(
                    text = "${selectedType.displayName}: ${selectedType.subtitle}",
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }

            // User-controlled Filename
            OutlinedTextField(
                value = filename,
                onValueChange = { filename = it },
                label = { Text("Output PDF Filename") },
                singleLine = true,
                modifier = Modifier
                    .fillMaxWidth()
                    .testTag("id_filename_input")
            )

            // Front Side Workflow Card
            IdSideEditorCard(
                title = "Front Side",
                stepBadge = if (frontSide.imagePath != null) "Captured" else "Step 1 · Required",
                sideState = frontSide,
                aspectRatio = selectedType.aspectRatio,
                cameraTestTag = "id_camera_front_btn",
                galleryTestTag = "id_pick_front_btn",
                cropTestTag = "id_crop_front_btn",
                rotateTestTag = "id_rotate_front_btn",
                onTakePhoto = { activeCameraSide = SIDE_FRONT },
                onPickGallery = {
                    frontGalleryPicker.launch(PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageOnly))
                },
                onOpenCrop = { cropTargetSide = SIDE_FRONT },
                onRotate = { onRotateSide(true) },
                onSelectFilter = { onUpdateSideFilter(true, it) },
                onClear = { onClearSide(true) }
            )

            // Back Side Workflow Card
            IdSideEditorCard(
                title = selectedType.backSlotLabel,
                stepBadge = when {
                    backSide.imagePath != null -> "Captured"
                    selectedType.requiresBackSide -> "Step 2 · Recommended"
                    else -> "Step 2 · Optional"
                },
                sideState = backSide,
                aspectRatio = selectedType.aspectRatio,
                cameraTestTag = "id_camera_back_btn",
                galleryTestTag = "id_pick_back_btn",
                cropTestTag = "id_crop_back_btn",
                rotateTestTag = "id_rotate_back_btn",
                onTakePhoto = { activeCameraSide = SIDE_BACK },
                onPickGallery = {
                    backGalleryPicker.launch(PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageOnly))
                },
                onOpenCrop = { cropTargetSide = SIDE_BACK },
                onRotate = { onRotateSide(false) },
                onSelectFilter = { onUpdateSideFilter(false, it) },
                onClear = { onClearSide(false) }
            )

            // PDF Layout & Privacy Options
            DocuScanCard {
                Text("PDF Layout & Local Protection", style = MaterialTheme.typography.titleSmall)
                Spacer(modifier = Modifier.height(8.dp))
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clickable { onSetSingleCombinedSheet(!singleCombinedSheet) },
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Checkbox(
                        checked = singleCombinedSheet,
                        onCheckedChange = onSetSingleCombinedSheet
                    )
                    Column {
                        Text("Combine both sides onto 1 A4 page", style = MaterialTheme.typography.bodyMedium)
                        Text(
                            text = if (singleCombinedSheet) "Front (top) & Back (bottom) on one sheet" else "Each side on its own A4 page",
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                }
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clickable { protectWithPassword = !protectWithPassword },
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Checkbox(
                        checked = protectWithPassword,
                        onCheckedChange = { protectWithPassword = it }
                    )
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        Icon(LucideIcons.Lock, contentDescription = null, modifier = Modifier.size(16.dp))
                        Text("Encrypt PDF with password", style = MaterialTheme.typography.bodyMedium)
                    }
                }
                if (protectWithPassword) {
                    Spacer(modifier = Modifier.height(6.dp))
                    OutlinedTextField(
                        value = pdfPassword,
                        onValueChange = { pdfPassword = it },
                        label = { Text("PDF Password") },
                        visualTransformation = PasswordVisualTransformation(),
                        singleLine = true,
                        modifier = Modifier
                            .fillMaxWidth()
                            .testTag("id_password_input")
                    )
                }
            }

            val isWorking = operationState is OperationState.Working
            Button(
                onClick = {
                    val pwd = if (protectWithPassword) pdfPassword else null
                    onGenerateIdPdf(filename, pwd) { created -> onPdfCreated(created.id) }
                },
                enabled = !frontSide.imagePath.isNullOrBlank() &&
                    filename.isNotBlank() &&
                    (!protectWithPassword || pdfPassword.isNotBlank()) &&
                    !isWorking,
                colors = ButtonDefaults.buttonColors(
                    containerColor = MaterialTheme.colorScheme.primary,
                    contentColor = MaterialTheme.colorScheme.onPrimary
                ),
                shape = MaterialTheme.shapes.medium,
                modifier = Modifier
                    .fillMaxWidth()
                    .height(54.dp)
                    .minimumInteractiveComponentSize()
                    .testTag("id_generate_pdf_btn")
            ) {
                if (isWorking) {
                    CircularProgressIndicator(
                        color = MaterialTheme.colorScheme.onPrimary,
                        modifier = Modifier.size(20.dp),
                        strokeWidth = 2.dp
                    )
                    Spacer(modifier = Modifier.size(8.dp))
                    Text("Building Local ID PDF...")
                } else {
                    Icon(LucideIcons.FileText, contentDescription = null, modifier = Modifier.size(20.dp))
                    Spacer(modifier = Modifier.size(8.dp))
                    Text("Save ${selectedType.displayName} PDF")
                }
            }
        }
    }

    // Guided In-App CameraX Overlay (Front or Back)
    val cameraSide = activeCameraSide
    if (cameraSide != null) {
        val isFrontCamera = cameraSide == SIDE_FRONT
        IdCardCameraOverlay(
            sideTitle = if (isFrontCamera) "Front Side" else selectedType.backSlotLabel,
            documentName = selectedType.displayName,
            aspectRatio = selectedType.aspectRatio,
            createCameraTempFile = createCameraTempFile,
            onCapturedFile = { file ->
                activeCameraSide = null
                if (isFrontCamera) {
                    onCaptureFrontFile(file)
                    cropTargetSide = SIDE_FRONT
                } else {
                    onCaptureBackFile(file)
                    cropTargetSide = SIDE_BACK
                }
            },
            onLaunchSystemCameraFallback = {
                activeCameraSide = null
                requestAndLaunchSystemCamera(cameraSide)
            },
            onPickFromDeviceFallback = {
                activeCameraSide = null
                if (isFrontCamera) {
                    frontGalleryPicker.launch(PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageOnly))
                } else {
                    backGalleryPicker.launch(PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageOnly))
                }
            },
            onDismiss = { activeCameraSide = null }
        )
    }

    // Full-Screen Interactive Visual Crop Studio (Front or Back)
    val cropSide = cropTargetSide
    if (cropSide != null) {
        val isFrontCrop = cropSide == SIDE_FRONT
        val sideState = if (isFrontCrop) frontSide else backSide
        if (!sideState.imagePath.isNullOrBlank()) {
            IdCardCropStudioDialog(
                title = if (isFrontCrop) "Crop Front Side" else "Crop ${selectedType.backSlotLabel}",
                sideState = sideState,
                aspectRatio = selectedType.aspectRatio,
                onRotate90 = { onRotateSide(isFrontCrop) },
                onDismiss = { cropTargetSide = null },
                    onApplyCrop = { newRect ->
                        onUpdateSideCrop(isFrontCrop, newRect)
                        cropTargetSide = null
                    }
                )
            }
        }
    }
}

@Composable
private fun IdSideEditorCard(
    title: String,
    stepBadge: String,
    sideState: IdSideScanState,
    aspectRatio: Float,
    cameraTestTag: String,
    galleryTestTag: String,
    cropTestTag: String,
    rotateTestTag: String,
    onTakePhoto: () -> Unit,
    onPickGallery: () -> Unit,
    onOpenCrop: () -> Unit,
    onRotate: () -> Unit,
    onSelectFilter: (ScanFilter) -> Unit,
    onClear: () -> Unit
) {
    val previewBitmap by produceState<Bitmap?>(
        initialValue = null,
        key1 = sideState.imagePath,
        key2 = sideState.cropRect,
        key3 = Pair(sideState.rotationDegrees, sideState.filter)
    ) {
        val path = sideState.imagePath
        value = if (path.isNullOrBlank()) {
            null
        } else {
            withContext(Dispatchers.IO) {
                val raw = BitmapFilterEngine.decodeSampledBitmap(path, maxDimension = 900)
                raw?.let {
                    BitmapFilterEngine.cropAndTransform(
                        source = it,
                        cropRect = sideState.cropRect,
                        rotationDegrees = sideState.rotationDegrees,
                        filter = sideState.filter
                    )
                }
            }
        }
    }

    DocuScanCard {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Row(
                modifier = Modifier.weight(1f),
                horizontalArrangement = Arrangement.spacedBy(8.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(text = title, style = MaterialTheme.typography.titleMedium)
                Surface(
                    shape = RoundedCornerShape(999.dp),
                    color = if (sideState.imagePath != null) {
                        MaterialTheme.colorScheme.primary.copy(alpha = 0.16f)
                    } else {
                        MaterialTheme.colorScheme.surfaceVariant
                    }
                ) {
                    Text(
                        text = stepBadge,
                        style = MaterialTheme.typography.labelSmall,
                        fontWeight = FontWeight.Medium,
                        color = if (sideState.imagePath != null) {
                            MaterialTheme.colorScheme.primary
                        } else {
                            MaterialTheme.colorScheme.onSurfaceVariant
                        },
                        modifier = Modifier.padding(horizontal = 8.dp, vertical = 3.dp)
                    )
                }
            }
            if (sideState.imagePath != null) {
                IconButton(onClick = onClear, modifier = Modifier.size(36.dp)) {
                    Icon(LucideIcons.X, contentDescription = "Clear $title")
                }
            }
        }

        Spacer(modifier = Modifier.height(8.dp))
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .aspectRatio(aspectRatio)
                .clip(RoundedCornerShape(14.dp))
                .background(MaterialTheme.colorScheme.surface)
                .border(1.dp, MaterialTheme.colorScheme.outline, RoundedCornerShape(14.dp))
                .clickable(enabled = sideState.imagePath != null, onClick = onOpenCrop),
            contentAlignment = Alignment.Center
        ) {
            val bmp = previewBitmap
            if (bmp != null) {
                Image(
                    bitmap = bmp.asImageBitmap(),
                    contentDescription = "$title preview, tap to crop",
                    contentScale = ContentScale.Fit,
                    modifier = Modifier.fillMaxSize()
                )
                Surface(
                    shape = RoundedCornerShape(999.dp),
                    color = Color.Black.copy(alpha = 0.68f),
                    modifier = Modifier
                        .align(Alignment.BottomEnd)
                        .padding(8.dp)
                ) {
                    Row(
                        modifier = Modifier.padding(horizontal = 10.dp, vertical = 5.dp),
                        horizontalArrangement = Arrangement.spacedBy(4.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Icon(
                            imageVector = LucideIcons.Crop,
                            contentDescription = null,
                            tint = MaterialTheme.colorScheme.primary,
                            modifier = Modifier.size(13.dp)
                        )
                        Text(
                            text = if (sideState.cropRect.isFullFrame) "Tap to Crop" else "Cropped",
                            style = MaterialTheme.typography.labelSmall,
                            color = Color.White
                        )
                    }
                }
            } else {
                Column(
                    horizontalAlignment = Alignment.CenterHorizontally,
                    verticalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    Icon(
                        imageVector = LucideIcons.IdCard,
                        contentDescription = null,
                        tint = MaterialTheme.colorScheme.primary,
                        modifier = Modifier.size(32.dp)
                    )
                    Text(
                        text = "Capture or choose $title",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
            }
        }

        Spacer(modifier = Modifier.height(10.dp))
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            OutlinedButton(
                onClick = onTakePhoto,
                modifier = Modifier
                    .weight(1f)
                    .minimumInteractiveComponentSize()
                    .testTag(cameraTestTag)
            ) {
                Icon(LucideIcons.Camera, contentDescription = null, modifier = Modifier.size(16.dp))
                Spacer(modifier = Modifier.size(6.dp))
                Text("Camera")
            }
            OutlinedButton(
                onClick = onPickGallery,
                modifier = Modifier
                    .weight(1f)
                    .minimumInteractiveComponentSize()
                    .testTag(galleryTestTag)
            ) {
                Icon(LucideIcons.Images, contentDescription = null, modifier = Modifier.size(16.dp))
                Spacer(modifier = Modifier.size(6.dp))
                Text("From Device")
            }
        }

        if (sideState.imagePath != null) {
            Spacer(modifier = Modifier.height(8.dp))
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                OutlinedButton(
                    onClick = onOpenCrop,
                    modifier = Modifier
                        .weight(1f)
                        .minimumInteractiveComponentSize()
                        .testTag(cropTestTag)
                ) {
                    Icon(LucideIcons.Crop, contentDescription = null, modifier = Modifier.size(16.dp))
                    Spacer(modifier = Modifier.size(6.dp))
                    Text(if (sideState.cropRect.isFullFrame) "Crop Studio" else "Edit Crop")
                }
                OutlinedButton(
                    onClick = onRotate,
                    modifier = Modifier
                        .weight(1f)
                        .minimumInteractiveComponentSize()
                        .testTag(rotateTestTag)
                ) {
                    Icon(LucideIcons.RotateCw, contentDescription = null, modifier = Modifier.size(16.dp))
                    Spacer(modifier = Modifier.size(6.dp))
                    Text("Rotate (${sideState.rotationDegrees}°)")
                }
            }

            Spacer(modifier = Modifier.height(8.dp))
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .horizontalScroll(rememberScrollState()),
                horizontalArrangement = Arrangement.spacedBy(6.dp)
            ) {
                ScanFilter.entries.forEach { filter ->
                    FilterChip(
                        selected = sideState.filter == filter,
                        onClick = { onSelectFilter(filter) },
                        label = { Text(filter.label) },
                        colors = FilterChipDefaults.filterChipColors(
                            selectedContainerColor = MaterialTheme.colorScheme.primary,
                            selectedLabelColor = MaterialTheme.colorScheme.onPrimary
                        )
                    )
                }
            }
        }
    }
}
