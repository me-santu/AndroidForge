package com.example.pdf

import android.content.Context
import android.graphics.Bitmap
import com.example.domain.model.PdfCreationOptions
import com.example.domain.model.PdfDocxConversionResult
import com.example.domain.model.PdfImageFormat
import com.example.domain.model.PdfOrientation
import com.example.domain.model.PdfPageSize
import com.example.domain.model.PdfTextExtractionResult
import com.tom_roush.pdfbox.android.PDFBoxResourceLoader
import com.tom_roush.pdfbox.io.MemoryUsageSetting
import com.tom_roush.pdfbox.pdmodel.PDDocument
import com.tom_roush.pdfbox.pdmodel.PDPage
import com.tom_roush.pdfbox.pdmodel.PDPageContentStream
import com.tom_roush.pdfbox.pdmodel.common.PDRectangle
import com.tom_roush.pdfbox.pdmodel.encryption.AccessPermission
import com.tom_roush.pdfbox.pdmodel.encryption.InvalidPasswordException
import com.tom_roush.pdfbox.pdmodel.encryption.StandardProtectionPolicy
import com.tom_roush.pdfbox.pdmodel.font.PDType1Font
import com.tom_roush.pdfbox.text.PDFTextStripper
import kotlinx.coroutines.CoroutineDispatcher
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.io.ByteArrayOutputStream
import java.io.File
import java.io.FileOutputStream
import java.util.zip.ZipEntry
import java.util.zip.ZipOutputStream
import kotlin.math.max
import kotlin.math.min

class PdfConversionEngine(
    private val context: Context? = null,
    private val rendererHelper: PdfRendererHelper = PdfRendererHelper(context = context),
    private val ioDispatcher: CoroutineDispatcher = Dispatchers.IO
) {

    private fun ensurePdfBoxReady() {
        if (context != null && !PDFBoxResourceLoader.isReady()) {
            PDFBoxResourceLoader.init(context.applicationContext)
        }
    }

    private fun loadDocument(file: File, password: String? = null): PDDocument {
        ensurePdfBoxReady()
        require(file.exists() && file.length() > 0L) { "PDF file does not exist or is empty." }
        return try {
            val mem = MemoryUsageSetting.setupTempFileOnly()
            if (!password.isNullOrEmpty()) {
                PDDocument.load(file, password, mem)
            } else {
                PDDocument.load(file, mem)
            }
        } catch (e: InvalidPasswordException) {
            throw IllegalStateException(
                if (password.isNullOrEmpty()) {
                    "This PDF is password protected. Enter the password to convert it."
                } else {
                    "Incorrect PDF password. Please verify and try again."
                },
                e
            )
        }
    }

    suspend fun createPdfFromText(
        text: String,
        headerTitle: String = "",
        outputFile: File,
        pageSize: PdfPageSize = PdfPageSize.A4,
        orientation: PdfOrientation = PdfOrientation.PORTRAIT,
        marginPt: Float = 40f,
        fontSizePt: Float = 12f,
        includePageNumbers: Boolean = true,
        password: String = ""
    ): Int = withContext(ioDispatcher) {
        val trimmed = text.trim()
        require(trimmed.isNotEmpty()) { "Enter or import text content to convert to PDF." }
        ensurePdfBoxReady()

        val baseW = if (pageSize == PdfPageSize.FIT_IMAGE) 595f else pageSize.widthPt.toFloat().coerceAtLeast(300f)
        val baseH = if (pageSize == PdfPageSize.FIT_IMAGE) 842f else pageSize.heightPt.toFloat().coerceAtLeast(400f)
        val pageW = if (orientation == PdfOrientation.LANDSCAPE) max(baseW, baseH) else min(baseW, baseH)
        val pageH = if (orientation == PdfOrientation.LANDSCAPE) min(baseW, baseH) else max(baseW, baseH)

        val safeMargin = marginPt.coerceIn(18f, 84f)
        val safeFontSize = fontSizePt.coerceIn(8f, 24f)
        val leading = safeFontSize * 1.42f
        val font = PDType1Font.HELVETICA
        val boldFont = PDType1Font.HELVETICA_BOLD
        val maxLineWidth = (pageW - safeMargin * 2f).coerceAtLeast(100f)
        val topY = pageH - safeMargin - (if (headerTitle.isNotBlank()) 28f else 0f)
        val bottomY = safeMargin + (if (includePageNumbers) 22f else 0f)
        val linesPerPage = ((topY - bottomY) / leading).toInt().coerceAtLeast(4)

        val wrappedLines = wrapParagraphs(trimmed, font, safeFontSize, maxLineWidth)
        val pageChunks = wrappedLines.chunked(linesPerPage).ifEmpty { listOf(emptyList()) }

        PDDocument(MemoryUsageSetting.setupTempFileOnly()).use { doc ->
            val totalPages = pageChunks.size
            pageChunks.forEachIndexed { idx, lines ->
                val page = PDPage(PDRectangle(pageW, pageH))
                doc.addPage(page)
                PDPageContentStream(doc, page).use { stream ->
                    if (idx == 0 && headerTitle.isNotBlank()) {
                        stream.beginText()
                        stream.setFont(boldFont, safeFontSize + 3f)
                        stream.setNonStrokingColor(0.1f, 0.1f, 0.1f)
                        stream.newLineAtOffset(safeMargin, pageH - safeMargin)
                        stream.showText(sanitizePdfWinAnsi(headerTitle.trim()).take(90))
                        stream.endText()
                    }

                    var y = topY
                    stream.setFont(font, safeFontSize)
                    stream.setNonStrokingColor(0.08f, 0.08f, 0.08f)
                    lines.forEach { line ->
                        if (line.isNotEmpty()) {
                            stream.beginText()
                            stream.newLineAtOffset(safeMargin, y)
                            stream.showText(line)
                            stream.endText()
                        }
                        y -= leading
                    }

                    if (includePageNumbers) {
                        val footerLabel = "Page ${idx + 1} of $totalPages"
                        val lw = font.getStringWidth(footerLabel) / 1000f * 9.5f
                        stream.beginText()
                        stream.setFont(font, 9.5f)
                        stream.setNonStrokingColor(0.4f, 0.4f, 0.4f)
                        stream.newLineAtOffset(((pageW - lw) / 2f).coerceAtLeast(12f), 14f)
                        stream.showText(footerLabel)
                        stream.endText()
                    }
                }
            }

            if (password.isNotBlank()) {
                val perm = AccessPermission().apply {
                    setCanPrint(true)
                    setCanModify(false)
                    setCanExtractContent(true)
                }
                val policy = StandardProtectionPolicy(password, password, perm).apply {
                    encryptionKeyLength = 128
                }
                doc.protect(policy)
            }

            doc.save(outputFile)
            totalPages
        }
    }

    private fun wrapParagraphs(
        text: String,
        font: PDType1Font,
        fontSize: Float,
        maxWidth: Float
    ): List<String> {
        val result = mutableListOf<String>()
        text.replace("\r\n", "\n").replace("\r", "\n").split("\n").forEach { rawPara ->
            val para = sanitizePdfWinAnsi(rawPara)
            if (para.isBlank()) {
                result.add("")
                return@forEach
            }
            val words = para.trim().split(Regex("\\s+"))
            var current = StringBuilder()
            for (word in words) {
                val candidate = if (current.isEmpty()) word else "$current $word"
                val width = font.getStringWidth(candidate) / 1000f * fontSize
                if (width <= maxWidth) {
                    current = StringBuilder(candidate)
                } else {
                    if (current.isNotEmpty()) {
                        result.add(current.toString())
                        current = StringBuilder(word)
                    } else {
                        // Hard wrap single very long word
                        var slice = word
                        while (slice.isNotEmpty()) {
                            var take = slice.length
                            while (take > 1 && font.getStringWidth(slice.substring(0, take)) / 1000f * fontSize > maxWidth) {
                                take--
                            }
                            result.add(slice.substring(0, take))
                            slice = slice.substring(take)
                        }
                    }
                }
            }
            if (current.isNotEmpty()) {
                result.add(current.toString())
            }
        }
        return result
    }

    suspend fun extractTextFromPdf(
        sourceFile: File,
        startPageOneBased: Int = 1,
        endPageOneBased: Int = Int.MAX_VALUE,
        password: String? = null
    ): PdfTextExtractionResult = withContext(ioDispatcher) {
        loadDocument(sourceFile, password).use { doc ->
            val total = doc.numberOfPages
            require(total > 0) { "Source PDF has no pages." }
            val safeStart = startPageOneBased.coerceIn(1, total)
            val safeEnd = endPageOneBased.coerceIn(safeStart, total)
            val stripper = PDFTextStripper()
            val pageTexts = mutableListOf<String>()
            val combined = StringBuilder()

            for (p in safeStart..safeEnd) {
                stripper.startPage = p
                stripper.endPage = p
                val text = stripper.getText(doc).trim()
                pageTexts.add(text)
                if (combined.isNotEmpty()) combined.append("\n\n")
                combined.append("--- Page $p ---\n")
                combined.append(if (text.isNotEmpty()) text else "[No embedded selectable text on this page]")
            }

            val hasEmbeddedText = pageTexts.any { it.isNotBlank() }
            PdfTextExtractionResult(
                fullText = combined.toString().trim(),
                pageTexts = pageTexts,
                totalPages = total,
                hasEmbeddedText = hasEmbeddedText
            )
        }
    }

    suspend fun exportPdfToImages(
        sourceFile: File,
        outputDir: File,
        baseName: String,
        format: PdfImageFormat,
        pageIndicesOneBased: List<Int> = emptyList(),
        quality: Int = 90,
        targetWidthPx: Int = 1440,
        password: String? = null
    ): List<File> = withContext(ioDispatcher) {
        outputDir.mkdirs()
        val total = rendererHelper.getPageCount(sourceFile.absolutePath, password)
        require(total > 0) { "Could not read pages from selected PDF (it may be encrypted or damaged)." }

        val targetPages = if (pageIndicesOneBased.isEmpty()) {
            (1..total).toList()
        } else {
            pageIndicesOneBased.filter { it in 1..total }.distinct()
        }
        require(targetPages.isNotEmpty()) { "Select at least one valid page (1..$total) to export." }

        val cleanBase = baseName.trim().replace(Regex("[^a-zA-Z0-9._-]"), "_").ifBlank { "DocuScan" }.take(36)
        val stamp = System.currentTimeMillis()
        val compressFormat = if (format == PdfImageFormat.PNG) Bitmap.CompressFormat.PNG else Bitmap.CompressFormat.JPEG
        val safeQuality = if (format == PdfImageFormat.PNG) 100 else quality.coerceIn(50, 100)

        val generated = mutableListOf<File>()
        targetPages.forEach { pageOneBased ->
            when (val outcome = rendererHelper.renderPageOutcome(sourceFile.absolutePath, pageOneBased - 1, targetWidthPx, password)) {
                is PdfRenderOutcome.Success -> {
                    val outFile = File(outputDir, "${cleanBase}_p${pageOneBased}_${stamp}.${format.extension}")
                    try {
                        FileOutputStream(outFile).use { out ->
                            outcome.bitmap.compress(compressFormat, safeQuality, out)
                        }
                        generated.add(outFile)
                    } finally {
                        if (!outcome.bitmap.isRecycled) {
                            outcome.bitmap.recycle()
                        }
                    }
                }
                is PdfRenderOutcome.PasswordRequired -> {
                    generated.forEach { it.delete() }
                    throw IllegalStateException("This PDF is password protected. Enter the password to export images.")
                }
                is PdfRenderOutcome.Error -> {
                    generated.forEach { it.delete() }
                    throw IllegalStateException(outcome.message)
                }
            }
        }
        generated
    }

    /**
     * Converts a PDF into a valid OOXML (.docx) Word document.
     * Extracts text paragraphs page-by-page using PDFTextStripper, and for scanned/image-only pages
     * embeds rendered JPEG page images inside WordprocessingML drawings when fallback is enabled.
     */
    suspend fun convertPdfToDocx(
        sourceFile: File,
        outputFile: File,
        title: String,
        includePageImagesFallback: Boolean = true,
        password: String? = null
    ): PdfDocxConversionResult = withContext(ioDispatcher) {
        val pageTexts = mutableListOf<String>()
        val mediaImages = mutableMapOf<Int, ByteArray>()

        loadDocument(sourceFile, password).use { doc ->
            val total = doc.numberOfPages
            require(total > 0) { "Source PDF has no pages." }
            val stripper = PDFTextStripper()
            for (p in 1..total) {
                stripper.startPage = p
                stripper.endPage = p
                pageTexts.add(stripper.getText(doc).trim())
            }
        }

        if (includePageImagesFallback) {
            pageTexts.forEachIndexed { idx, txt ->
                if (txt.isBlank()) {
                    val outcome = rendererHelper.renderPageOutcome(sourceFile.absolutePath, idx, 1200, password)
                    if (outcome is PdfRenderOutcome.Success) {
                        val baos = ByteArrayOutputStream()
                        outcome.bitmap.compress(Bitmap.CompressFormat.JPEG, 82, baos)
                        if (!outcome.bitmap.isRecycled) outcome.bitmap.recycle()
                        mediaImages[idx] = baos.toByteArray()
                    }
                }
            }
        }

        writeOoxmlDocx(
            outputFile = outputFile,
            docTitle = title,
            pageTexts = pageTexts,
            mediaImages = mediaImages
        )

        PdfDocxConversionResult(
            outputFilePath = outputFile.absolutePath,
            title = title,
            pageCount = pageTexts.size,
            extractedCharCount = pageTexts.sumOf { it.length },
            imageFallbackPages = mediaImages.size
        )
    }

    private fun writeOoxmlDocx(
        outputFile: File,
        docTitle: String,
        pageTexts: List<String>,
        mediaImages: Map<Int, ByteArray>
    ) {
        val hasImages = mediaImages.isNotEmpty()
        val contentTypesXml = buildString {
            append("""<?xml version="1.0" encoding="UTF-8" standalone="yes"?>""")
            append("""<Types xmlns="http://schemas.openxmlformats.org/package/2006/content-types">""")
            append("""<Default Extension="rels" ContentType="application/vnd.openxmlformats-package.relationships+xml"/>""")
            append("""<Default Extension="xml" ContentType="application/xml"/>""")
            if (hasImages) {
                append("""<Default Extension="jpg" ContentType="image/jpeg"/>""")
            }
            append("""<Override PartName="/word/document.xml" ContentType="application/vnd.openxmlformats-officedocument.wordprocessingml.document.main+xml"/>""")
            append("""<Override PartName="/word/styles.xml" ContentType="application/vnd.openxmlformats-officedocument.wordprocessingml.styles+xml"/>""")
            append("""</Types>""")
        }

        val rootRelsXml = """<?xml version="1.0" encoding="UTF-8" standalone="yes"?>""" +
            """<Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships">""" +
            """<Relationship Id="rId1" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/officeDocument" Target="word/document.xml"/>""" +
            """</Relationships>"""

        val docRelsXml = buildString {
            append("""<?xml version="1.0" encoding="UTF-8" standalone="yes"?>""")
            append("""<Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships">""")
            append("""<Relationship Id="rIdStyles" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/styles" Target="styles.xml"/>""")
            mediaImages.keys.sorted().forEach { pageIdx ->
                val pNum = pageIdx + 1
                append("""<Relationship Id="rIdImg$pNum" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/image" Target="media/page_$pNum.jpg"/>""")
            }
            append("""</Relationships>""")
        }

        val stylesXml = """<?xml version="1.0" encoding="UTF-8" standalone="yes"?>""" +
            """<w:styles xmlns:w="http://schemas.openxmlformats.org/wordprocessingml/2006/main">""" +
            """<w:style w:type="paragraph" w:default="1" w:styleId="Normal"><w:name w:val="Normal"/></w:style>""" +
            """</w:styles>"""

        val documentXml = buildString {
            append("""<?xml version="1.0" encoding="UTF-8" standalone="yes"?>""")
            append("""<w:document xmlns:w="http://schemas.openxmlformats.org/wordprocessingml/2006/main" """)
            append("""xmlns:r="http://schemas.openxmlformats.org/officeDocument/2006/relationships" """)
            append("""xmlns:wp="http://schemas.openxmlformats.org/drawingml/2006/wordprocessingDrawing" """)
            append("""xmlns:a="http://schemas.openxmlformats.org/drawingml/2006/main" """)
            append("""xmlns:pic="http://schemas.openxmlformats.org/drawingml/2006/picture">""")
            append("<w:body>")

            if (docTitle.isNotBlank()) {
                append("<w:p><w:r><w:rPr><w:b/><w:sz w:val=\"28\"/></w:rPr>")
                append("""<w:t xml:space="preserve">${xmlEscape(docTitle)}</w:t>""")
                append("</w:r></w:p>")
            }

            pageTexts.forEachIndexed { idx, rawPageText ->
                val pageNum = idx + 1
                if (rawPageText.isNotBlank()) {
                    rawPageText.replace("\r\n", "\n").replace("\r", "\n").split("\n").forEach { line ->
                        append("<w:p><w:r><w:t xml:space=\"preserve\">${xmlEscape(line)}</w:t></w:r></w:p>")
                    }
                } else if (pageNum - 1 in mediaImages) {
                    val emuW = 5486400L // 6 inches
                    val emuH = 7315200L // 8 inches
                    val rId = "rIdImg$pageNum"
                    append("<w:p><w:r><w:drawing><wp:inline><wp:extent cx=\"$emuW\" cy=\"$emuH\"/>")
                    append("""<wp:docPr id="$pageNum" name="Page$pageNum"/>""")
                    append("""<a:graphic><a:graphicData uri="http://schemas.openxmlformats.org/drawingml/2006/picture">""")
                    append("""<pic:pic><pic:nvPicPr><pic:cNvPr id="$pageNum" name="page_$pageNum.jpg"/><pic:cNvPicPr/></pic:nvPicPr>""")
                    append("""<pic:blipFill><a:blip r:embed="$rId"/><a:stretch><a:fillRect/></a:stretch></pic:blipFill>""")
                    append("""<pic:spPr><a:xfrm><a:off x="0" y="0"/><a:ext cx="$emuW" cy="$emuH"/></a:xfrm><a:prstGeom prst="rect"><a:avLst/></a:prstGeom></pic:spPr>""")
                    append("</pic:pic></a:graphicData></a:graphic></wp:inline></w:drawing></w:r></w:p>")
                } else {
                    append("<w:p><w:r><w:t xml:space=\"preserve\">[Page $pageNum: No embedded text]</w:t></w:r></w:p>")
                }

                if (idx < pageTexts.lastIndex) {
                    append("<w:p><w:r><w:br w:type=\"page\"/></w:r></w:p>")
                }
            }

            append("<w:sectPr><w:pgSz w:w=\"11906\" w:h=\"16838\"/></w:sectPr>")
            append("</w:body></w:document>")
        }

        ZipOutputStream(FileOutputStream(outputFile)).use { zip ->
            writeZipText(zip, "[Content_Types].xml", contentTypesXml)
            writeZipText(zip, "_rels/.rels", rootRelsXml)
            writeZipText(zip, "word/_rels/document.xml.rels", docRelsXml)
            writeZipText(zip, "word/styles.xml", stylesXml)
            writeZipText(zip, "word/document.xml", documentXml)
            mediaImages.forEach { (pageIdx, bytes) ->
                zip.putNextEntry(ZipEntry("word/media/page_${pageIdx + 1}.jpg"))
                zip.write(bytes)
                zip.closeEntry()
            }
        }
    }

    private fun writeZipText(zip: ZipOutputStream, entryName: String, content: String) {
        zip.putNextEntry(ZipEntry(entryName))
        zip.write(content.toByteArray(Charsets.UTF_8))
        zip.closeEntry()
    }

    private fun xmlEscape(text: String): String = buildString(text.length) {
        text.forEach { ch ->
            when (ch) {
                '&' -> append("&amp;")
                '<' -> append("&lt;")
                '>' -> append("&gt;")
                '"' -> append("&quot;")
                '\'' -> append("&apos;")
                else -> if (ch.code >= 0x20 || ch == '\t') append(ch)
            }
        }
    }

    private fun sanitizePdfWinAnsi(raw: String): String =
        raw.map { ch -> if (ch.code in 32..126 || ch.code in 160..255) ch else ' ' }.joinToString("")
}
