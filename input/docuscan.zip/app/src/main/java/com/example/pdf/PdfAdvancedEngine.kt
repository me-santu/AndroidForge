package com.example.pdf

import android.content.Context
import android.graphics.Bitmap
import android.graphics.pdf.PdfRenderer
import android.os.ParcelFileDescriptor
import com.example.domain.model.PageNumberFormat
import com.example.domain.model.PageNumberPosition
import com.example.domain.model.PdfDocumentInfo
import com.example.domain.model.WatermarkRemovalResult
import com.tom_roush.pdfbox.android.PDFBoxResourceLoader
import com.tom_roush.pdfbox.contentstream.operator.Operator
import com.tom_roush.pdfbox.cos.COSArray
import com.tom_roush.pdfbox.cos.COSName
import com.tom_roush.pdfbox.cos.COSString
import com.tom_roush.pdfbox.io.MemoryUsageSetting
import com.tom_roush.pdfbox.pdfparser.PDFStreamParser
import com.tom_roush.pdfbox.pdfwriter.ContentStreamWriter
import com.tom_roush.pdfbox.pdmodel.PDDocument
import com.tom_roush.pdfbox.pdmodel.PDDocumentInformation
import com.tom_roush.pdfbox.pdmodel.PDPage
import com.tom_roush.pdfbox.pdmodel.PDPageContentStream
import com.tom_roush.pdfbox.pdmodel.PDResources
import com.tom_roush.pdfbox.pdmodel.common.PDRectangle
import com.tom_roush.pdfbox.pdmodel.common.PDStream
import com.tom_roush.pdfbox.pdmodel.encryption.InvalidPasswordException
import com.tom_roush.pdfbox.pdmodel.font.PDType1Font
import com.tom_roush.pdfbox.pdmodel.graphics.form.PDFormXObject
import com.tom_roush.pdfbox.pdmodel.graphics.image.JPEGFactory
import com.tom_roush.pdfbox.pdmodel.graphics.image.PDImageXObject
import com.tom_roush.pdfbox.rendering.PDFRenderer
import kotlinx.coroutines.CoroutineDispatcher
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.io.File
import java.io.FileOutputStream
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import kotlin.math.max

sealed interface PdfValidationOutcome {
    data class Valid(val pageCount: Int, val isPasswordProtected: Boolean = false) : PdfValidationOutcome
    data object PasswordRequired : PdfValidationOutcome
    data class Invalid(val reason: String) : PdfValidationOutcome
}

class PdfAdvancedEngine(
    private val context: Context? = null,
    private val ioDispatcher: CoroutineDispatcher = Dispatchers.IO
) {

    private fun ensurePdfBoxReady() {
        if (context != null && !PDFBoxResourceLoader.isReady()) {
            PDFBoxResourceLoader.init(context.applicationContext)
        }
    }

    private fun loadDocument(file: File, password: String? = null): PDDocument {
        ensurePdfBoxReady()
        require(file.exists() && file.length() > 0L) { "PDF file does not exist or is empty." }
        return try {
            val mem = MemoryUsageSetting.setupTempFileOnly()
            if (!password.isNullOrEmpty()) {
                PDDocument.load(file, password, mem)
            } else {
                PDDocument.load(file, mem)
            }
        } catch (e: InvalidPasswordException) {
            throw IllegalStateException(
                if (password.isNullOrEmpty()) {
                    "This PDF is password protected. Enter the password to proceed."
                } else {
                    "Incorrect PDF password. Please verify and try again."
                },
                e
            )
        }
    }

    suspend fun validatePdf(file: File, password: String? = null): PdfValidationOutcome =
        withContext(ioDispatcher) {
            if (!file.exists() || file.length() == 0L) {
                return@withContext PdfValidationOutcome.Invalid("Selected file is empty or missing.")
            }
            val headerProbe = runCatching {
                file.inputStream().use { input ->
                    val buf = ByteArray(1024)
                    val read = input.read(buf)
                    if (read > 0) String(buf, 0, read, Charsets.ISO_8859_1) else ""
                }
            }.getOrDefault("")
            if (!headerProbe.contains("%PDF-")) {
                return@withContext PdfValidationOutcome.Invalid("Selected file is not a valid PDF document.")
            }

            ensurePdfBoxReady()
            try {
                val mem = MemoryUsageSetting.setupTempFileOnly()
                val doc = if (!password.isNullOrEmpty()) {
                    PDDocument.load(file, password, mem)
                } else {
                    PDDocument.load(file, mem)
                }
                doc.use {
                    PdfValidationOutcome.Valid(
                        pageCount = it.numberOfPages.coerceAtLeast(1),
                        isPasswordProtected = it.isEncrypted
                    )
                }
            } catch (_: InvalidPasswordException) {
                PdfValidationOutcome.PasswordRequired
            } catch (t: Throwable) {
                PdfValidationOutcome.Invalid(t.message ?: "PDF appears damaged or unreadable.")
            }
        }

    suspend fun inspectPdfInfo(file: File, password: String? = null): PdfDocumentInfo =
        withContext(ioDispatcher) {
            loadDocument(file, password).use { doc ->
                val info = doc.documentInformation ?: PDDocumentInformation()
                val firstBox = if (doc.numberOfPages > 0) {
                    val p = doc.getPage(0)
                    p.cropBox ?: p.mediaBox ?: PDRectangle.A4
                } else {
                    PDRectangle.A4
                }
                PdfDocumentInfo(
                    title = info.title?.trim().orEmpty(),
                    author = info.author?.trim().orEmpty(),
                    subject = info.subject?.trim().orEmpty(),
                    creator = info.creator?.trim().orEmpty(),
                    producer = info.producer?.trim().orEmpty(),
                    pdfVersion = doc.version.toString(),
                    pageCount = doc.numberOfPages,
                    fileSizeBytes = file.length(),
                    isEncrypted = doc.isEncrypted,
                    keyLengthBits = if (doc.isEncrypted) runCatching { doc.encryption.length }.getOrDefault(128) else 0,
                    firstPageWidthPt = firstBox.width,
                    firstPageHeightPt = firstBox.height,
                    createdDateMillis = runCatching { info.creationDate?.timeInMillis }.getOrNull(),
                    modifiedDateMillis = runCatching { info.modificationDate?.timeInMillis }.getOrNull(),
                    filePath = file.absolutePath
                )
            }
        }

    suspend fun reorderPages(
        sourceFile: File,
        outputFile: File,
        oneBasedNewOrder: List<Int>,
        password: String? = null
    ): Int = withContext(ioDispatcher) {
        loadDocument(sourceFile, password).use { srcDoc ->
            val total = srcDoc.numberOfPages
            require(total > 0) { "Source PDF has no pages." }
            val cleanOrder = oneBasedNewOrder.filter { it in 1..total }
            require(cleanOrder.isNotEmpty()) { "Provide at least one valid page number (1..$total)." }

            PDDocument(MemoryUsageSetting.setupTempFileOnly()).use { outDoc ->
                cleanOrder.forEach { pageNum ->
                    outDoc.importPage(srcDoc.getPage(pageNum - 1))
                }
                outDoc.save(outputFile)
                outDoc.numberOfPages
            }
        }
    }

    suspend fun duplicatePages(
        sourceFile: File,
        outputFile: File,
        oneBasedPagesToDuplicate: List<Int>,
        insertAdjacent: Boolean = true,
        password: String? = null
    ): Int = withContext(ioDispatcher) {
        loadDocument(sourceFile, password).use { srcDoc ->
            val total = srcDoc.numberOfPages
            require(total > 0) { "Source PDF has no pages." }
            val targets = oneBasedPagesToDuplicate.filter { it in 1..total }
            require(targets.isNotEmpty()) { "Select at least one valid page (1..$total) to duplicate." }

            val newOrder = buildList {
                if (insertAdjacent) {
                    val counts = targets.groupingBy { it }.eachCount()
                    for (p in 1..total) {
                        add(p)
                        repeat(counts[p] ?: 0) { add(p) }
                    }
                } else {
                    addAll(1..total)
                    addAll(targets)
                }
            }

            PDDocument(MemoryUsageSetting.setupTempFileOnly()).use { outDoc ->
                newOrder.forEach { pageNum ->
                    outDoc.importPage(srcDoc.getPage(pageNum - 1))
                }
                outDoc.save(outputFile)
                outDoc.numberOfPages
            }
        }
    }

    suspend fun unlockPdf(
        sourceFile: File,
        outputFile: File,
        password: String
    ): Int = withContext(ioDispatcher) {
        require(password.isNotEmpty()) { "Enter the existing PDF password to unlock it." }
        loadDocument(sourceFile, password).use { doc ->
            doc.isAllSecurityToBeRemoved = true
            doc.save(outputFile)
            doc.numberOfPages
        }
    }

    suspend fun removeWatermark(
        sourceFile: File,
        outputFile: File,
        matchText: String? = null,
        password: String? = null
    ): Triple<Int, Int, Int> = withContext(ioDispatcher) {
        val needle = matchText?.trim()?.takeIf { it.isNotEmpty() }
        var removedAnnotations = 0
        var removedTextBlocks = 0
        var removedOcgCount = 0

        loadDocument(sourceFile, password).use { doc ->
            val ocProps = doc.documentCatalog.ocProperties
            if (ocProps != null) {
                val wmGroups = ocProps.optionalContentGroups.filter {
                    val name = it.name.orEmpty()
                    name.contains("watermark", ignoreCase = true) ||
                        (needle != null && name.contains(needle, ignoreCase = true))
                }
                if (wmGroups.isNotEmpty()) {
                    wmGroups.forEach { group ->
                        ocProps.setGroupEnabled(group, false)
                        removedOcgCount++
                    }
                }
            }

            for (i in 0 until doc.numberOfPages) {
                val page = doc.getPage(i)

                // 1. Remove Watermark / Stamp annotations
                val annots = page.annotations.toMutableList()
                val kept = annots.filter { annot ->
                    val subtype = annot.subtype.orEmpty()
                    val contents = annot.contents.orEmpty()
                    val isWm = subtype.equals("Watermark", ignoreCase = true) ||
                        subtype.equals("Stamp", ignoreCase = true) ||
                        (needle != null && contents.contains(needle, ignoreCase = true))
                    if (isWm) removedAnnotations++
                    !isWm
                }
                if (kept.size != annots.size) {
                    page.annotations = kept.toMutableList()
                }

                // 2. Strip matching watermark BT..ET blocks from page content stream
                val parser = PDFStreamParser(page)
                parser.parse()
                val tokens = parser.tokens
                val (filtered, strippedHere) = stripWatermarkTextBlocks(tokens, needle)
                if (strippedHere > 0) {
                    removedTextBlocks += strippedHere
                    val newStream = PDStream(doc)
                    newStream.createOutputStream(COSName.FLATE_DECODE).use { out ->
                        ContentStreamWriter(out).writeTokens(filtered)
                    }
                    page.setContents(newStream)
                }
            }

            val totalRemoved = removedAnnotations + removedTextBlocks + removedOcgCount
            require(totalRemoved > 0) {
                "No removable watermark annotations, layers, or matching text overlays were found. " +
                    "Rasterized or outlined watermarks embedded inside page images cannot be stripped automatically."
            }

            doc.save(outputFile)
            Triple(removedAnnotations, removedTextBlocks, removedOcgCount)
        }
    }

    private fun stripWatermarkTextBlocks(
        tokens: List<Any>,
        matchNeedle: String?
    ): Pair<List<Any>, Int> {
        val output = mutableListOf<Any>()
        val commonWatermarkWords = listOf("CONFIDENTIAL", "WATERMARK", "DRAFT", "SAMPLE", "DO NOT COPY")
        var strippedCount = 0
        var i = 0

        while (i < tokens.size) {
            val token = tokens[i]
            if (token is Operator && token.name == "BT") {
                val btBlock = mutableListOf<Any>(token)
                var j = i + 1
                val textBuffer = StringBuilder()
                var hasRotationMatrix = false
                while (j < tokens.size) {
                    val inner = tokens[j]
                    btBlock.add(inner)
                    if (inner is Operator && inner.name == "Tm") {
                        // Diagonal text matrix: check b/c shear components before Tm
                        val nums = btBlock.dropLast(1).takeLast(6).mapNotNull {
                            (it as? Number)?.toFloat()
                        }
                        if (nums.size == 6 && (kotlin.math.abs(nums[1]) > 0.1f || kotlin.math.abs(nums[2]) > 0.1f)) {
                            hasRotationMatrix = true
                        }
                    } else if (inner is Operator && (inner.name == "Tj" || inner.name == "TJ")) {
                        val arg = btBlock.getOrNull(btBlock.size - 2)
                        textBuffer.append(extractCosStringText(arg))
                    } else if (inner is Operator && inner.name == "ET") {
                        break
                    }
                    j++
                }
                val blockText = textBuffer.toString().trim()
                val matchesTarget = when {
                    matchNeedle != null -> blockText.contains(matchNeedle, ignoreCase = true)
                    hasRotationMatrix -> commonWatermarkWords.any { blockText.contains(it, ignoreCase = true) }
                    else -> false
                }
                if (matchesTarget && blockText.isNotEmpty()) {
                    strippedCount++
                } else {
                    output.addAll(btBlock)
                }
                i = j + 1
            } else {
                output.add(token)
                i++
            }
        }
        return output to strippedCount
    }

    private fun extractCosStringText(token: Any?): String = when (token) {
        is COSString -> token.string
        is COSArray -> buildString {
            for (item in token) {
                if (item is COSString) append(item.string)
            }
        }
        else -> ""
    }

    suspend fun addPageNumbers(
        sourceFile: File,
        outputFile: File,
        position: PageNumberPosition = PageNumberPosition.BOTTOM_CENTER,
        format: PageNumberFormat = PageNumberFormat.PAGE_X_OF_N,
        startNumber: Int = 1,
        fontSizePt: Float = 10f,
        password: String? = null
    ): Int = withContext(ioDispatcher) {
        val safeStart = startNumber.coerceAtLeast(1)
        loadDocument(sourceFile, password).use { doc ->
            val total = doc.numberOfPages
            require(total > 0) { "Source PDF has no pages." }
            val font = PDType1Font.HELVETICA_BOLD
            val displayTotal = safeStart + total - 1

            for (i in 0 until total) {
                val page = doc.getPage(i)
                val box = page.cropBox ?: page.mediaBox ?: PDRectangle.A4
                val currentNum = safeStart + i
                val label = when (format) {
                    PageNumberFormat.PAGE_X_OF_N -> "Page $currentNum of $displayTotal"
                    PageNumberFormat.X_SLASH_N -> "$currentNum / $displayTotal"
                    PageNumberFormat.X_ONLY -> "$currentNum"
                }
                val textWidth = font.getStringWidth(label) / 1000f * fontSizePt
                val marginX = 28f
                val marginY = 18f
                val x = when (position) {
                    PageNumberPosition.BOTTOM_LEFT -> box.lowerLeftX + marginX
                    PageNumberPosition.BOTTOM_RIGHT, PageNumberPosition.TOP_RIGHT ->
                        (box.upperRightX - marginX - textWidth).coerceAtLeast(box.lowerLeftX + 12f)
                    PageNumberPosition.BOTTOM_CENTER, PageNumberPosition.TOP_CENTER ->
                        box.lowerLeftX + ((box.width - textWidth) / 2f).coerceAtLeast(12f)
                }
                val y = when (position) {
                    PageNumberPosition.TOP_CENTER, PageNumberPosition.TOP_RIGHT ->
                        box.upperRightY - marginY - fontSizePt
                    else -> box.lowerLeftY + marginY
                }

                PDPageContentStream(
                    doc,
                    page,
                    PDPageContentStream.AppendMode.APPEND,
                    true,
                    true
                ).use { stream ->
                    stream.beginText()
                    stream.setFont(font, fontSizePt)
                    stream.setNonStrokingColor(0.22f, 0.22f, 0.22f)
                    stream.newLineAtOffset(x, y)
                    stream.showText(sanitizePdfText(label))
                    stream.endText()
                }
            }
            doc.save(outputFile)
            total
        }
    }

    suspend fun addHeaderFooter(
        sourceFile: File,
        outputFile: File,
        headerText: String,
        footerText: String,
        includeDate: Boolean = false,
        fontSizePt: Float = 10f,
        password: String? = null
    ): Int = withContext(ioDispatcher) {
        val cleanHeader = headerText.trim()
        val dateStamp = SimpleDateFormat("yyyy-MM-dd", Locale.US).format(Date())
        val resolvedFooter = buildString {
            val base = footerText.trim()
            if (base.isNotEmpty()) append(base)
            if (includeDate) {
                if (isNotEmpty()) append("  ·  ")
                append(dateStamp)
            }
        }
        require(cleanHeader.isNotEmpty() || resolvedFooter.isNotEmpty()) {
            "Enter header text, footer text, or enable date stamp."
        }

        loadDocument(sourceFile, password).use { doc ->
            val total = doc.numberOfPages
            require(total > 0) { "Source PDF has no pages." }
            val font = PDType1Font.HELVETICA

            for (i in 0 until total) {
                val page = doc.getPage(i)
                val box = page.cropBox ?: page.mediaBox ?: PDRectangle.A4
                PDPageContentStream(
                    doc,
                    page,
                    PDPageContentStream.AppendMode.APPEND,
                    true,
                    true
                ).use { stream ->
                    stream.setFont(font, fontSizePt)
                    stream.setNonStrokingColor(0.25f, 0.25f, 0.25f)

                    if (cleanHeader.isNotEmpty()) {
                        val safe = sanitizePdfText(cleanHeader).take(120)
                        val w = font.getStringWidth(safe) / 1000f * fontSizePt
                        val hx = box.lowerLeftX + ((box.width - w) / 2f).coerceAtLeast(24f)
                        val hy = box.upperRightY - 22f
                        stream.beginText()
                        stream.newLineAtOffset(hx, hy)
                        stream.showText(safe)
                        stream.endText()
                    }

                    if (resolvedFooter.isNotEmpty()) {
                        val safe = sanitizePdfText(resolvedFooter).take(120)
                        val w = font.getStringWidth(safe) / 1000f * fontSizePt
                        val fx = box.lowerLeftX + ((box.width - w) / 2f).coerceAtLeast(24f)
                        val fy = box.lowerLeftY + 18f
                        stream.beginText()
                        stream.newLineAtOffset(fx, fy)
                        stream.showText(safe)
                        stream.endText()
                    }
                }
            }
            doc.save(outputFile)
            total
        }
    }

    suspend fun reducePdfSize(
        sourceFile: File,
        outputFile: File,
        maxImageDimension: Int = 1280,
        jpegQuality: Float = 0.55f,
        stripMetadata: Boolean = true,
        password: String? = null
    ): Pair<Int, Pair<Long, Long>> = withContext(ioDispatcher) {
        val origBytes = sourceFile.length()
        loadDocument(sourceFile, password).use { doc ->
            val total = doc.numberOfPages
            require(total > 0) { "Source PDF has no pages." }

            if (stripMetadata) {
                doc.documentInformation = PDDocumentInformation()
                doc.documentCatalog.metadata = null
            }

            for (i in 0 until total) {
                val page = doc.getPage(i)
                if (stripMetadata) {
                    page.cosObject.removeItem(COSName.getPDFName("Thumb"))
                }
                optimizeResourcesImages(doc, page.resources, maxImageDimension, jpegQuality.coerceIn(0.25f, 0.92f))
            }

            doc.save(outputFile)
            total to (origBytes to outputFile.length())
        }
    }

    private fun optimizeResourcesImages(
        doc: PDDocument,
        resources: PDResources?,
        maxDim: Int,
        jpegQuality: Float,
        depth: Int = 0
    ) {
        if (resources == null || depth > 4) return
        val xObjectNames = resources.xObjectNames?.toList().orEmpty()
        for (name in xObjectNames) {
            val xObj = runCatching { resources.getXObject(name) }.getOrNull() ?: continue
            when (xObj) {
                is PDImageXObject -> {
                    val origLen = xObj.cosObject.length
                    val rawBitmap = runCatching { xObj.image }.getOrNull() ?: continue
                    val largest = max(rawBitmap.width, rawBitmap.height)
                    val scaled = if (largest > maxDim) {
                        val ratio = maxDim.toFloat() / largest.toFloat()
                        Bitmap.createScaledBitmap(
                            rawBitmap,
                            (rawBitmap.width * ratio).toInt().coerceAtLeast(16),
                            (rawBitmap.height * ratio).toInt().coerceAtLeast(16),
                            true
                        )
                    } else {
                        rawBitmap
                    }
                    val recompressed = JPEGFactory.createFromImage(doc, scaled, jpegQuality)
                    val newLen = recompressed.cosObject.length
                    if (newLen < origLen || scaled !== rawBitmap) {
                        resources.put(name, recompressed)
                    }
                    if (scaled !== rawBitmap && !scaled.isRecycled) scaled.recycle()
                    if (!rawBitmap.isRecycled) rawBitmap.recycle()
                }
                is PDFormXObject -> {
                    optimizeResourcesImages(doc, xObj.resources, maxDim, jpegQuality, depth + 1)
                }
            }
        }
    }

    suspend fun repairPdf(
        sourceFile: File,
        outputFile: File,
        password: String? = null
    ): Pair<Int, String> = withContext(ioDispatcher) {
        ensurePdfBoxReady()
        require(sourceFile.exists() && sourceFile.length() > 0L) { "Source file is missing or empty." }

        // 1. Trim garbage leading bytes before %PDF- if present
        val rawBytes = sourceFile.readBytes()
        val headerSig = "%PDF-".toByteArray(Charsets.US_ASCII)
        val headerIdx = findSequence(rawBytes, headerSig)
        require(headerIdx >= 0) { "No PDF header (%PDF-) found — file is not a recoverable PDF." }

        val candidateFile = if (headerIdx > 0) {
            File.createTempFile("docuscan_trimmed_", ".pdf", outputFile.parentFile).apply {
                FileOutputStream(this).use { it.write(rawBytes, headerIdx, rawBytes.size - headerIdx) }
            }
        } else {
            sourceFile
        }

        try {
            // 2. Attempt structural page-by-page rebuild via PDFBox
            val structuralAttempt = runCatching {
                loadDocument(candidateFile, password).use { srcDoc ->
                    val total = srcDoc.numberOfPages
                    require(total > 0) { "No pages present in document." }
                    var recovered = 0
                    PDDocument(MemoryUsageSetting.setupTempFileOnly()).use { outDoc ->
                        for (i in 0 until total) {
                            runCatching {
                                outDoc.importPage(srcDoc.getPage(i))
                                recovered++
                            }
                        }
                        require(recovered > 0) { "Zero recoverable pages found." }
                        outDoc.save(outputFile)
                    }
                    recovered to "Structural XRef & Page Tree Rebuild ($recovered/$total pages)"
                }
            }
            if (structuralAttempt.isSuccess) {
                return@withContext structuralAttempt.getOrThrow()
            }

            // Check explicit wrong password so we don't mask InvalidPassword
            structuralAttempt.exceptionOrNull()?.let { err ->
                if (err is IllegalStateException && err.cause is InvalidPasswordException) {
                    throw err
                }
            }

            // 3. Fallback: attempt page-by-page raster recovery using PdfRenderer or PDFRenderer
            var renderedCount = 0
            PDDocument(MemoryUsageSetting.setupTempFileOnly()).use { rebuilt ->
                val nativeWorked = runCatching {
                    ParcelFileDescriptor.open(candidateFile, ParcelFileDescriptor.MODE_READ_ONLY).use { fd ->
                        PdfRenderer(fd).use { renderer ->
                            for (i in 0 until renderer.pageCount) {
                                renderer.openPage(i).use { p ->
                                    val bmp = Bitmap.createBitmap(
                                        (p.width * 2).coerceIn(400, 1800),
                                        (p.height * 2).coerceIn(400, 2400),
                                        Bitmap.Config.ARGB_8888
                                    )
                                    bmp.eraseColor(android.graphics.Color.WHITE)
                                    p.render(bmp, null, null, PdfRenderer.Page.RENDER_MODE_FOR_DISPLAY)
                                    val newPage = PDPage(PDRectangle(p.width.toFloat(), p.height.toFloat()))
                                    rebuilt.addPage(newPage)
                                    val imgObj = JPEGFactory.createFromImage(rebuilt, bmp, 0.90f)
                                    PDPageContentStream(rebuilt, newPage).use { stream ->
                                        stream.drawImage(imgObj, 0f, 0f, p.width.toFloat(), p.height.toFloat())
                                    }
                                    bmp.recycle()
                                    renderedCount++
                                }
                            }
                        }
                    }
                }.isSuccess

                if (!nativeWorked || renderedCount == 0) {
                    error(structuralAttempt.exceptionOrNull()?.message ?: "PDF structure is corrupted beyond repair.")
                }
                rebuilt.save(outputFile)
            }
            renderedCount to "Page Raster Reconstruction ($renderedCount pages recovered)"
        } finally {
            if (candidateFile !== sourceFile && candidateFile.exists()) {
                candidateFile.delete()
            }
        }
    }

    private fun findSequence(data: ByteArray, pattern: ByteArray): Int {
        if (pattern.isEmpty() || data.size < pattern.size) return -1
        outer@ for (i in 0..(data.size - pattern.size).coerceAtMost(2048)) {
            for (j in pattern.indices) {
                if (data[i + j] != pattern[j]) continue@outer
            }
            return i
        }
        return -1
    }

    private fun sanitizePdfText(raw: String): String =
        raw.map { ch -> if (ch.code in 32..126) ch else ' ' }.joinToString("")
}
