package com.example.ui.icons

import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.StrokeJoin
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.graphics.vector.PathBuilder
import androidx.compose.ui.graphics.vector.path
import androidx.compose.ui.unit.dp

/**
 * Shared Lucide-style 24x24 vector icon builder:
 * 2px stroke, rounded caps and rounded joins on a 24x24 viewport.
 */
internal inline fun lucideIcon(
    name: String,
    autoMirror: Boolean = false,
    strokeWidth: Float = 2f,
    crossinline block: LucideBuilderScope.() -> Unit
): ImageVector {
    val builder = ImageVector.Builder(
        name = "Lucide.$name",
        defaultWidth = 24.dp,
        defaultHeight = 24.dp,
        viewportWidth = 24f,
        viewportHeight = 24f,
        autoMirror = autoMirror
    )
    LucideBuilderScope(builder, strokeWidth).block()
    return builder.build()
}

internal class LucideBuilderScope(
    private val builder: ImageVector.Builder,
    private val defaultStrokeWidth: Float
) {
    fun strokePath(
        strokeWidth: Float = defaultStrokeWidth,
        block: PathBuilder.() -> Unit
    ) {
        builder.path(
            fill = null,
            stroke = SolidColor(Color.Black),
            strokeLineWidth = strokeWidth,
            strokeLineCap = StrokeCap.Round,
            strokeLineJoin = StrokeJoin.Round,
            pathBuilder = block
        )
    }

    fun filledStrokePath(
        strokeWidth: Float = defaultStrokeWidth,
        block: PathBuilder.() -> Unit
    ) {
        builder.path(
            fill = SolidColor(Color.Black),
            stroke = SolidColor(Color.Black),
            strokeLineWidth = strokeWidth,
            strokeLineCap = StrokeCap.Round,
            strokeLineJoin = StrokeJoin.Round,
            pathBuilder = block
        )
    }

    fun line(x1: Float, y1: Float, x2: Float, y2: Float, strokeWidth: Float = defaultStrokeWidth) {
        strokePath(strokeWidth) {
            moveTo(x1, y1)
            lineTo(x2, y2)
        }
    }

    fun circle(cx: Float, cy: Float, r: Float, strokeWidth: Float = defaultStrokeWidth) {
        strokePath(strokeWidth) {
            moveTo(cx + r, cy)
            arcTo(
                horizontalEllipseRadius = r,
                verticalEllipseRadius = r,
                theta = 0f,
                isMoreThanHalf = true,
                isPositiveArc = true,
                x1 = cx - r,
                y1 = cy
            )
            arcTo(
                horizontalEllipseRadius = r,
                verticalEllipseRadius = r,
                theta = 0f,
                isMoreThanHalf = true,
                isPositiveArc = true,
                x1 = cx + r,
                y1 = cy
            )
            close()
        }
    }

    fun dot(cx: Float, cy: Float, r: Float = 0.85f) {
        filledStrokePath(strokeWidth = 0.5f) {
            moveTo(cx + r, cy)
            arcTo(r, r, 0f, isMoreThanHalf = true, isPositiveArc = true, cx - r, cy)
            arcTo(r, r, 0f, isMoreThanHalf = true, isPositiveArc = true, cx + r, cy)
            close()
        }
    }

    fun roundRect(
        x: Float,
        y: Float,
        w: Float,
        h: Float,
        r: Float = 2f,
        strokeWidth: Float = defaultStrokeWidth
    ) {
        val rad = r.coerceAtMost(minOf(w, h) / 2f)
        strokePath(strokeWidth) {
            moveTo(x + rad, y)
            lineTo(x + w - rad, y)
            if (rad > 0f) {
                arcTo(rad, rad, 0f, false, true, x + w, y + rad)
            }
            lineTo(x + w, y + h - rad)
            if (rad > 0f) {
                arcTo(rad, rad, 0f, false, true, x + w - rad, y + h)
            }
            lineTo(x + rad, y + h)
            if (rad > 0f) {
                arcTo(rad, rad, 0f, false, true, x, y + h - rad)
            }
            lineTo(x, y + rad)
            if (rad > 0f) {
                arcTo(rad, rad, 0f, false, true, x + rad, y)
            }
            close()
        }
    }
}
