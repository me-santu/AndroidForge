package com.example.ui.icons

import androidx.compose.ui.graphics.vector.ImageVector

internal object LucideSecurityAndToolIcons {

    val Lock: ImageVector by lazy {
        lucideIcon("Lock") {
            roundRect(3f, 11f, 18f, 11f, 2f)
            strokePath {
                moveTo(7f, 11f)
                verticalLineTo(7f)
                arcTo(5f, 5f, 0f, false, true, 17f, 7f)
                verticalLineTo(11f)
            }
        }
    }

    val LockOpen: ImageVector by lazy {
        lucideIcon("LockOpen") {
            roundRect(3f, 11f, 18f, 11f, 2f)
            strokePath {
                moveTo(7f, 11f)
                verticalLineTo(7f)
                arcTo(5f, 5f, 0f, false, true, 16.9f, 6f)
            }
        }
    }

    val Shield: ImageVector by lazy {
        lucideIcon("Shield") {
            strokePath {
                moveTo(12f, 22f)
                curveTo(12f, 22f, 20f, 18f, 20f, 12f)
                verticalLineTo(5f)
                lineTo(12f, 2f)
                lineTo(4f, 5f)
                verticalLineTo(12f)
                curveTo(4f, 18f, 12f, 22f, 12f, 22f)
                close()
            }
        }
    }

    val ShieldCheck: ImageVector by lazy {
        lucideIcon("ShieldCheck") {
            strokePath {
                moveTo(12f, 22f)
                curveTo(12f, 22f, 20f, 18f, 20f, 12f)
                verticalLineTo(5f)
                lineTo(12f, 2f)
                lineTo(4f, 5f)
                verticalLineTo(12f)
                curveTo(4f, 18f, 12f, 22f, 12f, 22f)
                close()
            }
            strokePath {
                moveTo(9f, 12f)
                lineTo(11f, 14f)
                lineTo(15f, 10f)
            }
        }
    }

    val Fingerprint: ImageVector by lazy {
        lucideIcon("Fingerprint") {
            strokePath {
                moveTo(12f, 10f)
                arcTo(2f, 2f, 0f, false, false, 10f, 12f)
                curveTo(10f, 14.5f, 10.6f, 17f, 11.5f, 19.5f)
            }
            strokePath {
                moveTo(14f, 13.12f)
                curveTo(14f, 15.5f, 14f, 17.5f, 15f, 20f)
            }
            strokePath {
                moveTo(6.5f, 12f)
                arcTo(5.5f, 5.5f, 0f, false, true, 17.5f, 12f)
                curveTo(17.5f, 14.5f, 17.8f, 16.5f, 18.5f, 18.5f)
            }
            strokePath {
                moveTo(4f, 10f)
                arcTo(8.5f, 8.5f, 0f, false, true, 20f, 10f)
                verticalLineTo(12f)
            }
            strokePath {
                moveTo(6.5f, 16f)
                curveTo(7f, 17.6f, 7.6f, 19f, 8.5f, 20.5f)
            }
            strokePath {
                moveTo(3f, 14f)
                curveTo(3.2f, 16f, 3.8f, 17.8f, 4.7f, 19.3f)
            }
        }
    }

    val KeyRound: ImageVector by lazy {
        lucideIcon("KeyRound") {
            circle(7.5f, 15.5f, 4.5f)
            strokePath {
                moveTo(10.8f, 12.2f)
                lineTo(19f, 4f)
                lineTo(21f, 6f)
            }
            line(15.5f, 7.5f, 18f, 10f)
        }
    }

    val Eye: ImageVector by lazy {
        lucideIcon("Eye") {
            strokePath {
                moveTo(2f, 12f)
                curveTo(3.8f, 7.5f, 7.5f, 5f, 12f, 5f)
                curveTo(16.5f, 5f, 20.2f, 7.5f, 22f, 12f)
                curveTo(20.2f, 16.5f, 16.5f, 19f, 12f, 19f)
                curveTo(7.5f, 19f, 3.8f, 16.5f, 2f, 12f)
                close()
            }
            circle(12f, 12f, 3f)
        }
    }

    val Palette: ImageVector by lazy {
        lucideIcon("Palette") {
            strokePath {
                moveTo(12f, 2f)
                arcTo(10f, 10f, 0f, false, false, 12f, 22f)
                arcTo(1.5f, 1.5f, 0f, false, false, 13.5f, 20.5f)
                curveTo(13.5f, 19.7f, 13f, 19.2f, 13f, 18.5f)
                arcTo(1.5f, 1.5f, 0f, false, true, 14.5f, 17f)
                horizontalLineTo(16f)
                arcTo(6f, 6f, 0f, false, false, 22f, 11f)
                curveTo(22f, 5.8f, 17.5f, 2f, 12f, 2f)
                close()
            }
            dot(7.5f, 10.5f)
            dot(10.5f, 7.5f)
            dot(14.5f, 7.5f)
            dot(17f, 11f)
        }
    }

    val Globe: ImageVector by lazy {
        lucideIcon("Globe") {
            circle(12f, 12f, 10f)
            line(2f, 12f, 22f, 12f)
            strokePath {
                moveTo(12f, 2f)
                curveTo(14.5f, 4.7f, 16f, 8.2f, 16f, 12f)
                curveTo(16f, 15.8f, 14.5f, 19.3f, 12f, 22f)
                curveTo(9.5f, 19.3f, 8f, 15.8f, 8f, 12f)
                curveTo(8f, 8.2f, 9.5f, 4.7f, 12f, 2f)
                close()
            }
        }
    }

    val Languages: ImageVector by lazy {
        lucideIcon("Languages") {
            line(5f, 8f, 11f, 14f)
            line(4f, 14f, 10f, 8f)
            line(2f, 5f, 14f, 5f)
            line(7f, 2f, 7f, 5f)
            strokePath {
                moveTo(14f, 18f)
                lineTo(18f, 10f)
                lineTo(22f, 18f)
            }
            line(15.5f, 15.5f, 20.5f, 15.5f)
        }
    }

    val Type: ImageVector by lazy {
        lucideIcon("Type") {
            strokePath {
                moveTo(4f, 7f)
                verticalLineTo(4f)
                horizontalLineTo(20f)
                verticalLineTo(7f)
            }
            line(12f, 4f, 12f, 20f)
            line(9f, 20f, 15f, 20f)
        }
    }

    val Sparkles: ImageVector by lazy {
        lucideIcon("Sparkles") {
            strokePath {
                moveTo(12f, 3f)
                lineTo(13.8f, 8.2f)
                lineTo(19f, 10f)
                lineTo(13.8f, 11.8f)
                lineTo(12f, 17f)
                lineTo(10.2f, 11.8f)
                lineTo(5f, 10f)
                lineTo(10.2f, 8.2f)
                close()
            }
            line(19f, 16f, 19f, 20f)
            line(17f, 18f, 21f, 18f)
            line(5f, 16f, 5f, 18f)
            line(4f, 17f, 6f, 17f)
        }
    }

    val SlidersHorizontal: ImageVector by lazy {
        lucideIcon("SlidersHorizontal") {
            line(21f, 6f, 14f, 6f)
            line(10f, 6f, 3f, 6f)
            line(21f, 12f, 12f, 12f)
            line(8f, 12f, 3f, 12f)
            line(21f, 18f, 16f, 18f)
            line(12f, 18f, 3f, 18f)
            line(14f, 4f, 14f, 8f)
            line(8f, 10f, 8f, 14f)
            line(16f, 16f, 16f, 20f)
        }
    }

    val HardDrive: ImageVector by lazy {
        lucideIcon("HardDrive") {
            line(22f, 12f, 2f, 12f)
            strokePath {
                moveTo(5.45f, 5.11f)
                lineTo(2f, 12f)
                verticalLineTo(18f)
                arcTo(2f, 2f, 0f, false, false, 4f, 20f)
                horizontalLineTo(20f)
                arcTo(2f, 2f, 0f, false, false, 22f, 18f)
                verticalLineTo(12f)
                lineTo(18.55f, 5.11f)
                arcTo(2f, 2f, 0f, false, false, 16.76f, 4f)
                horizontalLineTo(7.24f)
                arcTo(2f, 2f, 0f, false, false, 5.45f, 5.11f)
                close()
            }
            dot(6f, 16f)
            dot(10f, 16f)
        }
    }

    val DatabaseBackup: ImageVector by lazy {
        lucideIcon("DatabaseBackup") {
            strokePath {
                moveTo(3f, 5f)
                curveTo(3f, 3.34f, 7.03f, 2f, 12f, 2f)
                curveTo(16.97f, 2f, 21f, 3.34f, 21f, 5f)
                curveTo(21f, 6.66f, 16.97f, 8f, 12f, 8f)
                curveTo(7.03f, 8f, 3f, 6.66f, 3f, 5f)
                close()
            }
            strokePath {
                moveTo(3f, 5f)
                verticalLineTo(17f)
                curveTo(3f, 18.66f, 7.03f, 20f, 12f, 20f)
                curveTo(13.2f, 20f, 14.3f, 19.9f, 15.3f, 19.7f)
            }
            strokePath {
                moveTo(21f, 5f)
                verticalLineTo(11f)
            }
            strokePath {
                moveTo(3f, 11f)
                curveTo(3f, 12.66f, 7.03f, 14f, 12f, 14f)
            }
            strokePath {
                moveTo(21f, 18f)
                arcTo(3.5f, 3.5f, 0f, true, true, 19.5f, 14.6f)
                lineTo(21f, 15.8f)
            }
            strokePath {
                moveTo(21f, 13f)
                verticalLineTo(16f)
                horizontalLineTo(18f)
            }
        }
    }

    val CloudOff: ImageVector by lazy {
        lucideIcon("CloudOff") {
            strokePath {
                moveTo(22f, 16f)
                arcTo(4f, 4f, 0f, false, false, 18f, 12f)
                horizontalLineTo(16.7f)
                arcTo(6f, 6f, 0f, false, false, 10f, 6.3f)
            }
            strokePath {
                moveTo(6.5f, 10.2f)
                arcTo(4.5f, 4.5f, 0f, false, false, 6.5f, 19f)
                horizontalLineTo(16f)
            }
            line(2f, 2f, 22f, 22f)
        }
    }

    val Info: ImageVector by lazy {
        lucideIcon("Info") {
            circle(12f, 12f, 10f)
            line(12f, 16f, 12f, 12f)
            dot(12f, 8f)
        }
    }

    val CircleAlert: ImageVector by lazy {
        lucideIcon("CircleAlert") {
            circle(12f, 12f, 10f)
            line(12f, 8f, 12f, 12f)
            dot(12f, 16f)
        }
    }

    val TriangleAlert: ImageVector by lazy {
        lucideIcon("TriangleAlert") {
            strokePath {
                moveTo(10.29f, 3.86f)
                lineTo(1.82f, 18f)
                arcTo(2f, 2f, 0f, false, false, 3.53f, 21f)
                horizontalLineTo(20.47f)
                arcTo(2f, 2f, 0f, false, false, 22.18f, 18f)
                lineTo(13.71f, 3.86f)
                arcTo(2f, 2f, 0f, false, false, 10.29f, 3.86f)
                close()
            }
            line(12f, 9f, 12f, 13f)
            dot(12f, 17f)
        }
    }

    val Crop: ImageVector by lazy {
        lucideIcon("Crop") {
            strokePath {
                moveTo(6f, 2f)
                verticalLineTo(16f)
                arcTo(2f, 2f, 0f, false, false, 8f, 18f)
                horizontalLineTo(22f)
            }
            strokePath {
                moveTo(18f, 22f)
                verticalLineTo(8f)
                arcTo(2f, 2f, 0f, false, false, 16f, 6f)
                horizontalLineTo(2f)
            }
        }
    }

    val Move: ImageVector by lazy {
        lucideIcon("Move") {
            line(2f, 12f, 22f, 12f)
            line(12f, 2f, 12f, 22f)
            strokePath {
                moveTo(5f, 9f)
                lineTo(2f, 12f)
                lineTo(5f, 15f)
            }
            strokePath {
                moveTo(19f, 9f)
                lineTo(22f, 12f)
                lineTo(19f, 15f)
            }
            strokePath {
                moveTo(9f, 5f)
                lineTo(12f, 2f)
                lineTo(15f, 5f)
            }
            strokePath {
                moveTo(9f, 19f)
                lineTo(12f, 22f)
                lineTo(15f, 19f)
            }
        }
    }

    val Maximize2: ImageVector by lazy {
        lucideIcon("Maximize2") {
            strokePath {
                moveTo(15f, 3f)
                horizontalLineTo(21f)
                verticalLineTo(9f)
            }
            strokePath {
                moveTo(9f, 21f)
                horizontalLineTo(3f)
                verticalLineTo(15f)
            }
            line(21f, 3f, 14f, 10f)
            line(3f, 21f, 10f, 14f)
        }
    }

    val Minimize2: ImageVector by lazy {
        lucideIcon("Minimize2") {
            strokePath {
                moveTo(4f, 14f)
                horizontalLineTo(10f)
                verticalLineTo(20f)
            }
            strokePath {
                moveTo(20f, 10f)
                horizontalLineTo(14f)
                verticalLineTo(4f)
            }
            line(14f, 10f, 21f, 3f)
            line(3f, 21f, 10f, 14f)
        }
    }

    val Droplet: ImageVector by lazy {
        lucideIcon("Droplet") {
            strokePath {
                moveTo(12f, 2.69f)
                lineTo(17.66f, 8.35f)
                arcTo(8f, 8f, 0f, true, true, 6.34f, 8.35f)
                close()
            }
        }
    }

    val Eraser: ImageVector by lazy {
        lucideIcon("Eraser") {
            strokePath {
                moveTo(7f, 21f)
                horizontalLineTo(21f)
            }
            strokePath {
                moveTo(20.5f, 11.5f)
                lineTo(11f, 21f)
                horizontalLineTo(6.5f)
                lineTo(2.8f, 17.3f)
                arcTo(2f, 2f, 0f, false, true, 2.8f, 14.5f)
                lineTo(12.5f, 4.8f)
                arcTo(2f, 2f, 0f, false, true, 15.3f, 4.8f)
                lineTo(20.5f, 10f)
                arcTo(1.1f, 1.1f, 0f, false, true, 20.5f, 11.5f)
                close()
            }
            line(8.5f, 8.8f, 15.2f, 15.5f)
        }
    }

    val Gauge: ImageVector by lazy {
        lucideIcon("Gauge") {
            strokePath {
                moveTo(12f, 14f)
                lineTo(16f, 10f)
            }
            strokePath {
                moveTo(3.34f, 19f)
                arcTo(10f, 10f, 0f, true, true, 20.66f, 19f)
            }
        }
    }
}
