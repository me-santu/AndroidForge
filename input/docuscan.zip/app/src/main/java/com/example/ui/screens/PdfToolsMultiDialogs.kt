package com.example.ui.screens

import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import com.example.ui.icons.LucideIcons
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Checkbox
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FilterChipDefaults
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.minimumInteractiveComponentSize
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.unit.dp
import com.example.domain.model.DocumentItem
import com.example.domain.model.PdfOrientation
import com.example.domain.model.PdfPageSize
import com.example.util.FormatUtils

@Composable
fun MergePdfDialog(
    pdfDocuments: List<DocumentItem>,
    newlyImportedIds: List<Long> = emptyList(),
    onImportPdfSaf: () -> Unit,
    onDismiss: () -> Unit,
    onConfirmMerge: (title: String, selectedIds: List<Long>) -> Unit
) {
    val selectedIds = remember { mutableStateListOf<Long>() }
    var mergeTitle by remember { mutableStateOf("Merged_${System.currentTimeMillis() % 10000}") }

    LaunchedEffect(newlyImportedIds) {
        newlyImportedIds.forEach { id ->
            if (id !in selectedIds) {
                selectedIds.add(id)
            }
        }
    }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Merge PDF Documents") },
        text = {
            Column(
                modifier = Modifier
                    .heightIn(max = 420.dp)
                    .verticalScroll(rememberScrollState()),
                verticalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                OutlinedTextField(
                    value = mergeTitle,
                    onValueChange = { mergeTitle = it },
                    label = { Text("Output PDF Title") },
                    singleLine = true,
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("merge_title_input")
                )
                OutlinedButton(
                    onClick = onImportPdfSaf,
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("merge_select_device_btn")
                ) {
                    Icon(LucideIcons.FileUp, contentDescription = null, modifier = Modifier.size(18.dp))
                    Spacer(modifier = Modifier.size(6.dp))
                    Text("Select PDFs from Device")
                }

                val unlockedDocs = pdfDocuments.filter { !it.isPasswordProtected }
                val lockedCount = pdfDocuments.size - unlockedDocs.size
                if (lockedCount > 0) {
                    Text(
                        text = "$lockedCount password-protected PDF(s) must be unlocked via 'Unlock PDF' before merging.",
                        style = MaterialTheme.typography.labelSmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }

                if (unlockedDocs.isEmpty()) {
                    Text(
                        text = "No unencrypted PDFs in library yet. Tap 'Select PDFs from Device' above to pick 2 or more PDFs.",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                } else {
                    Text("Select 2 or more PDFs:", style = MaterialTheme.typography.labelMedium)
                    unlockedDocs.forEach { doc ->
                        val checked = doc.id in selectedIds
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .clickable {
                                    if (checked) selectedIds.remove(doc.id) else selectedIds.add(doc.id)
                                },
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Checkbox(
                                checked = checked,
                                onCheckedChange = {
                                    if (checked) selectedIds.remove(doc.id) else selectedIds.add(doc.id)
                                }
                            )
                            Column(modifier = Modifier.weight(1f)) {
                                Text(doc.title, style = MaterialTheme.typography.bodyMedium)
                                Text(
                                    text = "${doc.pageCount}p · ${FormatUtils.formatBytes(doc.sizeBytes)}",
                                    style = MaterialTheme.typography.labelSmall,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant
                                )
                            }
                        }
                    }
                }

                if (selectedIds.size >= 2) {
                    HorizontalDivider()
                    Text("Merge Order:", style = MaterialTheme.typography.labelMedium)
                    selectedIds.forEachIndexed { idx, docId ->
                        val doc = pdfDocuments.firstOrNull { it.id == docId }
                        if (doc != null) {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Text(
                                    text = "${idx + 1}. ${doc.title}",
                                    style = MaterialTheme.typography.bodySmall,
                                    modifier = Modifier.weight(1f)
                                )
                                IconButton(
                                    enabled = idx > 0,
                                    onClick = {
                                        val item = selectedIds.removeAt(idx)
                                        selectedIds.add(idx - 1, item)
                                    }
                                ) {
                                    Icon(LucideIcons.ArrowUp, contentDescription = "Move up", modifier = Modifier.size(16.dp))
                                }
                                IconButton(
                                    enabled = idx < selectedIds.lastIndex,
                                    onClick = {
                                        val item = selectedIds.removeAt(idx)
                                        selectedIds.add(idx + 1, item)
                                    }
                                ) {
                                    Icon(LucideIcons.ArrowDown, contentDescription = "Move down", modifier = Modifier.size(16.dp))
                                }
                            }
                        }
                    }
                }
            }
        },
        confirmButton = {
            TextButton(
                enabled = selectedIds.size >= 2 && mergeTitle.isNotBlank(),
                onClick = {
                    val ids = selectedIds.toList()
                    onDismiss()
                    onConfirmMerge(mergeTitle.trim(), ids)
                },
                modifier = Modifier.testTag("merge_confirm_btn")
            ) { Text("Merge (${selectedIds.size})") }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) { Text("Cancel") }
        }
    )
}

@OptIn(ExperimentalLayoutApi::class)
@Composable
fun TextToPdfDialog(
    initialImportedText: String,
    onImportTxtSaf: () -> Unit,
    onDismiss: () -> Unit,
    onGenerateTextPdf: (
        title: String,
        text: String,
        pageSize: PdfPageSize,
        orientation: PdfOrientation,
        marginPt: Float,
        fontSizePt: Float,
        includePageNumbers: Boolean,
        password: String
    ) -> Unit
) {
    var title by remember { mutableStateOf("Notes_${System.currentTimeMillis() % 10000}") }
    var bodyText by remember(initialImportedText) { mutableStateOf(initialImportedText) }
    var pageSize by remember { mutableStateOf(PdfPageSize.A4) }
    var orientation by remember { mutableStateOf(PdfOrientation.PORTRAIT) }
    var fontSizePt by remember { mutableFloatStateOf(12f) }
    var includePageNumbers by remember { mutableStateOf(true) }
    var password by remember { mutableStateOf("") }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Text to PDF") },
        text = {
            Column(
                modifier = Modifier
                    .heightIn(max = 440.dp)
                    .verticalScroll(rememberScrollState()),
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                OutlinedTextField(
                    value = title,
                    onValueChange = { title = it },
                    label = { Text("Document Title") },
                    singleLine = true,
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("text_to_pdf_title_input")
                )
                OutlinedButton(
                    onClick = onImportTxtSaf,
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("text_to_pdf_select_device_btn")
                ) {
                    Icon(LucideIcons.FileUp, contentDescription = null, modifier = Modifier.size(18.dp))
                    Spacer(modifier = Modifier.size(6.dp))
                    Text("Select .TXT File from Device")
                }
                OutlinedTextField(
                    value = bodyText,
                    onValueChange = { bodyText = it },
                    label = { Text("Text Content") },
                    placeholder = { Text("Type or paste paragraphs here...") },
                    minLines = 5,
                    maxLines = 10,
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("text_to_pdf_body_input")
                )
                Text("Page Size:", style = MaterialTheme.typography.labelMedium)
                FlowRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    listOf(PdfPageSize.A4, PdfPageSize.A5, PdfPageSize.LETTER).forEach { sz ->
                        FilterChip(
                            selected = pageSize == sz,
                            onClick = { pageSize = sz },
                            label = { Text(sz.label) },
                            colors = FilterChipDefaults.filterChipColors(
                                selectedContainerColor = MaterialTheme.colorScheme.primary,
                                selectedLabelColor = MaterialTheme.colorScheme.onPrimary
                            )
                        )
                    }
                }
                Text("Orientation & Font:", style = MaterialTheme.typography.labelMedium)
                FlowRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    PdfOrientation.entries.forEach { ori ->
                        FilterChip(
                            selected = orientation == ori,
                            onClick = { orientation = ori },
                            label = { Text(ori.label) },
                            colors = FilterChipDefaults.filterChipColors(
                                selectedContainerColor = MaterialTheme.colorScheme.primary,
                                selectedLabelColor = MaterialTheme.colorScheme.onPrimary
                            )
                        )
                    }
                    listOf(10f, 12f, 14f, 16f).forEach { pt ->
                        FilterChip(
                            selected = fontSizePt == pt,
                            onClick = { fontSizePt = pt },
                            label = { Text("${pt.toInt()}pt") },
                            colors = FilterChipDefaults.filterChipColors(
                                selectedContainerColor = MaterialTheme.colorScheme.primary,
                                selectedLabelColor = MaterialTheme.colorScheme.onPrimary
                            )
                        )
                    }
                }
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clickable { includePageNumbers = !includePageNumbers },
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Checkbox(
                        checked = includePageNumbers,
                        onCheckedChange = { includePageNumbers = it }
                    )
                    Text("Include page numbers", style = MaterialTheme.typography.bodySmall)
                }
                OutlinedTextField(
                    value = password,
                    onValueChange = { password = it },
                    label = { Text("Optional AES-128 Password") },
                    leadingIcon = { Icon(LucideIcons.Lock, contentDescription = null) },
                    visualTransformation = PasswordVisualTransformation(),
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )
            }
        },
        confirmButton = {
            TextButton(
                enabled = title.isNotBlank() && bodyText.isNotBlank(),
                onClick = {
                    onDismiss()
                    onGenerateTextPdf(
                        title.trim(),
                        bodyText,
                        pageSize,
                        orientation,
                        40f,
                        fontSizePt,
                        includePageNumbers,
                        password
                    )
                },
                modifier = Modifier.testTag("text_to_pdf_confirm_btn")
            ) { Text("Create PDF") }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) { Text("Cancel") }
        }
    )
}

@Composable
fun ImagesToPdfDialog(
    activeSessionPageCount: Int,
    onPickGalleryImages: () -> Unit,
    onOpenPageManager: () -> Unit,
    onDismiss: () -> Unit
) {
    AlertDialog(
        onDismissRequest = onDismiss,
        icon = {
            Icon(LucideIcons.FileText, contentDescription = null, tint = MaterialTheme.colorScheme.primary)
        },
        title = { Text("Images to PDF") },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                Text(
                    text = "Select one or multiple gallery photos via Android Photo Picker, reorder or enhance pages in Page Manager, then export with A4/A5/Letter/Custom sizing.",
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
                if (activeSessionPageCount > 0) {
                    Text(
                        text = "Current workspace has $activeSessionPageCount ready page(s).",
                        style = MaterialTheme.typography.labelMedium,
                        color = MaterialTheme.colorScheme.primary
                    )
                }
                Button(
                    onClick = {
                        onDismiss()
                        onPickGalleryImages()
                    },
                    colors = ButtonDefaults.buttonColors(
                        containerColor = MaterialTheme.colorScheme.primary,
                        contentColor = MaterialTheme.colorScheme.onPrimary
                    ),
                    modifier = Modifier
                        .fillMaxWidth()
                        .minimumInteractiveComponentSize()
                        .testTag("images_to_pdf_pick_gallery_btn")
                ) {
                    Icon(LucideIcons.Images, contentDescription = null)
                    Spacer(modifier = Modifier.size(8.dp))
                    Text("Select Images from Device")
                }
                OutlinedButton(
                    onClick = {
                        onDismiss()
                        onOpenPageManager()
                    },
                    modifier = Modifier
                        .fillMaxWidth()
                        .minimumInteractiveComponentSize()
                        .testTag("images_to_pdf_open_manager_btn")
                ) {
                    Icon(LucideIcons.FileText, contentDescription = null)
                    Spacer(modifier = Modifier.size(8.dp))
                    Text(
                        if (activeSessionPageCount > 0) {
                            "Continue in Page Manager ($activeSessionPageCount)"
                        } else {
                            "Open Page Manager Workspace"
                        }
                    )
                }
            }
        },
        confirmButton = {},
        dismissButton = {
            TextButton(onClick = onDismiss) { Text("Close") }
        }
    )
}
