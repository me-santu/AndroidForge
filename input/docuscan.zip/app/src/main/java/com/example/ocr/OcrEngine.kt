package com.example.ocr

import android.graphics.Bitmap
import android.graphics.BitmapFactory
import com.example.domain.model.ScanPage
import com.example.pdf.PdfRenderOutcome
import com.example.pdf.PdfRendererHelper
import com.example.scanner.BitmapFilterEngine
import com.google.android.gms.tasks.Task
import com.google.mlkit.vision.common.InputImage
import com.google.mlkit.vision.text.TextRecognition
import com.google.mlkit.vision.text.TextRecognizer
import com.google.mlkit.vision.text.chinese.ChineseTextRecognizerOptions
import com.google.mlkit.vision.text.devanagari.DevanagariTextRecognizerOptions
import com.google.mlkit.vision.text.japanese.JapaneseTextRecognizerOptions
import com.google.mlkit.vision.text.korean.KoreanTextRecognizerOptions
import com.google.mlkit.vision.text.latin.TextRecognizerOptions
import com.tom_roush.pdfbox.pdmodel.PDDocument
import com.tom_roush.pdfbox.text.PDFTextStripper
import kotlinx.coroutines.CoroutineDispatcher
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.suspendCancellableCoroutine
import kotlinx.coroutines.withContext
import java.io.File
import kotlin.coroutines.resume
import kotlin.coroutines.resumeWithException

enum class OcrScript(
    val label: String,
    val shortLabel: String,
    val engineDescription: String,
    val isSupported: Boolean,
    val supportBadge: String
) {
    AUTO(
        label = "Auto Detect (All)",
        shortLabel = "Auto",
        engineDescription = "Auto-detects language & script across Latin (50+ languages), Devanagari (Hindi/Marathi/Nepali/Sanskrit), Chinese, Japanese & Korean on-device, plus all Unicode PDFs.",
        isSupported = true,
        supportBadge = "Auto"
    ),
    LATIN(
        label = "Latin (EN/ES/FR/DE+)",
        shortLabel = "Latin",
        engineDescription = "Google ML Kit v2 · English, Spanish, French, German, Italian, Portuguese, Dutch, Turkish, Vietnamese, Indonesian & 50+ Latin languages",
        isSupported = true,
        supportBadge = "Ready"
    ),
    DEVANAGARI(
        label = "Hindi (Devanagari)",
        shortLabel = "Hindi",
        engineDescription = "Google ML Kit v2 · Hindi, Marathi, Nepali, Sanskrit, Konkani & Maithili",
        isSupported = true,
        supportBadge = "Ready"
    ),
    CHINESE(
        label = "Chinese (中文)",
        shortLabel = "Chinese",
        engineDescription = "Google ML Kit v2 · Simplified & Traditional Chinese",
        isSupported = true,
        supportBadge = "Ready"
    ),
    JAPANESE(
        label = "Japanese (日本語)",
        shortLabel = "Japanese",
        engineDescription = "Google ML Kit v2 · Japanese (Kanji, Hiragana & Katakana)",
        isSupported = true,
        supportBadge = "Ready"
    ),
    KOREAN(
        label = "Korean (한국어)",
        shortLabel = "Korean",
        engineDescription = "Google ML Kit v2 · Korean (Hangul)",
        isSupported = true,
        supportBadge = "Ready"
    ),
    BENGALI(
        label = "Bengali (বাংলা)",
        shortLabel = "Bengali",
        engineDescription = "Digital Bengali PDFs extract directly; scanned Bengali images require a separate compatible Bengali OCR engine (not supported by ML Kit Text Recognition v2).",
        isSupported = false,
        supportBadge = "Separate Engine Required"
    )
}

data class OcrPageResult(
    val pageNumberOneBased: Int,
    val text: String,
    val qualityWarning: String? = null,
    val detectedLanguage: DetectedLanguageInfo? = null,
    val recognizedScript: OcrScript? = null
)

data class OcrExtractionResult(
    val script: OcrScript,
    val pages: List<OcrPageResult>,
    val combinedText: String,
    val warnings: List<String> = emptyList(),
    val detectedLanguage: DetectedLanguageInfo? = null,
    val effectiveScript: OcrScript = script
)

interface OcrProvider {
    val script: OcrScript
    val engineName: String
    val isAvailable: Boolean

    suspend fun recognizeBitmap(bitmap: Bitmap, rotationDegrees: Int = 0): Result<String>
}

class BengaliOcrStubProvider : OcrProvider {
    override val script: OcrScript = OcrScript.BENGALI
    override val engineName: String = "Bengali OCR Plugin Slot (Not Bundled)"
    override val isAvailable: Boolean = false

    override suspend fun recognizeBitmap(bitmap: Bitmap, rotationDegrees: Int): Result<String> =
        Result.failure(
            UnsupportedOperationException(
                "Bengali image OCR is not supported by ML Kit Text Recognition v2. Plug in a compatible Bengali OCR engine via OcrEngine.registerProvider() or use Auto Detect for text-based PDFs."
            )
        )
}

class MlKitOcrProvider(
    override val script: OcrScript,
    override val engineName: String,
    private val recognizerFactory: () -> TextRecognizer
) : OcrProvider {

    override val isAvailable: Boolean = script.isSupported

    @Volatile
    private var cachedRecognizer: TextRecognizer? = null

    private fun getOrCreateRecognizer(): TextRecognizer {
        return cachedRecognizer ?: synchronized(this) {
            cachedRecognizer ?: recognizerFactory().also { cachedRecognizer = it }
        }
    }

    override suspend fun recognizeBitmap(bitmap: Bitmap, rotationDegrees: Int): Result<String> {
        return runCatching {
            val normalizedRotation = ((rotationDegrees % 360) + 360) % 360
            val sanitizedRotation = when (normalizedRotation) {
                90, 180, 270 -> normalizedRotation
                else -> 0
            }
            val inputImage = InputImage.fromBitmap(bitmap, sanitizedRotation)
            val resultText = getOrCreateRecognizer().process(inputImage).awaitResult()
            resultText.text.trim()
        }
    }
}

private suspend fun <T> Task<T>.awaitResult(): T = suspendCancellableCoroutine { cont ->
    addOnSuccessListener { value ->
        if (cont.isActive) cont.resume(value)
    }
    addOnFailureListener { exc ->
        if (cont.isActive) cont.resumeWithException(exc)
    }
    addOnCanceledListener {
        if (cont.isActive) cont.cancel()
    }
}

class OcrEngine(
    initialProviders: Map<OcrScript, OcrProvider> = defaultProviders(),
    private val workerDispatcher: CoroutineDispatcher = Dispatchers.Default
) {
    private val providers: MutableMap<OcrScript, OcrProvider> = initialProviders.toMutableMap()

    fun registerProvider(provider: OcrProvider) {
        providers[provider.script] = provider
    }

    fun getProvider(script: OcrScript): OcrProvider? = providers[script]

    fun isScriptSupported(script: OcrScript): Boolean {
        if (script == OcrScript.AUTO) {
            return providers.values.any { it.isAvailable }
        }
        return providers[script]?.isAvailable == true
    }

    suspend fun extractTextFromBitmap(
        bitmap: Bitmap,
        script: OcrScript = OcrScript.AUTO,
        rotationDegrees: Int = 0
    ): Result<OcrExtractionResult> = withContext(workerDispatcher) {
        extractPageInternal(
            bitmap = bitmap,
            pageNumberOneBased = 1,
            script = script,
            rotationDegrees = rotationDegrees
        )
    }

    suspend fun extractTextFromImageFile(
        filePath: String,
        script: OcrScript = OcrScript.AUTO,
        rotationDegrees: Int = 0
    ): Result<OcrExtractionResult> = withContext(workerDispatcher) {
        val file = File(filePath)
        if (!file.exists() || file.length() == 0L) {
            return@withContext Result.failure(IllegalArgumentException("Image file could not be found."))
        }
        val bitmap = BitmapFilterEngine.decodeSampledBitmap(filePath, maxDimension = 2200)
            ?: BitmapFactory.decodeFile(filePath)
            ?: return@withContext Result.failure(IllegalStateException("Unable to decode image for OCR."))
        try {
            extractPageInternal(
                bitmap = bitmap,
                pageNumberOneBased = 1,
                script = script,
                rotationDegrees = rotationDegrees
            )
        } finally {
            if (!bitmap.isRecycled) {
                bitmap.recycle()
            }
        }
    }

    suspend fun extractTextFromScanPages(
        pages: List<ScanPage>,
        script: OcrScript = OcrScript.AUTO,
        onProgress: (current: Int, total: Int) -> Unit = { _, _ -> }
    ): Result<OcrExtractionResult> = withContext(workerDispatcher) {
        if (pages.isEmpty()) {
            return@withContext Result.failure(IllegalArgumentException("No scanned pages selected for OCR."))
        }
        if (script != OcrScript.AUTO) {
            validateProvider(script).getOrElse { return@withContext Result.failure(it) }
        } else if (!isScriptSupported(OcrScript.AUTO)) {
            return@withContext Result.failure(UnsupportedOperationException("No OCR provider is available."))
        }

        val orderedPages = pages.sortedBy { it.orderIndex }
        val results = mutableListOf<OcrPageResult>()
        val warnings = mutableListOf<String>()

        orderedPages.forEachIndexed { index, scanPage ->
            val pageNum = index + 1
            onProgress(pageNum, orderedPages.size)
            val raw = BitmapFilterEngine.decodeSampledBitmap(scanPage.sourcePath, maxDimension = 2200)
                ?: return@withContext Result.failure(IllegalStateException("Could not decode page $pageNum image."))
            val transformed = BitmapFilterEngine.applyTransformAndFilter(
                source = raw,
                rotationDegrees = scanPage.rotationDegrees,
                filter = scanPage.filter
            )
            try {
                val pageOutcome = recognizeSinglePageBitmap(
                    bitmap = transformed,
                    pageNumberOneBased = pageNum,
                    script = script,
                    rotationDegrees = 0
                ).getOrElse { return@withContext Result.failure(it) }
                pageOutcome.qualityWarning?.let { warnings.add("Page $pageNum: $it") }
                results.add(pageOutcome)
            } finally {
                if (transformed !== raw && !transformed.isRecycled) transformed.recycle()
                if (!raw.isRecycled) raw.recycle()
            }
        }

        finalizeMultiPageResults(script, results, warnings)
    }

    suspend fun extractTextFromPdf(
        pdfPath: String,
        pdfRendererHelper: PdfRendererHelper,
        script: OcrScript = OcrScript.AUTO,
        password: String? = null,
        onProgress: (current: Int, total: Int) -> Unit = { _, _ -> }
    ): Result<OcrExtractionResult> = withContext(workerDispatcher) {
        val file = File(pdfPath)
        if (!file.exists() || file.length() == 0L) {
            return@withContext Result.failure(IllegalArgumentException("PDF file could not be found on device."))
        }

        // First try direct Unicode embedded text extraction (supports ALL world languages in digital PDFs:
        // Bengali, Tamil, Telugu, Gujarati, Arabic, Urdu, Cyrillic, Hindi, English, Chinese, Japanese, Korean, etc.)
        val embeddedPages = extractEmbeddedPdfPageTexts(pdfPath, password)
        if (embeddedPages != null && embeddedPages.any { it.length >= 6 && it.any(Char::isLetter) }) {
            val pageResults = mutableListOf<OcrPageResult>()
            val totalPages = embeddedPages.size
            for (index in 0 until totalPages) {
                val pageNum = index + 1
                onProgress(pageNum, totalPages)
                val embedded = embeddedPages[index]
                if (embedded.length >= 6 && embedded.any(Char::isLetter)) {
                    val lang = OcrLanguageDetector.detectLanguage(embedded, script)
                    pageResults.add(
                        OcrPageResult(
                            pageNumberOneBased = pageNum,
                            text = embedded,
                            detectedLanguage = lang,
                            recognizedScript = lang?.suggestedOcrScript ?: script
                        )
                    )
                } else if (isScriptSupported(script)) {
                    // Mixed PDF: fall back to bitmap OCR for scanned image pages inside the same PDF
                    val outcome = pdfRendererHelper.renderPageOutcome(pdfPath, index, 1600, password)
                    if (outcome is PdfRenderOutcome.Success) {
                        val bmp = outcome.bitmap
                        try {
                            val ocrPage = recognizeSinglePageBitmap(bmp, pageNum, script, 0).getOrNull()
                            pageResults.add(ocrPage ?: OcrPageResult(pageNum, ""))
                        } finally {
                            if (!bmp.isRecycled) bmp.recycle()
                        }
                    } else {
                        pageResults.add(OcrPageResult(pageNum, ""))
                    }
                } else {
                    pageResults.add(OcrPageResult(pageNum, ""))
                }
            }
            if (pageResults.any { it.text.isNotBlank() }) {
                return@withContext finalizeMultiPageResults(script, pageResults, emptyList())
            }
        }

        if (script != OcrScript.AUTO) {
            validateProvider(script).getOrElse { return@withContext Result.failure(it) }
        } else if (!isScriptSupported(OcrScript.AUTO)) {
            return@withContext Result.failure(UnsupportedOperationException("No OCR provider is available."))
        }

        val firstOutcome = pdfRendererHelper.renderPageOutcome(
            filePath = pdfPath,
            pageIndex = 0,
            targetWidthPx = 1600,
            password = password
        )
        val totalPages = when (firstOutcome) {
            is PdfRenderOutcome.Success -> firstOutcome.totalPages.coerceAtLeast(1)
            is PdfRenderOutcome.PasswordRequired -> {
                return@withContext Result.failure(
                    IllegalStateException("This PDF is password protected. Enter the PDF password and retry.")
                )
            }
            is PdfRenderOutcome.Error -> {
                return@withContext Result.failure(IllegalStateException(firstOutcome.message))
            }
        }

        val pageResults = mutableListOf<OcrPageResult>()
        val warnings = mutableListOf<String>()

        for (pageIndex in 0 until totalPages) {
            val pageNum = pageIndex + 1
            onProgress(pageNum, totalPages)

            val bitmap = if (pageIndex == 0) {
                (firstOutcome as PdfRenderOutcome.Success).bitmap
            } else {
                when (val outcome = pdfRendererHelper.renderPageOutcome(pdfPath, pageIndex, 1600, password)) {
                    is PdfRenderOutcome.Success -> outcome.bitmap
                    is PdfRenderOutcome.PasswordRequired -> {
                        return@withContext Result.failure(IllegalStateException("PDF password required."))
                    }
                    is PdfRenderOutcome.Error -> {
                        return@withContext Result.failure(
                            IllegalStateException("Failed rendering page $pageNum: ${outcome.message}")
                        )
                    }
                }
            }

            try {
                val pageOutcome = recognizeSinglePageBitmap(
                    bitmap = bitmap,
                    pageNumberOneBased = pageNum,
                    script = script,
                    rotationDegrees = 0
                ).getOrElse { return@withContext Result.failure(it) }
                pageOutcome.qualityWarning?.let { warnings.add("Page $pageNum: $it") }
                pageResults.add(pageOutcome)
            } finally {
                if (!bitmap.isRecycled) {
                    bitmap.recycle()
                }
            }
        }

        finalizeMultiPageResults(script, pageResults, warnings)
    }

    private fun extractEmbeddedPdfPageTexts(pdfPath: String, password: String?): List<String>? {
        return runCatching {
            val doc = if (password.isNullOrEmpty()) {
                PDDocument.load(File(pdfPath))
            } else {
                PDDocument.load(File(pdfPath), password)
            }
            doc.use { pd ->
                val count = pd.numberOfPages
                if (count <= 0) return@use null
                val stripper = PDFTextStripper()
                (1..count).map { pageNum ->
                    stripper.startPage = pageNum
                    stripper.endPage = pageNum
                    stripper.getText(pd).trim()
                }
            }
        }.getOrNull()
    }

    private fun validateProvider(script: OcrScript): Result<OcrProvider> {
        val provider = providers[script]
            ?: return Result.failure(UnsupportedOperationException("No OCR provider registered for ${script.label}."))
        if (!provider.isAvailable) {
            return Result.failure(
                UnsupportedOperationException(
                    "${script.label} requires a separate compatible OCR engine and is not supported by ML Kit Text Recognition v2."
                )
            )
        }
        return Result.success(provider)
    }

    private suspend fun extractPageInternal(
        bitmap: Bitmap,
        pageNumberOneBased: Int,
        script: OcrScript,
        rotationDegrees: Int
    ): Result<OcrExtractionResult> {
        if (script != OcrScript.AUTO) {
            validateProvider(script).getOrElse { return Result.failure(it) }
        } else if (!isScriptSupported(OcrScript.AUTO)) {
            return Result.failure(UnsupportedOperationException("No OCR provider is available."))
        }

        val pageResult = recognizeSinglePageBitmap(
            bitmap = bitmap,
            pageNumberOneBased = pageNumberOneBased,
            script = script,
            rotationDegrees = rotationDegrees
        ).getOrElse { return Result.failure(it) }

        val warnings = listOfNotNull(pageResult.qualityWarning)
        if (pageResult.text.isBlank()) {
            val blankReason = if (pageResult.qualityWarning != null) {
                "No readable text recognized (${pageResult.qualityWarning}). Try sharper focus, better lighting, or switching language."
            } else {
                "No readable text found in this image. Ensure clear contrast and try Auto Detect or another script."
            }
            return Result.failure(IllegalStateException(blankReason))
        }
        val detectedLang = pageResult.detectedLanguage
            ?: OcrLanguageDetector.detectLanguage(pageResult.text, pageResult.recognizedScript ?: script)
        return Result.success(
            OcrExtractionResult(
                script = script,
                pages = listOf(pageResult.copy(detectedLanguage = detectedLang)),
                combinedText = pageResult.text,
                warnings = warnings,
                detectedLanguage = detectedLang,
                effectiveScript = pageResult.recognizedScript ?: detectedLang?.suggestedOcrScript ?: script
            )
        )
    }

    private suspend fun recognizeSinglePageBitmap(
        bitmap: Bitmap,
        pageNumberOneBased: Int,
        script: OcrScript,
        rotationDegrees: Int
    ): Result<OcrPageResult> {
        if (bitmap.width <= 0 || bitmap.height <= 0 || bitmap.isRecycled) {
            return Result.failure(IllegalArgumentException("Page $pageNumberOneBased image is invalid or empty."))
        }
        val quality = BitmapFilterEngine.assessImageQuality(bitmap)
        if (quality.isBlankOrUniform) {
            return Result.success(
                OcrPageResult(
                    pageNumberOneBased = pageNumberOneBased,
                    text = "",
                    qualityWarning = "Image appears empty or uniform with minimal visual detail"
                )
            )
        }
        val warning = if (quality.isLikelyBlurry) {
            "Low edge sharpness detected — image may be blurry"
        } else {
            null
        }

        if (script == OcrScript.AUTO) {
            return recognizeAutoDetectBitmap(bitmap, pageNumberOneBased, rotationDegrees, warning)
        }

        val provider = validateProvider(script).getOrElse { return Result.failure(it) }
        val text = provider.recognizeBitmap(bitmap, rotationDegrees)
            .getOrElse { return Result.failure(it) }
        val detected = if (text.isNotBlank()) OcrLanguageDetector.detectLanguage(text, script) else null
        return Result.success(
            OcrPageResult(
                pageNumberOneBased = pageNumberOneBased,
                text = text,
                qualityWarning = warning,
                detectedLanguage = detected,
                recognizedScript = script
            )
        )
    }

    private suspend fun recognizeAutoDetectBitmap(
        bitmap: Bitmap,
        pageNumberOneBased: Int,
        rotationDegrees: Int,
        qualityWarning: String?
    ): Result<OcrPageResult> {
        val candidateOrder = listOf(
            OcrScript.LATIN,
            OcrScript.DEVANAGARI,
            OcrScript.CHINESE,
            OcrScript.JAPANESE,
            OcrScript.KOREAN,
            OcrScript.BENGALI
        )
        val availableProviders = candidateOrder
            .mapNotNull { providers[it] }
            .filter { it.isAvailable }

        if (availableProviders.isEmpty()) {
            return Result.failure(UnsupportedOperationException("No OCR script recognizers are available."))
        }

        var bestScript: OcrScript = availableProviders.first().script
        var bestText = ""
        var bestScore = -1.0
        var lastError: Throwable? = null

        for (provider in availableProviders) {
            val outcome = provider.recognizeBitmap(bitmap, rotationDegrees)
            outcome.onSuccess { raw ->
                val trimmed = raw.trim()
                if (trimmed.isNotEmpty()) {
                    val score = OcrLanguageDetector.scoreCandidateForScript(provider.script, trimmed)
                    if (score > bestScore) {
                        bestScore = score
                        bestText = trimmed
                        bestScript = provider.script
                    }
                }
            }.onFailure { err ->
                lastError = err
            }
        }

        if (bestText.isBlank() && lastError != null && bestScore < 0.0) {
            return Result.failure(lastError!!)
        }

        val detected = if (bestText.isNotBlank()) {
            OcrLanguageDetector.detectLanguage(bestText, bestScript)
        } else {
            null
        }

        return Result.success(
            OcrPageResult(
                pageNumberOneBased = pageNumberOneBased,
                text = bestText,
                qualityWarning = qualityWarning,
                detectedLanguage = detected,
                recognizedScript = bestScript
            )
        )
    }

    private suspend fun finalizeMultiPageResults(
        script: OcrScript,
        results: List<OcrPageResult>,
        warnings: List<String>
    ): Result<OcrExtractionResult> {
        if (results.all { it.text.isBlank() }) {
            val detail = warnings.firstOrNull()?.let { " ($it)" }.orEmpty()
            return Result.failure(
                IllegalStateException(
                    "No readable text could be recognized across ${results.size} page(s)$detail. Verify script selection and retry."
                )
            )
        }
        val combined = if (results.size == 1) {
            results.first().text
        } else {
            results.joinToString(separator = "\n\n") { page ->
                val body = page.text.ifBlank { "[No text recognized on this page]" }
                "--- Page ${page.pageNumberOneBased} ---\n$body"
            }
        }
        val dominantScript = results
            .mapNotNull { it.recognizedScript }
            .groupingBy { it }
            .eachCount()
            .maxByOrNull { it.value }
            ?.key ?: script
        val overallLang = OcrLanguageDetector.detectLanguage(combined, dominantScript)
            ?: results.firstNotNullOfOrNull { it.detectedLanguage }

        return Result.success(
            OcrExtractionResult(
                script = script,
                pages = results,
                combinedText = combined,
                warnings = warnings,
                detectedLanguage = overallLang,
                effectiveScript = dominantScript
            )
        )
    }

    companion object {
        fun defaultProviders(): Map<OcrScript, OcrProvider> = mapOf(
            OcrScript.LATIN to MlKitOcrProvider(
                script = OcrScript.LATIN,
                engineName = "ML Kit Text Recognition v2 (Latin)",
                recognizerFactory = {
                    TextRecognition.getClient(TextRecognizerOptions.DEFAULT_OPTIONS)
                }
            ),
            OcrScript.DEVANAGARI to MlKitOcrProvider(
                script = OcrScript.DEVANAGARI,
                engineName = "ML Kit Text Recognition v2 (Devanagari)",
                recognizerFactory = {
                    TextRecognition.getClient(DevanagariTextRecognizerOptions.Builder().build())
                }
            ),
            OcrScript.CHINESE to MlKitOcrProvider(
                script = OcrScript.CHINESE,
                engineName = "ML Kit Text Recognition v2 (Chinese)",
                recognizerFactory = {
                    TextRecognition.getClient(ChineseTextRecognizerOptions.Builder().build())
                }
            ),
            OcrScript.JAPANESE to MlKitOcrProvider(
                script = OcrScript.JAPANESE,
                engineName = "ML Kit Text Recognition v2 (Japanese)",
                recognizerFactory = {
                    TextRecognition.getClient(JapaneseTextRecognizerOptions.Builder().build())
                }
            ),
            OcrScript.KOREAN to MlKitOcrProvider(
                script = OcrScript.KOREAN,
                engineName = "ML Kit Text Recognition v2 (Korean)",
                recognizerFactory = {
                    TextRecognition.getClient(KoreanTextRecognizerOptions.Builder().build())
                }
            ),
            OcrScript.BENGALI to BengaliOcrStubProvider()
        )
    }
}
