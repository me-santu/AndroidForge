package com.example.security

import android.app.KeyguardManager
import android.content.Context
import android.content.Intent
import android.os.Build
import android.provider.Settings
import android.security.keystore.KeyGenParameterSpec
import android.security.keystore.KeyProperties
import android.util.Base64
import androidx.biometric.BiometricManager
import androidx.biometric.BiometricPrompt
import androidx.core.content.ContextCompat
import androidx.fragment.app.FragmentActivity
import java.io.File
import java.security.KeyStore
import java.security.MessageDigest
import java.security.SecureRandom
import javax.crypto.Cipher
import javax.crypto.KeyGenerator
import javax.crypto.SecretKey
import javax.crypto.spec.GCMParameterSpec

data class BiometricCapability(
    val isAvailable: Boolean,
    val statusLabel: String,
    val canUseBiometrics: Boolean = isAvailable,
    val canUseDeviceCredential: Boolean = false,
    val needsEnrollment: Boolean = false
)

/**
 * Local security & privacy manager backed by Android Keystore (AES-256-GCM),
 * stretched salted PIN verification, and androidx.biometric.BiometricPrompt.
 * Never logs PINs, keys, or document contents.
 */
class SecurityManager(private val context: Context? = null) {

    companion object {
        private const val ANDROID_KEYSTORE = "AndroidKeyStore"
        private const val KEY_ALIAS = "DocuScanVaultKey_v1"
        private const val TRANSFORMATION = "AES/GCM/NoPadding"
        private const val GCM_TAG_BITS = 128
        private const val PIN_ITERATIONS = 65_536
        private val VAULT_MAGIC = "DSVAULT1".toByteArray(Charsets.US_ASCII)
    }

    val storageModeLabel: String = "100% On-Device Encrypted Vault"

    private val secureRandom = SecureRandom()

    @Volatile
    private var fallbackJvmKey: SecretKey? = null

    val isHardwareKeystoreActive: Boolean by lazy {
        runCatching {
            KeyStore.getInstance(ANDROID_KEYSTORE).apply { load(null) }
            true
        }.getOrDefault(false)
    }

    val keystoreProviderLabel: String
        get() = if (isHardwareKeystoreActive) {
            "Android Keystore (AES-256-GCM)"
        } else {
            "AES-256-GCM (Software Keystore)"
        }

    private fun getOrCreateMasterKey(): SecretKey {
        if (isHardwareKeystoreActive) {
            val ks = KeyStore.getInstance(ANDROID_KEYSTORE).apply { load(null) }
            val existing = ks.getKey(KEY_ALIAS, null) as? SecretKey
            if (existing != null) return existing

            val keyGen = KeyGenerator.getInstance(KeyProperties.KEY_ALGORITHM_AES, ANDROID_KEYSTORE)
            val specBuilder = KeyGenParameterSpec.Builder(
                KEY_ALIAS,
                KeyProperties.PURPOSE_ENCRYPT or KeyProperties.PURPOSE_DECRYPT
            )
                .setBlockModes(KeyProperties.BLOCK_MODE_GCM)
                .setEncryptionPaddings(KeyProperties.ENCRYPTION_PADDING_NONE)
                .setKeySize(256)
                .setRandomizedEncryptionRequired(true)

            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.P && context != null) {
                specBuilder.setUnlockedDeviceRequired(false)
            }
            keyGen.init(specBuilder.build())
            return keyGen.generateKey()
        }

        // Deterministic-per-process fallback only when AndroidKeyStore provider is unavailable (e.g. host JVM tests)
        return fallbackJvmKey ?: synchronized(this) {
            fallbackJvmKey ?: KeyGenerator.getInstance("AES").apply {
                init(256, secureRandom)
            }.generateKey().also { fallbackJvmKey = it }
        }
    }

    fun encryptBytes(plainBytes: ByteArray): ByteArray {
        val key = getOrCreateMasterKey()
        val cipher = Cipher.getInstance(TRANSFORMATION)
        cipher.init(Cipher.ENCRYPT_MODE, key)
        val iv = cipher.iv
        val encrypted = cipher.doFinal(plainBytes)
        return ByteArray(VAULT_MAGIC.size + 1 + iv.size + encrypted.size).apply {
            System.arraycopy(VAULT_MAGIC, 0, this, 0, VAULT_MAGIC.size)
            this[VAULT_MAGIC.size] = iv.size.toByte()
            System.arraycopy(iv, 0, this, VAULT_MAGIC.size + 1, iv.size)
            System.arraycopy(encrypted, 0, this, VAULT_MAGIC.size + 1 + iv.size, encrypted.size)
        }
    }

    fun decryptBytes(vaultBytes: ByteArray): ByteArray {
        if (!isVaultPayload(vaultBytes)) return vaultBytes
        val ivLen = vaultBytes[VAULT_MAGIC.size].toInt() and 0xFF
        val ivStart = VAULT_MAGIC.size + 1
        require(ivLen in 8..32 && vaultBytes.size > ivStart + ivLen) {
            "Corrupted vault encryption header."
        }
        val iv = vaultBytes.copyOfRange(ivStart, ivStart + ivLen)
        val ciphertext = vaultBytes.copyOfRange(ivStart + ivLen, vaultBytes.size)
        val key = getOrCreateMasterKey()
        val cipher = Cipher.getInstance(TRANSFORMATION)
        cipher.init(Cipher.DECRYPT_MODE, key, GCMParameterSpec(GCM_TAG_BITS, iv))
        return cipher.doFinal(ciphertext)
    }

    fun isVaultPayload(bytes: ByteArray): Boolean {
        if (bytes.size <= VAULT_MAGIC.size + 2) return false
        for (i in VAULT_MAGIC.indices) {
            if (bytes[i] != VAULT_MAGIC[i]) return false
        }
        return true
    }

    fun isVaultEncryptedFile(file: File): Boolean {
        if (!file.exists() || file.length() <= VAULT_MAGIC.size + 2) return false
        return runCatching {
            val header = ByteArray(VAULT_MAGIC.size)
            file.inputStream().use { input ->
                val read = input.read(header)
                read == VAULT_MAGIC.size && header.contentEquals(VAULT_MAGIC)
            }
        }.getOrDefault(false)
    }

    fun sealFileInPlace(file: File): Boolean {
        if (!file.exists() || isVaultEncryptedFile(file)) return isVaultEncryptedFile(file)
        val plain = file.readBytes()
        val sealed = encryptBytes(plain)
        val tmp = File(file.parentFile, "${file.name}.seal_tmp")
        tmp.writeBytes(sealed)
        if (!tmp.renameTo(file)) {
            file.writeBytes(sealed)
            tmp.delete()
        }
        plain.fill(0)
        return true
    }

    fun unsealFileInPlace(file: File): Boolean {
        if (!file.exists() || !isVaultEncryptedFile(file)) return false
        val sealed = file.readBytes()
        val plain = decryptBytes(sealed)
        val tmp = File(file.parentFile, "${file.name}.unseal_tmp")
        tmp.writeBytes(plain)
        if (!tmp.renameTo(file)) {
            file.writeBytes(plain)
            tmp.delete()
        }
        plain.fill(0)
        return true
    }

    fun readFilePlainBytes(file: File): ByteArray {
        val raw = file.readBytes()
        return if (isVaultPayload(raw)) decryptBytes(raw) else raw
    }

    fun createTempUnsealedCopy(sourceFile: File, cacheDir: File): File {
        if (!isVaultEncryptedFile(sourceFile)) return sourceFile
        cacheDir.mkdirs()
        val out = File(cacheDir, "view_unsealed_${System.nanoTime()}.tmp")
        val plain = readFilePlainBytes(sourceFile)
        out.writeBytes(plain)
        plain.fill(0)
        return out
    }

    fun sealString(plainText: String): String {
        val encrypted = encryptBytes(plainText.toByteArray(Charsets.UTF_8))
        return Base64.encodeToString(encrypted, Base64.NO_WRAP)
    }

    fun unsealString(sealedBase64: String): String {
        val raw = Base64.decode(sealedBase64, Base64.NO_WRAP)
        val plain = decryptBytes(raw)
        return try {
            String(plain, Charsets.UTF_8)
        } finally {
            plain.fill(0)
        }
    }

    fun createSealedPinRecord(pin: String): String {
        val clean = pin.trim()
        require(clean.length in 4..8 && clean.all(Char::isDigit)) {
            "PIN must be 4 to 8 digits."
        }
        val salt = ByteArray(16).also { secureRandom.nextBytes(it) }
        val hash = stretchPin(clean, salt)
        val payload = "v1:${Base64.encodeToString(salt, Base64.NO_WRAP)}:${Base64.encodeToString(hash, Base64.NO_WRAP)}"
        return sealString(payload)
    }

    fun verifyPin(candidatePin: String, sealedRecord: String?): Boolean {
        if (sealedRecord.isNullOrBlank()) return false
        val clean = candidatePin.trim()
        if (clean.isEmpty()) return false
        return runCatching {
            val payload = unsealString(sealedRecord)
            val parts = payload.split(":")
            if (parts.size != 3 || parts[0] != "v1") return false
            val salt = Base64.decode(parts[1], Base64.NO_WRAP)
            val expectedHash = Base64.decode(parts[2], Base64.NO_WRAP)
            val candidateHash = stretchPin(clean, salt)
            MessageDigest.isEqual(expectedHash, candidateHash)
        }.getOrDefault(false)
    }

    private fun stretchPin(pin: String, salt: ByteArray): ByteArray {
        val digest = MessageDigest.getInstance("SHA-256")
        val pinBytes = pin.toByteArray(Charsets.UTF_8)
        var current = ByteArray(salt.size + pinBytes.size).apply {
            System.arraycopy(salt, 0, this, 0, salt.size)
            System.arraycopy(pinBytes, 0, this, salt.size, pinBytes.size)
        }
        repeat(PIN_ITERATIONS) {
            digest.reset()
            digest.update(current)
            if (it % 128 == 0) digest.update(salt)
            current = digest.digest()
        }
        pinBytes.fill(0)
        return current
    }

    fun checkBiometricCapability(ctx: Context? = this.context): BiometricCapability {
        if (ctx == null) {
            return BiometricCapability(
                isAvailable = false,
                statusLabel = "Biometric context unavailable",
                canUseBiometrics = false,
                canUseDeviceCredential = false,
                needsEnrollment = false
            )
        }
        val manager = BiometricManager.from(ctx)
        val bioAuthenticators = BiometricManager.Authenticators.BIOMETRIC_STRONG or
            BiometricManager.Authenticators.BIOMETRIC_WEAK
        val bioStatus = runCatching { manager.canAuthenticate(bioAuthenticators) }
            .getOrDefault(BiometricManager.BIOMETRIC_ERROR_NO_HARDWARE)

        val hasDeviceCredential = runCatching {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
                manager.canAuthenticate(BiometricManager.Authenticators.DEVICE_CREDENTIAL) ==
                    BiometricManager.BIOMETRIC_SUCCESS
            } else {
                val km = ctx.getSystemService(Context.KEYGUARD_SERVICE) as? KeyguardManager
                km?.isDeviceSecure == true
            }
        }.getOrDefault(false)

        return when (bioStatus) {
            BiometricManager.BIOMETRIC_SUCCESS ->
                BiometricCapability(
                    isAvailable = true,
                    statusLabel = "Fingerprint / Face unlock ready",
                    canUseBiometrics = true,
                    canUseDeviceCredential = hasDeviceCredential,
                    needsEnrollment = false
                )
            BiometricManager.BIOMETRIC_ERROR_NONE_ENROLLED ->
                if (hasDeviceCredential) {
                    BiometricCapability(
                        isAvailable = true,
                        statusLabel = "Device screen lock ready · Enroll fingerprint in Settings for touch unlock",
                        canUseBiometrics = false,
                        canUseDeviceCredential = true,
                        needsEnrollment = true
                    )
                } else {
                    BiometricCapability(
                        isAvailable = false,
                        statusLabel = "No fingerprint, face, or screen lock enrolled on this device",
                        canUseBiometrics = false,
                        canUseDeviceCredential = false,
                        needsEnrollment = true
                    )
                }
            BiometricManager.BIOMETRIC_ERROR_NO_HARDWARE ->
                if (hasDeviceCredential) {
                    BiometricCapability(
                        isAvailable = true,
                        statusLabel = "Device screen lock ready (no biometric sensor)",
                        canUseBiometrics = false,
                        canUseDeviceCredential = true,
                        needsEnrollment = false
                    )
                } else {
                    BiometricCapability(
                        isAvailable = false,
                        statusLabel = "No biometric sensor or device lock available",
                        canUseBiometrics = false,
                        canUseDeviceCredential = false,
                        needsEnrollment = false
                    )
                }
            BiometricManager.BIOMETRIC_ERROR_HW_UNAVAILABLE ->
                if (hasDeviceCredential) {
                    BiometricCapability(
                        isAvailable = true,
                        statusLabel = "Biometric sensor busy · Device screen lock available",
                        canUseBiometrics = false,
                        canUseDeviceCredential = true,
                        needsEnrollment = false
                    )
                } else {
                    BiometricCapability(
                        isAvailable = false,
                        statusLabel = "Biometric sensor temporarily unavailable",
                        canUseBiometrics = false,
                        canUseDeviceCredential = false,
                        needsEnrollment = false
                    )
                }
            else ->
                if (hasDeviceCredential) {
                    BiometricCapability(
                        isAvailable = true,
                        statusLabel = "Device screen lock ready",
                        canUseBiometrics = false,
                        canUseDeviceCredential = true,
                        needsEnrollment = false
                    )
                } else {
                    BiometricCapability(
                        isAvailable = false,
                        statusLabel = "Biometric authentication unavailable",
                        canUseBiometrics = false,
                        canUseDeviceCredential = false,
                        needsEnrollment = false
                    )
                }
        }
    }

    fun createBiometricEnrollIntent(): Intent {
        return if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
            Intent(Settings.ACTION_BIOMETRIC_ENROLL).apply {
                putExtra(
                    Settings.EXTRA_BIOMETRIC_AUTHENTICATORS_ALLOWED,
                    BiometricManager.Authenticators.BIOMETRIC_STRONG or
                        BiometricManager.Authenticators.BIOMETRIC_WEAK
                )
            }
        } else {
            Intent(Settings.ACTION_SECURITY_SETTINGS)
        }
    }

    fun authenticateBiometric(
        activity: FragmentActivity,
        title: String,
        subtitle: String,
        negativeButtonText: String,
        allowDeviceCredentialFallback: Boolean = false,
        onSuccess: () -> Unit,
        onError: (String) -> Unit
    ) {
        val capability = checkBiometricCapability(activity)
        if (!capability.isAvailable) {
            onError(capability.statusLabel)
            return
        }

        val executor = ContextCompat.getMainExecutor(activity)
        val prompt = BiometricPrompt(
            activity,
            executor,
            object : BiometricPrompt.AuthenticationCallback() {
                override fun onAuthenticationSucceeded(result: BiometricPrompt.AuthenticationResult) {
                    super.onAuthenticationSucceeded(result)
                    onSuccess()
                }

                override fun onAuthenticationError(errorCode: Int, errString: CharSequence) {
                    super.onAuthenticationError(errorCode, errString)
                    when (errorCode) {
                        BiometricPrompt.ERROR_NEGATIVE_BUTTON,
                        BiometricPrompt.ERROR_USER_CANCELED,
                        BiometricPrompt.ERROR_CANCELED -> {
                            // User intentionally canceled or chose PIN fallback
                            onError("")
                        }
                        else -> onError(errString.toString())
                    }
                }

                override fun onAuthenticationFailed() {
                    super.onAuthenticationFailed()
                    onError("Biometric did not match. Please try again.")
                }
            }
        )

        val useDeviceCredential = (allowDeviceCredentialFallback && capability.canUseDeviceCredential) ||
            (!capability.canUseBiometrics && capability.canUseDeviceCredential)

        val builder = BiometricPrompt.PromptInfo.Builder()
            .setTitle(title)
            .setSubtitle(subtitle)
            .setConfirmationRequired(false)

        if (useDeviceCredential) {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
                val allowed = if (capability.canUseBiometrics) {
                    BiometricManager.Authenticators.BIOMETRIC_STRONG or
                        BiometricManager.Authenticators.BIOMETRIC_WEAK or
                        BiometricManager.Authenticators.DEVICE_CREDENTIAL
                } else {
                    BiometricManager.Authenticators.DEVICE_CREDENTIAL
                }
                builder.setAllowedAuthenticators(allowed)
            } else {
                @Suppress("DEPRECATION")
                builder.setDeviceCredentialAllowed(true)
            }
        } else {
            builder
                .setNegativeButtonText(negativeButtonText.ifBlank { "Cancel" })
                .setAllowedAuthenticators(
                    BiometricManager.Authenticators.BIOMETRIC_STRONG or
                        BiometricManager.Authenticators.BIOMETRIC_WEAK
                )
        }

        runCatching {
            prompt.authenticate(builder.build())
        }.onFailure { err ->
            onError(err.message ?: "Unable to open biometric authentication prompt.")
        }
    }
}
