package com.example.database

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase
import androidx.room.migration.Migration
import androidx.sqlite.db.SupportSQLiteDatabase
import com.example.database.dao.DeletedDocumentDao
import com.example.database.dao.DocumentDao
import com.example.database.dao.FolderDao
import com.example.database.dao.SignatureDao
import com.example.database.entity.DeletedDocumentEntity
import com.example.database.entity.DocumentEntity
import com.example.database.entity.DocumentPageEntity
import com.example.database.entity.FolderEntity
import com.example.database.entity.SignatureEntity

@Database(
    entities = [
        FolderEntity::class,
        DocumentEntity::class,
        DocumentPageEntity::class,
        SignatureEntity::class,
        DeletedDocumentEntity::class
    ],
    version = 2,
    exportSchema = false
)
abstract class DocuScanDatabase : RoomDatabase() {
    abstract fun folderDao(): FolderDao
    abstract fun documentDao(): DocumentDao
    abstract fun signatureDao(): SignatureDao
    abstract fun deletedDocumentDao(): DeletedDocumentDao

    companion object {
        val MIGRATION_1_2: Migration = object : Migration(1, 2) {
            override fun migrate(db: SupportSQLiteDatabase) {
                db.execSQL("ALTER TABLE documents ADD COLUMN isFavorite INTEGER NOT NULL DEFAULT 0")
                db.execSQL("ALTER TABLE documents ADD COLUMN isPasswordProtected INTEGER NOT NULL DEFAULT 0")
                db.execSQL("ALTER TABLE documents ADD COLUMN bookmarkedPages TEXT NOT NULL DEFAULT ''")
                db.execSQL(
                    """
                    CREATE TABLE IF NOT EXISTS deleted_documents (
                        id INTEGER PRIMARY KEY AUTOINCREMENT NOT NULL,
                        originalDocumentId INTEGER NOT NULL,
                        title TEXT NOT NULL,
                        folderId INTEGER,
                        filePath TEXT NOT NULL,
                        thumbnailPath TEXT,
                        fileType TEXT NOT NULL,
                        pageCount INTEGER NOT NULL,
                        sizeBytes INTEGER NOT NULL,
                        deletedAt INTEGER NOT NULL
                    )
                    """.trimIndent()
                )
                db.execSQL(
                    "CREATE INDEX IF NOT EXISTS index_documents_folderId ON documents(folderId)"
                )
                db.execSQL(
                    "CREATE INDEX IF NOT EXISTS index_documents_isDeleted ON documents(isDeleted)"
                )
                db.execSQL(
                    "CREATE INDEX IF NOT EXISTS index_deleted_documents_originalDocumentId ON deleted_documents(originalDocumentId)"
                )
                db.execSQL(
                    "CREATE INDEX IF NOT EXISTS index_deleted_documents_deletedAt ON deleted_documents(deletedAt)"
                )
            }
        }

        @Volatile
        private var INSTANCE: DocuScanDatabase? = null

        fun getInstance(context: Context): DocuScanDatabase {
            return INSTANCE ?: synchronized(this) {
                INSTANCE ?: Room.databaseBuilder(
                    context.applicationContext,
                    DocuScanDatabase::class.java,
                    "docuscan.db"
                )
                    .addMigrations(MIGRATION_1_2)
                    .build()
                    .also { INSTANCE = it }
            }
        }
    }
}
