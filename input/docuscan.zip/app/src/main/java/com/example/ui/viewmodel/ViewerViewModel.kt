package com.example.ui.viewmodel

import android.content.Context
import android.graphics.Bitmap
import android.net.Uri
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.example.domain.model.DocumentFileType
import com.example.domain.model.DocumentItem
import com.example.domain.model.PdfSearchMatch
import com.example.domain.repository.DocumentRepository
import com.example.pdf.PdfRenderOutcome
import com.example.pdf.PdfRendererHelper
import com.example.scanner.BitmapFilterEngine
import com.example.security.SecurityManager
import com.example.util.LocalFileManager
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.File

sealed interface ViewerUiState {
    data object Loading : ViewerUiState
    data class PasswordRequired(
        val document: DocumentItem,
        val errorMessage: String? = null
    ) : ViewerUiState
    data class Ready(
        val document: DocumentItem,
        val currentPageIndex: Int,
        val totalPages: Int,
        val pageBitmap: Bitmap?,
        val bookmarkedPages: List<Int> = emptyList(),
        val searchQuery: String = "",
        val searchMatches: List<PdfSearchMatch> = emptyList(),
        val isProcessingAction: Boolean = false
    ) : ViewerUiState
    data class Error(val message: String) : ViewerUiState
}

class ViewerViewModel(
    private val documentRepository: DocumentRepository,
    private val pdfRendererHelper: PdfRendererHelper,
    private val fileManager: LocalFileManager,
    private val securityManager: SecurityManager? = null
) : ViewModel() {

    private val _uiState = MutableStateFlow<ViewerUiState>(ViewerUiState.Loading)
    val uiState: StateFlow<ViewerUiState> = _uiState.asStateFlow()

    private val _statusMessage = MutableStateFlow<String?>(null)
    val statusMessage: StateFlow<String?> = _statusMessage.asStateFlow()

    private var loadedDoc: DocumentItem? = null
    private var activePassword: String? = null
    private var activeReadablePath: String? = null
    private var tempUnsealedFile: File? = null

    private fun clearTempUnsealedFile() {
        tempUnsealedFile?.let { tmp ->
            runCatching { if (tmp.exists()) tmp.delete() }
        }
        tempUnsealedFile = null
    }

    override fun onCleared() {
        super.onCleared()
        clearTempUnsealedFile()
    }

    fun loadDocument(documentId: Long, password: String? = null) {
        viewModelScope.launch {
            _uiState.value = ViewerUiState.Loading
            if (loadedDoc?.id != documentId && password == null) {
                activePassword = null
                clearTempUnsealedFile()
            } else if (password != null) {
                activePassword = password
            }

            val doc = documentRepository.getDocumentById(documentId)
            if (doc == null) {
                _uiState.value = ViewerUiState.Error("Document not found on device.")
                return@launch
            }
            loadedDoc = doc
            val resolvedPath = withContext(fileManager.ioDispatcher) {
                val raw = File(doc.filePath)
                if (securityManager != null && securityManager.isVaultEncryptedFile(raw)) {
                    clearTempUnsealedFile()
                    val unsealed = securityManager.createTempUnsealedCopy(raw, fileManager.appCacheDir)
                    tempUnsealedFile = unsealed
                    unsealed.absolutePath
                } else {
                    doc.filePath
                }
            }
            activeReadablePath = resolvedPath

            if (doc.fileType == DocumentFileType.IMAGE) {
                val bmp = withContext(fileManager.ioDispatcher) {
                    BitmapFilterEngine.decodeSampledBitmap(resolvedPath, 1800)
                }
                if (bmp == null) {
                    _uiState.value = ViewerUiState.Error("Could not decode image file.")
                } else {
                    _uiState.value = ViewerUiState.Ready(
                        document = doc,
                        currentPageIndex = 0,
                        totalPages = 1,
                        pageBitmap = bmp,
                        bookmarkedPages = doc.bookmarkedPages
                    )
                }
            } else {
                when (val outcome = pdfRendererHelper.renderPageOutcome(resolvedPath, 0, 1200, activePassword)) {
                    is PdfRenderOutcome.Success -> {
                        _uiState.value = ViewerUiState.Ready(
                            document = doc,
                            currentPageIndex = 0,
                            totalPages = outcome.totalPages.coerceAtLeast(1),
                            pageBitmap = outcome.bitmap,
                            bookmarkedPages = doc.bookmarkedPages
                        )
                    }
                    is PdfRenderOutcome.PasswordRequired -> {
                        _uiState.value = ViewerUiState.PasswordRequired(
                            document = doc,
                            errorMessage = if (password != null) "Incorrect password. Please try again." else null
                        )
                    }
                    is PdfRenderOutcome.Error -> {
                        _uiState.value = ViewerUiState.Error(outcome.message)
                    }
                }
            }
        }
    }

    fun unlockWithPassword(password: String) {
        val doc = loadedDoc ?: return
        loadDocument(doc.id, password)
    }

    fun goToPage(index: Int) {
        val current = _uiState.value as? ViewerUiState.Ready ?: return
        val doc = loadedDoc ?: return
        val path = activeReadablePath ?: doc.filePath
        if (index !in 0 until current.totalPages || doc.fileType == DocumentFileType.IMAGE) return
        viewModelScope.launch {
            when (val outcome = pdfRendererHelper.renderPageOutcome(path, index, 1200, activePassword)) {
                is PdfRenderOutcome.Success -> {
                    _uiState.value = current.copy(currentPageIndex = index, pageBitmap = outcome.bitmap)
                }
                is PdfRenderOutcome.Error -> {
                    _statusMessage.value = outcome.message
                }
                else -> Unit
            }
        }
    }

    fun toggleBookmark(pageIndex: Int) {
        val current = _uiState.value as? ViewerUiState.Ready ?: return
        val doc = loadedDoc ?: return
        viewModelScope.launch {
            documentRepository.togglePageBookmark(doc.id, pageIndex)
                .onSuccess { updatedBookmarks ->
                    val refreshed = documentRepository.getDocumentById(doc.id) ?: doc.copy(bookmarkedPages = updatedBookmarks)
                    loadedDoc = refreshed
                    val latest = _uiState.value as? ViewerUiState.Ready ?: current
                    _uiState.value = latest.copy(document = refreshed, bookmarkedPages = updatedBookmarks)
                    _statusMessage.value = if (pageIndex in updatedBookmarks) {
                        "Bookmarked Page ${pageIndex + 1}"
                    } else {
                        "Removed bookmark on Page ${pageIndex + 1}"
                    }
                }
        }
    }

    fun searchText(query: String) {
        val current = _uiState.value as? ViewerUiState.Ready ?: return
        val doc = loadedDoc ?: return
        if (query.isBlank()) {
            _uiState.value = current.copy(searchQuery = "", searchMatches = emptyList())
            return
        }
        viewModelScope.launch {
            _uiState.value = current.copy(isProcessingAction = true, searchQuery = query)
            val matches = documentRepository.searchTextInPdf(doc.id, query, activePassword)
            val latest = _uiState.value as? ViewerUiState.Ready ?: current
            _uiState.value = latest.copy(
                searchQuery = query,
                searchMatches = matches,
                isProcessingAction = false
            )
            if (matches.isEmpty()) {
                _statusMessage.value = "No embedded text matches for '$query'"
            } else {
                goToPage(matches.first().pageIndex)
            }
        }
    }

    fun clearSearch() {
        val current = _uiState.value as? ViewerUiState.Ready ?: return
        _uiState.value = current.copy(searchQuery = "", searchMatches = emptyList())
    }

    fun addAnnotation(
        noteText: String,
        addHighlightBar: Boolean,
        onNewDocCreated: (Long) -> Unit
    ) {
        val current = _uiState.value as? ViewerUiState.Ready ?: return
        val doc = loadedDoc ?: return
        viewModelScope.launch {
            _uiState.value = current.copy(isProcessingAction = true)
            documentRepository.annotatePdfDocument(
                sourceDocumentId = doc.id,
                newTitle = "${doc.title}_Annotated",
                pageIndexZeroBased = current.currentPageIndex,
                noteText = noteText,
                addHighlightBar = addHighlightBar,
                password = activePassword
            ).onSuccess { newDoc ->
                _statusMessage.value = "Saved annotated copy '${newDoc.title}'"
                onNewDocCreated(newDoc.id)
            }.onFailure { err ->
                val latest = _uiState.value as? ViewerUiState.Ready
                if (latest != null) _uiState.value = latest.copy(isProcessingAction = false)
                _statusMessage.value = err.message ?: "Could not add annotation"
            }
        }
    }

    fun exportToUri(destinationUri: Uri) {
        val doc = loadedDoc ?: return
        viewModelScope.launch {
            documentRepository.exportDocumentToUri(doc.id, destinationUri)
                .onSuccess { _statusMessage.value = "Exported PDF copy" }
                .onFailure { _statusMessage.value = it.message ?: "Export failed" }
        }
    }

    fun printCurrentDocument(context: Context) {
        val doc = loadedDoc ?: return
        if (doc.fileType == DocumentFileType.IMAGE) {
            _statusMessage.value = "Convert image to PDF first to print"
            return
        }
        val path = activeReadablePath ?: doc.filePath
        val started = pdfRendererHelper.printPdf(context, path, doc.title)
        if (!started) {
            _statusMessage.value = "Print service unavailable"
        }
    }

    fun shareCurrentDocument() {
        val doc = loadedDoc ?: return
        val mime = if (doc.fileType == DocumentFileType.IMAGE) "image/jpeg" else "application/pdf"
        fileManager.shareFile(doc.filePath, mime, "Share ${doc.title}", securityManager)
    }

    fun saveOcrNotes(documentId: Long, text: String, onSaved: () -> Unit = {}) {
        viewModelScope.launch {
            documentRepository.updateOcrText(documentId, text)
                .onSuccess {
                    loadedDoc = documentRepository.getDocumentById(documentId)
                    val current = _uiState.value as? ViewerUiState.Ready
                    val refreshed = loadedDoc
                    if (current != null && refreshed != null) {
                        _uiState.value = current.copy(document = refreshed)
                    }
                    onSaved()
                }
        }
    }

    fun clearStatusMessage() {
        _statusMessage.value = null
    }
}
