package com.example.ui.screens

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.PickVisualMediaRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.WindowInsetsSides
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.only
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.safeDrawing
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FilterChipDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.SnackbarHost
import androidx.compose.material3.SnackbarHostState
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.minimumInteractiveComponentSize
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalClipboardManager
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.SpanStyle
import androidx.compose.ui.text.buildAnnotatedString
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.core.content.ContextCompat
import androidx.core.content.FileProvider
import com.example.domain.model.DocumentItem
import com.example.domain.model.ScanPage
import com.example.ocr.OcrScript
import com.example.ui.components.DocuScanCard
import com.example.ui.components.DocuScanTopBar
import com.example.ui.components.EmptyStateView
import com.example.ui.components.PhaseStatusChip
import com.example.ui.icons.LucideIcons
import com.example.ui.viewmodel.OcrRunState
import com.example.ui.viewmodel.OcrSourceKind
import com.example.ui.viewmodel.OcrUiState
import kotlinx.coroutines.launch
import java.io.File

@Composable
fun OcrExtractorScreen(
    documents: List<DocumentItem>,
    activeSessionPages: List<ScanPage>,
    initialDocumentId: Long,
    uiState: OcrUiState,
    createCameraTempFile: () -> File,
    onInitializeDocument: (DocumentItem?) -> Unit,
    onSelectDocument: (DocumentItem) -> Unit,
    onImportImageUri: (Uri) -> Unit,
    onImportPdfUri: (Uri) -> Unit = {},
    onCapturedImageFile: (File) -> Unit,
    onSelectScanSession: (List<ScanPage>) -> Unit,
    onSelectScript: (OcrScript) -> Unit,
    onUpdatePdfPassword: (String) -> Unit,
    onRunExtraction: () -> Unit,
    onUpdateEditableText: (String) -> Unit,
    onUpdateSearchQuery: (String) -> Unit,
    onSaveNotesToDocument: () -> Unit,
    onSaveAsTxtToUri: (Uri) -> Unit,
    onClearStatusMessage: () -> Unit,
    onScanFirstDocument: () -> Unit,
    onBack: () -> Unit
) {
    val context = LocalContext.current
    val clipboardManager = LocalClipboardManager.current
    val snackbarHostState = remember { SnackbarHostState() }
    val scope = rememberCoroutineScope()

    var showPreviewTab by remember { mutableStateOf(false) }
    var pendingCameraPath by rememberSaveable { mutableStateOf<String?>(null) }

    LaunchedEffect(initialDocumentId, documents) {
        val target = if (initialDocumentId > 0L) {
            documents.firstOrNull { it.id == initialDocumentId }
        } else {
            documents.firstOrNull()
        }
        onInitializeDocument(target)
    }

    LaunchedEffect(uiState.statusMessage) {
        val msg = uiState.statusMessage
        if (!msg.isNullOrBlank()) {
            snackbarHostState.showSnackbar(msg)
            onClearStatusMessage()
        }
    }

    val photoPickerLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.PickVisualMedia()
    ) { uri ->
        if (uri != null) {
            onImportImageUri(uri)
        }
    }

    val pdfPickerLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.OpenDocument()
    ) { uri ->
        if (uri != null) {
            onImportPdfUri(uri)
        }
    }

    val cameraLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.TakePicture()
    ) { saved ->
        val path = pendingCameraPath
        pendingCameraPath = null
        val file = path?.let(::File)
        if (saved && file != null && file.exists() && file.length() > 0L) {
            onCapturedImageFile(file)
        }
    }

    fun launchCameraCapture() {
        runCatching {
            val file = createCameraTempFile()
            pendingCameraPath = file.absolutePath
            val uri = FileProvider.getUriForFile(
                context,
                "${context.packageName}.fileprovider",
                file
            )
            cameraLauncher.launch(uri)
        }.onFailure { err ->
            pendingCameraPath = null
            scope.launch {
                snackbarHostState.showSnackbar(err.message ?: "Unable to launch camera on this device.")
            }
        }
    }

    val cameraPermissionLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.RequestPermission()
    ) { granted ->
        if (granted) {
            launchCameraCapture()
        } else {
            scope.launch {
                snackbarHostState.showSnackbar("Camera permission is required to capture a photo for OCR.")
            }
        }
    }

    val saveTxtLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.CreateDocument("text/plain")
    ) { uri ->
        if (uri != null) {
            onSaveAsTxtToUri(uri)
        }
    }

    Scaffold(
        modifier = Modifier.fillMaxSize(),
        containerColor = MaterialTheme.colorScheme.background,
        contentWindowInsets = WindowInsets.safeDrawing.only(
            WindowInsetsSides.Bottom + WindowInsetsSides.Horizontal
        ),
        snackbarHost = { SnackbarHost(snackbarHostState) },
        topBar = {
            DocuScanTopBar(
                title = "OCR Text Extractor",
                subtitle = "Auto-Detect · Multi-Language On-Device",
                onBack = onBack
            )
        }
    ) { innerPadding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
                .verticalScroll(rememberScrollState())
                .padding(horizontal = 16.dp, vertical = 12.dp),
            verticalArrangement = Arrangement.spacedBy(14.dp)
        ) {
            // Script & Auto-Language Detector Card
            DocuScanCard {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        Icon(
                            imageVector = LucideIcons.Languages,
                            contentDescription = null,
                            tint = MaterialTheme.colorScheme.primary
                        )
                        Text("Language & Auto-Detector", style = MaterialTheme.typography.titleSmall)
                    }
                    PhaseStatusChip(
                        text = when {
                            uiState.selectedScript == OcrScript.AUTO -> "Auto-Detect"
                            uiState.selectedScript.isSupported -> "ML Kit v2"
                            else -> "Unavailable"
                        },
                        highlighted = uiState.selectedScript.isSupported
                    )
                }

                Spacer(modifier = Modifier.height(10.dp))
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .horizontalScroll(rememberScrollState()),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    OcrScript.entries.forEach { script ->
                        val selected = uiState.selectedScript == script
                        FilterChip(
                            selected = selected,
                            onClick = { onSelectScript(script) },
                            leadingIcon = if (script == OcrScript.AUTO) {
                                {
                                    Icon(
                                        imageVector = LucideIcons.Sparkles,
                                        contentDescription = null,
                                        modifier = Modifier.size(15.dp)
                                    )
                                }
                            } else {
                                null
                            },
                            label = {
                                Text(
                                    if (script.isSupported) script.label
                                    else "${script.shortLabel} (Separate Engine)"
                                )
                            },
                            colors = FilterChipDefaults.filterChipColors(
                                selectedContainerColor = if (script.isSupported) {
                                    MaterialTheme.colorScheme.primary
                                } else {
                                    MaterialTheme.colorScheme.surfaceContainerHigh
                                },
                                selectedLabelColor = if (script.isSupported) {
                                    MaterialTheme.colorScheme.onPrimary
                                } else {
                                    MaterialTheme.colorScheme.error
                                },
                                selectedLeadingIconColor = MaterialTheme.colorScheme.onPrimary
                            ),
                            modifier = Modifier.testTag("ocr_script_${script.name.lowercase()}")
                        )
                    }
                }

                Spacer(modifier = Modifier.height(8.dp))
                if (!uiState.selectedScript.isSupported) {
                    Surface(
                        color = MaterialTheme.colorScheme.errorContainer.copy(alpha = 0.45f),
                        shape = MaterialTheme.shapes.small,
                        border = BorderStroke(1.dp, MaterialTheme.colorScheme.error.copy(alpha = 0.5f)),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Row(
                            modifier = Modifier.padding(10.dp),
                            horizontalArrangement = Arrangement.spacedBy(8.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Icon(
                                imageVector = LucideIcons.TriangleAlert,
                                contentDescription = "Separate engine required",
                                tint = MaterialTheme.colorScheme.error,
                                modifier = Modifier.size(18.dp)
                            )
                            Text(
                                text = "Bengali scanned-image OCR requires a separate compatible OCR engine. Digital Bengali PDFs extract automatically using Auto Detect.",
                                style = MaterialTheme.typography.bodySmall,
                                color = MaterialTheme.colorScheme.onSurface
                            )
                        }
                    }
                } else {
                    Text(
                        text = uiState.selectedScript.engineDescription,
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }

                val detected = uiState.detectedLanguage
                if (detected != null) {
                    Spacer(modifier = Modifier.height(10.dp))
                    Surface(
                        color = MaterialTheme.colorScheme.primary.copy(alpha = 0.14f),
                        shape = MaterialTheme.shapes.small,
                        border = BorderStroke(1.dp, MaterialTheme.colorScheme.primary.copy(alpha = 0.45f)),
                        modifier = Modifier
                            .fillMaxWidth()
                            .testTag("ocr_detected_language_badge")
                    ) {
                        Row(
                            modifier = Modifier.padding(horizontal = 12.dp, vertical = 8.dp),
                            horizontalArrangement = Arrangement.spacedBy(8.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Icon(
                                imageVector = LucideIcons.Globe,
                                contentDescription = "Detected Language",
                                tint = MaterialTheme.colorScheme.primary,
                                modifier = Modifier.size(16.dp)
                            )
                            Text(
                                text = "Auto-Detected: ${detected.badgeLabel}",
                                style = MaterialTheme.typography.labelMedium,
                                fontWeight = FontWeight.SemiBold,
                                color = MaterialTheme.colorScheme.onSurface
                            )
                        }
                    }
                }
            }

            // Source Selection Card
            DocuScanCard {
                Text("Source Image or Document", style = MaterialTheme.typography.titleSmall)
                Spacer(modifier = Modifier.height(10.dp))

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    OutlinedButton(
                        onClick = {
                            photoPickerLauncher.launch(
                                PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageOnly)
                            )
                        },
                        modifier = Modifier
                            .weight(1f)
                            .minimumInteractiveComponentSize()
                            .testTag("ocr_pick_image_btn")
                    ) {
                        Icon(LucideIcons.Images, contentDescription = null, modifier = Modifier.size(18.dp))
                        Spacer(modifier = Modifier.size(6.dp))
                        Text("Image (Device)")
                    }

                    OutlinedButton(
                        onClick = {
                            val granted = ContextCompat.checkSelfPermission(
                                context,
                                Manifest.permission.CAMERA
                            ) == PackageManager.PERMISSION_GRANTED
                            if (granted) {
                                launchCameraCapture()
                            } else {
                                cameraPermissionLauncher.launch(Manifest.permission.CAMERA)
                            }
                        },
                        modifier = Modifier
                            .weight(1f)
                            .minimumInteractiveComponentSize()
                            .testTag("ocr_camera_btn")
                    ) {
                        Icon(LucideIcons.Camera, contentDescription = null, modifier = Modifier.size(18.dp))
                        Spacer(modifier = Modifier.size(6.dp))
                        Text("Take Photo")
                    }
                }

                Spacer(modifier = Modifier.height(8.dp))
                OutlinedButton(
                    onClick = { pdfPickerLauncher.launch(arrayOf("application/pdf")) },
                    modifier = Modifier
                        .fillMaxWidth()
                        .minimumInteractiveComponentSize()
                        .testTag("ocr_pick_pdf_btn")
                ) {
                    Icon(LucideIcons.FileUp, contentDescription = null, modifier = Modifier.size(18.dp))
                    Spacer(modifier = Modifier.size(6.dp))
                    Text("Select PDF from Device")
                }

                if (activeSessionPages.isNotEmpty()) {
                    Spacer(modifier = Modifier.height(8.dp))
                    OutlinedButton(
                        onClick = { onSelectScanSession(activeSessionPages) },
                        modifier = Modifier
                            .fillMaxWidth()
                            .testTag("ocr_use_session_btn")
                    ) {
                        Icon(LucideIcons.Layers, contentDescription = null, modifier = Modifier.size(18.dp))
                        Spacer(modifier = Modifier.size(6.dp))
                        Text("Use Current Scan Session (${activeSessionPages.size} page(s))")
                    }
                }

                if (documents.isNotEmpty()) {
                    Spacer(modifier = Modifier.height(10.dp))
                    Text(
                        text = "Saved Documents",
                        style = MaterialTheme.typography.labelMedium,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                    Spacer(modifier = Modifier.height(6.dp))
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .horizontalScroll(rememberScrollState()),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        documents.forEach { doc ->
                            val isSelected = uiState.sourceKind == OcrSourceKind.DOCUMENT &&
                                uiState.selectedDocumentId == doc.id
                            FilterChip(
                                selected = isSelected,
                                onClick = { onSelectDocument(doc) },
                                label = { Text("${doc.title} (${doc.pageCount}p)") },
                                leadingIcon = {
                                    Icon(
                                        LucideIcons.FileText,
                                        contentDescription = null,
                                        modifier = Modifier.size(16.dp)
                                    )
                                },
                                colors = FilterChipDefaults.filterChipColors(
                                    selectedContainerColor = MaterialTheme.colorScheme.primary,
                                    selectedLabelColor = MaterialTheme.colorScheme.onPrimary
                                )
                            )
                        }
                    }
                } else if (uiState.standaloneImagePath == null && activeSessionPages.isEmpty()) {
                    Spacer(modifier = Modifier.height(10.dp))
                    EmptyStateView(
                        title = "No document selected yet",
                        subtitle = "Pick a photo, take a picture, or scan a document to auto-detect language and extract editable text.",
                        actionLabel = "Scan Document",
                        onAction = onScanFirstDocument
                    )
                }

                val selectedDoc = documents.firstOrNull { it.id == uiState.selectedDocumentId }
                if (uiState.sourceKind == OcrSourceKind.DOCUMENT && selectedDoc?.isPasswordProtected == true) {
                    Spacer(modifier = Modifier.height(10.dp))
                    OutlinedTextField(
                        value = uiState.pdfPassword,
                        onValueChange = onUpdatePdfPassword,
                        label = { Text("PDF Password (if required)") },
                        singleLine = true,
                        modifier = Modifier.fillMaxWidth()
                    )
                }

                Spacer(modifier = Modifier.height(12.dp))
                val hasSource = when (uiState.sourceKind) {
                    OcrSourceKind.STANDALONE_IMAGE -> !uiState.standaloneImagePath.isNullOrBlank()
                    OcrSourceKind.SCAN_SESSION -> uiState.sessionPages.isNotEmpty()
                    OcrSourceKind.DOCUMENT -> uiState.selectedDocumentId > 0L
                }
                val isExtracting = uiState.runState is OcrRunState.Extracting
                val allowExtraction = uiState.selectedScript.isSupported ||
                    (uiState.sourceKind == OcrSourceKind.DOCUMENT && selectedDoc?.fileType != com.example.domain.model.DocumentFileType.IMAGE)
                Button(
                    onClick = onRunExtraction,
                    enabled = hasSource && !isExtracting && allowExtraction,
                    colors = ButtonDefaults.buttonColors(
                        containerColor = MaterialTheme.colorScheme.primary,
                        contentColor = MaterialTheme.colorScheme.onPrimary
                    ),
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(50.dp)
                        .testTag("ocr_run_btn")
                ) {
                    Icon(LucideIcons.Sparkles, contentDescription = null, modifier = Modifier.size(18.dp))
                    Spacer(modifier = Modifier.size(8.dp))
                    Text(
                        when {
                            !allowExtraction -> "Select Auto Detect or Supported Script"
                            isExtracting -> "Detecting & Extracting..."
                            uiState.sourceTitle.isNotBlank() -> "Extract Text · ${uiState.sourceTitle.take(22)}"
                            else -> "Extract Text"
                        }
                    )
                }
            }

            // Progress, Warnings, and Errors
            when (val runState = uiState.runState) {
                is OcrRunState.Extracting -> {
                    DocuScanCard(highlighted = true) {
                        Text(
                            text = if (uiState.selectedScript == OcrScript.AUTO) {
                                "Auto-detecting language & recognizing text (Page ${runState.currentPage} of ${runState.totalPages})..."
                            } else {
                                "Recognizing ${uiState.selectedScript.shortLabel} text (Page ${runState.currentPage} of ${runState.totalPages})..."
                            },
                            style = MaterialTheme.typography.titleSmall
                        )
                        Spacer(modifier = Modifier.height(8.dp))
                        LinearProgressIndicator(
                            progress = {
                                (runState.currentPage.toFloat() / runState.totalPages.coerceAtLeast(1).toFloat())
                                    .coerceIn(0.1f, 1f)
                            },
                            modifier = Modifier
                                .fillMaxWidth()
                                .testTag("ocr_progress")
                        )
                    }
                }
                is OcrRunState.Error -> {
                    DocuScanCard {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(10.dp)
                        ) {
                            Icon(
                                imageVector = LucideIcons.CircleAlert,
                                contentDescription = "OCR Error",
                                tint = MaterialTheme.colorScheme.error
                            )
                            Text(
                                text = runState.message,
                                style = MaterialTheme.typography.bodyMedium,
                                modifier = Modifier.weight(1f)
                            )
                        }
                        if (runState.canRetry) {
                            Spacer(modifier = Modifier.height(10.dp))
                            OutlinedButton(
                                onClick = onRunExtraction,
                                modifier = Modifier.testTag("ocr_retry_btn")
                            ) {
                                Icon(LucideIcons.RefreshCw, contentDescription = null, modifier = Modifier.size(18.dp))
                                Spacer(modifier = Modifier.size(6.dp))
                                Text("Retry OCR")
                            }
                        }
                    }
                }
                is OcrRunState.Success -> {
                    if (runState.warnings.isNotEmpty()) {
                        DocuScanCard {
                            Row(
                                horizontalArrangement = Arrangement.spacedBy(8.dp),
                                verticalAlignment = Alignment.Top
                            ) {
                                Icon(
                                    imageVector = LucideIcons.TriangleAlert,
                                    contentDescription = "Quality advisory",
                                    tint = MaterialTheme.colorScheme.primary
                                )
                                Column(verticalArrangement = Arrangement.spacedBy(2.dp)) {
                                    Text("Image Quality Notice", style = MaterialTheme.typography.labelLarge)
                                    runState.warnings.forEach { warn ->
                                        Text(
                                            text = warn,
                                            style = MaterialTheme.typography.bodySmall,
                                            color = MaterialTheme.colorScheme.onSurfaceVariant
                                        )
                                    }
                                }
                            }
                        }
                    }
                }
                OcrRunState.Idle -> Unit
            }

            // Search within Extracted Text + Preview / Edit Tabs
            DocuScanCard {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text("Extracted Text", style = MaterialTheme.typography.titleSmall)
                    Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                        FilterChip(
                            selected = !showPreviewTab,
                            onClick = { showPreviewTab = false },
                            label = { Text("Edit") },
                            leadingIcon = {
                                Icon(LucideIcons.Pencil, contentDescription = null, modifier = Modifier.size(16.dp))
                            }
                        )
                        FilterChip(
                            selected = showPreviewTab,
                            onClick = { showPreviewTab = true },
                            label = { Text("Preview") },
                            leadingIcon = {
                                Icon(LucideIcons.Eye, contentDescription = null, modifier = Modifier.size(16.dp))
                            }
                        )
                    }
                }

                Spacer(modifier = Modifier.height(8.dp))
                OutlinedTextField(
                    value = uiState.searchQuery,
                    onValueChange = onUpdateSearchQuery,
                    label = { Text("Search extracted text") },
                    leadingIcon = { Icon(LucideIcons.Search, contentDescription = null) },
                    trailingIcon = {
                        if (uiState.searchQuery.isNotEmpty()) {
                            IconButton(onClick = { onUpdateSearchQuery("") }) {
                                Icon(LucideIcons.X, contentDescription = "Clear search")
                            }
                        }
                    },
                    singleLine = true,
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("ocr_search_input")
                )

                if (uiState.searchQuery.isNotBlank()) {
                    Spacer(modifier = Modifier.height(6.dp))
                    Text(
                        text = if (uiState.totalMatchCount > 0) {
                            "${uiState.totalMatchCount} match(es) across ${uiState.searchMatches.size} line(s)"
                        } else {
                            "No matches found for '${uiState.searchQuery.trim()}'"
                        },
                        style = MaterialTheme.typography.labelMedium,
                        color = if (uiState.totalMatchCount > 0) {
                            MaterialTheme.colorScheme.primary
                        } else {
                            MaterialTheme.colorScheme.onSurfaceVariant
                        },
                        modifier = Modifier.testTag("ocr_search_summary")
                    )
                    if (uiState.searchMatches.isNotEmpty()) {
                        Spacer(modifier = Modifier.height(6.dp))
                        Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
                            uiState.searchMatches.take(4).forEach { match ->
                                Surface(
                                    color = MaterialTheme.colorScheme.surface,
                                    shape = MaterialTheme.shapes.small,
                                    border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline)
                                ) {
                                    Text(
                                        text = "Line ${match.lineNumber}: ${match.snippet}",
                                        style = MaterialTheme.typography.bodySmall,
                                        modifier = Modifier
                                            .fillMaxWidth()
                                            .padding(horizontal = 10.dp, vertical = 6.dp)
                                    )
                                }
                            }
                        }
                    }
                }

                Spacer(modifier = Modifier.height(10.dp))
                if (showPreviewTab) {
                    val highlightColor = MaterialTheme.colorScheme.primary.copy(alpha = 0.35f)
                    val previewAnnotated = remember(uiState.editableText, uiState.searchQuery) {
                        highlightTextMatches(uiState.editableText, uiState.searchQuery, highlightColor)
                    }
                    Surface(
                        color = MaterialTheme.colorScheme.surface,
                        shape = MaterialTheme.shapes.medium,
                        border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Text(
                            text = if (previewAnnotated.isEmpty()) {
                                AnnotatedString("No extracted text yet. Run OCR on an image or PDF above.")
                            } else {
                                previewAnnotated
                            },
                            style = MaterialTheme.typography.bodyMedium,
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(14.dp)
                                .testTag("ocr_text_preview")
                        )
                    }
                } else {
                    OutlinedTextField(
                        value = uiState.editableText,
                        onValueChange = onUpdateEditableText,
                        label = { Text("Editable OCR Text") },
                        placeholder = { Text("Extracted text appears here in page order and can be edited freely...") },
                        minLines = 8,
                        modifier = Modifier
                            .fillMaxWidth()
                            .testTag("ocr_text_editor")
                    )
                }

                Spacer(modifier = Modifier.height(12.dp))
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    OutlinedButton(
                        onClick = {
                            clipboardManager.setText(AnnotatedString(uiState.editableText))
                            scope.launch { snackbarHostState.showSnackbar("Copied all text to clipboard") }
                        },
                        enabled = uiState.editableText.isNotBlank(),
                        modifier = Modifier
                            .weight(1f)
                            .minimumInteractiveComponentSize()
                            .testTag("ocr_copy_btn")
                    ) {
                        Icon(LucideIcons.Copy, contentDescription = null, modifier = Modifier.size(16.dp))
                        Spacer(modifier = Modifier.size(4.dp))
                        Text("Copy All")
                    }

                    OutlinedButton(
                        onClick = {
                            val sendIntent = Intent(Intent.ACTION_SEND).apply {
                                type = "text/plain"
                                putExtra(Intent.EXTRA_SUBJECT, uiState.sourceTitle.ifBlank { "Extracted Text" })
                                putExtra(Intent.EXTRA_TEXT, uiState.editableText)
                            }
                            context.startActivity(
                                Intent.createChooser(sendIntent, "Share Extracted Text").apply {
                                    addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                                }
                            )
                        },
                        enabled = uiState.editableText.isNotBlank(),
                        modifier = Modifier
                            .weight(1f)
                            .minimumInteractiveComponentSize()
                            .testTag("ocr_share_btn")
                    ) {
                        Icon(LucideIcons.Share2, contentDescription = null, modifier = Modifier.size(16.dp))
                        Spacer(modifier = Modifier.size(4.dp))
                        Text("Share")
                    }
                }

                Spacer(modifier = Modifier.height(8.dp))
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    OutlinedButton(
                        onClick = {
                            val base = uiState.sourceTitle.ifBlank { "DocuScan_OCR" }
                                .replace(Regex("[^a-zA-Z0-9._-]"), "_")
                            saveTxtLauncher.launch("$base.txt")
                        },
                        enabled = uiState.editableText.isNotBlank(),
                        modifier = Modifier
                            .weight(1f)
                            .minimumInteractiveComponentSize()
                            .testTag("ocr_save_txt_btn")
                    ) {
                        Icon(LucideIcons.Download, contentDescription = null, modifier = Modifier.size(16.dp))
                        Spacer(modifier = Modifier.size(4.dp))
                        Text("Save .TXT")
                    }

                    Button(
                        onClick = onSaveNotesToDocument,
                        enabled = uiState.selectedDocumentId > 0L,
                        colors = ButtonDefaults.buttonColors(
                            containerColor = MaterialTheme.colorScheme.primary,
                            contentColor = MaterialTheme.colorScheme.onPrimary
                        ),
                        modifier = Modifier
                            .weight(1f)
                            .minimumInteractiveComponentSize()
                            .testTag("ocr_save_btn")
                    ) {
                        Icon(LucideIcons.Save, contentDescription = null, modifier = Modifier.size(16.dp))
                        Spacer(modifier = Modifier.size(4.dp))
                        Text("Save to Doc")
                    }
                }
            }
        }
    }
}

private fun highlightTextMatches(
    source: String,
    query: String,
    highlightBackground: Color
): AnnotatedString {
    val cleanQuery = query.trim()
    if (cleanQuery.isEmpty() || source.isEmpty()) {
        return AnnotatedString(source)
    }
    return buildAnnotatedString {
        append(source)
        var cursor = source.indexOf(cleanQuery, ignoreCase = true)
        while (cursor >= 0) {
            addStyle(
                style = SpanStyle(
                    background = highlightBackground,
                    fontWeight = FontWeight.Bold
                ),
                start = cursor,
                end = cursor + cleanQuery.length
            )
            cursor = source.indexOf(cleanQuery, cursor + cleanQuery.length, ignoreCase = true)
        }
    }
}
