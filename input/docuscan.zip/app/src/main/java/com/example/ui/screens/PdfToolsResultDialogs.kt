package com.example.ui.screens

import android.content.Intent
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import com.example.ui.icons.LucideIcons
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalClipboardManager
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.unit.dp
import com.example.ui.components.DocuScanCard
import com.example.ui.viewmodel.PdfToolResult
import com.example.util.FormatUtils
import java.io.File
import kotlin.math.roundToInt

@OptIn(ExperimentalLayoutApi::class)
@Composable
fun PdfToolResultBanner(
    result: PdfToolResult,
    onDismiss: () -> Unit,
    onOpenPdf: (Long) -> Unit,
    onSavePdfCopySaf: (Long, String) -> Unit,
    onSharePdf: (Long, String, String) -> Unit,
    onSaveLocalFileSaf: (localPath: String, suggestedName: String, mimeType: String, label: String) -> Unit,
    onShareLocalFile: (localPath: String, mimeType: String, title: String) -> Unit,
    onSaveImagesToFolderSaf: (paths: List<String>) -> Unit,
    onSaveTextSaf: (text: String, suggestedName: String) -> Unit,
    onOpenOcrForDoc: (Long) -> Unit
) {
    val context = LocalContext.current
    @Suppress("DEPRECATION")
    val clipboard = LocalClipboardManager.current

    when (result) {
        is PdfToolResult.PdfCreated -> {
            DocuScanCard(
                highlighted = true,
                modifier = Modifier
                    .fillMaxWidth()
                    .testTag("pdf_tool_result_card")
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    Icon(
                        imageVector = LucideIcons.CircleCheck,
                        contentDescription = "Success",
                        tint = MaterialTheme.colorScheme.primary
                    )
                    Column(modifier = Modifier.weight(1f)) {
                        Text(result.toolTitle, style = MaterialTheme.typography.titleMedium)
                        Text(
                            text = result.detailMessage,
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                    IconButton(onClick = onDismiss) {
                        Icon(LucideIcons.X, contentDescription = "Dismiss result")
                    }
                }
                Spacer(modifier = Modifier.size(10.dp))
                FlowRow(
                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                    verticalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    Button(
                        onClick = { onOpenPdf(result.document.id) },
                        colors = ButtonDefaults.buttonColors(
                            containerColor = MaterialTheme.colorScheme.primary,
                            contentColor = MaterialTheme.colorScheme.onPrimary
                        ),
                        modifier = Modifier.testTag("result_open_pdf_btn")
                    ) {
                        Icon(LucideIcons.ExternalLink, contentDescription = null, modifier = Modifier.size(18.dp))
                        Spacer(modifier = Modifier.size(6.dp))
                        Text("Open")
                    }
                    OutlinedButton(
                        onClick = { onSavePdfCopySaf(result.document.id, "${result.document.title}.pdf") },
                        modifier = Modifier.testTag("result_save_pdf_saf_btn")
                    ) {
                        Icon(LucideIcons.Download, contentDescription = null, modifier = Modifier.size(18.dp))
                        Spacer(modifier = Modifier.size(6.dp))
                        Text("Save Copy")
                    }
                    OutlinedButton(
                        onClick = {
                            onSharePdf(result.document.id, result.document.filePath, result.document.title)
                        },
                        modifier = Modifier.testTag("result_share_pdf_btn")
                    ) {
                        Icon(LucideIcons.Share2, contentDescription = null, modifier = Modifier.size(18.dp))
                        Spacer(modifier = Modifier.size(6.dp))
                        Text("Share")
                    }
                }
            }
        }

        is PdfToolResult.ActionCompleted -> {
            DocuScanCard(
                highlighted = true,
                modifier = Modifier
                    .fillMaxWidth()
                    .testTag("pdf_tool_action_result")
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    Icon(
                        imageVector = LucideIcons.CircleCheck,
                        contentDescription = "Done",
                        tint = MaterialTheme.colorScheme.primary
                    )
                    Column(modifier = Modifier.weight(1f)) {
                        Text(result.title, style = MaterialTheme.typography.titleMedium)
                        Text(
                            text = result.message,
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                    IconButton(onClick = onDismiss) {
                        Icon(LucideIcons.X, contentDescription = "Close")
                    }
                }
            }
        }

        is PdfToolResult.DocxConverted -> {
            val docxFile = File(result.conversion.outputFilePath)
            DocuScanCard(
                highlighted = true,
                modifier = Modifier
                    .fillMaxWidth()
                    .testTag("pdf_tool_docx_result")
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    Icon(
                        imageVector = LucideIcons.CircleCheck,
                        contentDescription = "DOCX Created",
                        tint = MaterialTheme.colorScheme.primary
                    )
                    Column(modifier = Modifier.weight(1f)) {
                        Text("Word (.docx) Ready", style = MaterialTheme.typography.titleMedium)
                        Text(
                            text = "${docxFile.name} · ${result.conversion.pageCount} page(s) · " +
                                "${result.conversion.extractedCharCount} chars extracted" +
                                if (result.conversion.imageFallbackPages > 0) {
                                    " · ${result.conversion.imageFallbackPages} scanned snapshot page(s)"
                                } else {
                                    ""
                                },
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                    IconButton(onClick = onDismiss) {
                        Icon(LucideIcons.X, contentDescription = "Close")
                    }
                }
                Spacer(modifier = Modifier.size(10.dp))
                FlowRow(
                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                    verticalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    Button(
                        onClick = {
                            onSaveLocalFileSaf(
                                result.conversion.outputFilePath,
                                "${result.conversion.title}.docx",
                                "application/vnd.openxmlformats-officedocument.wordprocessingml.document",
                                "DOCX"
                            )
                        },
                        colors = ButtonDefaults.buttonColors(
                            containerColor = MaterialTheme.colorScheme.primary,
                            contentColor = MaterialTheme.colorScheme.onPrimary
                        ),
                        modifier = Modifier.testTag("result_save_docx_btn")
                    ) {
                        Icon(LucideIcons.Download, contentDescription = null, modifier = Modifier.size(18.dp))
                        Spacer(modifier = Modifier.size(6.dp))
                        Text("Save .DOCX (SAF)")
                    }
                    OutlinedButton(
                        onClick = {
                            onShareLocalFile(
                                result.conversion.outputFilePath,
                                "application/vnd.openxmlformats-officedocument.wordprocessingml.document",
                                "Share ${result.conversion.title}.docx"
                            )
                        },
                        modifier = Modifier.testTag("result_share_docx_btn")
                    ) {
                        Icon(LucideIcons.Share2, contentDescription = null, modifier = Modifier.size(18.dp))
                        Spacer(modifier = Modifier.size(6.dp))
                        Text("Share .DOCX")
                    }
                }
            }
        }

        is PdfToolResult.ImagesExported -> {
            val export = result.export
            val paths = export.imageFilePaths
            val zipPath = export.zipFilePath
            DocuScanCard(
                highlighted = true,
                modifier = Modifier
                    .fillMaxWidth()
                    .testTag("pdf_tool_images_result")
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    Icon(
                        imageVector = LucideIcons.CircleCheck,
                        contentDescription = "Images Exported",
                        tint = MaterialTheme.colorScheme.primary
                    )
                    Column(modifier = Modifier.weight(1f)) {
                        Text("Exported ${paths.size} ${export.format.label} Image(s)", style = MaterialTheme.typography.titleMedium)
                        Text(
                            text = buildString {
                                append("Source: ${result.sourceTitle}")
                                if (export.savedDocumentIds.isNotEmpty()) {
                                    append(" · Saved ${export.savedDocumentIds.size} image(s) to DocuScan library")
                                }
                            },
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                    IconButton(onClick = onDismiss) {
                        Icon(LucideIcons.X, contentDescription = "Close")
                    }
                }
                Spacer(modifier = Modifier.size(10.dp))
                FlowRow(
                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                    verticalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    Button(
                        onClick = { onSaveImagesToFolderSaf(paths) },
                        colors = ButtonDefaults.buttonColors(
                            containerColor = MaterialTheme.colorScheme.primary,
                            contentColor = MaterialTheme.colorScheme.onPrimary
                        ),
                        modifier = Modifier.testTag("result_save_images_folder_btn")
                    ) {
                        Icon(LucideIcons.Folders, contentDescription = null, modifier = Modifier.size(18.dp))
                        Spacer(modifier = Modifier.size(6.dp))
                        Text("Save to Folder (SAF)")
                    }
                    if (zipPath != null) {
                        OutlinedButton(
                            onClick = {
                                onSaveLocalFileSaf(
                                    zipPath,
                                    "${result.sourceTitle}_${export.format.name}.zip",
                                    "application/zip",
                                    "Images ZIP"
                                )
                            }
                        ) {
                            Icon(LucideIcons.Download, contentDescription = null, modifier = Modifier.size(18.dp))
                            Spacer(modifier = Modifier.size(6.dp))
                            Text("Save ZIP")
                        }
                        OutlinedButton(
                            onClick = {
                                onShareLocalFile(zipPath, "application/zip", "Share ${result.sourceTitle} Images")
                            }
                        ) {
                            Icon(LucideIcons.Share2, contentDescription = null, modifier = Modifier.size(18.dp))
                            Spacer(modifier = Modifier.size(6.dp))
                            Text("Share ZIP")
                        }
                    } else if (paths.isNotEmpty()) {
                        OutlinedButton(
                            onClick = {
                                onSaveLocalFileSaf(
                                    paths.first(),
                                    "${result.sourceTitle}_page1.${export.format.extension}",
                                    export.format.mimeType,
                                    export.format.label
                                )
                            }
                        ) {
                            Icon(LucideIcons.Download, contentDescription = null, modifier = Modifier.size(18.dp))
                            Spacer(modifier = Modifier.size(6.dp))
                            Text("Save ${export.format.label}")
                        }
                        OutlinedButton(
                            onClick = {
                                onShareLocalFile(paths.first(), export.format.mimeType, "Share ${export.format.label}")
                            }
                        ) {
                            Icon(LucideIcons.Share2, contentDescription = null, modifier = Modifier.size(18.dp))
                            Spacer(modifier = Modifier.size(6.dp))
                            Text("Share")
                        }
                    }
                }
            }
        }

        is PdfToolResult.InfoInspected -> {
            val info = result.info
            val widthMm = (info.firstPageWidthPt * 25.4f / 72f).roundToInt()
            val heightMm = (info.firstPageHeightPt * 25.4f / 72f).roundToInt()
            AlertDialog(
                onDismissRequest = onDismiss,
                icon = {
                    Icon(LucideIcons.Info, contentDescription = null, tint = MaterialTheme.colorScheme.primary)
                },
                title = { Text("PDF Information") },
                text = {
                    Column(
                        modifier = Modifier
                            .heightIn(max = 380.dp)
                            .verticalScroll(rememberScrollState()),
                        verticalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        InfoRow("Document", result.document.title)
                        InfoRow("Pages", "${info.pageCount}")
                        InfoRow("File Size", FormatUtils.formatBytes(info.fileSizeBytes))
                        InfoRow("Page Dimensions", "${info.firstPageWidthPt.roundToInt()} x ${info.firstPageHeightPt.roundToInt()} pt (${widthMm} x ${heightMm} mm)")
                        InfoRow("PDF Version", info.pdfVersion)
                        InfoRow(
                            "Security",
                            if (info.isEncrypted) "Encrypted (${info.keyLengthBits}-bit)" else "Unencrypted"
                        )
                        if (info.title.isNotBlank()) InfoRow("Embedded Title", info.title)
                        if (info.author.isNotBlank()) InfoRow("Author", info.author)
                        if (info.creator.isNotBlank()) InfoRow("Creator", info.creator)
                        if (info.producer.isNotBlank()) InfoRow("Producer", info.producer)
                        info.createdDateMillis?.let {
                            InfoRow("Created", FormatUtils.formatShortDate(it))
                        }
                    }
                },
                confirmButton = {
                    TextButton(
                        onClick = {
                            onDismiss()
                            onOpenPdf(result.document.id)
                        }
                    ) { Text("Open Viewer") }
                },
                dismissButton = {
                    TextButton(onClick = onDismiss) { Text("Close") }
                }
            )
        }

        is PdfToolResult.TextExtracted -> {
            val extraction = result.extraction
            AlertDialog(
                onDismissRequest = onDismiss,
                title = {
                    Text("Extracted Text (${extraction.totalPages}p)")
                },
                text = {
                    Column(
                        modifier = Modifier
                            .heightIn(max = 400.dp)
                            .verticalScroll(rememberScrollState()),
                        verticalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        if (!extraction.hasEmbeddedText) {
                            Text(
                                text = "This PDF appears to be scanned images without embedded selectable text. Use OCR Text Extractor to recognize text from its pages.",
                                style = MaterialTheme.typography.bodySmall,
                                color = MaterialTheme.colorScheme.primary
                            )
                        }
                        Text(
                            text = extraction.fullText,
                            style = MaterialTheme.typography.bodySmall,
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(vertical = 4.dp)
                                .testTag("extracted_pdf_text_preview")
                        )
                        HorizontalDivider()
                        FlowRow(
                            horizontalArrangement = Arrangement.spacedBy(8.dp),
                            verticalArrangement = Arrangement.spacedBy(6.dp)
                        ) {
                            OutlinedButton(
                                onClick = {
                                    clipboard.setText(AnnotatedString(extraction.fullText))
                                }
                            ) {
                                Icon(LucideIcons.Copy, contentDescription = null, modifier = Modifier.size(16.dp))
                                Spacer(modifier = Modifier.size(4.dp))
                                Text("Copy All")
                            }
                            OutlinedButton(
                                onClick = {
                                    val shareIntent = Intent(Intent.ACTION_SEND).apply {
                                        type = "text/plain"
                                        putExtra(Intent.EXTRA_TEXT, extraction.fullText)
                                    }
                                    val chooser = Intent.createChooser(shareIntent, "Share Extracted Text").apply {
                                        addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                                    }
                                    context.startActivity(chooser)
                                }
                            ) {
                                Icon(LucideIcons.Share2, contentDescription = null, modifier = Modifier.size(16.dp))
                                Spacer(modifier = Modifier.size(4.dp))
                                Text("Share")
                            }
                            OutlinedButton(
                                onClick = {
                                    onSaveTextSaf(extraction.fullText, "${result.document.title}.txt")
                                }
                            ) {
                                Icon(LucideIcons.Download, contentDescription = null, modifier = Modifier.size(16.dp))
                                Spacer(modifier = Modifier.size(4.dp))
                                Text("Save .TXT")
                            }
                            if (!extraction.hasEmbeddedText && result.document.id > 0L) {
                                Button(
                                    onClick = {
                                        onDismiss()
                                        onOpenOcrForDoc(result.document.id)
                                    },
                                    colors = ButtonDefaults.buttonColors(
                                        containerColor = MaterialTheme.colorScheme.primary,
                                        contentColor = MaterialTheme.colorScheme.onPrimary
                                    )
                                ) {
                                    Icon(LucideIcons.Type, contentDescription = null, modifier = Modifier.size(16.dp))
                                    Spacer(modifier = Modifier.size(4.dp))
                                    Text("Run OCR")
                                }
                            }
                        }
                    }
                },
                confirmButton = {
                    TextButton(onClick = onDismiss) { Text("Done") }
                }
            )
        }
    }
}

@Composable
private fun InfoRow(label: String, value: String) {
    Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween
    ) {
        Text(
            text = label,
            style = MaterialTheme.typography.labelMedium,
            color = MaterialTheme.colorScheme.onSurfaceVariant,
            modifier = Modifier.weight(0.42f)
        )
        Text(
            text = value,
            style = MaterialTheme.typography.bodySmall,
            color = MaterialTheme.colorScheme.onSurface,
            modifier = Modifier.weight(0.58f)
        )
    }
}
