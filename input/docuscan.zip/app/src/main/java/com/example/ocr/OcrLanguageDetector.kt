package com.example.ocr

import com.google.android.gms.tasks.Task
import com.google.mlkit.nl.languageid.LanguageIdentification
import com.google.mlkit.nl.languageid.LanguageIdentificationOptions
import kotlinx.coroutines.suspendCancellableCoroutine
import java.util.Locale
import kotlin.coroutines.resume
import kotlin.coroutines.resumeWithException

data class DetectedLanguageInfo(
    val languageCode: String,
    val displayName: String,
    val confidence: Float,
    val scriptFamily: String,
    val suggestedOcrScript: OcrScript
) {
    val badgeLabel: String
        get() {
            val pct = (confidence * 100f).toInt().coerceIn(0, 100)
            return if (pct >= 50) {
                "$displayName (${languageCode.uppercase(Locale.ROOT)}) · $pct%"
            } else {
                "$displayName · $scriptFamily"
            }
        }
}

/**
 * Automatic language & script detector for OCR results.
 * Combines Google ML Kit on-device Language Identification (100+ languages)
 * with fast Unicode script-block analysis covering all major world & Indian scripts.
 */
object OcrLanguageDetector {

    private val languageNames: Map<String, String> = mapOf(
        "en" to "English",
        "hi" to "Hindi",
        "bn" to "Bengali",
        "mr" to "Marathi",
        "ne" to "Nepali",
        "sa" to "Sanskrit",
        "ta" to "Tamil",
        "te" to "Telugu",
        "gu" to "Gujarati",
        "pa" to "Punjabi",
        "kn" to "Kannada",
        "ml" to "Malayalam",
        "or" to "Odia",
        "ur" to "Urdu",
        "ar" to "Arabic",
        "fa" to "Persian",
        "zh" to "Chinese",
        "ja" to "Japanese",
        "ko" to "Korean",
        "es" to "Spanish",
        "fr" to "French",
        "de" to "German",
        "it" to "Italian",
        "pt" to "Portuguese",
        "nl" to "Dutch",
        "pl" to "Polish",
        "tr" to "Turkish",
        "vi" to "Vietnamese",
        "id" to "Indonesian",
        "ms" to "Malay",
        "ru" to "Russian",
        "uk" to "Ukrainian",
        "el" to "Greek",
        "he" to "Hebrew",
        "iw" to "Hebrew",
        "th" to "Thai",
        "sv" to "Swedish",
        "no" to "Norwegian",
        "da" to "Danish",
        "fi" to "Finnish",
        "cs" to "Czech",
        "ro" to "Romanian",
        "hu" to "Hungarian",
        "sw" to "Swahili",
        "fil" to "Filipino",
        "tl" to "Tagalog"
    )

    suspend fun detectLanguage(
        text: String,
        preferredScript: OcrScript? = null
    ): DetectedLanguageInfo? {
        val sample = text.trim()
        if (sample.length < 2) return null

        val unicodeFallback = detectByUnicodeScript(sample, preferredScript)

        // Try on-device ML Kit Language Identification (supports 100+ languages)
        val mlKitResult = runCatching {
            val identifier = LanguageIdentification.getClient(
                LanguageIdentificationOptions.Builder()
                    .setConfidenceThreshold(0.35f)
                    .build()
            )
            try {
                val candidates = identifier.identifyPossibleLanguages(sample.take(2000)).awaitLangId()
                candidates.firstOrNull {
                    it.languageTag.isNotBlank() && !it.languageTag.equals("und", ignoreCase = true)
                }
            } finally {
                runCatching { identifier.close() }
            }
        }.getOrNull()

        if (mlKitResult != null) {
            val baseCode = mlKitResult.languageTag.substringBefore('-').lowercase(Locale.ROOT)
            val resolvedName = languageNames[baseCode]
                ?: runCatching {
                    Locale.forLanguageTag(mlKitResult.languageTag).getDisplayLanguage(Locale.ENGLISH)
                }.getOrNull()?.takeIf { it.isNotBlank() && !it.equals(baseCode, ignoreCase = true) }
                ?: baseCode.uppercase(Locale.ROOT)

            return DetectedLanguageInfo(
                languageCode = baseCode,
                displayName = resolvedName,
                confidence = mlKitResult.confidence.coerceIn(0f, 1f),
                scriptFamily = unicodeFallback.scriptFamily,
                suggestedOcrScript = preferredScript?.takeIf { it != OcrScript.AUTO }
                    ?: unicodeFallback.suggestedOcrScript
            )
        }

        return unicodeFallback
    }

    fun detectByUnicodeScript(
        text: String,
        preferredScript: OcrScript? = null
    ): DetectedLanguageInfo {
        var latin = 0
        var devanagari = 0
        var bengali = 0
        var tamil = 0
        var telugu = 0
        var gujarati = 0
        var gurmukhi = 0
        var kannada = 0
        var malayalam = 0
        var odia = 0
        var arabic = 0
        var cyrillic = 0
        var greek = 0
        var hebrew = 0
        var thai = 0
        var cjk = 0
        var kana = 0
        var hangul = 0

        for (ch in text) {
            val code = ch.code
            when {
                code in 0x0900..0x097F -> devanagari++
                code in 0x0980..0x09FF -> bengali++
                code in 0x0B80..0x0BFF -> tamil++
                code in 0x0C00..0x0C7F -> telugu++
                code in 0x0A80..0x0AFF -> gujarati++
                code in 0x0A00..0x0A7F -> gurmukhi++
                code in 0x0C80..0x0CFF -> kannada++
                code in 0x0D00..0x0D7F -> malayalam++
                code in 0x0B00..0x0B7F -> odia++
                code in 0x0600..0x06FF || code in 0x0750..0x077F -> arabic++
                code in 0x0400..0x04FF -> cyrillic++
                code in 0x0370..0x03FF -> greek++
                code in 0x0590..0x05FF -> hebrew++
                code in 0x0E00..0x0E7F -> thai++
                code in 0x3040..0x30FF || code in 0x31F0..0x31FF -> kana++
                code in 0xAC00..0xD7AF || code in 0x1100..0x11FF -> hangul++
                code in 0x4E00..0x9FFF || code in 0x3400..0x4DBF -> cjk++
                (ch in 'A'..'Z') || (ch in 'a'..'z') || code in 0x00C0..0x024F -> latin++
            }
        }

        val totalLetters = (
            latin + devanagari + bengali + tamil + telugu + gujarati + gurmukhi +
                kannada + malayalam + odia + arabic + cyrillic + greek + hebrew +
                thai + cjk + kana + hangul
            ).coerceAtLeast(1)

        // Japanese wins over Chinese when Hiragana/Katakana characters are present
        if (kana > 0 && (kana + cjk) >= maxOf(latin, devanagari, hangul)) {
            return DetectedLanguageInfo(
                languageCode = "ja",
                displayName = "Japanese",
                confidence = ((kana + cjk).toFloat() / totalLetters).coerceIn(0.6f, 0.99f),
                scriptFamily = "Japanese",
                suggestedOcrScript = OcrScript.JAPANESE
            )
        }

        val counts = listOf(
            Triple(devanagari, "hi", Triple("Hindi / Devanagari", "Devanagari", OcrScript.DEVANAGARI)),
            Triple(bengali, "bn", Triple("Bengali", "Bengali", OcrScript.BENGALI)),
            Triple(tamil, "ta", Triple("Tamil", "Tamil", OcrScript.AUTO)),
            Triple(telugu, "te", Triple("Telugu", "Telugu", OcrScript.AUTO)),
            Triple(gujarati, "gu", Triple("Gujarati", "Gujarati", OcrScript.AUTO)),
            Triple(gurmukhi, "pa", Triple("Punjabi", "Gurmukhi", OcrScript.AUTO)),
            Triple(kannada, "kn", Triple("Kannada", "Kannada", OcrScript.AUTO)),
            Triple(malayalam, "ml", Triple("Malayalam", "Malayalam", OcrScript.AUTO)),
            Triple(odia, "or", Triple("Odia", "Odia", OcrScript.AUTO)),
            Triple(arabic, "ar", Triple("Arabic / Urdu", "Arabic", OcrScript.AUTO)),
            Triple(cyrillic, "ru", Triple("Russian / Cyrillic", "Cyrillic", OcrScript.AUTO)),
            Triple(greek, "el", Triple("Greek", "Greek", OcrScript.AUTO)),
            Triple(hebrew, "he", Triple("Hebrew", "Hebrew", OcrScript.AUTO)),
            Triple(thai, "th", Triple("Thai", "Thai", OcrScript.AUTO)),
            Triple(hangul, "ko", Triple("Korean", "Hangul", OcrScript.KOREAN)),
            Triple(cjk, "zh", Triple("Chinese", "CJK", OcrScript.CHINESE)),
            Triple(latin, "en", Triple("English / Latin", "Latin", OcrScript.LATIN))
        )

        val winner = counts.maxByOrNull { it.first }
        if (winner != null && winner.first > 0) {
            val (count, code, meta) = winner
            val (displayName, family, suggested) = meta
            return DetectedLanguageInfo(
                languageCode = code,
                displayName = displayName,
                confidence = (count.toFloat() / totalLetters).coerceIn(0.55f, 0.98f),
                scriptFamily = family,
                suggestedOcrScript = preferredScript?.takeIf { it != OcrScript.AUTO } ?: suggested
            )
        }

        return DetectedLanguageInfo(
            languageCode = "en",
            displayName = "Detected Text",
            confidence = 0.5f,
            scriptFamily = preferredScript?.shortLabel ?: "Auto",
            suggestedOcrScript = preferredScript ?: OcrScript.LATIN
        )
    }

    /**
     * Scores an OCR candidate result produced by a specific [OcrScript] recognizer
     * to select the best script automatically during multi-script Auto-Detection.
     */
    fun scoreCandidateForScript(script: OcrScript, rawText: String): Double {
        val text = rawText.trim()
        if (text.isEmpty()) return 0.0

        var nativeCount = 0
        var latinCount = 0
        var digitCount = 0
        var noiseCount = 0
        var kanaCount = 0

        for (ch in text) {
            val code = ch.code
            when {
                ch.isWhitespace() -> Unit
                ch.isDigit() -> digitCount++
                code in 0x0900..0x097F -> if (script == OcrScript.DEVANAGARI) nativeCount++ else noiseCount++
                code in 0x3040..0x30FF || code in 0x31F0..0x31FF -> {
                    kanaCount++
                    if (script == OcrScript.JAPANESE) nativeCount++ else noiseCount++
                }
                code in 0xAC00..0xD7AF || code in 0x1100..0x11FF -> if (script == OcrScript.KOREAN) nativeCount++ else noiseCount++
                code in 0x4E00..0x9FFF || code in 0x3400..0x4DBF -> {
                    if (script == OcrScript.CHINESE || script == OcrScript.JAPANESE) nativeCount++ else noiseCount++
                }
                (ch in 'A'..'Z') || (ch in 'a'..'z') || code in 0x00C0..0x024F -> {
                    latinCount++
                    if (script == OcrScript.LATIN) nativeCount++
                }
                ch in ".,;:!?()-/'\"%₹$@#&+_=" -> Unit
                else -> noiseCount++
            }
        }

        val words = text.split(Regex("\\s+")).count { it.length >= 2 }
        val nonSpaceLen = text.count { !it.isWhitespace() }.coerceAtLeast(1)
        val noisePenalty = (noiseCount.toDouble() / nonSpaceLen) * 40.0

        val baseScore = when (script) {
            OcrScript.LATIN -> (latinCount * 1.15) + (digitCount * 0.6) + (words * 1.5)
            OcrScript.DEVANAGARI -> (nativeCount * 3.4) + (latinCount * 0.45) + (digitCount * 0.5) + (words * 1.4)
            OcrScript.CHINESE -> (nativeCount * 3.2) + (latinCount * 0.35) + (digitCount * 0.5)
            OcrScript.JAPANESE -> (kanaCount * 4.5) + (nativeCount * 3.1) + (latinCount * 0.35) + (digitCount * 0.5)
            OcrScript.KOREAN -> (nativeCount * 3.4) + (latinCount * 0.35) + (digitCount * 0.5) + (words * 1.2)
            else -> (nativeCount * 2.5) + (latinCount * 0.5) + (digitCount * 0.5)
        }

        return (baseScore - noisePenalty).coerceAtLeast(0.0)
    }

    private suspend fun <T> Task<T>.awaitLangId(): T = suspendCancellableCoroutine { cont ->
        addOnSuccessListener { value ->
            if (cont.isActive) cont.resume(value)
        }
        addOnFailureListener { exc ->
            if (cont.isActive) cont.resumeWithException(exc)
        }
        addOnCanceledListener {
            if (cont.isActive) cont.cancel()
        }
    }
}
