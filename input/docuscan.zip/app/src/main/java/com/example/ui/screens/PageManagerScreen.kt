package com.example.ui.screens

import android.graphics.Bitmap
import android.net.Uri
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.PickVisualMediaRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.itemsIndexed
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import com.example.ui.icons.LucideIcons
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.minimumInteractiveComponentSize
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.unit.dp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import coil.compose.AsyncImage
import com.example.domain.model.ScanPage
import com.example.scanner.BitmapFilterEngine
import com.example.ui.components.DocuScanTopBar
import com.example.ui.components.EmptyStateView
import com.example.ui.components.LoadingStateView
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.io.File

@Composable
fun PageManagerScreen(
    pages: List<ScanPage>,
    activeDocumentTitle: String? = null,
    onAddAnotherScan: () -> Unit,
    onImportUri: (Uri) -> Unit,
    onImportMultipleUris: ((List<Uri>) -> Unit)? = null,
    onEditPage: (String) -> Unit,
    onRotatePage: (String, Int) -> Unit,
    onMovePage: (String, Int) -> Unit,
    onRemovePage: (String) -> Unit,
    onClearAll: () -> Unit,
    onExportFinalPdf: () -> Unit,
    onBack: () -> Unit
) {
    val photoPickerLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.PickMultipleVisualMedia(maxItems = 50),
        onResult = { uris ->
            if (uris.isNotEmpty()) {
                if (onImportMultipleUris != null) {
                    onImportMultipleUris(uris)
                } else {
                    uris.forEach(onImportUri)
                }
            }
        }
    )
    var previewPageId by remember { mutableStateOf<String?>(null) }
    val previewPage = pages.firstOrNull { it.id == previewPageId }

    Scaffold(
        modifier = Modifier
            .fillMaxSize()
            .statusBarsPadding()
            .navigationBarsPadding(),
        containerColor = MaterialTheme.colorScheme.background,
        topBar = {
            DocuScanTopBar(
                title = "Page Manager",
                subtitle = activeDocumentTitle?.let { "$it · ${pages.size} page(s)" }
                    ?: "${pages.size} page(s) in current batch",
                onBack = onBack,
                actions = {
                    if (pages.isNotEmpty()) {
                        TextButton(
                            onClick = onClearAll,
                            modifier = Modifier.testTag("page_mgr_clear_btn")
                        ) {
                            Text("Clear", color = MaterialTheme.colorScheme.error)
                        }
                    }
                }
            )
        }
    ) { innerPadding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
                .padding(horizontal = 16.dp, vertical = 12.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                OutlinedButton(
                    onClick = onAddAnotherScan,
                    modifier = Modifier
                        .weight(1f)
                        .minimumInteractiveComponentSize()
                        .testTag("page_mgr_add_scan_btn")
                ) {
                    Icon(LucideIcons.ScanLine, contentDescription = null, modifier = Modifier.size(18.dp))
                    Spacer(modifier = Modifier.size(6.dp))
                    Text("Add Scan")
                }
                OutlinedButton(
                    onClick = {
                        photoPickerLauncher.launch(
                            PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageOnly)
                        )
                    },
                    modifier = Modifier
                        .weight(1f)
                        .minimumInteractiveComponentSize()
                        .testTag("page_mgr_gallery_btn")
                ) {
                    Icon(LucideIcons.ImagePlus, contentDescription = null, modifier = Modifier.size(18.dp))
                    Spacer(modifier = Modifier.size(6.dp))
                    Text("From Device")
                }
            }

            if (pages.isEmpty()) {
                Box(
                    modifier = Modifier
                        .weight(1f)
                        .fillMaxWidth(),
                    contentAlignment = Alignment.Center
                ) {
                    EmptyStateView(
                        title = "No pages in your batch",
                        subtitle = "Scan documents with ML Kit Document Scanner or import images from your gallery.",
                        actionLabel = "Add Scan",
                        onAction = onAddAnotherScan
                    )
                }
            } else {
                LazyVerticalGrid(
                    columns = GridCells.Adaptive(156.dp),
                    modifier = Modifier.weight(1f),
                    contentPadding = PaddingValues(vertical = 4.dp),
                    verticalArrangement = Arrangement.spacedBy(12.dp),
                    horizontalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    itemsIndexed(pages, key = { _, page -> page.id }) { index, page ->
                        Surface(
                            shape = MaterialTheme.shapes.medium,
                            color = MaterialTheme.colorScheme.surfaceContainer,
                            border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline),
                            modifier = Modifier.testTag("page_card_${page.id}")
                        ) {
                            Column(modifier = Modifier.padding(10.dp)) {
                                Box(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .height(160.dp)
                                        .clip(RoundedCornerShape(12.dp))
                                        .background(MaterialTheme.colorScheme.surface)
                                        .clickable { previewPageId = page.id }
                                        .testTag("page_thumb_${index}")
                                ) {
                                    AsyncImage(
                                        model = File(page.sourcePath),
                                        contentDescription = "Page ${index + 1}",
                                        contentScale = ContentScale.Crop,
                                        modifier = Modifier
                                            .fillMaxSize()
                                            .graphicsLayer {
                                                rotationZ = page.rotationDegrees.toFloat()
                                            }
                                    )
                                    Surface(
                                        shape = RoundedCornerShape(8.dp),
                                        color = MaterialTheme.colorScheme.background.copy(alpha = 0.85f),
                                        modifier = Modifier
                                            .align(Alignment.TopStart)
                                            .padding(6.dp)
                                    ) {
                                        Text(
                                            text = "P${index + 1}",
                                            style = MaterialTheme.typography.labelSmall,
                                            color = MaterialTheme.colorScheme.primary,
                                            modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                                        )
                                    }
                                    Surface(
                                        onClick = { onRemovePage(page.id) },
                                        shape = CircleShape,
                                        color = MaterialTheme.colorScheme.background.copy(alpha = 0.85f),
                                        modifier = Modifier
                                            .align(Alignment.TopEnd)
                                            .padding(6.dp)
                                            .size(28.dp)
                                            .testTag("page_delete_${index}")
                                    ) {
                                        Box(contentAlignment = Alignment.Center) {
                                            Icon(
                                                imageVector = LucideIcons.X,
                                                contentDescription = "Remove page ${index + 1}",
                                                tint = MaterialTheme.colorScheme.error,
                                                modifier = Modifier.size(16.dp)
                                            )
                                        }
                                    }
                                    Surface(
                                        onClick = { previewPageId = page.id },
                                        shape = RoundedCornerShape(8.dp),
                                        color = MaterialTheme.colorScheme.background.copy(alpha = 0.78f),
                                        modifier = Modifier
                                            .align(Alignment.BottomEnd)
                                            .padding(6.dp)
                                    ) {
                                        Icon(
                                            imageVector = LucideIcons.Eye,
                                            contentDescription = "Preview page ${index + 1}",
                                            tint = Color.White,
                                            modifier = Modifier
                                                .padding(4.dp)
                                                .size(15.dp)
                                        )
                                    }
                                }

                                Spacer(modifier = Modifier.height(8.dp))

                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.SpaceBetween,
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    IconButton(
                                        onClick = { onMovePage(page.id, -1) },
                                        enabled = index > 0,
                                        modifier = Modifier
                                            .size(34.dp)
                                            .testTag("page_move_left_${index}")
                                    ) {
                                        Icon(
                                            imageVector = LucideIcons.ArrowLeft,
                                            contentDescription = "Move page earlier",
                                            modifier = Modifier.size(17.dp)
                                        )
                                    }
                                    IconButton(
                                        onClick = { onRotatePage(page.id, 90) },
                                        modifier = Modifier
                                            .size(34.dp)
                                            .testTag("page_rotate_${index}")
                                    ) {
                                        Icon(
                                            imageVector = LucideIcons.RotateCw,
                                            contentDescription = "Rotate page 90°",
                                            tint = MaterialTheme.colorScheme.primary,
                                            modifier = Modifier.size(17.dp)
                                        )
                                    }
                                    IconButton(
                                        onClick = { onEditPage(page.id) },
                                        modifier = Modifier
                                            .size(34.dp)
                                            .testTag("page_edit_${index}")
                                    ) {
                                        Icon(
                                            imageVector = LucideIcons.Pencil,
                                            contentDescription = "Edit filters",
                                            modifier = Modifier.size(17.dp)
                                        )
                                    }
                                    IconButton(
                                        onClick = { onMovePage(page.id, 1) },
                                        enabled = index < pages.lastIndex,
                                        modifier = Modifier
                                            .size(34.dp)
                                            .testTag("page_move_right_${index}")
                                    ) {
                                        Icon(
                                            imageVector = LucideIcons.ArrowRight,
                                            contentDescription = "Move page later",
                                            modifier = Modifier.size(17.dp)
                                        )
                                    }
                                }
                            }
                        }
                    }
                }
            }

            Button(
                onClick = onExportFinalPdf,
                enabled = pages.isNotEmpty(),
                colors = ButtonDefaults.buttonColors(
                    containerColor = MaterialTheme.colorScheme.primary,
                    contentColor = MaterialTheme.colorScheme.onPrimary
                ),
                shape = MaterialTheme.shapes.medium,
                modifier = Modifier
                    .fillMaxWidth()
                    .height(52.dp)
                    .testTag("page_mgr_create_pdf_btn")
            ) {
                Icon(LucideIcons.FileText, contentDescription = null, modifier = Modifier.size(18.dp))
                Spacer(modifier = Modifier.size(8.dp))
                Text("Export Final PDF (${pages.size})")
            }
        }
    }

    if (previewPage != null) {
        PagePreviewDialog(
            page = previewPage,
            pageNumber = pages.indexOfFirst { it.id == previewPage.id } + 1,
            totalPages = pages.size,
            onRotate = { onRotatePage(previewPage.id, 90) },
            onEditFilters = {
                previewPageId = null
                onEditPage(previewPage.id)
            },
            onDismiss = { previewPageId = null }
        )
    }
}

@Composable
private fun PagePreviewDialog(
    page: ScanPage,
    pageNumber: Int,
    totalPages: Int,
    onRotate: () -> Unit,
    onEditFilters: () -> Unit,
    onDismiss: () -> Unit
) {
    var previewBitmap by remember { mutableStateOf<Bitmap?>(null) }

    LaunchedEffect(page.sourcePath, page.filter, page.rotationDegrees) {
        previewBitmap = withContext(Dispatchers.IO) {
            val base = BitmapFilterEngine.decodeSampledBitmap(page.sourcePath, 1600) ?: return@withContext null
            BitmapFilterEngine.applyTransformAndFilter(base, page.rotationDegrees, page.filter)
        }
    }

    Dialog(
        onDismissRequest = onDismiss,
        properties = DialogProperties(usePlatformDefaultWidth = false)
    ) {
        Surface(
            modifier = Modifier
                .fillMaxSize()
                .padding(16.dp),
            shape = MaterialTheme.shapes.large,
            color = MaterialTheme.colorScheme.surface,
            border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline)
        ) {
            Column(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(16.dp),
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column {
                        Text(
                            text = "Page $pageNumber of $totalPages",
                            style = MaterialTheme.typography.titleMedium
                        )
                        Text(
                            text = "${page.filter.label} · ${page.rotationDegrees}°",
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                    IconButton(onClick = onDismiss) {
                        Icon(LucideIcons.X, contentDescription = "Close preview")
                    }
                }

                Box(
                    modifier = Modifier
                        .weight(1f)
                        .fillMaxWidth()
                        .clip(MaterialTheme.shapes.medium)
                        .background(MaterialTheme.colorScheme.background),
                    contentAlignment = Alignment.Center
                ) {
                    val bmp = previewBitmap
                    if (bmp != null) {
                        Image(
                            bitmap = bmp.asImageBitmap(),
                            contentDescription = "Page $pageNumber preview",
                            contentScale = ContentScale.Fit,
                            modifier = Modifier
                                .fillMaxSize()
                                .padding(8.dp)
                        )
                    } else {
                        LoadingStateView("Rendering preview...")
                    }
                }

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    OutlinedButton(
                        onClick = onRotate,
                        modifier = Modifier
                            .weight(1f)
                            .minimumInteractiveComponentSize()
                    ) {
                        Icon(LucideIcons.RotateCw, contentDescription = null, modifier = Modifier.size(18.dp))
                        Spacer(modifier = Modifier.size(6.dp))
                        Text("Rotate 90°")
                    }
                    Button(
                        onClick = onEditFilters,
                        colors = ButtonDefaults.buttonColors(
                            containerColor = MaterialTheme.colorScheme.primary,
                            contentColor = MaterialTheme.colorScheme.onPrimary
                        ),
                        modifier = Modifier
                            .weight(1f)
                            .minimumInteractiveComponentSize()
                    ) {
                        Icon(LucideIcons.Pencil, contentDescription = null, modifier = Modifier.size(18.dp))
                        Spacer(modifier = Modifier.size(6.dp))
                        Text("Filters")
                    }
                }
            }
        }
    }
}
