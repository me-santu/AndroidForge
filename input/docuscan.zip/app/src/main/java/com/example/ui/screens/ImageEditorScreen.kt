package com.example.ui.screens

import android.graphics.Bitmap
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FilterChipDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.minimumInteractiveComponentSize
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.unit.dp
import com.example.domain.model.ScanFilter
import com.example.domain.model.ScanPage
import com.example.scanner.BitmapFilterEngine
import com.example.ui.components.DocuScanTopBar
import com.example.ui.components.EmptyStateView
import com.example.ui.components.LoadingStateView
import com.example.ui.components.PhaseStatusChip
import com.example.ui.icons.LucideIcons
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

@Composable
fun ImageEditorScreen(
    page: ScanPage?,
    onSetFilter: (String, ScanFilter) -> Unit,
    onRotate: (String, Int) -> Unit,
    onDone: () -> Unit,
    onBack: () -> Unit
) {
    var previewBitmap by remember { mutableStateOf<Bitmap?>(null) }
    var isProcessing by remember { mutableStateOf(false) }
    var qualityLabel by remember { mutableStateOf("Ready") }

    LaunchedEffect(page?.sourcePath, page?.filter, page?.rotationDegrees) {
        if (page == null) return@LaunchedEffect
        isProcessing = true
        val (rendered, qualityStatus) = withContext(Dispatchers.IO) {
            val base = BitmapFilterEngine.decodeSampledBitmap(page.sourcePath, 1400)
                ?: return@withContext null to "Unavailable"
            val processed = BitmapFilterEngine.applyTransformAndFilter(base, page.rotationDegrees, page.filter)
            val assessment = BitmapFilterEngine.assessImageQuality(processed)
            val label = when {
                assessment.isBlankOrUniform -> "Blank Frame"
                assessment.isLikelyBlurry -> "Soft Focus"
                else -> "Sharp · ${page.filter.label}"
            }
            processed to label
        }
        previewBitmap = rendered
        qualityLabel = qualityStatus
        isProcessing = false
    }

    Scaffold(
        modifier = Modifier
            .fillMaxSize()
            .statusBarsPadding()
            .navigationBarsPadding(),
        containerColor = MaterialTheme.colorScheme.background,
        topBar = {
            DocuScanTopBar(
                title = "Image Editor",
                subtitle = page?.let { "${it.filter.label} · ${it.rotationDegrees}°" },
                onBack = onBack,
                actions = {
                    PhaseStatusChip(
                        text = qualityLabel,
                        highlighted = qualityLabel.startsWith("Sharp"),
                        modifier = Modifier.padding(end = 12.dp)
                    )
                }
            )
        }
    ) { innerPadding ->
        if (page == null) {
            EmptyStateView(
                title = "No page selected",
                subtitle = "Select or capture a page first to edit filters and rotation.",
                actionLabel = "Go Back",
                onAction = onBack,
                modifier = Modifier.padding(innerPadding)
            )
            return@Scaffold
        }

        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
                .padding(horizontal = 16.dp, vertical = 12.dp),
            verticalArrangement = Arrangement.spacedBy(14.dp)
        ) {
            // Canvas Preview
            Box(
                modifier = Modifier
                    .weight(1f)
                    .fillMaxWidth()
                    .clip(MaterialTheme.shapes.large)
                    .background(MaterialTheme.colorScheme.surface)
                    .border(1.dp, MaterialTheme.colorScheme.outline, MaterialTheme.shapes.large),
                contentAlignment = Alignment.Center
            ) {
                val bmp = previewBitmap
                when {
                    isProcessing && bmp == null -> LoadingStateView("Applying filter...")
                    bmp != null -> {
                        Image(
                            bitmap = bmp.asImageBitmap(),
                            contentDescription = "Edited scan preview",
                            contentScale = ContentScale.Fit,
                            modifier = Modifier
                                .fillMaxSize()
                                .padding(12.dp)
                        )
                    }
                    else -> {
                        EmptyStateView(
                            title = "Preview unavailable",
                            subtitle = "Unable to decode selected image file."
                        )
                    }
                }
            }

            // Filter Selector
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Text(
                    text = "Enhancement Filter",
                    style = MaterialTheme.typography.titleSmall
                )
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .horizontalScroll(rememberScrollState()),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    ScanFilter.entries.forEach { filter ->
                        val selected = page.filter == filter
                        FilterChip(
                            selected = selected,
                            onClick = { onSetFilter(page.id, filter) },
                            label = { Text(filter.label) },
                            colors = FilterChipDefaults.filterChipColors(
                                selectedContainerColor = MaterialTheme.colorScheme.primary,
                                selectedLabelColor = MaterialTheme.colorScheme.onPrimary
                            ),
                            modifier = Modifier.testTag("filter_${filter.name.lowercase()}")
                        )
                    }
                }
            }

            // Rotation & Done Controls
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(10.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                OutlinedButton(
                    onClick = { onRotate(page.id, -90) },
                    modifier = Modifier
                        .weight(1f)
                        .minimumInteractiveComponentSize()
                        .testTag("editor_rotate_left")
                ) {
                    Icon(
                        imageVector = LucideIcons.RotateCcw,
                        contentDescription = "Rotate left",
                        modifier = Modifier.size(18.dp)
                    )
                    Spacer(modifier = Modifier.size(6.dp))
                    Text("Left 90°")
                }

                OutlinedButton(
                    onClick = { onRotate(page.id, 90) },
                    modifier = Modifier
                        .weight(1f)
                        .minimumInteractiveComponentSize()
                        .testTag("editor_rotate_right")
                ) {
                    Icon(
                        imageVector = LucideIcons.RotateCw,
                        contentDescription = "Rotate right",
                        modifier = Modifier.size(18.dp)
                    )
                    Spacer(modifier = Modifier.size(6.dp))
                    Text("Right 90°")
                }
            }

            Button(
                onClick = onDone,
                colors = ButtonDefaults.buttonColors(
                    containerColor = MaterialTheme.colorScheme.primary,
                    contentColor = MaterialTheme.colorScheme.onPrimary
                ),
                shape = MaterialTheme.shapes.medium,
                modifier = Modifier
                    .fillMaxWidth()
                    .height(52.dp)
                    .testTag("editor_done_btn")
            ) {
                Icon(
                    imageVector = LucideIcons.Check,
                    contentDescription = null,
                    modifier = Modifier.size(18.dp)
                )
                Spacer(modifier = Modifier.size(8.dp))
                Text("Continue to Page Manager")
            }
        }
    }
}
