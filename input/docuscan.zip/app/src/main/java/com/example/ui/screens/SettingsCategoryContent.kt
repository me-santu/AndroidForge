package com.example.ui.screens

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FilterChipDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Surface
import androidx.compose.material3.Switch
import androidx.compose.material3.SwitchDefaults
import androidx.compose.material3.Text
import androidx.compose.material3.minimumInteractiveComponentSize
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.example.domain.model.AppFontStyle
import com.example.domain.model.AppLanguage
import com.example.domain.model.CacheSummary
import com.example.domain.model.PdfPageSize
import com.example.domain.model.ScanQuality
import com.example.domain.model.StorageSummary
import com.example.domain.model.ThemeMode
import com.example.domain.model.UserPreferences
import com.example.security.BiometricCapability
import com.example.security.SecurityManager
import com.example.ui.components.DocuScanCard
import com.example.ui.components.PhaseStatusChip
import com.example.ui.icons.LucideIcons
import com.example.ui.theme.previewFontFamilyFor
import com.example.util.FormatUtils
import com.example.util.LocalAppStrings

@Composable
internal fun AppearanceSettingsSection(
    preferences: UserPreferences,
    onSelectTheme: (ThemeMode) -> Unit,
    onSelectFontStyle: (AppFontStyle) -> Unit,
    onSelectLanguage: (AppLanguage) -> Unit
) {
    val strings = LocalAppStrings.current
    Column(verticalArrangement = Arrangement.spacedBy(14.dp)) {
        DocuScanCard {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                Icon(
                    imageVector = LucideIcons.Palette,
                    contentDescription = null,
                    tint = MaterialTheme.colorScheme.primary
                )
                Text(strings.appTheme, style = MaterialTheme.typography.titleMedium)
            }
            Spacer(modifier = Modifier.height(10.dp))
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                ThemeMode.entries.forEach { mode ->
                    FilterChip(
                        selected = preferences.themeMode == mode,
                        onClick = { onSelectTheme(mode) },
                        label = { Text(mode.label) },
                        colors = FilterChipDefaults.filterChipColors(
                            selectedContainerColor = MaterialTheme.colorScheme.primary,
                            selectedLabelColor = MaterialTheme.colorScheme.onPrimary
                        ),
                        modifier = Modifier
                            .weight(1f)
                            .testTag("theme_option_${mode.name.lowercase()}")
                    )
                }
            }
        }

        // Font Style Selector (Default, Poppins, Leelawadi)
        DocuScanCard {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                Icon(
                    imageVector = LucideIcons.Type,
                    contentDescription = null,
                    tint = MaterialTheme.colorScheme.primary
                )
                Text(strings.fontStyle, style = MaterialTheme.typography.titleMedium)
            }
            Spacer(modifier = Modifier.height(10.dp))
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                AppFontStyle.entries.forEach { style ->
                    val isSelected = preferences.fontStyle == style
                    val previewFamily = previewFontFamilyFor(style)
                    Surface(
                        onClick = { onSelectFontStyle(style) },
                        shape = RoundedCornerShape(12.dp),
                        color = if (isSelected) {
                            MaterialTheme.colorScheme.primaryContainer
                        } else {
                            MaterialTheme.colorScheme.surface
                        },
                        border = BorderStroke(
                            width = if (isSelected) 1.5.dp else 1.dp,
                            color = if (isSelected) {
                                MaterialTheme.colorScheme.primary
                            } else {
                                MaterialTheme.colorScheme.outline
                            }
                        ),
                        modifier = Modifier
                            .fillMaxWidth()
                            .minimumInteractiveComponentSize()
                            .testTag("font_style_option_${style.name.lowercase()}")
                    ) {
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(horizontal = 14.dp, vertical = 12.dp),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Column(verticalArrangement = Arrangement.spacedBy(2.dp)) {
                                Text(
                                    text = style.label,
                                    style = MaterialTheme.typography.titleSmall.copy(
                                        fontFamily = previewFamily,
                                        fontWeight = FontWeight.SemiBold
                                    ),
                                    color = if (isSelected) {
                                        MaterialTheme.colorScheme.primary
                                    } else {
                                        MaterialTheme.colorScheme.onSurface
                                    }
                                )
                                Text(
                                    text = "${style.subtitle} · Aa Bb Cc 123",
                                    style = MaterialTheme.typography.bodySmall.copy(
                                        fontFamily = previewFamily
                                    ),
                                    color = MaterialTheme.colorScheme.onSurfaceVariant
                                )
                            }
                            if (isSelected) {
                                Icon(
                                    imageVector = LucideIcons.CircleCheck,
                                    contentDescription = "Selected font style",
                                    tint = MaterialTheme.colorScheme.primary,
                                    modifier = Modifier.size(20.dp)
                                )
                            }
                        }
                    }
                }
            }
        }

        DocuScanCard {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                Icon(
                    imageVector = LucideIcons.Globe,
                    contentDescription = null,
                    tint = MaterialTheme.colorScheme.primary
                )
                Text(strings.interfaceLanguage, style = MaterialTheme.typography.titleMedium)
            }
            Spacer(modifier = Modifier.height(10.dp))
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                AppLanguage.entries.forEach { lang ->
                    FilterChip(
                        selected = preferences.appLanguage == lang,
                        onClick = { onSelectLanguage(lang) },
                        label = { Text(lang.nativeLabel) },
                        colors = FilterChipDefaults.filterChipColors(
                            selectedContainerColor = MaterialTheme.colorScheme.primary,
                            selectedLabelColor = MaterialTheme.colorScheme.onPrimary
                        ),
                        modifier = Modifier
                            .weight(1f)
                            .testTag("lang_option_${lang.code}")
                    )
                }
            }
        }
    }
}

@OptIn(ExperimentalLayoutApi::class)
@Composable
internal fun ScanningPdfSettingsSection(
    preferences: UserPreferences,
    onSelectScanQuality: (ScanQuality) -> Unit,
    onSelectDefaultPageSize: (PdfPageSize) -> Unit,
    onToggleAutoEnhance: (Boolean) -> Unit
) {
    val strings = LocalAppStrings.current
    Column(verticalArrangement = Arrangement.spacedBy(14.dp)) {
        DocuScanCard {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                Icon(
                    imageVector = LucideIcons.Gauge,
                    contentDescription = null,
                    tint = MaterialTheme.colorScheme.primary
                )
                Text(strings.pdfDefaults, style = MaterialTheme.typography.titleMedium)
            }
            Spacer(modifier = Modifier.height(10.dp))
            Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                ScanQuality.entries.forEach { quality ->
                    FilterChip(
                        selected = preferences.scanQuality == quality,
                        onClick = { onSelectScanQuality(quality) },
                        label = { Text(quality.label) },
                        colors = FilterChipDefaults.filterChipColors(
                            selectedContainerColor = MaterialTheme.colorScheme.primary,
                            selectedLabelColor = MaterialTheme.colorScheme.onPrimary
                        ),
                        modifier = Modifier
                            .fillMaxWidth()
                            .testTag("quality_option_${quality.name.lowercase()}")
                    )
                }
            }
        }

        DocuScanCard {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                Icon(
                    imageVector = LucideIcons.Maximize2,
                    contentDescription = null,
                    tint = MaterialTheme.colorScheme.primary,
                    modifier = Modifier.size(20.dp)
                )
                Text(strings.defaultPageSize, style = MaterialTheme.typography.titleMedium)
            }
            Spacer(modifier = Modifier.height(10.dp))
            FlowRow(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp),
                verticalArrangement = Arrangement.spacedBy(4.dp)
            ) {
                PdfPageSize.entries.forEach { pageSize ->
                    FilterChip(
                        selected = preferences.defaultPageSize == pageSize,
                        onClick = { onSelectDefaultPageSize(pageSize) },
                        label = { Text(pageSize.label) },
                        colors = FilterChipDefaults.filterChipColors(
                            selectedContainerColor = MaterialTheme.colorScheme.primary,
                            selectedLabelColor = MaterialTheme.colorScheme.onPrimary
                        ),
                        modifier = Modifier.testTag("page_size_option_${pageSize.name.lowercase()}")
                    )
                }
            }
        }

        DocuScanCard {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(10.dp),
                    modifier = Modifier.weight(1f)
                ) {
                    Icon(
                        imageVector = LucideIcons.Sparkles,
                        contentDescription = null,
                        tint = MaterialTheme.colorScheme.primary
                    )
                    Column {
                        Text(strings.autoEnhanceTitle, style = MaterialTheme.typography.titleSmall)
                        Text(
                            text = strings.autoEnhanceSubtitle,
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                }
                Switch(
                    checked = preferences.autoEnhance,
                    onCheckedChange = onToggleAutoEnhance,
                    colors = SwitchDefaults.colors(checkedThumbColor = MaterialTheme.colorScheme.onPrimary),
                    modifier = Modifier.testTag("settings_auto_enhance_switch")
                )
            }
        }
    }
}

@Composable
internal fun SecuritySettingsSection(
    preferences: UserPreferences,
    biometricCapability: BiometricCapability,
    securityManager: SecurityManager,
    onToggleAppLock: (Boolean) -> Unit,
    onRequestPinSetup: (enableLockAfter: Boolean) -> Unit,
    onToggleBiometricUnlock: (Boolean) -> Unit,
    onTestBiometricUnlock: () -> Unit,
    onOpenBiometricEnrollment: () -> Unit,
    onToggleEncryptSensitiveFiles: (Boolean) -> Unit,
    onRemovePin: () -> Unit,
    onLockVaultNow: () -> Unit
) {
    val strings = LocalAppStrings.current
    val hasAnyLockMethod = preferences.hasPinConfigured || preferences.biometricUnlockEnabled

    Column(verticalArrangement = Arrangement.spacedBy(14.dp)) {
        DocuScanCard(highlighted = preferences.appLockEnabled) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(10.dp),
                    modifier = Modifier.weight(1f)
                ) {
                    Icon(
                        imageVector = LucideIcons.Shield,
                        contentDescription = null,
                        tint = MaterialTheme.colorScheme.primary
                    )
                    Column {
                        Text(strings.securitySettingsTitle, style = MaterialTheme.typography.titleMedium)
                        Text(
                            text = securityManager.keystoreProviderLabel,
                            style = MaterialTheme.typography.labelSmall,
                            color = MaterialTheme.colorScheme.primary
                        )
                    }
                }
                PhaseStatusChip(
                    text = if (preferences.appLockEnabled) "Protected" else "Keystore",
                    highlighted = preferences.appLockEnabled
                )
            }

            Spacer(modifier = Modifier.height(14.dp))

            // Vault App Lock Toggle
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(10.dp),
                    modifier = Modifier.weight(1f)
                ) {
                    Icon(LucideIcons.Lock, contentDescription = null, tint = MaterialTheme.colorScheme.primary)
                    Column {
                        Text(strings.vaultAppLock, style = MaterialTheme.typography.titleSmall)
                        Text(
                            text = if (hasAnyLockMethod) {
                                "Automatically locks DocuScan when reopened"
                            } else {
                                "Enable Biometric Unlock or set a 4–8 digit Vault PIN"
                            },
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                }
                Switch(
                    checked = preferences.appLockEnabled,
                    onCheckedChange = { wantEnabled ->
                        if (wantEnabled && !hasAnyLockMethod) {
                            onRequestPinSetup(true)
                        } else {
                            onToggleAppLock(wantEnabled)
                        }
                    },
                    modifier = Modifier.testTag("settings_app_lock_switch")
                )
            }

            Spacer(modifier = Modifier.height(12.dp))

            // Biometric Unlock Toggle (works standalone OR with PIN)
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(10.dp),
                    modifier = Modifier.weight(1f)
                ) {
                    Icon(
                        LucideIcons.Fingerprint,
                        contentDescription = null,
                        tint = MaterialTheme.colorScheme.primary
                    )
                    Column {
                        Text(strings.biometricUnlock, style = MaterialTheme.typography.titleSmall)
                        Text(
                            text = biometricCapability.statusLabel,
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                }
                Switch(
                    checked = preferences.biometricUnlockEnabled,
                    enabled = biometricCapability.isAvailable || preferences.biometricUnlockEnabled,
                    onCheckedChange = onToggleBiometricUnlock,
                    modifier = Modifier.testTag("settings_biometric_switch")
                )
            }

            if (biometricCapability.isAvailable) {
                Spacer(modifier = Modifier.height(10.dp))
                OutlinedButton(
                    onClick = onTestBiometricUnlock,
                    modifier = Modifier
                        .fillMaxWidth()
                        .minimumInteractiveComponentSize()
                        .testTag("settings_test_biometric_btn")
                ) {
                    Icon(LucideIcons.ShieldCheck, contentDescription = null, modifier = Modifier.size(18.dp))
                    Spacer(modifier = Modifier.size(6.dp))
                    Text(strings.testBiometricUnlock)
                }
            }

            if (biometricCapability.needsEnrollment) {
                Spacer(modifier = Modifier.height(8.dp))
                OutlinedButton(
                    onClick = onOpenBiometricEnrollment,
                    modifier = Modifier
                        .fillMaxWidth()
                        .minimumInteractiveComponentSize()
                        .testTag("settings_enroll_biometric_btn")
                ) {
                    Icon(LucideIcons.Settings, contentDescription = null, modifier = Modifier.size(18.dp))
                    Spacer(modifier = Modifier.size(6.dp))
                    Text(strings.enrollBiometrics)
                }
            }
        }

        // PIN & Sensitive ID Encryption Card
        DocuScanCard {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(10.dp),
                    modifier = Modifier.weight(1f)
                ) {
                    Icon(LucideIcons.KeyRound, contentDescription = null, tint = MaterialTheme.colorScheme.primary)
                    Column {
                        Text(strings.encryptIdScans, style = MaterialTheme.typography.titleSmall)
                        Text(
                            text = "Wrap saved Aadhaar, PAN & ID PDFs using AES-256-GCM",
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                }
                Switch(
                    checked = preferences.encryptSensitiveFiles,
                    onCheckedChange = onToggleEncryptSensitiveFiles,
                    modifier = Modifier.testTag("settings_encrypt_ids_switch")
                )
            }

            Spacer(modifier = Modifier.height(12.dp))

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                OutlinedButton(
                    onClick = { onRequestPinSetup(!preferences.hasPinConfigured || preferences.appLockEnabled) },
                    modifier = Modifier
                        .weight(1f)
                        .minimumInteractiveComponentSize()
                        .testTag("settings_set_pin_btn")
                ) {
                    Text(if (preferences.hasPinConfigured) strings.changePin else strings.setPin)
                }
                if (preferences.hasPinConfigured) {
                    OutlinedButton(
                        onClick = onRemovePin,
                        modifier = Modifier
                            .weight(1f)
                            .minimumInteractiveComponentSize()
                            .testTag("settings_remove_pin_btn")
                    ) {
                        Text(strings.removePin, color = MaterialTheme.colorScheme.error)
                    }
                }
            }

            if (preferences.appLockEnabled && hasAnyLockMethod) {
                Spacer(modifier = Modifier.height(10.dp))
                Button(
                    onClick = onLockVaultNow,
                    colors = ButtonDefaults.buttonColors(
                        containerColor = MaterialTheme.colorScheme.primary,
                        contentColor = MaterialTheme.colorScheme.onPrimary
                    ),
                    modifier = Modifier
                        .fillMaxWidth()
                        .minimumInteractiveComponentSize()
                        .testTag("settings_lock_now_btn")
                ) {
                    Icon(LucideIcons.Lock, contentDescription = null, modifier = Modifier.size(18.dp))
                    Spacer(modifier = Modifier.size(6.dp))
                    Text(strings.lockNow)
                }
            }
        }
    }
}

@Composable
internal fun StorageBackupSettingsSection(
    storageSummary: StorageSummary,
    cacheSummary: CacheSummary,
    onClearTempCache: () -> Unit,
    onOpenBackup: () -> Unit,
    onOpenRecycleBin: () -> Unit
) {
    val strings = LocalAppStrings.current
    Column(verticalArrangement = Arrangement.spacedBy(14.dp)) {
        DocuScanCard {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                Icon(
                    imageVector = LucideIcons.FolderOpen,
                    contentDescription = null,
                    tint = MaterialTheme.colorScheme.primary
                )
                Text(strings.saveLocationTitle, style = MaterialTheme.typography.titleMedium)
            }
            Spacer(modifier = Modifier.height(6.dp))
            Text(
                text = strings.saveLocationSubtitle,
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
            Spacer(modifier = Modifier.height(8.dp))
            Text(
                text = cacheSummary.saveDirectoryPath.ifBlank { "App-private storage/files/documents" },
                style = MaterialTheme.typography.labelSmall,
                color = MaterialTheme.colorScheme.primary
            )
            if (cacheSummary.usableSpaceBytes > 0L) {
                Text(
                    text = "${FormatUtils.formatBytes(cacheSummary.usableSpaceBytes)} free on device",
                    style = MaterialTheme.typography.labelSmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                    modifier = Modifier.padding(top = 4.dp)
                )
            }
        }

        DocuScanCard {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                Icon(
                    imageVector = LucideIcons.Eraser,
                    contentDescription = null,
                    tint = MaterialTheme.colorScheme.primary
                )
                Column {
                    Text(strings.cacheManagementTitle, style = MaterialTheme.typography.titleMedium)
                    Text(
                        text = "Temp cache: ${FormatUtils.formatBytes(cacheSummary.totalClearableCacheBytes)} · Vault files: ${FormatUtils.formatBytes(cacheSummary.documentsBytes)}",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
            }
            Spacer(modifier = Modifier.height(10.dp))
            OutlinedButton(
                onClick = onClearTempCache,
                modifier = Modifier
                    .fillMaxWidth()
                    .minimumInteractiveComponentSize()
                    .testTag("settings_clear_cache_btn")
            ) {
                Text(strings.clearTempCache)
            }
        }

        DocuScanCard(
            onClick = onOpenBackup,
            modifier = Modifier
                .fillMaxWidth()
                .testTag("settings_backup_row")
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    Icon(LucideIcons.DatabaseBackup, contentDescription = null, tint = MaterialTheme.colorScheme.primary)
                    Column {
                        Text(strings.backupAndVault, style = MaterialTheme.typography.titleSmall)
                        Text(
                            text = "${FormatUtils.formatBytes(storageSummary.totalUsedBytes)} used locally",
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                }
                Icon(LucideIcons.ChevronRight, contentDescription = null)
            }
        }

        DocuScanCard(
            onClick = onOpenRecycleBin,
            modifier = Modifier
                .fillMaxWidth()
                .testTag("settings_recycle_bin_row")
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    Icon(LucideIcons.Trash2, contentDescription = null, tint = MaterialTheme.colorScheme.error)
                    Column {
                        Text(strings.recycleBin, style = MaterialTheme.typography.titleSmall)
                        Text(
                            text = "${storageSummary.trashCount} deleted document(s)",
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                }
                Icon(LucideIcons.ChevronRight, contentDescription = null)
            }
        }
    }
}
