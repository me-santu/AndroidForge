package com.docuscan.app.database.dao

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import com.docuscan.app.database.entity.DeletedDocumentEntity
import com.docuscan.app.database.entity.DocumentEntity
import com.docuscan.app.database.entity.DocumentPageEntity
import com.docuscan.app.database.entity.FolderEntity
import com.docuscan.app.database.entity.SignatureEntity
import kotlinx.coroutines.flow.Flow

@Dao
interface FolderDao {
    @Query("SELECT * FROM folders ORDER BY name COLLATE NOCASE ASC")
    fun observeAllFolders(): Flow<List<FolderEntity>>

    @Query("SELECT * FROM folders WHERE id = :folderId")
    suspend fun getById(folderId: Long): FolderEntity?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertFolder(folder: FolderEntity): Long

    @Query("UPDATE folders SET name = :name WHERE id = :folderId")
    suspend fun renameFolder(folderId: Long, name: String)

    @Query("DELETE FROM folders WHERE id = :folderId")
    suspend fun deleteFolder(folderId: Long)
}

@Dao
interface DocumentDao {
    @Query("SELECT * FROM documents WHERE isDeleted = 0 ORDER BY isPinned DESC, updatedAt DESC")
    fun observeActiveDocuments(): Flow<List<DocumentEntity>>

    @Query("SELECT * FROM documents WHERE isDeleted = 0 ORDER BY updatedAt DESC LIMIT :limit")
    fun observeRecentDocuments(limit: Int): Flow<List<DocumentEntity>>

    @Query("SELECT * FROM documents WHERE isDeleted = 1 ORDER BY deletedAt DESC")
    fun observeTrashDocuments(): Flow<List<DocumentEntity>>

    @Query("SELECT * FROM documents WHERE id = :id")
    suspend fun getById(id: Long): DocumentEntity?

    @Query("SELECT * FROM documents WHERE id IN (:ids)")
    suspend fun getByIds(ids: List<Long>): List<DocumentEntity>

    @Query("SELECT * FROM documents WHERE isDeleted = 1")
    suspend fun getAllTrashSync(): List<DocumentEntity>

    @Query("SELECT * FROM document_pages WHERE documentId = :documentId ORDER BY pageIndex ASC")
    suspend fun getPagesForDocument(documentId: Long): List<DocumentPageEntity>

    @Query(
        "SELECT filePath FROM documents " +
            "UNION SELECT thumbnailPath FROM documents WHERE thumbnailPath IS NOT NULL " +
            "UNION SELECT imagePath FROM document_pages"
    )
    suspend fun getAllReferencedFilePaths(): List<String>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertDocument(doc: DocumentEntity): Long

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertPages(pages: List<DocumentPageEntity>)

    @Query("DELETE FROM document_pages WHERE documentId = :documentId")
    suspend fun deletePagesForDocument(documentId: Long)

    @Query(
        "UPDATE documents SET title = :title, folderId = :folderId, filePath = :filePath, " +
            "thumbnailPath = :thumbnailPath, pageCount = :pageCount, sizeBytes = :sizeBytes, " +
            "updatedAt = :updatedAt WHERE id = :id"
    )
    suspend fun updateDocumentFileAndStats(
        id: Long,
        title: String,
        folderId: Long?,
        filePath: String,
        thumbnailPath: String?,
        pageCount: Int,
        sizeBytes: Long,
        updatedAt: Long
    )

    @Query("UPDATE documents SET title = :title, updatedAt = :updatedAt WHERE id = :id")
    suspend fun renameDocument(id: Long, title: String, updatedAt: Long)

    @Query("UPDATE documents SET isPinned = NOT isPinned, updatedAt = :updatedAt WHERE id = :id")
    suspend fun togglePin(id: Long, updatedAt: Long)

    @Query("UPDATE documents SET isFavorite = NOT isFavorite, updatedAt = :updatedAt WHERE id = :id")
    suspend fun toggleFavorite(id: Long, updatedAt: Long)

    @Query("UPDATE documents SET isFavorite = :isFavorite, updatedAt = :updatedAt WHERE id IN (:ids)")
    suspend fun setFavorites(ids: List<Long>, isFavorite: Boolean, updatedAt: Long)

    @Query("UPDATE documents SET folderId = :folderId, updatedAt = :updatedAt WHERE id = :id")
    suspend fun moveDocumentToFolder(id: Long, folderId: Long?, updatedAt: Long)

    @Query("UPDATE documents SET folderId = :folderId, updatedAt = :updatedAt WHERE id IN (:ids)")
    suspend fun moveDocumentsToFolder(ids: List<Long>, folderId: Long?, updatedAt: Long)

    @Query("UPDATE documents SET bookmarkedPages = :bookmarkedPages, updatedAt = :updatedAt WHERE id = :id")
    suspend fun updateBookmarkedPages(id: Long, bookmarkedPages: String, updatedAt: Long)

    @Query("UPDATE documents SET ocrText = :ocrText, updatedAt = :updatedAt WHERE id = :id")
    suspend fun updateOcrText(id: Long, ocrText: String, updatedAt: Long)

    @Query("UPDATE documents SET isDeleted = 1, deletedAt = :deletedAt, isPinned = 0 WHERE id = :id")
    suspend fun softDelete(id: Long, deletedAt: Long)

    @Query("UPDATE documents SET isDeleted = 1, deletedAt = :deletedAt, isPinned = 0 WHERE id IN (:ids)")
    suspend fun softDeleteBatch(ids: List<Long>, deletedAt: Long)

    @Query("UPDATE documents SET isDeleted = 0, deletedAt = NULL, updatedAt = :updatedAt WHERE id = :id")
    suspend fun restore(id: Long, updatedAt: Long)

    @Query("DELETE FROM documents WHERE id = :id")
    suspend fun deletePermanently(id: Long)

    @Query("DELETE FROM documents WHERE isDeleted = 1")
    suspend fun emptyTrash()
}

@Dao
interface SignatureDao {
    @Query("SELECT * FROM signatures ORDER BY createdAt DESC")
    fun observeSignatures(): Flow<List<SignatureEntity>>

    @Query("SELECT * FROM signatures WHERE id = :id")
    suspend fun getById(id: Long): SignatureEntity?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertSignature(signature: SignatureEntity): Long

    @Query("DELETE FROM signatures WHERE id = :id")
    suspend fun deleteSignature(id: Long)
}

@Dao
interface DeletedDocumentDao {
    @Query("SELECT * FROM deleted_documents ORDER BY deletedAt DESC")
    fun observeDeletedDocuments(): Flow<List<DeletedDocumentEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertDeleted(item: DeletedDocumentEntity): Long

    @Query("DELETE FROM deleted_documents WHERE originalDocumentId = :originalDocumentId")
    suspend fun deleteByOriginalDocumentId(originalDocumentId: Long)

    @Query("DELETE FROM deleted_documents")
    suspend fun emptyDeletedRecords()
}
