package com.docuscan.app.ui.screens

import androidx.compose.ui.graphics.vector.ImageVector
import com.docuscan.app.ui.icons.LucideIcons

enum class PdfToolCategory(val title: String) {
    EDITING("PDF Editing"),
    CONVERSION("PDF Conversion"),
    SECURITY("PDF Security & Stamp"),
    OPTIMIZATION("PDF Optimization"),
    SUITES("Document & Scan Suites")
}

enum class PdfToolId(
    val category: PdfToolCategory,
    val title: String,
    val subtitle: String,
    val badge: String,
    val icon: ImageVector,
    val testTag: String
) {
    // Editing
    MERGE_PDF(
        PdfToolCategory.EDITING,
        "Merge PDF",
        "Combine 2 or more PDFs in your chosen order into one file",
        "Merge",
        LucideIcons.Merge,
        "tool_merge_pdf"
    ),
    SPLIT_PDF(
        PdfToolCategory.EDITING,
        "Split PDF",
        "Extract a contiguous page range into a new PDF",
        "Split",
        LucideIcons.Scissors,
        "tool_split_pdf"
    ),
    EXTRACT_PAGES(
        PdfToolCategory.EDITING,
        "Extract Pages",
        "Pick individual pages (e.g. 1, 3, 5) into a separate PDF",
        "Extract",
        LucideIcons.Layers,
        "tool_extract_pages"
    ),
    REORDER_PAGES(
        PdfToolCategory.EDITING,
        "Reorder Pages",
        "Move individual PDF pages up/down into a new sequence",
        "Order",
        LucideIcons.ArrowUpDown,
        "tool_reorder_pages"
    ),
    REARRANGE_PAGES(
        PdfToolCategory.EDITING,
        "Rearrange Pages",
        "Custom arrange, reverse, or move pages to top/bottom",
        "Arrange",
        LucideIcons.List,
        "tool_rearrange_pages"
    ),
    ROTATE_PAGES(
        PdfToolCategory.EDITING,
        "Rotate Pages",
        "Rotate all or selected PDF pages by 90°, 180°, or 270°",
        "Rotate",
        LucideIcons.RotateCw,
        "tool_rotate_pages"
    ),
    DELETE_PAGES(
        PdfToolCategory.EDITING,
        "Delete Pages",
        "Remove unwanted pages and save a clean PDF copy",
        "Trim",
        LucideIcons.Eraser,
        "tool_delete_pages"
    ),
    DUPLICATE_PAGES(
        PdfToolCategory.EDITING,
        "Duplicate Pages",
        "Clone selected pages inside a PDF (adjacent or appended)",
        "Clone",
        LucideIcons.CopyPlus,
        "tool_duplicate_pages"
    ),

    // Conversion
    IMAGES_TO_PDF(
        PdfToolCategory.CONVERSION,
        "Images to PDF",
        "Select gallery images or edit current scan session into a PDF",
        "Creator",
        LucideIcons.FileText,
        "tool_images_to_pdf"
    ),
    PDF_TO_IMAGES(
        PdfToolCategory.CONVERSION,
        "PDF to Images",
        "Render PDF pages to JPG or PNG, save to library or export ZIP",
        "Export",
        LucideIcons.Images,
        "tool_pdf_to_images"
    ),
    PDF_TO_JPG(
        PdfToolCategory.CONVERSION,
        "PDF to JPG",
        "Convert PDF pages to high-quality JPG images",
        "JPG",
        LucideIcons.Image,
        "tool_pdf_to_jpg"
    ),
    PDF_TO_PNG(
        PdfToolCategory.CONVERSION,
        "PDF to PNG",
        "Convert PDF pages to lossless PNG images",
        "PNG",
        LucideIcons.Image,
        "tool_pdf_to_png"
    ),
    TEXT_TO_PDF(
        PdfToolCategory.CONVERSION,
        "Text to PDF",
        "Type text or import .txt into a formatted multi-page PDF",
        "Generate",
        LucideIcons.FileText,
        "tool_text_to_pdf"
    ),
    PDF_TO_DOCX(
        PdfToolCategory.CONVERSION,
        "PDF to Word (DOCX)",
        "Export PDF text & page fallback snapshots to Word .docx",
        "DOCX",
        LucideIcons.FileText,
        "tool_pdf_to_docx"
    ),
    PDF_TO_TEXT(
        PdfToolCategory.CONVERSION,
        "PDF to Text",
        "Extract embedded selectable text, copy, share, or save .txt",
        "Text",
        LucideIcons.Type,
        "tool_pdf_to_text"
    ),

    // Security & Stamp
    PROTECT_PDF(
        PdfToolCategory.SECURITY,
        "Protect PDF with Password",
        "Encrypt any PDF copy with AES-128 password protection",
        "AES-128",
        LucideIcons.Lock,
        "tool_protect_pdf"
    ),
    UNLOCK_PDF(
        PdfToolCategory.SECURITY,
        "Unlock PDF",
        "Remove password protection when you know the current password",
        "Unlock",
        LucideIcons.LockOpen,
        "tool_unlock_pdf"
    ),
    ADD_WATERMARK(
        PdfToolCategory.SECURITY,
        "Add Watermark",
        "Stamp diagonal semi-transparent text across all PDF pages",
        "Stamp",
        LucideIcons.Droplet,
        "tool_watermark_pdf"
    ),
    REMOVE_WATERMARK(
        PdfToolCategory.SECURITY,
        "Remove Watermark",
        "Strip watermark annotations, layers & matching text overlays",
        "Clean",
        LucideIcons.LayersOff,
        "tool_remove_watermark"
    ),
    ADD_PAGE_NUMBERS(
        PdfToolCategory.SECURITY,
        "Add Page Numbers",
        "Stamp customizable page numbers at top or bottom margin",
        "Pages",
        LucideIcons.ListOrdered,
        "tool_add_page_numbers"
    ),
    ADD_HEADER_FOOTER(
        PdfToolCategory.SECURITY,
        "Add Header and Footer",
        "Add document header, footer text, and optional date stamp",
        "Layout",
        LucideIcons.Layers,
        "tool_add_header_footer"
    ),

    // Optimization
    COMPRESS_PDF(
        PdfToolCategory.OPTIMIZATION,
        "Compress PDF",
        "Shrink PDF file size using Low, Balanced, or High presets",
        "Preset",
        LucideIcons.Minimize2,
        "tool_compress_pdf"
    ),
    REDUCE_PDF_SIZE(
        PdfToolCategory.OPTIMIZATION,
        "Reduce PDF Size",
        "Fine-tune max image resolution, JPEG quality & strip metadata",
        "Optimize",
        LucideIcons.SlidersHorizontal,
        "tool_reduce_pdf_size"
    ),
    REPAIR_PDF(
        PdfToolCategory.OPTIMIZATION,
        "Repair PDF",
        "Trim header junk & rebuild XRef / page tree where recoverable",
        "Recover",
        LucideIcons.Wrench,
        "tool_repair_pdf"
    ),

    // Suites
    ID_SCANNER(
        PdfToolCategory.SUITES,
        "ID Document Scanner",
        "Aadhaar, PAN, Passport, Driving Licence & Voter ID workflows",
        "Studio",
        LucideIcons.IdCard,
        "tool_id_scanner"
    ),
    SIGNATURE_CREATOR(
        PdfToolCategory.SUITES,
        "Signature Creator",
        "Draw & store reusable transparent signatures",
        "Sign",
        LucideIcons.PenTool,
        "tool_signature_creator"
    ),
    SIGN_PDF(
        PdfToolCategory.SUITES,
        "Sign PDF Document",
        "Place, resize & reposition your saved signature on any PDF page",
        "Place",
        LucideIcons.PenTool,
        "tool_sign_pdf"
    ),
    OCR_EXTRACTOR(
        PdfToolCategory.SUITES,
        "OCR Text Extractor",
        "Extract English, Hindi, Bengali & global scripts offline",
        "Offline OCR",
        LucideIcons.Type,
        "tool_ocr_extractor"
    )
}
