package com.docuscan.app.navigation

import androidx.compose.ui.graphics.vector.ImageVector
import com.docuscan.app.ui.icons.LucideIcons
import com.docuscan.app.util.LocalizedStrings
import kotlinx.serialization.Serializable

@Serializable
data object SplashRoute

@Serializable
data object OnboardingRoute

@Serializable
data object HomeRoute

@Serializable
data class CameraScannerRoute(val initialMode: String = "DOCS")

@Serializable
data class ImageEditorRoute(val pageId: String)

@Serializable
data object PageManagerRoute

@Serializable
data object PdfCreatorRoute

@Serializable
data class OcrExtractorRoute(val documentId: Long = -1L)

@Serializable
data class DocumentsRoute(val folderId: Long = -1L)

@Serializable
data class PdfViewerRoute(val documentId: Long)

@Serializable
data object PdfToolsRoute

@Serializable
data object IdScannerRoute

@Serializable
data object SignatureCreatorRoute

@Serializable
data class SignPdfRoute(val documentId: Long = -1L, val signatureId: Long = -1L)

@Serializable
data object BackupRoute

@Serializable
data object SettingsRoute

@Serializable
data object RecycleBinRoute

@Serializable
data object AboutPrivacyRoute

enum class BottomNavDestination(
    val label: String,
    val selectedIcon: ImageVector,
    val unselectedIcon: ImageVector,
    val testTag: String
) {
    HOME(
        label = "Home",
        selectedIcon = LucideIcons.Home,
        unselectedIcon = LucideIcons.Home,
        testTag = "nav_home"
    ),
    DOCUMENTS(
        label = "Documents",
        selectedIcon = LucideIcons.FolderOpen,
        unselectedIcon = LucideIcons.Folder,
        testTag = "nav_documents"
    ),
    TOOLS(
        label = "Tools",
        selectedIcon = LucideIcons.Wrench,
        unselectedIcon = LucideIcons.Wrench,
        testTag = "nav_tools"
    ),
    SETTINGS(
        label = "Settings",
        selectedIcon = LucideIcons.Settings,
        unselectedIcon = LucideIcons.Settings,
        testTag = "nav_settings"
    );

    fun localizedLabel(strings: LocalizedStrings): String = when (this) {
        HOME -> strings.navHome
        DOCUMENTS -> strings.navDocuments
        TOOLS -> strings.navTools
        SETTINGS -> strings.navSettings
    }
}
