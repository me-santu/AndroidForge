package com.docuscan.app.ui.screens

import android.content.Context
import android.content.ContextWrapper
import android.content.Intent
import android.provider.Settings
import androidx.activity.compose.BackHandler
import androidx.compose.foundation.background
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FilterChipDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.minimumInteractiveComponentSize
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.fragment.app.FragmentActivity
import com.docuscan.app.BuildConfig
import com.docuscan.app.domain.model.AppFontStyle
import com.docuscan.app.domain.model.AppLanguage
import com.docuscan.app.domain.model.CacheSummary
import com.docuscan.app.domain.model.FileNamingFormat
import com.docuscan.app.domain.model.PdfPageSize
import com.docuscan.app.domain.model.ScanQuality
import com.docuscan.app.domain.model.StorageSummary
import com.docuscan.app.domain.model.ThemeMode
import com.docuscan.app.domain.model.UserPreferences
import com.docuscan.app.security.BiometricCapability
import com.docuscan.app.security.SecurityManager
import com.docuscan.app.ui.components.DocuScanCard
import com.docuscan.app.ui.components.DocuScanSwitch
import com.docuscan.app.ui.components.PhaseStatusChip
import com.docuscan.app.ui.icons.LucideIcons
import com.docuscan.app.util.FormatUtils
import com.docuscan.app.util.LocalAppStrings

enum class SettingsCategory {
    APPEARANCE,
    SCANNING_PDF,
    SECURITY_BIOMETRICS,
    STORAGE_BACKUP
}

private tailrec fun Context.findSettingsFragmentActivity(): FragmentActivity? = when (this) {
    is FragmentActivity -> this
    is ContextWrapper -> baseContext.findSettingsFragmentActivity()
    else -> null
}

@Composable
fun SettingsScreen(
    preferences: UserPreferences,
    storageSummary: StorageSummary,
    cacheSummary: CacheSummary,
    biometricCapability: BiometricCapability,
    securityManager: SecurityManager,
    onSelectTheme: (ThemeMode) -> Unit,
    onSelectLanguage: (AppLanguage) -> Unit,
    onSelectFontStyle: (AppFontStyle) -> Unit = {},
    onSelectScanQuality: (ScanQuality) -> Unit,
    onSelectDefaultPageSize: (PdfPageSize) -> Unit,
    onSelectFileNamingFormat: (FileNamingFormat) -> Unit = {},
    onToggleAutoEnhance: (Boolean) -> Unit,
    onToggleAppLock: (Boolean) -> Unit,
    onToggleBiometricUnlock: (Boolean) -> Unit,
    onToggleEncryptSensitiveFiles: (Boolean) -> Unit,
    onConfigurePin: (newPin: String, enableLock: Boolean) -> Result<Unit>,
    onRemovePin: () -> Unit,
    onLockVaultNow: () -> Unit,
    onClearTempCache: () -> Unit,
    onOpenBackup: () -> Unit,
    onOpenRecycleBin: () -> Unit,
    onOpenAboutPrivacy: () -> Unit,
    onOpenSignatureCreator: () -> Unit = {},
    onSettingsStatusMessage: (String) -> Unit = {},
    onBeforeExternalSettingsLaunch: () -> Unit = {},
    modifier: Modifier = Modifier
) {
    val strings = LocalAppStrings.current
    val context = LocalContext.current

    var selectedCategory by remember { mutableStateOf<SettingsCategory?>(null) }
    var showPinSetupDialog by remember { mutableStateOf(false) }
    var enableLockAfterPinSetup by remember { mutableStateOf(true) }
    var pinInput by remember { mutableStateOf("") }
    var pinConfirmInput by remember { mutableStateOf("") }
    var pinDialogError by remember { mutableStateOf<String?>(null) }

    BackHandler(enabled = selectedCategory != null) {
        selectedCategory = null
    }

    fun launchBiometricVerification(
        title: String,
        subtitle: String,
        onVerified: () -> Unit
    ) {
        val activity = context.findSettingsFragmentActivity()
        if (activity == null) {
            onVerified()
            return
        }
        securityManager.authenticateBiometric(
            activity = activity,
            title = title,
            subtitle = subtitle,
            negativeButtonText = "Cancel",
            allowDeviceCredentialFallback = true,
            onSuccess = onVerified,
            onError = { err ->
                if (err.isNotBlank()) {
                    onSettingsStatusMessage(err)
                }
            }
        )
    }

    fun openDeviceBiometricSettings() {
        onBeforeExternalSettingsLaunch()
        val enrollIntent = securityManager.createBiometricEnrollIntent().apply {
            addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        }
        val launched = runCatching { context.startActivity(enrollIntent) }.isSuccess
        if (!launched) {
            runCatching {
                context.startActivity(
                    Intent(Settings.ACTION_SECURITY_SETTINGS).apply {
                        addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                    }
                )
            }.onFailure {
                onSettingsStatusMessage("Open Android Settings > Security to enroll fingerprint or screen lock.")
            }
        }
    }

    val activeCat = selectedCategory
    val hasAnyLockMethod = preferences.hasPinConfigured || preferences.biometricUnlockEnabled

    Column(modifier = modifier.fillMaxSize()) {
        if (activeCat != null) {
            val catTitle = when (activeCat) {
                SettingsCategory.APPEARANCE -> strings.catAppearanceTitle
                SettingsCategory.SCANNING_PDF -> strings.catScanningTitle
                SettingsCategory.SECURITY_BIOMETRICS -> strings.catSecurityTitle
                SettingsCategory.STORAGE_BACKUP -> strings.catStorageTitle
            }
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 8.dp, vertical = 6.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                IconButton(
                    onClick = { selectedCategory = null },
                    modifier = Modifier.testTag("settings_category_back_btn")
                ) {
                    Icon(
                        imageVector = LucideIcons.ArrowLeft,
                        contentDescription = "Back to Settings categories"
                    )
                }
                Column(modifier = Modifier.weight(1f)) {
                    Text(
                        text = catTitle,
                        style = MaterialTheme.typography.headlineSmall,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis
                    )
                    Text(
                        text = strings.settingsTitle,
                        style = MaterialTheme.typography.labelMedium,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
            }
        }

        LazyColumn(
            modifier = Modifier
                .weight(1f)
                .fillMaxWidth()
                .testTag("settings_list"),
            contentPadding = PaddingValues(start = 16.dp, end = 16.dp, top = 12.dp, bottom = 96.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            if (activeCat == null) {
                // Header
                item {
                    Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
                        Text(strings.settingsTitle, style = MaterialTheme.typography.headlineMedium)
                        Text(
                            text = strings.settingsSubtitle,
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                }

                // Quick Toggles Row: App Lock & Auto-Enhance
                item {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        QuickSettingToggleTile(
                            title = "App Lock",
                            subtitle = if (preferences.appLockEnabled) "Vault Protected" else "Unlocked",
                            icon = LucideIcons.Lock,
                            checked = preferences.appLockEnabled,
                            testTag = "settings_quick_app_lock_switch",
                            onCheckedChange = { wantEnabled ->
                                if (wantEnabled && !hasAnyLockMethod) {
                                    enableLockAfterPinSetup = true
                                    pinInput = ""
                                    pinConfirmInput = ""
                                    pinDialogError = null
                                    showPinSetupDialog = true
                                } else {
                                    onToggleAppLock(wantEnabled)
                                }
                            },
                            modifier = Modifier.weight(1f)
                        )
                        QuickSettingToggleTile(
                            title = "Auto-Enhance",
                            subtitle = if (preferences.autoEnhance) "Magic Color" else "Original",
                            icon = LucideIcons.Sparkles,
                            checked = preferences.autoEnhance,
                            testTag = "settings_quick_auto_enhance_switch",
                            onCheckedChange = onToggleAutoEnhance,
                            modifier = Modifier.weight(1f)
                        )
                    }
                }

                // 2. Digital Signature Card
                item {
                    DocuScanCard(
                        onClick = onOpenSignatureCreator,
                        modifier = Modifier
                            .fillMaxWidth()
                            .testTag("settings_digital_signature_card")
                    ) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Row(
                                modifier = Modifier
                                    .weight(1f)
                                    .padding(end = 8.dp),
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.spacedBy(10.dp)
                            ) {
                                SettingsIconBadge(
                                    icon = LucideIcons.PenTool,
                                    contentDescription = "Digital Signature"
                                )
                                Column {
                                    Text(
                                        text = "Digital Signature",
                                        style = MaterialTheme.typography.titleSmall,
                                        maxLines = 1,
                                        overflow = TextOverflow.Ellipsis
                                    )
                                    Text(
                                        text = "Draw, update, or save your stamp/sign",
                                        style = MaterialTheme.typography.bodySmall,
                                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                                        maxLines = 2,
                                        overflow = TextOverflow.Ellipsis
                                    )
                                }
                            }
                            OutlinedButton(
                                onClick = onOpenSignatureCreator,
                                shape = CircleShape,
                                modifier = Modifier
                                    .minimumInteractiveComponentSize()
                                    .testTag("settings_manage_signature_btn")
                            ) {
                                Text("Manage")
                            }
                        }
                    }
                }

                // 3. Default File Naming Format Quick Selector
                item {
                    DocuScanCard {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            Icon(
                                imageVector = LucideIcons.FilePen,
                                contentDescription = null,
                                tint = MaterialTheme.colorScheme.primary,
                                modifier = Modifier.size(18.dp)
                            )
                            Text(
                                text = "Default File Naming Format",
                                style = MaterialTheme.typography.titleSmall,
                                maxLines = 1,
                                overflow = TextOverflow.Ellipsis
                            )
                        }
                        Spacer(modifier = Modifier.height(6.dp))
                        Text(
                            text = "Preview: ${preferences.fileNamingFormat.patternPreview}.pdf",
                            style = MaterialTheme.typography.labelSmall,
                            color = MaterialTheme.colorScheme.primary
                        )
                        Spacer(modifier = Modifier.height(8.dp))
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .horizontalScroll(rememberScrollState()),
                            horizontalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            FileNamingFormat.entries.forEach { format ->
                                FilterChip(
                                    selected = preferences.fileNamingFormat == format,
                                    onClick = { onSelectFileNamingFormat(format) },
                                    label = { Text(format.label, maxLines = 1) },
                                    colors = FilterChipDefaults.filterChipColors(
                                        selectedContainerColor = MaterialTheme.colorScheme.primary,
                                        selectedLabelColor = MaterialTheme.colorScheme.onPrimary
                                    ),
                                    modifier = Modifier.testTag("naming_format_${format.name.lowercase()}")
                                )
                            }
                        }
                    }
                }

                // Categorized Settings Cards (single-line titles, crisp short badges, fixed pluralization)
                item {
                    SettingsCategoryCard(
                        title = strings.catAppearanceTitle,
                        subtitle = "${preferences.themeMode.label} · ${preferences.fontStyle.label} · ${preferences.appLanguage.nativeLabel}",
                        badge = preferences.fontStyle.label,
                        icon = LucideIcons.Palette,
                        highlighted = false,
                        testTag = "settings_cat_appearance",
                        onClick = { selectedCategory = SettingsCategory.APPEARANCE }
                    )
                }

                item {
                    SettingsCategoryCard(
                        title = strings.catScanningTitle,
                        subtitle = "${preferences.scanQuality.label} · ${preferences.defaultPageSize.shortLabel} · Auto-Enhance ${if (preferences.autoEnhance) "ON" else "OFF"}",
                        badge = preferences.defaultPageSize.shortLabel,
                        icon = LucideIcons.SlidersHorizontal,
                        highlighted = false,
                        testTag = "settings_cat_scanning",
                        onClick = { selectedCategory = SettingsCategory.SCANNING_PDF }
                    )
                }

                item {
                    val secSummary = buildString {
                        append(if (preferences.appLockEnabled) "App Lock ON" else "App Lock OFF")
                        if (preferences.biometricUnlockEnabled) append(" · Biometric ON")
                        if (preferences.hasPinConfigured) append(" · PIN Set")
                        if (!preferences.biometricUnlockEnabled && !preferences.hasPinConfigured) {
                            append(" · ${if (biometricCapability.isAvailable) "Biometric Ready" else "Keystore Vault"}")
                        }
                    }
                    SettingsCategoryCard(
                        title = strings.catSecurityTitle,
                        subtitle = secSummary,
                        badge = if (preferences.appLockEnabled) "Protected" else "Vault",
                        icon = LucideIcons.Shield,
                        highlighted = preferences.appLockEnabled,
                        testTag = "settings_cat_security",
                        onClick = { selectedCategory = SettingsCategory.SECURITY_BIOMETRICS }
                    )
                }

                item {
                    val docCount = storageSummary.activeDocumentCount
                    val fileCountBadge = if (docCount == 1) "1 file" else "$docCount files"
                    SettingsCategoryCard(
                        title = strings.catStorageTitle,
                        subtitle = "${FormatUtils.formatBytes(storageSummary.totalUsedBytes)} vault · ${FormatUtils.formatBytes(cacheSummary.totalClearableCacheBytes)} cache · ${storageSummary.trashCount} in Bin",
                        badge = fileCountBadge,
                        icon = LucideIcons.HardDrive,
                        highlighted = false,
                        testTag = "settings_cat_storage",
                        onClick = { selectedCategory = SettingsCategory.STORAGE_BACKUP }
                    )
                }

                // 8. Temporary Scan Cache Card (directly below Storage & Backup and above About & Privacy)
                item {
                    DocuScanCard {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Row(
                                modifier = Modifier
                                    .weight(1f)
                                    .padding(end = 8.dp),
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.spacedBy(10.dp)
                            ) {
                                SettingsIconBadge(
                                    icon = LucideIcons.Eraser,
                                    contentDescription = "Temporary Scan Cache"
                                )
                                Column {
                                    Text(
                                        text = "Temporary Scan Cache",
                                        style = MaterialTheme.typography.titleSmall,
                                        maxLines = 1,
                                        overflow = TextOverflow.Ellipsis
                                    )
                                    Text(
                                        text = "${FormatUtils.formatBytes(cacheSummary.totalClearableCacheBytes)} clearable",
                                        style = MaterialTheme.typography.bodySmall,
                                        color = MaterialTheme.colorScheme.onSurfaceVariant
                                    )
                                }
                            }
                            OutlinedButton(
                                onClick = onClearTempCache,
                                shape = CircleShape,
                                modifier = Modifier
                                    .minimumInteractiveComponentSize()
                                    .testTag("settings_quick_clear_cache_btn")
                            ) {
                                Text("Clear Cache")
                            }
                        }
                    }
                }

                // 9. About & Privacy Card
                item {
                    SettingsCategoryCard(
                        title = strings.catAboutTitle,
                        subtitle = strings.aboutAndPrivacySubtitle,
                        badge = "v${BuildConfig.VERSION_NAME}",
                        icon = LucideIcons.ShieldCheck,
                        highlighted = false,
                        testTag = "settings_about_privacy_row",
                        onClick = onOpenAboutPrivacy
                    )
                }

                // Centered Offline & Ad-Free Footer
                item {
                    Text(
                        text = "DocuScan v${BuildConfig.VERSION_NAME} • 100% Offline & Ad-Free",
                        style = MaterialTheme.typography.labelMedium,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                        textAlign = TextAlign.Center,
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(top = 8.dp, bottom = 16.dp)
                            .testTag("settings_footer_text")
                    )
                }
            } else {
                // Inside Selected Category
                item {
                    when (activeCat) {
                        SettingsCategory.APPEARANCE -> AppearanceSettingsSection(
                            preferences = preferences,
                            onSelectTheme = onSelectTheme,
                            onSelectFontStyle = onSelectFontStyle,
                            onSelectLanguage = onSelectLanguage
                        )
                        SettingsCategory.SCANNING_PDF -> ScanningPdfSettingsSection(
                            preferences = preferences,
                            onSelectScanQuality = onSelectScanQuality,
                            onSelectDefaultPageSize = onSelectDefaultPageSize,
                            onSelectFileNamingFormat = onSelectFileNamingFormat,
                            onToggleAutoEnhance = onToggleAutoEnhance
                        )
                        SettingsCategory.SECURITY_BIOMETRICS -> SecuritySettingsSection(
                            preferences = preferences,
                            biometricCapability = biometricCapability,
                            securityManager = securityManager,
                            onToggleAppLock = onToggleAppLock,
                            onRequestPinSetup = { enableAfter ->
                                enableLockAfterPinSetup = enableAfter
                                pinInput = ""
                                pinConfirmInput = ""
                                pinDialogError = null
                                showPinSetupDialog = true
                            },
                            onToggleBiometricUnlock = { wantEnabled ->
                                if (wantEnabled) {
                                    launchBiometricVerification(
                                        title = strings.biometricUnlock,
                                        subtitle = "Confirm your fingerprint, face, or screen lock to enable Biometric Unlock",
                                        onVerified = { onToggleBiometricUnlock(true) }
                                    )
                                } else {
                                    onToggleBiometricUnlock(false)
                                }
                            },
                            onTestBiometricUnlock = {
                                launchBiometricVerification(
                                    title = strings.testBiometricUnlock,
                                    subtitle = "Verify your fingerprint, face, or screen lock",
                                    onVerified = {
                                        onSettingsStatusMessage("Biometric authentication succeeded!")
                                    }
                                )
                            },
                            onOpenBiometricEnrollment = ::openDeviceBiometricSettings,
                            onToggleEncryptSensitiveFiles = onToggleEncryptSensitiveFiles,
                            onRemovePin = onRemovePin,
                            onLockVaultNow = onLockVaultNow
                        )
                        SettingsCategory.STORAGE_BACKUP -> StorageBackupSettingsSection(
                            storageSummary = storageSummary,
                            cacheSummary = cacheSummary,
                            onClearTempCache = onClearTempCache,
                            onOpenBackup = onOpenBackup,
                            onOpenRecycleBin = onOpenRecycleBin
                        )
                    }
                }
            }
        }
    }

    if (showPinSetupDialog) {
        AlertDialog(
            onDismissRequest = { showPinSetupDialog = false },
            title = { Text(if (preferences.hasPinConfigured) strings.changePin else strings.setPin) },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    Text(
                        text = "Enter a 4–8 digit PIN. It is hashed with a random salt and sealed using Android Keystore AES-256-GCM.",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                    OutlinedTextField(
                        value = pinInput,
                        onValueChange = { value ->
                            if (value.length <= 8 && value.all(Char::isDigit)) {
                                pinInput = value
                                pinDialogError = null
                            }
                        },
                        label = { Text("New PIN (4–8 digits)") },
                        singleLine = true,
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.NumberPassword),
                        visualTransformation = PasswordVisualTransformation(),
                        modifier = Modifier
                            .fillMaxWidth()
                            .testTag("pin_setup_input")
                    )
                    OutlinedTextField(
                        value = pinConfirmInput,
                        onValueChange = { value ->
                            if (value.length <= 8 && value.all(Char::isDigit)) {
                                pinConfirmInput = value
                                pinDialogError = null
                            }
                        },
                        label = { Text("Confirm PIN") },
                        singleLine = true,
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.NumberPassword),
                        visualTransformation = PasswordVisualTransformation(),
                        modifier = Modifier
                            .fillMaxWidth()
                            .testTag("pin_setup_confirm_input")
                    )
                    if (!pinDialogError.isNullOrBlank()) {
                        Text(
                            text = pinDialogError!!,
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.error
                        )
                    }
                }
            },
            confirmButton = {
                TextButton(
                    onClick = {
                        when {
                            pinInput.length !in 4..8 -> {
                                pinDialogError = "PIN must be 4 to 8 digits."
                            }
                            pinInput != pinConfirmInput -> {
                                pinDialogError = "PINs do not match."
                            }
                            else -> {
                                onConfigurePin(pinInput, enableLockAfterPinSetup)
                                    .onSuccess { showPinSetupDialog = false }
                                    .onFailure { pinDialogError = it.message ?: "Could not save PIN" }
                            }
                        }
                    },
                    modifier = Modifier.testTag("pin_setup_save_btn")
                ) {
                    Text("Save PIN")
                }
            },
            dismissButton = {
                TextButton(onClick = { showPinSetupDialog = false }) { Text("Cancel") }
            }
        )
    }
}

@Composable
private fun QuickSettingToggleTile(
    title: String,
    subtitle: String,
    icon: ImageVector,
    checked: Boolean,
    testTag: String,
    onCheckedChange: (Boolean) -> Unit,
    modifier: Modifier = Modifier
) {
    DocuScanCard(
        highlighted = checked,
        modifier = modifier
    ) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Icon(
                imageVector = icon,
                contentDescription = title,
                tint = MaterialTheme.colorScheme.primary,
                modifier = Modifier.size(20.dp)
            )
            DocuScanSwitch(
                checked = checked,
                onCheckedChange = onCheckedChange,
                modifier = Modifier.testTag(testTag)
            )
        }
        Spacer(modifier = Modifier.height(6.dp))
        Text(
            text = title,
            style = MaterialTheme.typography.titleSmall,
            fontWeight = FontWeight.SemiBold,
            maxLines = 1,
            overflow = TextOverflow.Ellipsis
        )
        Text(
            text = subtitle,
            style = MaterialTheme.typography.labelSmall,
            color = MaterialTheme.colorScheme.onSurfaceVariant,
            maxLines = 1,
            overflow = TextOverflow.Ellipsis
        )
    }
}

@Composable
private fun SettingsCategoryCard(
    title: String,
    subtitle: String,
    badge: String,
    icon: ImageVector,
    highlighted: Boolean,
    testTag: String,
    onClick: () -> Unit
) {
    DocuScanCard(
        highlighted = highlighted,
        onClick = onClick,
        modifier = Modifier
            .fillMaxWidth()
            .testTag(testTag)
    ) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            SettingsIconBadge(
                icon = icon,
                contentDescription = title
            )
            Column(
                modifier = Modifier.weight(1f),
                verticalArrangement = Arrangement.spacedBy(3.dp)
            ) {
                Text(
                    text = title,
                    style = MaterialTheme.typography.titleSmall,
                    fontWeight = FontWeight.SemiBold,
                    color = MaterialTheme.colorScheme.onSurface,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis
                )
                Text(
                    text = subtitle,
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                    maxLines = 2,
                    overflow = TextOverflow.Ellipsis
                )
            }
            PhaseStatusChip(text = badge, highlighted = highlighted)
            Icon(
                imageVector = LucideIcons.ChevronRight,
                contentDescription = null,
                tint = MaterialTheme.colorScheme.onSurfaceVariant,
                modifier = Modifier.size(18.dp)
            )
        }
    }
}

@Composable
private fun SettingsIconBadge(
    icon: ImageVector,
    contentDescription: String?
) {
    Box(
        modifier = Modifier
            .size(42.dp)
            .clip(RoundedCornerShape(12.dp))
            .background(MaterialTheme.colorScheme.primary.copy(alpha = 0.14f)),
        contentAlignment = Alignment.Center
    ) {
        Icon(
            imageVector = icon,
            contentDescription = contentDescription,
            tint = MaterialTheme.colorScheme.primary,
            modifier = Modifier.size(20.dp)
        )
    }
}
