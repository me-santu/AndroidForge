package com.docuscan.app.domain.model

data class DocumentItem(
    val id: Long = 0,
    val title: String,
    val folderId: Long? = null,
    val folderName: String? = null,
    val filePath: String,
    val thumbnailPath: String? = null,
    val fileType: DocumentFileType = DocumentFileType.PDF,
    val pageCount: Int = 1,
    val sizeBytes: Long = 0L,
    val ocrText: String = "",
    val createdAt: Long = System.currentTimeMillis(),
    val updatedAt: Long = System.currentTimeMillis(),
    val isPinned: Boolean = false,
    val isFavorite: Boolean = false,
    val isPasswordProtected: Boolean = false,
    val bookmarkedPages: List<Int> = emptyList(),
    val isDeleted: Boolean = false,
    val deletedAt: Long? = null
)

data class FolderItem(
    val id: Long = 0,
    val name: String,
    val accentHex: Long = 0xFFF5C542,
    val createdAt: Long = System.currentTimeMillis(),
    val documentCount: Int = 0
)

data class SignatureItem(
    val id: Long = 0,
    val name: String,
    val filePath: String,
    val createdAt: Long = System.currentTimeMillis()
)

data class ScanPage(
    val id: String,
    val sourcePath: String,
    val filter: ScanFilter = ScanFilter.ORIGINAL,
    val rotationDegrees: Int = 0,
    val orderIndex: Int = 0,
    val cropRect: NormalizedCropRect = NormalizedCropRect()
)

data class DeletedDocumentItem(
    val id: Long = 0,
    val originalDocumentId: Long,
    val title: String,
    val folderId: Long? = null,
    val filePath: String,
    val thumbnailPath: String? = null,
    val fileType: DocumentFileType = DocumentFileType.PDF,
    val pageCount: Int = 1,
    val sizeBytes: Long = 0L,
    val deletedAt: Long = System.currentTimeMillis()
)

data class StorageSummary(
    val totalUsedBytes: Long = 0L,
    val activeDocumentCount: Int = 0,
    val pdfCount: Int = 0,
    val folderCount: Int = 0,
    val trashCount: Int = 0,
    val signatureCount: Int = 0
)

data class CacheSummary(
    val cacheDirBytes: Long = 0L,
    val orphanedTempScanBytes: Long = 0L,
    val documentsBytes: Long = 0L,
    val signaturesBytes: Long = 0L,
    val backupsBytes: Long = 0L,
    val usableSpaceBytes: Long = 0L,
    val saveDirectoryPath: String = ""
) {
    val totalClearableCacheBytes: Long
        get() = cacheDirBytes + orphanedTempScanBytes
}

data class UserPreferences(
    val themeMode: ThemeMode = ThemeMode.DARK,
    val appLanguage: AppLanguage = AppLanguage.ENGLISH,
    val fontStyle: AppFontStyle = AppFontStyle.POPPINS,
    val onboardingCompleted: Boolean = false,
    val scanQuality: ScanQuality = ScanQuality.HIGH,
    val defaultPageSize: PdfPageSize = PdfPageSize.A4,
    val autoEnhance: Boolean = true,
    val appLockEnabled: Boolean = false,
    val biometricUnlockEnabled: Boolean = false,
    val encryptSensitiveFiles: Boolean = false,
    val sealedPinRecord: String? = null,
    val lastBackupAt: Long? = null,
    val fileNamingFormat: FileNamingFormat = FileNamingFormat.DOCUSCAN_DATETIME
) {
    val hasPinConfigured: Boolean
        get() = !sealedPinRecord.isNullOrBlank()
}

data class PdfCreationOptions(
    val pageSize: PdfPageSize = PdfPageSize.A4,
    val customWidthPt: Int = 595,
    val customHeightPt: Int = 842,
    val orientation: PdfOrientation = PdfOrientation.PORTRAIT,
    val marginPt: Float = 24f,
    val includePageNumbers: Boolean = false,
    val quality: ScanQuality = ScanQuality.HIGH,
    val watermarkText: String = "",
    val password: String = "",
    val embedSearchableText: Boolean = false
)

data class PdfSearchMatch(
    val pageIndex: Int,
    val snippet: String,
    val matchCount: Int
)

data class PdfAnnotationRecord(
    val pageIndex: Int,
    val type: String,
    val contents: String
)

data class NormalizedCropRect(
    val left: Float = 0f,
    val top: Float = 0f,
    val right: Float = 1f,
    val bottom: Float = 1f
) {
    val isFullFrame: Boolean
        get() = left <= 0.01f && top <= 0.01f && right >= 0.99f && bottom >= 0.99f

    fun sanitized(): NormalizedCropRect {
        val safeLeft = left.coerceIn(0f, 0.85f)
        val safeTop = top.coerceIn(0f, 0.85f)
        val safeRight = right.coerceIn(safeLeft + 0.12f, 1f)
        val safeBottom = bottom.coerceIn(safeTop + 0.12f, 1f)
        return NormalizedCropRect(safeLeft, safeTop, safeRight, safeBottom)
    }
}

data class IdSideScanState(
    val imagePath: String? = null,
    val cropRect: NormalizedCropRect = NormalizedCropRect(),
    val filter: ScanFilter = ScanFilter.MAGIC_COLOR,
    val rotationDegrees: Int = 0
)

data class SignaturePlacement(
    val pageIndex: Int = 0,
    val normX: Float = 0.56f,
    val normY: Float = 0.72f,
    val normWidth: Float = 0.30f
)

typealias Document = DocumentItem
typealias Folder = FolderItem
typealias Page = ScanPage
typealias Signature = SignatureItem
typealias AppSettings = UserPreferences
typealias DeletedDocument = DeletedDocumentItem

data class PdfDocumentInfo(
    val title: String,
    val author: String,
    val subject: String,
    val creator: String,
    val producer: String,
    val pdfVersion: String,
    val pageCount: Int,
    val fileSizeBytes: Long,
    val isEncrypted: Boolean,
    val keyLengthBits: Int,
    val firstPageWidthPt: Float,
    val firstPageHeightPt: Float,
    val createdDateMillis: Long?,
    val modifiedDateMillis: Long?,
    val filePath: String
)

data class PdfTextExtractionResult(
    val fullText: String,
    val pageTexts: List<String>,
    val totalPages: Int,
    val hasEmbeddedText: Boolean
)

data class PdfDocxConversionResult(
    val outputFilePath: String,
    val title: String,
    val pageCount: Int,
    val extractedCharCount: Int,
    val imageFallbackPages: Int
)

data class PdfImagesExportResult(
    val imageFilePaths: List<String>,
    val savedDocumentIds: List<Long>,
    val zipFilePath: String?,
    val format: PdfImageFormat
)

data class PdfReduceSizeResult(
    val document: DocumentItem,
    val originalBytes: Long,
    val outputBytes: Long
) {
    val savingsPercent: Int
        get() = if (originalBytes > 0L && outputBytes < originalBytes) {
            (((originalBytes - outputBytes) * 100.0) / originalBytes).toInt()
        } else {
            0
        }
}

data class WatermarkRemovalResult(
    val document: DocumentItem,
    val removedAnnotations: Int,
    val removedTextBlocks: Int,
    val removedOcgCount: Int
) {
    val totalRemoved: Int
        get() = removedAnnotations + removedTextBlocks + removedOcgCount
}

data class PdfRepairResult(
    val document: DocumentItem,
    val recoveredPages: Int,
    val methodSummary: String
)

