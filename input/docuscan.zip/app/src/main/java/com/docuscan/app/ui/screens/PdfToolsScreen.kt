package com.docuscan.app.ui.screens

import android.net.Uri
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.PickVisualMediaRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import com.docuscan.app.ui.icons.LucideIcons
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FilterChipDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.unit.dp
import com.docuscan.app.domain.model.DocumentItem
import com.docuscan.app.domain.model.PageNumberFormat
import com.docuscan.app.domain.model.PageNumberPosition
import com.docuscan.app.domain.model.PdfCompressionLevel
import com.docuscan.app.domain.model.PdfImageFormat
import com.docuscan.app.domain.model.PdfOrientation
import com.docuscan.app.domain.model.PdfPageSize
import com.docuscan.app.ui.components.DocuScanCard
import com.docuscan.app.ui.components.ErrorStateView
import com.docuscan.app.ui.components.PhaseStatusChip
import com.docuscan.app.ui.viewmodel.PdfToolsUiState

@Composable
fun PdfToolsScreen(
    pdfDocuments: List<DocumentItem>,
    activeSessionPageCount: Int,
    uiState: PdfToolsUiState,
    onDismissError: () -> Unit,
    onDismissResult: () -> Unit,
    onOpenIdScanner: () -> Unit,
    onOpenSignatureCreator: () -> Unit,
    onOpenSignPdf: () -> Unit,
    onOpenOcrExtractor: (Long?) -> Unit,
    onOpenPageManager: () -> Unit,
    onImportMultipleGalleryImages: (List<Uri>) -> Unit,
    onImportExternalPdf: (Uri, onImported: (DocumentItem) -> Unit) -> Unit,
    onImportMultipleExternalPdfs: (List<Uri>, onImported: (List<DocumentItem>) -> Unit) -> Unit = { uris, cb ->
        uris.firstOrNull()?.let { uri -> onImportExternalPdf(uri) { doc -> cb(listOf(doc)) } }
    },
    onOpenExternalPdfUri: (Uri) -> Unit,
    onOpenDocument: (Long) -> Unit,
    onRenamePdf: (Long, String) -> Unit,
    onDeletePdf: (Long, Boolean) -> Unit,
    onSharePdf: (DocumentItem) -> Unit,
    onPrintPdf: (android.content.Context, DocumentItem) -> Unit,
    onDuplicatePdf: (Long, String) -> Unit,
    onInspectInfo: (Long, String?) -> Unit,
    onMergePdfs: (String, List<Long>) -> Unit,
    onSplitPdf: (Long, String, Int, Int, String?) -> Unit,
    onExtractPages: (Long, String, List<Int>, String?) -> Unit,
    onReorderPages: (Long, String, List<Int>, String, String?) -> Unit,
    onRotatePages: (Long, String, Set<Int>, Int, String?) -> Unit,
    onDeletePages: (Long, String, Set<Int>, String?) -> Unit,
    onDuplicatePages: (Long, String, List<Int>, Boolean, String?) -> Unit,
    onExportPdfToImages: (Long, PdfImageFormat, List<Int>, Int, Boolean, String?) -> Unit,
    onReadTextFromUri: (Uri, (String) -> Unit) -> Unit,
    onCreatePdfFromText: (String, String, PdfPageSize, PdfOrientation, Float, Float, Boolean, String) -> Unit,
    onConvertPdfToDocx: (Long, String, Boolean, String?) -> Unit,
    onExtractTextFromPdf: (Long, Int, Int, String?) -> Unit,
    onProtectPdf: (Long, String, String, String?) -> Unit,
    onUnlockPdf: (Long, String, String) -> Unit,
    onWatermarkPdf: (Long, String, String, String?) -> Unit,
    onRemoveWatermark: (Long, String, String?, String?) -> Unit,
    onAddPageNumbers: (Long, String, PageNumberPosition, PageNumberFormat, Int, String?) -> Unit,
    onAddHeaderFooter: (Long, String, String, String, Boolean, Float, String?) -> Unit,
    onCompressPdf: (Long, String, PdfCompressionLevel, String?) -> Unit,
    onReducePdfSize: (Long, String, Int, Float, Boolean, String?) -> Unit,
    onRepairPdf: (Long, String, String?) -> Unit,
    onRepairExternalPdfUri: (Uri, String, String?) -> Unit,
    onExportPdfToSaf: (Long, Uri) -> Unit,
    onExportLocalFileToSaf: (String, Uri, String) -> Unit,
    onExportTextToSaf: (String, Uri) -> Unit,
    onExportImagesToSafTree: (List<String>, PdfImageFormat, Uri) -> Unit,
    onShareLocalFile: (String, String, String) -> Unit,
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current

    var searchQuery by remember { mutableStateOf("") }
    var selectedCategory by remember { mutableStateOf<PdfToolCategory?>(null) }

    var activeSingleTool by remember { mutableStateOf<PdfToolId?>(null) }
    var showMergeDialog by remember { mutableStateOf(false) }
    var showTextToPdfDialog by remember { mutableStateOf(false) }
    var showImagesToPdfDialog by remember { mutableStateOf(false) }
    var importedTextDraft by remember { mutableStateOf("") }
    var preferredDocId by remember { mutableStateOf<Long?>(null) }
    var mergeNewlyImportedIds by remember { mutableStateOf<List<Long>>(emptyList()) }

    var pendingRepairTitle by remember { mutableStateOf("") }
    var pendingRepairPassword by remember { mutableStateOf<String?>(null) }

    var pendingSafPdfDocId by remember { mutableStateOf<Long?>(null) }
    var pendingSafLocalPath by remember { mutableStateOf<String?>(null) }
    var pendingSafLocalLabel by remember { mutableStateOf("File") }
    var pendingSafText by remember { mutableStateOf("") }
    var pendingFolderImagePaths by remember { mutableStateOf<List<String>>(emptyList()) }
    var pendingFolderImageFormat by remember { mutableStateOf(PdfImageFormat.JPG) }

    val openAndViewSafLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.OpenDocument()
    ) { uri ->
        if (uri != null) onOpenExternalPdfUri(uri)
    }

    val pickPdfForDialogLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.OpenDocument()
    ) { uri ->
        if (uri != null) {
            onImportExternalPdf(uri) { imported ->
                preferredDocId = imported.id
            }
        }
    }

    val pickMultiPdfForMergeLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.OpenMultipleDocuments()
    ) { uris ->
        if (uris.isNotEmpty()) {
            onImportMultipleExternalPdfs(uris) { imported ->
                mergeNewlyImportedIds = imported
                    .filter { !it.isPasswordProtected }
                    .map { it.id }
            }
        }
    }

    val repairExternalSafLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.OpenDocument()
    ) { uri ->
        if (uri != null) {
            onRepairExternalPdfUri(uri, pendingRepairTitle, pendingRepairPassword)
        }
    }

    val importTxtSafLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.OpenDocument()
    ) { uri ->
        if (uri != null) {
            onReadTextFromUri(uri) { loaded -> importedTextDraft = loaded }
        }
    }

    val pickMultiImagesLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.PickMultipleVisualMedia(maxItems = 50)
    ) { uris ->
        if (uris.isNotEmpty()) {
            onImportMultipleGalleryImages(uris)
        }
    }

    val savePdfSafLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.CreateDocument("application/pdf")
    ) { uri ->
        val id = pendingSafPdfDocId
        if (uri != null && id != null) onExportPdfToSaf(id, uri)
    }

    val saveDocxSafLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.CreateDocument(
            "application/vnd.openxmlformats-officedocument.wordprocessingml.document"
        )
    ) { uri ->
        val path = pendingSafLocalPath
        if (uri != null && path != null) onExportLocalFileToSaf(path, uri, pendingSafLocalLabel)
    }

    val saveZipSafLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.CreateDocument("application/zip")
    ) { uri ->
        val path = pendingSafLocalPath
        if (uri != null && path != null) onExportLocalFileToSaf(path, uri, pendingSafLocalLabel)
    }

    val saveJpgSafLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.CreateDocument("image/jpeg")
    ) { uri ->
        val path = pendingSafLocalPath
        if (uri != null && path != null) onExportLocalFileToSaf(path, uri, pendingSafLocalLabel)
    }

    val savePngSafLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.CreateDocument("image/png")
    ) { uri ->
        val path = pendingSafLocalPath
        if (uri != null && path != null) onExportLocalFileToSaf(path, uri, pendingSafLocalLabel)
    }

    val saveTxtSafLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.CreateDocument("text/plain")
    ) { uri ->
        if (uri != null && pendingSafText.isNotEmpty()) {
            onExportTextToSaf(pendingSafText, uri)
        }
    }

    val saveImagesTreeLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.OpenDocumentTree()
    ) { treeUri ->
        if (treeUri != null && pendingFolderImagePaths.isNotEmpty()) {
            onExportImagesToSafTree(pendingFolderImagePaths, pendingFolderImageFormat, treeUri)
        }
    }

    fun launchTool(tool: PdfToolId) {
        preferredDocId = null
        when (tool) {
            PdfToolId.MERGE_PDF -> {
                mergeNewlyImportedIds = emptyList()
                showMergeDialog = true
            }
            PdfToolId.IMAGES_TO_PDF -> showImagesToPdfDialog = true
            PdfToolId.TEXT_TO_PDF -> {
                importedTextDraft = ""
                showTextToPdfDialog = true
            }
            PdfToolId.ID_SCANNER -> onOpenIdScanner()
            PdfToolId.SIGNATURE_CREATOR -> onOpenSignatureCreator()
            PdfToolId.SIGN_PDF -> onOpenSignPdf()
            PdfToolId.OCR_EXTRACTOR -> onOpenOcrExtractor(null)
            else -> activeSingleTool = tool
        }
    }

    val filteredTools = remember(searchQuery, selectedCategory) {
        val q = searchQuery.trim()
        PdfToolId.entries.filter { tool ->
            (selectedCategory == null || tool.category == selectedCategory) &&
                (q.isEmpty() || tool.title.contains(q, ignoreCase = true) || tool.subtitle.contains(q, ignoreCase = true))
        }
    }
    val groupedTools = remember(filteredTools) {
        PdfToolCategory.entries.mapNotNull { cat ->
            val itemsInCat = filteredTools.filter { it.category == cat }
            if (itemsInCat.isEmpty()) null else cat to itemsInCat
        }
    }

    LazyColumn(
        modifier = modifier
            .fillMaxSize()
            .testTag("pdf_tools_list"),
        contentPadding = PaddingValues(horizontal = 16.dp, vertical = 14.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp)
    ) {
        item {
            Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                Text("PDF & Document Tools", style = MaterialTheme.typography.headlineMedium)
                Text(
                    text = "${PdfToolId.entries.size} offline tools · ${pdfDocuments.size} local PDF(s) ready",
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
        }

        item {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                OutlinedTextField(
                    value = searchQuery,
                    onValueChange = { searchQuery = it },
                    placeholder = { Text("Search PDF tools...") },
                    leadingIcon = { Icon(LucideIcons.Search, contentDescription = null) },
                    trailingIcon = {
                        if (searchQuery.isNotEmpty()) {
                            IconButton(onClick = { searchQuery = "" }) {
                                Icon(LucideIcons.X, contentDescription = "Clear tool search")
                            }
                        }
                    },
                    singleLine = true,
                    modifier = Modifier
                        .weight(1f)
                        .testTag("pdf_tools_search_input")
                )
                OutlinedButton(
                    onClick = { openAndViewSafLauncher.launch(arrayOf("application/pdf")) },
                    modifier = Modifier.testTag("quick_open_saf_pdf_btn")
                ) {
                    Icon(LucideIcons.FolderOpen, contentDescription = "Select PDF from Device", modifier = Modifier.size(18.dp))
                    Spacer(modifier = Modifier.size(4.dp))
                    Text("Device")
                }
            }
        }

        item {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .horizontalScroll(rememberScrollState()),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                FilterChip(
                    selected = selectedCategory == null,
                    onClick = { selectedCategory = null },
                    label = { Text("All (${PdfToolId.entries.size})") },
                    colors = FilterChipDefaults.filterChipColors(
                        selectedContainerColor = MaterialTheme.colorScheme.primary,
                        selectedLabelColor = MaterialTheme.colorScheme.onPrimary
                    )
                )
                PdfToolCategory.entries.forEach { cat ->
                    FilterChip(
                        selected = selectedCategory == cat,
                        onClick = { selectedCategory = if (selectedCategory == cat) null else cat },
                        label = { Text(cat.title.removePrefix("PDF ")) },
                        colors = FilterChipDefaults.filterChipColors(
                            selectedContainerColor = MaterialTheme.colorScheme.primary,
                            selectedLabelColor = MaterialTheme.colorScheme.onPrimary
                        )
                    )
                }
            }
        }

        if (uiState.isWorking) {
            item {
                DocuScanCard(highlighted = true) {
                    Text(uiState.workingMessage, style = MaterialTheme.typography.titleSmall)
                    Spacer(modifier = Modifier.size(8.dp))
                    LinearProgressIndicator(modifier = Modifier.fillMaxWidth())
                }
            }
        }

        if (!uiState.errorMessage.isNullOrBlank()) {
            item {
                DocuScanCard(modifier = Modifier.testTag("pdf_tools_error_card")) {
                    ErrorStateView(
                        message = uiState.errorMessage,
                        onRetry = onDismissError
                    )
                }
            }
        }

        val currentResult = uiState.result
        if (currentResult != null) {
            item {
                PdfToolResultBanner(
                    result = currentResult,
                    onDismiss = onDismissResult,
                    onOpenPdf = onOpenDocument,
                    onSavePdfCopySaf = { docId, suggestedName ->
                        pendingSafPdfDocId = docId
                        savePdfSafLauncher.launch(suggestedName)
                    },
                    onSharePdf = { docId, path, title ->
                        val doc = pdfDocuments.firstOrNull { it.id == docId }
                            ?: DocumentItem(id = docId, title = title, filePath = path)
                        onSharePdf(doc)
                    },
                    onSaveLocalFileSaf = { path, name, mime, label ->
                        pendingSafLocalPath = path
                        pendingSafLocalLabel = label
                        when (mime) {
                            "application/vnd.openxmlformats-officedocument.wordprocessingml.document" ->
                                saveDocxSafLauncher.launch(name)
                            "application/zip" -> saveZipSafLauncher.launch(name)
                            "image/png" -> savePngSafLauncher.launch(name)
                            else -> saveJpgSafLauncher.launch(name)
                        }
                    },
                    onShareLocalFile = onShareLocalFile,
                    onSaveImagesToFolderSaf = { paths ->
                        pendingFolderImagePaths = paths
                        pendingFolderImageFormat = (currentResult as? com.docuscan.app.ui.viewmodel.PdfToolResult.ImagesExported)
                            ?.export?.format ?: PdfImageFormat.JPG
                        saveImagesTreeLauncher.launch(null)
                    },
                    onSaveTextSaf = { text, name ->
                        pendingSafText = text
                        saveTxtSafLauncher.launch(name)
                    },
                    onOpenOcrForDoc = { docId -> onOpenOcrExtractor(docId) }
                )
            }
        }

        groupedTools.forEach { (category, toolsInCategory) ->
            item(key = "header_${category.name}") {
                Text(
                    text = category.title,
                    style = MaterialTheme.typography.titleMedium,
                    color = MaterialTheme.colorScheme.primary,
                    modifier = Modifier.padding(top = 6.dp, bottom = 2.dp)
                )
            }
            items(toolsInCategory, key = { it.name }) { tool ->
                ToolRowCard(
                    tool = tool,
                    onClick = { launchTool(tool) }
                )
            }
        }
    }

    if (showMergeDialog) {
        MergePdfDialog(
            pdfDocuments = pdfDocuments,
            newlyImportedIds = mergeNewlyImportedIds,
            onImportPdfSaf = { pickMultiPdfForMergeLauncher.launch(arrayOf("application/pdf")) },
            onDismiss = { showMergeDialog = false },
            onConfirmMerge = onMergePdfs
        )
    }

    if (showTextToPdfDialog) {
        TextToPdfDialog(
            initialImportedText = importedTextDraft,
            onImportTxtSaf = { importTxtSafLauncher.launch(arrayOf("text/plain", "text/*")) },
            onDismiss = { showTextToPdfDialog = false },
            onGenerateTextPdf = onCreatePdfFromText
        )
    }

    if (showImagesToPdfDialog) {
        ImagesToPdfDialog(
            activeSessionPageCount = activeSessionPageCount,
            onPickGalleryImages = {
                pickMultiImagesLauncher.launch(
                    PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageOnly)
                )
            },
            onOpenPageManager = onOpenPageManager,
            onDismiss = { showImagesToPdfDialog = false }
        )
    }

    activeSingleTool?.let { tool ->
        PdfToolWorkspaceDialog(
            tool = tool,
            pdfDocuments = pdfDocuments,
            preferredSelectedDocId = preferredDocId,
            callbacks = PdfToolWorkspaceCallbacks(
                onPickPdfSafForSelection = { pickPdfForDialogLauncher.launch(arrayOf("application/pdf")) },
                onPickDamagedPdfSafRepair = { title, pwd ->
                    pendingRepairTitle = title
                    pendingRepairPassword = pwd
                    repairExternalSafLauncher.launch(arrayOf("application/pdf", "*/*"))
                },
                onViewPdf = onOpenDocument,
                onRenamePdf = onRenamePdf,
                onDeletePdf = onDeletePdf,
                onSharePdf = onSharePdf,
                onPrintPdf = { doc -> onPrintPdf(context, doc) },
                onDuplicatePdf = onDuplicatePdf,
                onInspectInfo = onInspectInfo,
                onSplitPdf = onSplitPdf,
                onExtractPages = onExtractPages,
                onReorderPages = onReorderPages,
                onRotatePages = onRotatePages,
                onDeletePages = onDeletePages,
                onDuplicatePages = onDuplicatePages,
                onExportImages = onExportPdfToImages,
                onPdfToDocx = onConvertPdfToDocx,
                onPdfToText = onExtractTextFromPdf,
                onProtectPdf = onProtectPdf,
                onUnlockPdf = onUnlockPdf,
                onAddWatermark = onWatermarkPdf,
                onRemoveWatermark = onRemoveWatermark,
                onAddPageNumbers = onAddPageNumbers,
                onAddHeaderFooter = onAddHeaderFooter,
                onCompressPdf = onCompressPdf,
                onReduceSize = onReducePdfSize,
                onRepairPdf = onRepairPdf
            ),
            onDismiss = { activeSingleTool = null }
        )
    }
}

@Composable
private fun ToolRowCard(
    tool: PdfToolId,
    onClick: () -> Unit
) {
    DocuScanCard(
        modifier = Modifier
            .fillMaxWidth()
            .testTag(tool.testTag),
        onClick = onClick
    ) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            Icon(
                imageVector = tool.icon,
                contentDescription = tool.title,
                tint = MaterialTheme.colorScheme.primary,
                modifier = Modifier.size(28.dp)
            )
            Column(
                modifier = Modifier.weight(1f),
                verticalArrangement = Arrangement.spacedBy(3.dp)
            ) {
                Text(
                    text = tool.title,
                    style = MaterialTheme.typography.titleMedium,
                    color = MaterialTheme.colorScheme.onSurface
                )
                Text(
                    text = tool.subtitle,
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
            PhaseStatusChip(text = tool.badge, highlighted = true)
        }
    }
}
