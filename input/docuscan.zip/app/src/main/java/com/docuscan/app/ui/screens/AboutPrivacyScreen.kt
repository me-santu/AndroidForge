package com.docuscan.app.ui.screens

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.WindowInsetsSides
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.only
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.safeDrawing
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.unit.dp
import com.docuscan.app.BuildConfig
import com.docuscan.app.security.SecurityManager
import com.docuscan.app.ui.components.DocuScanCard
import com.docuscan.app.ui.components.DocuScanTopBar
import com.docuscan.app.ui.components.PhaseStatusChip
import com.docuscan.app.ui.icons.LucideIcons

@Composable
fun AboutPrivacyScreen(
    securityManager: SecurityManager,
    onBack: () -> Unit
) {
    Scaffold(
        modifier = Modifier
            .fillMaxSize()
            .testTag("about_privacy_screen"),
        containerColor = MaterialTheme.colorScheme.background,
        contentWindowInsets = WindowInsets.safeDrawing.only(WindowInsetsSides.Bottom + WindowInsetsSides.Horizontal),
        topBar = {
            DocuScanTopBar(
                title = "About & Privacy",
                subtitle = "DocuScan v${BuildConfig.VERSION_NAME}",
                onBack = onBack
            )
        }
    ) { innerPadding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
                .verticalScroll(rememberScrollState())
                .padding(horizontal = 16.dp, vertical = 12.dp),
            verticalArrangement = Arrangement.spacedBy(14.dp)
        ) {
            DocuScanCard(highlighted = true) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    Icon(
                        imageVector = LucideIcons.Shield,
                        contentDescription = null,
                        tint = MaterialTheme.colorScheme.primary
                    )
                    Column {
                        Text("DocuScan — Offline-First Vault", style = MaterialTheme.typography.titleMedium)
                        Text(
                            text = "App ID: ${BuildConfig.APPLICATION_ID} · v${BuildConfig.VERSION_NAME} (${BuildConfig.VERSION_CODE})",
                            style = MaterialTheme.typography.labelSmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                }
                Spacer(modifier = Modifier.height(10.dp))
                Text(
                    text = "DocuScan processes camera captures, image filters, multi-language auto-detect OCR (Latin, Devanagari, Bengali via offline Tesseract, Chinese, Japanese, Korean, plus Unicode PDF extraction), PDF tools, ID scanning, and signatures locally on your device. No analytics SDKs, no advertising trackers, and no unauthorized uploads are included.",
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }

            DocuScanCard {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        Icon(
                            imageVector = LucideIcons.KeyRound,
                            contentDescription = null,
                            tint = MaterialTheme.colorScheme.primary
                        )
                        Text("Encryption & Key Management", style = MaterialTheme.typography.titleMedium)
                    }
                    PhaseStatusChip(text = "AES-256-GCM", highlighted = true)
                }
                Spacer(modifier = Modifier.height(8.dp))
                Text(
                    text = "• Active Key Provider: ${securityManager.keystoreProviderLabel}\n" +
                        "• Vault PINs are stretched with 65,536 SHA-256 iterations and random 16-byte salt, then wrapped with the Android Keystore master key.\n" +
                        "• OS Cloud Auto-Backup (allowBackup) is disabled and sensitive folders are excluded from system extraction rules.\n" +
                        "• Document contents, OCR text, PINs, and ID card data are never written to system logs.",
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }

            DocuScanCard {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    Icon(
                        imageVector = LucideIcons.ShieldCheck,
                        contentDescription = null,
                        tint = MaterialTheme.colorScheme.primary
                    )
                    Text("Permissions & Why They Exist", style = MaterialTheme.typography.titleMedium)
                }
                Spacer(modifier = Modifier.height(10.dp))
                PermissionExplanationRow(
                    icon = LucideIcons.Camera,
                    title = "Camera (android.permission.CAMERA)",
                    detail = "Used only when you open the live camera scanner or ID card camera capture. Completely optional—gallery import works without granting Camera."
                )
                Spacer(modifier = Modifier.height(10.dp))
                PermissionExplanationRow(
                    icon = LucideIcons.Images,
                    title = "Android Photo Picker (Zero Storage Permission)",
                    detail = "Uses the system PickVisualMedia picker. DocuScan intentionally does NOT request broad READ_EXTERNAL_STORAGE or READ_MEDIA_IMAGES permissions."
                )
                Spacer(modifier = Modifier.height(10.dp))
                PermissionExplanationRow(
                    icon = LucideIcons.Fingerprint,
                    title = "Biometrics (android.permission.USE_BIOMETRIC)",
                    detail = "Normal permission used only when you opt in to unlock your Vault App Lock with your fingerprint or face."
                )
                Spacer(modifier = Modifier.height(10.dp))
                PermissionExplanationRow(
                    icon = LucideIcons.FolderOpen,
                    title = "Storage Access Framework (SAF)",
                    detail = "Exports PDFs and ZIP backups strictly to folders you explicitly pick in the Android system file chooser."
                )
            }

            DocuScanCard {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        Icon(
                            imageVector = LucideIcons.CloudOff,
                            contentDescription = null,
                            tint = MaterialTheme.colorScheme.primary
                        )
                        Text("Optional Firebase & Cloud Costs", style = MaterialTheme.typography.titleMedium)
                    }
                    PhaseStatusChip(text = "Not Provisioned")
                }
                Spacer(modifier = Modifier.height(8.dp))
                Text(
                    text = "Cloud Status: Offline-Only (google-services.json not configured). Core scanning, PDF creation, OCR, and Vault encryption require zero internet and zero cloud billing.\n\n" +
                        "If optional Firebase Cloud Backup or Gemini AI features are configured later:\n" +
                        "• Required Setup: A Firebase project with google-services.json, Google Sign-In (Credential Manager), Cloud Firestore rules, Firebase App Check, and explicit per-document user consent before upload.\n" +
                        "• ID Card Policy: Aadhaar, PAN, Passport, Driving Licence, and Voter ID scans remain strictly excluded from cloud sync by default.\n" +
                        "• Costs: Firebase Spark (Free) tier includes Auth and limited Firestore (1 GiB / 50K daily reads / 20K writes); Firebase Blaze (Pay-as-you-go) is required for Cloud Storage buckets or high-volume Firebase AI Logic Gemini usage.",
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
        }
    }
}

@Composable
private fun PermissionExplanationRow(
    icon: ImageVector,
    title: String,
    detail: String
) {
    Row(
        horizontalArrangement = Arrangement.spacedBy(10.dp),
        verticalAlignment = Alignment.Top
    ) {
        Icon(
            imageVector = icon,
            contentDescription = null,
            tint = MaterialTheme.colorScheme.primary,
            modifier = Modifier
                .padding(top = 2.dp)
                .size(18.dp)
        )
        Column(verticalArrangement = Arrangement.spacedBy(2.dp)) {
            Text(text = title, style = MaterialTheme.typography.titleSmall)
            Text(
                text = detail,
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
        }
    }
}
