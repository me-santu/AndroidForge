package com.docuscan.app.ui.screens

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.imePadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.minimumInteractiveComponentSize
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.luminance
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.text.input.VisualTransformation
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import com.docuscan.app.domain.model.DocumentItem
import com.docuscan.app.domain.model.PdfSignatureDetail
import com.docuscan.app.domain.model.PdfSignatureValidationOutcome
import com.docuscan.app.ui.icons.LucideIcons
import com.docuscan.app.ui.theme.SignatureInvalidRedDark
import com.docuscan.app.ui.theme.SignatureInvalidRedLight
import com.docuscan.app.ui.theme.SignatureValidGreenDark
import com.docuscan.app.ui.theme.SignatureValidGreenLight
import com.docuscan.app.ui.theme.SignatureWarningAmberDark
import com.docuscan.app.ui.theme.SignatureWarningAmberLight
import com.docuscan.app.ui.viewmodel.SignatureValidationUiState
import com.docuscan.app.util.FormatUtils
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

@Composable
fun PdfSignatureValidationDialog(
    pdfDocuments: List<DocumentItem>,
    validationState: SignatureValidationUiState,
    onPickFromDevice: () -> Unit,
    onSelectDocument: (DocumentItem) -> Unit,
    onSubmitPassword: (String) -> Unit,
    onCheckAnother: () -> Unit,
    onDismiss: () -> Unit
) {
    val isDark = MaterialTheme.colorScheme.background.luminance() < 0.5f
    val validGreen = if (isDark) SignatureValidGreenDark else SignatureValidGreenLight
    val invalidRed = if (isDark) SignatureInvalidRedDark else SignatureInvalidRedLight
    val warningAmber = if (isDark) SignatureWarningAmberDark else SignatureWarningAmberLight

    var passwordInput by remember(validationState.outcome) { mutableStateOf("") }
    var showPassword by remember { mutableStateOf(false) }

    AlertDialog(
        onDismissRequest = onDismiss,
        modifier = Modifier
            .imePadding()
            .testTag("signature_validation_dialog"),
        icon = {
            Box(
                modifier = Modifier
                    .size(44.dp)
                    .clip(RoundedCornerShape(12.dp))
                    .background(MaterialTheme.colorScheme.primary.copy(alpha = 0.14f)),
                contentAlignment = Alignment.Center
            ) {
                Icon(
                    imageVector = LucideIcons.ShieldCheck,
                    contentDescription = "Validate PDF Signature",
                    tint = MaterialTheme.colorScheme.primary,
                    modifier = Modifier.size(24.dp)
                )
            }
        },
        title = {
            Text(
                text = "Validate PDF Signature",
                style = MaterialTheme.typography.titleLarge
            )
        },
        text = {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .heightIn(max = 460.dp)
                    .verticalScroll(rememberScrollState()),
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                when {
                    validationState.isChecking -> {
                        Column(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(vertical = 24.dp),
                            horizontalAlignment = Alignment.CenterHorizontally,
                            verticalArrangement = Arrangement.spacedBy(12.dp)
                        ) {
                            CircularProgressIndicator(
                                color = MaterialTheme.colorScheme.primary,
                                modifier = Modifier.size(36.dp)
                            )
                            Text(
                                text = validationState.checkingLabel,
                                style = MaterialTheme.typography.bodyMedium,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                    }

                    validationState.outcome == null -> {
                        Text(
                            text = "Verify embedded digital signatures & document integrity 100% offline. Supports e-Aadhaar and password-protected PDFs.",
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )

                        Button(
                            onClick = onPickFromDevice,
                            colors = ButtonDefaults.buttonColors(
                                containerColor = MaterialTheme.colorScheme.primary,
                                contentColor = MaterialTheme.colorScheme.onPrimary
                            ),
                            modifier = Modifier
                                .fillMaxWidth()
                                .minimumInteractiveComponentSize()
                                .testTag("sig_check_pick_device_btn")
                        ) {
                            Icon(
                                imageVector = LucideIcons.FolderOpen,
                                contentDescription = null,
                                modifier = Modifier.size(18.dp)
                            )
                            Spacer(modifier = Modifier.size(8.dp))
                            Text("Select PDF from Device Storage")
                        }

                        HorizontalDivider()

                        Text(
                            text = "Or pick from DocuScan Documents (${pdfDocuments.size}):",
                            style = MaterialTheme.typography.labelMedium,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )

                        if (pdfDocuments.isEmpty()) {
                            Surface(
                                shape = RoundedCornerShape(12.dp),
                                color = MaterialTheme.colorScheme.surfaceContainer,
                                border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline),
                                modifier = Modifier.fillMaxWidth()
                            ) {
                                Text(
                                    text = "No saved PDFs in DocuScan yet. Tap above to pick any PDF from device storage.",
                                    style = MaterialTheme.typography.bodySmall,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                                    modifier = Modifier.padding(12.dp)
                                )
                            }
                        } else {
                            Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                                pdfDocuments.forEach { doc ->
                                    Surface(
                                        shape = RoundedCornerShape(12.dp),
                                        color = MaterialTheme.colorScheme.surfaceContainer,
                                        border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline),
                                        modifier = Modifier
                                            .fillMaxWidth()
                                            .clip(RoundedCornerShape(12.dp))
                                            .clickable { onSelectDocument(doc) }
                                            .minimumInteractiveComponentSize()
                                            .testTag("sig_check_doc_${doc.id}")
                                    ) {
                                        Row(
                                            modifier = Modifier
                                                .fillMaxWidth()
                                                .padding(horizontal = 12.dp, vertical = 10.dp),
                                            verticalAlignment = Alignment.CenterVertically,
                                            horizontalArrangement = Arrangement.spacedBy(10.dp)
                                        ) {
                                            Icon(
                                                imageVector = LucideIcons.FileText,
                                                contentDescription = null,
                                                tint = MaterialTheme.colorScheme.primary,
                                                modifier = Modifier.size(20.dp)
                                            )
                                            Column(modifier = Modifier.weight(1f)) {
                                                Row(
                                                    verticalAlignment = Alignment.CenterVertically,
                                                    horizontalArrangement = Arrangement.spacedBy(4.dp)
                                                ) {
                                                    Text(
                                                        text = doc.title,
                                                        style = MaterialTheme.typography.bodyMedium,
                                                        maxLines = 1,
                                                        overflow = TextOverflow.Ellipsis
                                                    )
                                                    if (doc.isPasswordProtected) {
                                                        Icon(
                                                            imageVector = LucideIcons.Lock,
                                                            contentDescription = "Password Protected",
                                                            tint = MaterialTheme.colorScheme.primary,
                                                            modifier = Modifier.size(14.dp)
                                                        )
                                                    }
                                                }
                                                Text(
                                                    text = "${doc.pageCount}p · ${FormatUtils.formatBytes(doc.sizeBytes)}",
                                                    style = MaterialTheme.typography.labelSmall,
                                                    color = MaterialTheme.colorScheme.onSurfaceVariant
                                                )
                                            }
                                            Icon(
                                                imageVector = LucideIcons.ChevronRight,
                                                contentDescription = "Validate",
                                                tint = MaterialTheme.colorScheme.onSurfaceVariant,
                                                modifier = Modifier.size(18.dp)
                                            )
                                        }
                                    }
                                }
                            }
                        }
                    }

                    validationState.outcome is PdfSignatureValidationOutcome.PasswordRequired -> {
                        val req = validationState.outcome
                        Surface(
                            shape = RoundedCornerShape(14.dp),
                            color = MaterialTheme.colorScheme.surfaceContainer,
                            border = BorderStroke(1.dp, MaterialTheme.colorScheme.primary.copy(alpha = 0.45f)),
                            modifier = Modifier
                                .fillMaxWidth()
                                .testTag("sig_check_password_card")
                        ) {
                            Column(
                                modifier = Modifier.padding(14.dp),
                                verticalArrangement = Arrangement.spacedBy(10.dp)
                            ) {
                                Row(
                                    verticalAlignment = Alignment.CenterVertically,
                                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                                ) {
                                    Icon(
                                        imageVector = LucideIcons.Lock,
                                        contentDescription = "Password Required",
                                        tint = MaterialTheme.colorScheme.primary,
                                        modifier = Modifier.size(20.dp)
                                    )
                                    Text(
                                        text = "Password-Protected PDF",
                                        style = MaterialTheme.typography.titleSmall,
                                        fontWeight = FontWeight.SemiBold
                                    )
                                }
                                Text(
                                    text = "Enter the password for '${req.fileName}' (e.g., e-Aadhaar password) to unlock and verify its digital signature offline.",
                                    style = MaterialTheme.typography.bodySmall,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant
                                )
                                OutlinedTextField(
                                    value = passwordInput,
                                    onValueChange = { passwordInput = it },
                                    label = { Text("PDF Password") },
                                    singleLine = true,
                                    isError = req.incorrectPassword,
                                    supportingText = if (req.incorrectPassword) {
                                        {
                                            Text(
                                                text = "Incorrect password. Please try again.",
                                                color = invalidRed
                                            )
                                        }
                                    } else {
                                        null
                                    },
                                    visualTransformation = if (showPassword) {
                                        VisualTransformation.None
                                    } else {
                                        PasswordVisualTransformation()
                                    },
                                    trailingIcon = {
                                        IconButton(onClick = { showPassword = !showPassword }) {
                                            Icon(
                                                imageVector = LucideIcons.Eye,
                                                contentDescription = if (showPassword) "Hide password" else "Show password"
                                            )
                                        }
                                    },
                                    keyboardOptions = KeyboardOptions(imeAction = ImeAction.Done),
                                    keyboardActions = KeyboardActions(
                                        onDone = {
                                            if (passwordInput.isNotEmpty()) {
                                                onSubmitPassword(passwordInput)
                                            }
                                        }
                                    ),
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .testTag("sig_check_password_input")
                                )
                                Button(
                                    onClick = { onSubmitPassword(passwordInput) },
                                    enabled = passwordInput.isNotEmpty(),
                                    colors = ButtonDefaults.buttonColors(
                                        containerColor = MaterialTheme.colorScheme.primary,
                                        contentColor = MaterialTheme.colorScheme.onPrimary
                                    ),
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .minimumInteractiveComponentSize()
                                        .testTag("sig_check_unlock_verify_btn")
                                ) {
                                    Icon(
                                        imageVector = LucideIcons.ShieldCheck,
                                        contentDescription = null,
                                        modifier = Modifier.size(18.dp)
                                    )
                                    Spacer(modifier = Modifier.size(6.dp))
                                    Text("Unlock & Verify Signature")
                                }
                            }
                        }
                    }

                    validationState.outcome is PdfSignatureValidationOutcome.NoSignatureFound -> {
                        val noSig = validationState.outcome
                        Surface(
                            shape = RoundedCornerShape(14.dp),
                            color = warningAmber.copy(alpha = 0.12f),
                            border = BorderStroke(1.dp, warningAmber.copy(alpha = 0.45f)),
                            modifier = Modifier
                                .fillMaxWidth()
                                .testTag("sig_check_no_signature_card")
                        ) {
                            Column(
                                modifier = Modifier.padding(14.dp),
                                verticalArrangement = Arrangement.spacedBy(8.dp)
                            ) {
                                Row(
                                    verticalAlignment = Alignment.CenterVertically,
                                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                                ) {
                                    Box(
                                        modifier = Modifier
                                            .size(36.dp)
                                            .clip(CircleShape)
                                            .background(warningAmber.copy(alpha = 0.18f)),
                                        contentAlignment = Alignment.Center
                                    ) {
                                        Icon(
                                            imageVector = LucideIcons.Shield,
                                            contentDescription = "No Digital Signature Found",
                                            tint = warningAmber,
                                            modifier = Modifier.size(20.dp)
                                        )
                                    }
                                    Column(modifier = Modifier.weight(1f)) {
                                        Text(
                                            text = "No Digital Signature Found",
                                            style = MaterialTheme.typography.titleSmall,
                                            fontWeight = FontWeight.SemiBold,
                                            color = warningAmber
                                        )
                                        Text(
                                            text = noSig.fileName,
                                            style = MaterialTheme.typography.labelSmall,
                                            color = MaterialTheme.colorScheme.onSurfaceVariant,
                                            maxLines = 1,
                                            overflow = TextOverflow.Ellipsis
                                        )
                                    }
                                }
                                Text(
                                    text = if (noSig.unsignedSignatureFieldCount > 0) {
                                        "This PDF contains ${noSig.unsignedSignatureFieldCount} empty signature field(s), but no cryptographic digital signature has been applied."
                                    } else {
                                        "This PDF does not contain any embedded cryptographic PKCS#7 / AcroForm digital signature."
                                    },
                                    style = MaterialTheme.typography.bodySmall,
                                    color = MaterialTheme.colorScheme.onSurface
                                )
                                Text(
                                    text = "${noSig.pageCount} page(s) · ${FormatUtils.formatBytes(noSig.fileSizeBytes)}" +
                                        if (noSig.isEncrypted) " · Encrypted" else "",
                                    style = MaterialTheme.typography.labelSmall,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant
                                )
                            }
                        }
                    }

                    validationState.outcome is PdfSignatureValidationOutcome.Failed -> {
                        val failed = validationState.outcome
                        Surface(
                            shape = RoundedCornerShape(14.dp),
                            color = invalidRed.copy(alpha = 0.12f),
                            border = BorderStroke(1.dp, invalidRed.copy(alpha = 0.45f)),
                            modifier = Modifier
                                .fillMaxWidth()
                                .testTag("sig_check_failed_card")
                        ) {
                            Column(
                                modifier = Modifier.padding(14.dp),
                                verticalArrangement = Arrangement.spacedBy(6.dp)
                            ) {
                                Row(
                                    verticalAlignment = Alignment.CenterVertically,
                                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                                ) {
                                    Icon(
                                        imageVector = LucideIcons.CircleAlert,
                                        contentDescription = "Verification Failed",
                                        tint = invalidRed,
                                        modifier = Modifier.size(20.dp)
                                    )
                                    Text(
                                        text = "Unable to Verify PDF",
                                        style = MaterialTheme.typography.titleSmall,
                                        fontWeight = FontWeight.SemiBold,
                                        color = invalidRed
                                    )
                                }
                                Text(
                                    text = failed.reason,
                                    style = MaterialTheme.typography.bodySmall,
                                    color = MaterialTheme.colorScheme.onSurface
                                )
                            }
                        }
                    }

                    validationState.outcome is PdfSignatureValidationOutcome.Verified -> {
                        val verified = validationState.outcome
                        Surface(
                            shape = RoundedCornerShape(12.dp),
                            color = MaterialTheme.colorScheme.surfaceContainer,
                            border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(horizontal = 12.dp, vertical = 10.dp),
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.spacedBy(10.dp)
                            ) {
                                Icon(
                                    imageVector = LucideIcons.FileText,
                                    contentDescription = null,
                                    tint = MaterialTheme.colorScheme.primary,
                                    modifier = Modifier.size(20.dp)
                                )
                                Column(modifier = Modifier.weight(1f)) {
                                    Text(
                                        text = verified.fileName,
                                        style = MaterialTheme.typography.titleSmall,
                                        maxLines = 1,
                                        overflow = TextOverflow.Ellipsis
                                    )
                                    Text(
                                        text = "${verified.signatures.size} signature(s) · ${verified.pageCount}p · ${FormatUtils.formatBytes(verified.fileSizeBytes)}",
                                        style = MaterialTheme.typography.labelSmall,
                                        color = MaterialTheme.colorScheme.onSurfaceVariant
                                    )
                                }
                            }
                        }

                        verified.signatures.forEach { sig ->
                            SignatureDetailStatusCard(
                                detail = sig,
                                totalSignatures = verified.signatures.size,
                                validGreen = validGreen,
                                invalidRed = invalidRed,
                                warningAmber = warningAmber
                            )
                        }
                    }
                }
            }
        },
        confirmButton = {
            if (validationState.outcome != null && !validationState.isChecking) {
                TextButton(
                    onClick = onCheckAnother,
                    modifier = Modifier.testTag("sig_check_another_btn")
                ) {
                    Text("Check Another")
                }
            }
        },
        dismissButton = {
            TextButton(
                onClick = onDismiss,
                modifier = Modifier.testTag("sig_check_close_btn")
            ) {
                Text("Close")
            }
        }
    )
}

@Composable
private fun SignatureDetailStatusCard(
    detail: PdfSignatureDetail,
    totalSignatures: Int,
    validGreen: Color,
    invalidRed: Color,
    warningAmber: Color
) {
    val accent = if (detail.isValid) validGreen else invalidRed
    val badgeText = if (detail.isValid) {
        "Signature Valid (Document Unmodified)"
    } else {
        "Invalid / Modified"
    }

    Surface(
        shape = RoundedCornerShape(14.dp),
        color = MaterialTheme.colorScheme.surfaceContainer,
        border = BorderStroke(1.dp, accent.copy(alpha = 0.55f)),
        modifier = Modifier
            .fillMaxWidth()
            .testTag("sig_detail_card_${detail.index}")
    ) {
        Column(
            modifier = Modifier.padding(14.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            // Prominent Status Badge
            Surface(
                shape = RoundedCornerShape(10.dp),
                color = accent.copy(alpha = 0.14f),
                border = BorderStroke(1.dp, accent.copy(alpha = 0.4f)),
                modifier = Modifier.fillMaxWidth()
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 10.dp, vertical = 8.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    Icon(
                        imageVector = if (detail.isValid) LucideIcons.ShieldCheck else LucideIcons.TriangleAlert,
                        contentDescription = badgeText,
                        tint = accent,
                        modifier = Modifier.size(20.dp)
                    )
                    Column(modifier = Modifier.weight(1f)) {
                        Text(
                            text = badgeText,
                            style = MaterialTheme.typography.labelLarge,
                            fontWeight = FontWeight.SemiBold,
                            color = accent
                        )
                        if (!detail.isValid || !detail.coversWholeDocument) {
                            Text(
                                text = detail.statusSummary,
                                style = MaterialTheme.typography.labelSmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                    }
                }
            }

            if (totalSignatures > 1) {
                Text(
                    text = "Signature #${detail.index} · ${detail.fieldName}",
                    style = MaterialTheme.typography.labelSmall,
                    color = MaterialTheme.colorScheme.primary
                )
            }

            // Signed By (Subject CN & Organization)
            val signedByDisplay = buildString {
                append(detail.signerCommonName)
                if (!detail.signerOrganization.isNullOrBlank()) {
                    append("\n")
                    append(detail.signerOrganization)
                }
            }
            SignatureMetadataRow(
                label = "Signed By (Subject CN)",
                value = signedByDisplay
            )

            // Issued By (Issuer CA)
            val issuedByDisplay = buildString {
                append(detail.issuerCommonName)
                if (!detail.issuerOrganization.isNullOrBlank()) {
                    append("\n")
                    append(detail.issuerOrganization)
                }
            }
            SignatureMetadataRow(
                label = "Issued By (Issuer CA)",
                value = issuedByDisplay
            )

            // Signed On (Date & Time)
            SignatureMetadataRow(
                label = "Signed On",
                value = detail.signedAtMillis?.let { formatDateTime(it) } ?: "Not recorded in signature"
            )

            // Certificate Validity (Valid From – Valid To)
            val validityText = if (detail.validFromMillis != null && detail.validToMillis != null) {
                "${formatShortDate(detail.validFromMillis)} – ${formatShortDate(detail.validToMillis)}"
            } else {
                "Unavailable"
            }
            Column(verticalArrangement = Arrangement.spacedBy(3.dp)) {
                SignatureMetadataRow(
                    label = "Certificate Validity",
                    value = validityText
                )
                if (detail.isCertificateExpiredNow) {
                    Text(
                        text = "Note: Signer certificate has since expired (cryptographic hash still checked against document bytes).",
                        style = MaterialTheme.typography.labelSmall,
                        color = warningAmber
                    )
                }
            }

            HorizontalDivider(color = MaterialTheme.colorScheme.outline.copy(alpha = 0.5f))

            // Document Integrity & Technical Summary
            SignatureMetadataRow(
                label = "Document Integrity",
                value = when {
                    detail.cryptographicValid && detail.coversWholeDocument ->
                        "Full file byte range verified — no post-sign changes"
                    detail.cryptographicValid && !detail.isLatestRevision ->
                        "Signed revision intact (countersigned later)"
                    detail.cryptographicValid ->
                        "Post-sign bytes appended after signature"
                    else ->
                        "Cryptographic digest / signature mismatch"
                }
            )

            if (!detail.reason.isNullOrBlank()) {
                SignatureMetadataRow(label = "Reason", value = detail.reason)
            }
            if (!detail.location.isNullOrBlank()) {
                SignatureMetadataRow(label = "Location", value = detail.location)
            }
        }
    }
}

@Composable
private fun SignatureMetadataRow(
    label: String,
    value: String
) {
    Column(
        modifier = Modifier.fillMaxWidth(),
        verticalArrangement = Arrangement.spacedBy(2.dp)
    ) {
        Text(
            text = label,
            style = MaterialTheme.typography.labelSmall,
            color = MaterialTheme.colorScheme.onSurfaceVariant
        )
        Text(
            text = value,
            style = MaterialTheme.typography.bodySmall,
            fontWeight = FontWeight.Medium,
            color = MaterialTheme.colorScheme.onSurface
        )
    }
}

private fun formatDateTime(millis: Long): String {
    val sdf = SimpleDateFormat("dd MMM yyyy, hh:mm a", Locale.getDefault())
    return sdf.format(Date(millis))
}

private fun formatShortDate(millis: Long): String {
    val sdf = SimpleDateFormat("dd MMM yyyy", Locale.getDefault())
    return sdf.format(Date(millis))
}
