package com.docuscan.app.ui.screens

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.scaleIn
import androidx.compose.animation.scaleOut
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.ScreenRotation
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.PathEffect
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import com.docuscan.app.domain.model.CameraScanMode
import com.docuscan.app.ui.theme.ScanButtonGold

@Composable
internal fun CameraViewfinderOverlay(
    activeMode: CameraScanMode,
    bookBothSides: Boolean,
    idCaptureFront: Boolean,
    isLandscape: Boolean,
    isConfigLandscape: Boolean,
    sensorLandscapeAngle: Int,
    controlRotationDegrees: Float,
    modifier: Modifier = Modifier
) {
    Box(
        modifier = modifier.fillMaxSize(),
        contentAlignment = Alignment.Center
    ) {
        when (activeMode) {
            CameraScanMode.DOCS -> {
                Box(
                    modifier = Modifier
                        .fillMaxSize(if (isConfigLandscape) 0.88f else 0.84f)
                        .border(
                            width = 1.5.dp,
                            color = MaterialTheme.colorScheme.primary.copy(alpha = 0.72f),
                            shape = RoundedCornerShape(16.dp)
                        )
                )
            }

            CameraScanMode.BOOK -> {
                BookScannerOverlay(
                    bookBothSides = bookBothSides,
                    isLandscape = isLandscape,
                    isConfigLandscape = isConfigLandscape,
                    sensorLandscapeAngle = sensorLandscapeAngle,
                    controlRotationDegrees = controlRotationDegrees
                )
            }

            CameraScanMode.ID_CARD -> {
                val gold = MaterialTheme.colorScheme.primary
                Column(
                    modifier = Modifier
                        .fillMaxWidth(if (isConfigLandscape) 0.56f else 0.86f)
                        .graphicsLayer { rotationZ = controlRotationDegrees },
                    horizontalAlignment = Alignment.CenterHorizontally,
                    verticalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .aspectRatio(1.586f)
                            .border(
                                width = 2.dp,
                                color = gold,
                                shape = RoundedCornerShape(14.dp)
                            )
                            .testTag("camera_id_overlay_frame")
                    )
                    Surface(
                        shape = RoundedCornerShape(999.dp),
                        color = Color.Black.copy(alpha = 0.7f)
                    ) {
                        Text(
                            text = if (idCaptureFront) {
                                "Align ID Card Front Side inside frame"
                            } else {
                                "Flip & align ID Card Back Side inside frame"
                            },
                            style = MaterialTheme.typography.labelSmall,
                            color = Color.White,
                            modifier = Modifier.padding(horizontal = 12.dp, vertical = 6.dp)
                        )
                    }
                }
            }

            CameraScanMode.TO_TEXT -> {
                Box(
                    modifier = Modifier
                        .fillMaxSize(if (isConfigLandscape) 0.88f else 0.84f)
                        .border(
                            width = 1.5.dp,
                            color = MaterialTheme.colorScheme.primary.copy(alpha = 0.85f),
                            shape = RoundedCornerShape(14.dp)
                        )
                ) {
                    Surface(
                        shape = RoundedCornerShape(999.dp),
                        color = Color.Black.copy(alpha = 0.68f),
                        modifier = Modifier
                            .align(Alignment.BottomCenter)
                            .padding(bottom = 12.dp)
                            .graphicsLayer { rotationZ = controlRotationDegrees }
                    ) {
                        Text(
                            text = "Capture printed or handwritten text for instant OCR",
                            style = MaterialTheme.typography.labelSmall,
                            color = Color.White,
                            modifier = Modifier.padding(horizontal = 12.dp, vertical = 5.dp)
                        )
                    }
                }
            }
        }
    }
}

@Composable
private fun BookScannerOverlay(
    bookBothSides: Boolean,
    isLandscape: Boolean,
    isConfigLandscape: Boolean,
    sensorLandscapeAngle: Int,
    controlRotationDegrees: Float
) {
    val gold = ScanButtonGold

    // Single Page mode works cleanly in normal Portrait orientation without any rotate prompt
    if (!bookBothSides) {
        Box(
            modifier = Modifier
                .fillMaxSize(if (isConfigLandscape) 0.90f else 0.88f)
                .border(
                    width = 1.5.dp,
                    color = gold.copy(alpha = 0.82f),
                    shape = RoundedCornerShape(14.dp)
                )
        ) {
            Surface(
                shape = RoundedCornerShape(999.dp),
                color = Color.Black.copy(alpha = 0.65f),
                modifier = Modifier
                    .align(Alignment.BottomCenter)
                    .padding(bottom = 12.dp)
            ) {
                Text(
                    text = "Align single book page inside frame",
                    style = MaterialTheme.typography.labelSmall,
                    color = Color.White,
                    modifier = Modifier.padding(horizontal = 12.dp, vertical = 5.dp)
                )
            }
        }
        return
    }

    // Book -> Both Sides mode
    Box(
        modifier = Modifier
            .fillMaxSize()
            .padding(
                horizontal = if (isConfigLandscape) 12.dp else 14.dp,
                vertical = if (isConfigLandscape) 10.dp else 16.dp
            ),
        contentAlignment = Alignment.Center
    ) {
        // Outer framing border (expanded full wide landscape when rotated)
        val frameFraction = if (isConfigLandscape) 0.96f else if (isLandscape) 0.94f else 0.90f
        Box(
            modifier = Modifier
                .fillMaxSize(frameFraction)
                .border(
                    width = 1.5.dp,
                    color = gold.copy(alpha = if (isLandscape) 0.88f else 0.42f),
                    shape = RoundedCornerShape(14.dp)
                )
        ) {
            if (isLandscape) {
                if (isConfigLandscape) {
                    // True OS Landscape: crisp vertical dashed yellow center spine dividing Left & Right
                    Canvas(
                        modifier = Modifier
                            .fillMaxHeight()
                            .width(4.dp)
                            .align(Alignment.Center)
                            .testTag("book_spine_guide_line")
                    ) {
                        val centerX = size.width / 2f
                        drawLine(
                            color = gold,
                            start = Offset(centerX, 12f),
                            end = Offset(centerX, size.height - 12f),
                            strokeWidth = 5.5f,
                            pathEffect = PathEffect.dashPathEffect(floatArrayOf(20f, 14f), 0f)
                        )
                    }

                    BookSideBadge(
                        text = "Page 1 (Left)",
                        color = gold,
                        rotationDegrees = 0f,
                        modifier = Modifier
                            .align(Alignment.TopStart)
                            .padding(start = 12.dp, top = 54.dp)
                            .testTag("book_page_left_badge")
                    )
                    BookSideBadge(
                        text = "Page 2 (Right)",
                        color = gold,
                        rotationDegrees = 0f,
                        modifier = Modifier
                            .align(Alignment.TopEnd)
                            .padding(end = 12.dp, top = 54.dp)
                            .testTag("book_page_right_badge")
                    )
                    Surface(
                        shape = RoundedCornerShape(999.dp),
                        color = Color.Black.copy(alpha = 0.72f),
                        modifier = Modifier
                            .align(Alignment.BottomCenter)
                            .padding(bottom = 12.dp)
                            .testTag("book_spine_hint")
                    ) {
                        Text(
                            text = "Align book spine along center dashed line",
                            style = MaterialTheme.typography.labelSmall,
                            color = Color.White,
                            modifier = Modifier.padding(horizontal = 14.dp, vertical = 6.dp)
                        )
                    }
                } else {
                    // Portrait-locked phone physically rotated horizontally:
                    // Center spine line runs horizontally on screen (= vertical to user's horizontal gaze)
                    Canvas(
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(4.dp)
                            .align(Alignment.Center)
                            .testTag("book_spine_guide_line")
                    ) {
                        val centerY = size.height / 2f
                        drawLine(
                            color = gold,
                            start = Offset(12f, centerY),
                            end = Offset(size.width - 12f, centerY),
                            strokeWidth = 5.5f,
                            pathEffect = PathEffect.dashPathEffect(floatArrayOf(20f, 14f), 0f)
                        )
                    }

                    // Position Left/Right labels relative to whichever horizontal side the user tilted toward
                    val leftAlignment = if (sensorLandscapeAngle > 0) Alignment.TopCenter else Alignment.BottomCenter
                    val rightAlignment = if (sensorLandscapeAngle > 0) Alignment.BottomCenter else Alignment.TopCenter

                    BookSideBadge(
                        text = "Page 1 (Left)",
                        color = gold,
                        rotationDegrees = controlRotationDegrees,
                        modifier = Modifier
                            .align(leftAlignment)
                            .padding(vertical = 22.dp)
                            .testTag("book_page_left_badge")
                    )
                    BookSideBadge(
                        text = "Page 2 (Right)",
                        color = gold,
                        rotationDegrees = controlRotationDegrees,
                        modifier = Modifier
                            .align(rightAlignment)
                            .padding(vertical = 22.dp)
                            .testTag("book_page_right_badge")
                    )
                    Surface(
                        shape = RoundedCornerShape(999.dp),
                        color = Color.Black.copy(alpha = 0.72f),
                        modifier = Modifier
                            .align(if (sensorLandscapeAngle > 0) Alignment.CenterStart else Alignment.CenterEnd)
                            .padding(horizontal = 4.dp)
                            .graphicsLayer { rotationZ = controlRotationDegrees }
                            .testTag("book_spine_hint")
                    ) {
                        Text(
                            text = "Align book spine along center dashed line",
                            style = MaterialTheme.typography.labelSmall,
                            color = Color.White,
                            modifier = Modifier.padding(horizontal = 10.dp, vertical = 5.dp)
                        )
                    }
                }
            } else {
                // Subtle center dashed reference line behind the portrait rotation prompt
                Canvas(
                    modifier = Modifier
                        .fillMaxHeight()
                        .width(3.dp)
                        .align(Alignment.Center)
                        .testTag("book_spine_guide_line")
                ) {
                    val centerX = size.width / 2f
                    drawLine(
                        color = gold.copy(alpha = 0.35f),
                        start = Offset(centerX, 16f),
                        end = Offset(centerX, size.height - 16f),
                        strokeWidth = 4f,
                        pathEffect = PathEffect.dashPathEffect(floatArrayOf(16f, 14f), 0f)
                    )
                }
            }
        }

        // Portrait Rotation Guidance Overlay Card (hidden automatically once rotated to Landscape)
        AnimatedVisibility(
            visible = !isLandscape,
            enter = fadeIn(animationSpec = tween(220)) + scaleIn(initialScale = 0.94f, animationSpec = tween(220)),
            exit = fadeOut(animationSpec = tween(180)) + scaleOut(targetScale = 0.94f, animationSpec = tween(180))
        ) {
            RotateToLandscapeGuidanceCard(
                modifier = Modifier.testTag("book_rotate_landscape_prompt")
            )
        }
    }
}

@Composable
private fun BookSideBadge(
    text: String,
    color: Color,
    rotationDegrees: Float,
    modifier: Modifier = Modifier
) {
    Surface(
        shape = RoundedCornerShape(999.dp),
        color = Color.Black.copy(alpha = 0.65f),
        border = BorderStroke(1.dp, color.copy(alpha = 0.55f)),
        modifier = modifier.graphicsLayer { rotationZ = rotationDegrees }
    ) {
        Text(
            text = text,
            style = MaterialTheme.typography.labelSmall,
            fontWeight = FontWeight.SemiBold,
            color = color,
            modifier = Modifier.padding(horizontal = 10.dp, vertical = 4.dp)
        )
    }
}

@Composable
private fun RotateToLandscapeGuidanceCard(
    modifier: Modifier = Modifier
) {
    val infiniteTransition = rememberInfiniteTransition(label = "rotatePhoneTransition")
    val iconTilt by infiniteTransition.animateFloat(
        initialValue = -18f,
        targetValue = 28f,
        animationSpec = infiniteRepeatable(
            animation = tween(durationMillis = 1200, easing = FastOutSlowInEasing),
            repeatMode = RepeatMode.Reverse
        ),
        label = "rotatePhoneTilt"
    )

    Surface(
        shape = RoundedCornerShape(20.dp),
        color = Color(0xD9121212),
        border = BorderStroke(1.dp, ScanButtonGold.copy(alpha = 0.5f)),
        modifier = modifier
            .padding(horizontal = 24.dp)
            .widthIn(max = 320.dp)
    ) {
        Column(
            modifier = Modifier.padding(horizontal = 22.dp, vertical = 22.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            Box(
                modifier = Modifier
                    .size(64.dp)
                    .clip(CircleShape)
                    .background(ScanButtonGold.copy(alpha = 0.16f)),
                contentAlignment = Alignment.Center
            ) {
                Icon(
                    imageVector = Icons.Rounded.ScreenRotation,
                    contentDescription = "Rotate phone to landscape",
                    tint = ScanButtonGold,
                    modifier = Modifier
                        .size(34.dp)
                        .graphicsLayer { rotationZ = iconTilt }
                )
            }
            Text(
                text = "Rotate to Landscape",
                style = MaterialTheme.typography.titleMedium,
                fontWeight = FontWeight.SemiBold,
                color = Color.White,
                textAlign = TextAlign.Center
            )
            Text(
                text = "Rotate your phone horizontally (Landscape) to scan both book pages clearly",
                style = MaterialTheme.typography.bodySmall,
                color = Color.White.copy(alpha = 0.86f),
                textAlign = TextAlign.Center
            )
        }
    }
}
