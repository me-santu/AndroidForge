package com.docuscan.app.ui.screens

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.scaleIn
import androidx.compose.animation.scaleOut
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.ScreenRotation
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.PathEffect
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.StrokeJoin
import androidx.compose.ui.graphics.drawscope.DrawScope
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import com.docuscan.app.domain.model.CameraScanMode
import com.docuscan.app.scanner.DetectedDocumentQuad
import com.docuscan.app.scanner.NormalizedPoint
import com.docuscan.app.ui.theme.ScanButtonGold

@Composable
internal fun CameraViewfinderOverlay(
    activeMode: CameraScanMode,
    bookBothSides: Boolean,
    idCaptureFront: Boolean,
    isLandscape: Boolean,
    isConfigLandscape: Boolean,
    sensorLandscapeAngle: Int,
    controlRotationDegrees: Float,
    detectedQuad: DetectedDocumentQuad? = null,
    autoCaptureEnabled: Boolean = true,
    autoCaptureProgress: Float = 0f,
    modifier: Modifier = Modifier
) {
    val gold = ScanButtonGold
    val showBookRotatePrompt = activeMode == CameraScanMode.BOOK && bookBothSides && !isLandscape

    // Smoothly animate the 4 detected polygon vertices for fluid edge-to-edge snapping
    val fallbackQuad = rememberFallbackSharpQuad(
        activeMode = activeMode,
        isConfigLandscape = isConfigLandscape
    )
    val targetQuad = detectedQuad ?: fallbackQuad
    val animSpec = tween<Float>(durationMillis = 95)

    val tlX by animateFloatAsState(targetQuad.topLeft.x, animSpec, label = "qTlX")
    val tlY by animateFloatAsState(targetQuad.topLeft.y, animSpec, label = "qTlY")
    val trX by animateFloatAsState(targetQuad.topRight.x, animSpec, label = "qTrX")
    val trY by animateFloatAsState(targetQuad.topRight.y, animSpec, label = "qTrY")
    val brX by animateFloatAsState(targetQuad.bottomRight.x, animSpec, label = "qBrX")
    val brY by animateFloatAsState(targetQuad.bottomRight.y, animSpec, label = "qBrY")
    val blX by animateFloatAsState(targetQuad.bottomLeft.x, animSpec, label = "qBlX")
    val blY by animateFloatAsState(targetQuad.bottomLeft.y, animSpec, label = "qBlY")

    val smoothQuad = DetectedDocumentQuad(
        topLeft = NormalizedPoint(tlX, tlY),
        topRight = NormalizedPoint(trX, trY),
        bottomRight = NormalizedPoint(brX, brY),
        bottomLeft = NormalizedPoint(blX, blY),
        sourceAspectRatio = targetQuad.sourceAspectRatio,
        confidence = targetQuad.confidence
    )

    val isLiveDetected = detectedQuad != null

    Box(
        modifier = modifier.fillMaxSize(),
        contentAlignment = Alignment.Center
    ) {
        when (activeMode) {
            CameraScanMode.DOCS -> {
                SharpDocumentQuadCanvas(
                    quad = smoothQuad,
                    isLiveDetected = isLiveDetected,
                    color = gold,
                    modifier = Modifier
                        .fillMaxSize()
                        .testTag("camera_doc_detection_polygon")
                )
                if (!isLiveDetected) {
                    Surface(
                        shape = RoundedCornerShape(999.dp),
                        color = Color.Black.copy(alpha = 0.65f),
                        modifier = Modifier
                            .align(Alignment.BottomCenter)
                            .padding(bottom = 12.dp)
                            .graphicsLayer { rotationZ = controlRotationDegrees }
                    ) {
                        Text(
                            text = if (autoCaptureEnabled) {
                                "Point at document for automatic edge detection"
                            } else {
                                "Align document edges inside frame"
                            },
                            style = MaterialTheme.typography.labelSmall,
                            color = Color.White,
                            modifier = Modifier.padding(horizontal = 12.dp, vertical = 5.dp)
                        )
                    }
                }
            }

            CameraScanMode.BOOK -> {
                BookScannerOverlay(
                    bookBothSides = bookBothSides,
                    isLandscape = isLandscape,
                    isConfigLandscape = isConfigLandscape,
                    sensorLandscapeAngle = sensorLandscapeAngle,
                    controlRotationDegrees = controlRotationDegrees,
                    smoothQuad = smoothQuad,
                    isLiveDetected = isLiveDetected
                )
            }

            CameraScanMode.ID_CARD -> {
                if (isLiveDetected) {
                    SharpDocumentQuadCanvas(
                        quad = smoothQuad,
                        isLiveDetected = true,
                        color = gold,
                        modifier = Modifier
                            .fillMaxSize()
                            .testTag("camera_id_overlay_frame")
                    )
                } else {
                    Column(
                        modifier = Modifier
                            .fillMaxWidth(if (isConfigLandscape) 0.56f else 0.86f)
                            .graphicsLayer { rotationZ = controlRotationDegrees },
                        horizontalAlignment = Alignment.CenterHorizontally,
                        verticalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        Canvas(
                            modifier = Modifier
                                .fillMaxWidth()
                                .aspectRatio(1.586f)
                                .testTag("camera_id_overlay_frame")
                        ) {
                            val pts = listOf(
                                Offset(0f, 0f),
                                Offset(size.width, 0f),
                                Offset(size.width, size.height),
                                Offset(0f, size.height)
                            )
                            drawSharpQuadWithHandles(
                                corners = pts,
                                color = gold,
                                fillAlpha = 0.04f,
                                strokeWidthPx = 2.5.dp.toPx(),
                                handleRadiusPx = 5.5.dp.toPx()
                            )
                        }
                    }
                }
                Surface(
                    shape = RoundedCornerShape(999.dp),
                    color = Color.Black.copy(alpha = 0.7f),
                    modifier = Modifier
                        .align(Alignment.BottomCenter)
                        .padding(bottom = 14.dp)
                        .graphicsLayer { rotationZ = controlRotationDegrees }
                ) {
                    Text(
                        text = if (idCaptureFront) {
                            "Align ID Card Front Side inside frame"
                        } else {
                            "Flip & align ID Card Back Side inside frame"
                        },
                        style = MaterialTheme.typography.labelSmall,
                        color = Color.White,
                        modifier = Modifier.padding(horizontal = 12.dp, vertical = 6.dp)
                    )
                }
            }

            CameraScanMode.TO_TEXT -> {
                SharpDocumentQuadCanvas(
                    quad = smoothQuad,
                    isLiveDetected = isLiveDetected,
                    color = gold,
                    modifier = Modifier
                        .fillMaxSize()
                        .testTag("camera_doc_detection_polygon")
                )
                Surface(
                    shape = RoundedCornerShape(999.dp),
                    color = Color.Black.copy(alpha = 0.68f),
                    modifier = Modifier
                        .align(Alignment.BottomCenter)
                        .padding(bottom = 12.dp)
                        .graphicsLayer { rotationZ = controlRotationDegrees }
                ) {
                    Text(
                        text = "Capture printed or handwritten text for instant OCR",
                        style = MaterialTheme.typography.labelSmall,
                        color = Color.White,
                        modifier = Modifier.padding(horizontal = 12.dp, vertical = 5.dp)
                    )
                }
            }
        }

        // Auto-Capture "Hold steady..." circular progress ring overlay
        AnimatedVisibility(
            visible = autoCaptureEnabled && !showBookRotatePrompt && autoCaptureProgress > 0.04f,
            enter = fadeIn(tween(150)) + scaleIn(initialScale = 0.92f, animationSpec = tween(150)),
            exit = fadeOut(tween(140)) + scaleOut(targetScale = 0.92f, animationSpec = tween(140)),
            modifier = Modifier
                .align(Alignment.Center)
                .graphicsLayer { rotationZ = controlRotationDegrees }
        ) {
            HoldSteadyProgressBadge(
                progress = autoCaptureProgress,
                modifier = Modifier.testTag("camera_auto_capture_progress")
            )
        }
    }
}

private fun rememberFallbackSharpQuad(
    activeMode: CameraScanMode,
    isConfigLandscape: Boolean
): DetectedDocumentQuad {
    return when {
        activeMode == CameraScanMode.BOOK && isConfigLandscape -> DetectedDocumentQuad(
            topLeft = NormalizedPoint(0.05f, 0.14f),
            topRight = NormalizedPoint(0.95f, 0.14f),
            bottomRight = NormalizedPoint(0.95f, 0.88f),
            bottomLeft = NormalizedPoint(0.05f, 0.88f),
            sourceAspectRatio = 1.6f
        )
        isConfigLandscape -> DetectedDocumentQuad(
            topLeft = NormalizedPoint(0.08f, 0.14f),
            topRight = NormalizedPoint(0.92f, 0.14f),
            bottomRight = NormalizedPoint(0.92f, 0.88f),
            bottomLeft = NormalizedPoint(0.08f, 0.88f),
            sourceAspectRatio = 1.6f
        )
        else -> DetectedDocumentQuad(
            topLeft = NormalizedPoint(0.08f, 0.08f),
            topRight = NormalizedPoint(0.92f, 0.08f),
            bottomRight = NormalizedPoint(0.92f, 0.90f),
            bottomLeft = NormalizedPoint(0.08f, 0.90f),
            sourceAspectRatio = 0.75f
        )
    }
}

@Composable
private fun SharpDocumentQuadCanvas(
    quad: DetectedDocumentQuad,
    isLiveDetected: Boolean,
    color: Color,
    modifier: Modifier = Modifier
) {
    Canvas(modifier = modifier) {
        val corners = if (isLiveDetected) {
            quad.mapToFillCenterCanvas(size.width, size.height)
                .map { (x, y) -> Offset(x, y) }
        } else {
            listOf(
                Offset(quad.topLeft.x * size.width, quad.topLeft.y * size.height),
                Offset(quad.topRight.x * size.width, quad.topRight.y * size.height),
                Offset(quad.bottomRight.x * size.width, quad.bottomRight.y * size.height),
                Offset(quad.bottomLeft.x * size.width, quad.bottomLeft.y * size.height)
            )
        }
        if (corners.size == 4) {
            drawSharpQuadWithHandles(
                corners = corners,
                color = if (isLiveDetected) color else color.copy(alpha = 0.85f),
                fillAlpha = if (isLiveDetected) 0.08f else 0.0f,
                strokeWidthPx = if (isLiveDetected) 3.dp.toPx() else 2.dp.toPx(),
                handleRadiusPx = if (isLiveDetected) 6.dp.toPx() else 5.dp.toPx()
            )
        }
    }
}

private fun DrawScope.drawSharpQuadWithHandles(
    corners: List<Offset>,
    color: Color,
    fillAlpha: Float,
    strokeWidthPx: Float,
    handleRadiusPx: Float
) {
    if (corners.size != 4) return
    val path = Path().apply {
        moveTo(corners[0].x, corners[0].y)
        lineTo(corners[1].x, corners[1].y)
        lineTo(corners[2].x, corners[2].y)
        lineTo(corners[3].x, corners[3].y)
        close()
    }

    if (fillAlpha > 0f) {
        drawPath(
            path = path,
            color = color.copy(alpha = fillAlpha)
        )
    }

    // Crisp sharp 90° / miter-joined polygon border
    drawPath(
        path = path,
        color = color,
        style = Stroke(
            width = strokeWidthPx,
            cap = StrokeCap.Square,
            join = StrokeJoin.Miter
        )
    )

    // Crisp corner anchor dots/handles at all 4 vertices
    val innerRadius = (handleRadiusPx * 0.62f).coerceAtLeast(2.dp.toPx())
    for (pt in corners) {
        drawCircle(
            color = Color.White,
            radius = handleRadiusPx,
            center = pt
        )
        drawCircle(
            color = color,
            radius = innerRadius,
            center = pt
        )
    }
}

@Composable
private fun BookScannerOverlay(
    bookBothSides: Boolean,
    isLandscape: Boolean,
    isConfigLandscape: Boolean,
    sensorLandscapeAngle: Int,
    controlRotationDegrees: Float,
    smoothQuad: DetectedDocumentQuad,
    isLiveDetected: Boolean
) {
    val gold = ScanButtonGold

    // Single Page mode works cleanly in normal Portrait orientation without any rotate prompt
    if (!bookBothSides) {
        Box(modifier = Modifier.fillMaxSize()) {
            SharpDocumentQuadCanvas(
                quad = smoothQuad,
                isLiveDetected = isLiveDetected,
                color = gold,
                modifier = Modifier
                    .fillMaxSize()
                    .testTag("camera_doc_detection_polygon")
            )
            Surface(
                shape = RoundedCornerShape(999.dp),
                color = Color.Black.copy(alpha = 0.65f),
                modifier = Modifier
                    .align(Alignment.BottomCenter)
                    .padding(bottom = 12.dp)
            ) {
                Text(
                    text = "Align single book page inside frame",
                    style = MaterialTheme.typography.labelSmall,
                    color = Color.White,
                    modifier = Modifier.padding(horizontal = 12.dp, vertical = 5.dp)
                )
            }
        }
        return
    }

    // Book -> Both Sides mode
    Box(
        modifier = Modifier.fillMaxSize(),
        contentAlignment = Alignment.Center
    ) {
        if (isLandscape) {
            if (isConfigLandscape) {
                // True OS Landscape: single sharp 90° frame (snapping to book edges if detected)
                // + crisp vertical dashed yellow center spine dividing Page 1 (Left) & Page 2 (Right)
                Canvas(
                    modifier = Modifier
                        .fillMaxSize()
                        .testTag("book_spine_guide_line")
                ) {
                    val corners = if (isLiveDetected) {
                        smoothQuad.mapToFillCenterCanvas(size.width, size.height)
                            .map { (x, y) -> Offset(x, y) }
                    } else {
                        listOf(
                            Offset(size.width * 0.04f, size.height * 0.14f),
                            Offset(size.width * 0.96f, size.height * 0.14f),
                            Offset(size.width * 0.96f, size.height * 0.88f),
                            Offset(size.width * 0.04f, size.height * 0.88f)
                        )
                    }
                    if (corners.size == 4) {
                        drawSharpQuadWithHandles(
                            corners = corners,
                            color = gold,
                            fillAlpha = if (isLiveDetected) 0.08f else 0.0f,
                            strokeWidthPx = if (isLiveDetected) 3.dp.toPx() else 2.dp.toPx(),
                            handleRadiusPx = 5.5.dp.toPx()
                        )
                        val topMid = Offset(
                            (corners[0].x + corners[1].x) * 0.5f,
                            (corners[0].y + corners[1].y) * 0.5f
                        )
                        val bottomMid = Offset(
                            (corners[3].x + corners[2].x) * 0.5f,
                            (corners[3].y + corners[2].y) * 0.5f
                        )
                        drawLine(
                            color = gold,
                            start = topMid,
                            end = bottomMid,
                            strokeWidth = 5.5f,
                            pathEffect = PathEffect.dashPathEffect(floatArrayOf(20f, 14f), 0f)
                        )
                    }
                }

                BookSideBadge(
                    text = "Page 1 (Left)",
                    color = gold,
                    rotationDegrees = 0f,
                    modifier = Modifier
                        .align(Alignment.TopStart)
                        .padding(start = 18.dp, top = 56.dp)
                        .testTag("book_page_left_badge")
                )
                BookSideBadge(
                    text = "Page 2 (Right)",
                    color = gold,
                    rotationDegrees = 0f,
                    modifier = Modifier
                        .align(Alignment.TopEnd)
                        .padding(end = 18.dp, top = 56.dp)
                        .testTag("book_page_right_badge")
                )
                Surface(
                    shape = RoundedCornerShape(999.dp),
                    color = Color.Black.copy(alpha = 0.72f),
                    modifier = Modifier
                        .align(Alignment.BottomCenter)
                        .padding(bottom = 10.dp)
                        .testTag("book_spine_hint")
                ) {
                    Text(
                        text = "Align book spine along center dashed line",
                        style = MaterialTheme.typography.labelSmall,
                        color = Color.White,
                        modifier = Modifier.padding(horizontal = 14.dp, vertical = 6.dp)
                    )
                }
            } else {
                // Portrait-locked phone physically rotated horizontally:
                // Sharp 90° quad + center spine running across the physical landscape split
                Canvas(
                    modifier = Modifier
                        .fillMaxSize()
                        .testTag("book_spine_guide_line")
                ) {
                    val corners = if (isLiveDetected) {
                        smoothQuad.mapToFillCenterCanvas(size.width, size.height)
                            .map { (x, y) -> Offset(x, y) }
                    } else {
                        listOf(
                            Offset(size.width * 0.06f, size.height * 0.05f),
                            Offset(size.width * 0.94f, size.height * 0.05f),
                            Offset(size.width * 0.94f, size.height * 0.95f),
                            Offset(size.width * 0.06f, size.height * 0.95f)
                        )
                    }
                    if (corners.size == 4) {
                        drawSharpQuadWithHandles(
                            corners = corners,
                            color = gold,
                            fillAlpha = if (isLiveDetected) 0.08f else 0.0f,
                            strokeWidthPx = if (isLiveDetected) 3.dp.toPx() else 2.dp.toPx(),
                            handleRadiusPx = 5.5.dp.toPx()
                        )
                        val leftMid = Offset(
                            (corners[0].x + corners[3].x) * 0.5f,
                            (corners[0].y + corners[3].y) * 0.5f
                        )
                        val rightMid = Offset(
                            (corners[1].x + corners[2].x) * 0.5f,
                            (corners[1].y + corners[2].y) * 0.5f
                        )
                        drawLine(
                            color = gold,
                            start = leftMid,
                            end = rightMid,
                            strokeWidth = 5.5f,
                            pathEffect = PathEffect.dashPathEffect(floatArrayOf(20f, 14f), 0f)
                        )
                    }
                }

                val leftAlignment = if (sensorLandscapeAngle > 0) Alignment.TopCenter else Alignment.BottomCenter
                val rightAlignment = if (sensorLandscapeAngle > 0) Alignment.BottomCenter else Alignment.TopCenter

                BookSideBadge(
                    text = "Page 1 (Left)",
                    color = gold,
                    rotationDegrees = controlRotationDegrees,
                    modifier = Modifier
                        .align(leftAlignment)
                        .padding(vertical = 26.dp)
                        .testTag("book_page_left_badge")
                )
                BookSideBadge(
                    text = "Page 2 (Right)",
                    color = gold,
                    rotationDegrees = controlRotationDegrees,
                    modifier = Modifier
                        .align(rightAlignment)
                        .padding(vertical = 26.dp)
                        .testTag("book_page_right_badge")
                )
                Surface(
                    shape = RoundedCornerShape(999.dp),
                    color = Color.Black.copy(alpha = 0.72f),
                    modifier = Modifier
                        .align(if (sensorLandscapeAngle > 0) Alignment.CenterStart else Alignment.CenterEnd)
                        .padding(horizontal = 4.dp)
                        .graphicsLayer { rotationZ = controlRotationDegrees }
                        .testTag("book_spine_hint")
                ) {
                    Text(
                        text = "Align book spine along center dashed line",
                        style = MaterialTheme.typography.labelSmall,
                        color = Color.White,
                        modifier = Modifier.padding(horizontal = 10.dp, vertical = 5.dp)
                    )
                }
            }
        } else {
            // Subtle sharp 90° frame & vertical center reference line behind the portrait rotation prompt
            Canvas(
                modifier = Modifier
                    .fillMaxSize()
                    .testTag("book_spine_guide_line")
            ) {
                val left = size.width * 0.08f
                val top = size.height * 0.08f
                val right = size.width * 0.92f
                val bottom = size.height * 0.92f
                drawSharpQuadWithHandles(
                    corners = listOf(
                        Offset(left, top),
                        Offset(right, top),
                        Offset(right, bottom),
                        Offset(left, bottom)
                    ),
                    color = gold.copy(alpha = 0.42f),
                    fillAlpha = 0f,
                    strokeWidthPx = 1.5.dp.toPx(),
                    handleRadiusPx = 4.dp.toPx()
                )
                val centerX = size.width * 0.5f
                drawLine(
                    color = gold.copy(alpha = 0.35f),
                    start = Offset(centerX, top + 12f),
                    end = Offset(centerX, bottom - 12f),
                    strokeWidth = 4f,
                    pathEffect = PathEffect.dashPathEffect(floatArrayOf(16f, 14f), 0f)
                )
            }
        }

        // Portrait Rotation Guidance Overlay Card (hidden automatically once rotated to Landscape)
        AnimatedVisibility(
            visible = !isLandscape,
            enter = fadeIn(animationSpec = tween(220)) + scaleIn(initialScale = 0.94f, animationSpec = tween(220)),
            exit = fadeOut(animationSpec = tween(180)) + scaleOut(targetScale = 0.94f, animationSpec = tween(180))
        ) {
            RotateToLandscapeGuidanceCard(
                modifier = Modifier.testTag("book_rotate_landscape_prompt")
            )
        }
    }
}

@Composable
private fun HoldSteadyProgressBadge(
    progress: Float,
    modifier: Modifier = Modifier
) {
    val smoothProgress by animateFloatAsState(
        targetValue = progress.coerceIn(0f, 1f),
        animationSpec = tween(durationMillis = 80),
        label = "holdSteadyProgress"
    )
    Surface(
        shape = RoundedCornerShape(999.dp),
        color = Color(0xCC121212),
        border = BorderStroke(1.dp, ScanButtonGold.copy(alpha = 0.65f)),
        modifier = modifier
    ) {
        Row(
            modifier = Modifier.padding(horizontal = 16.dp, vertical = 10.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            CircularProgressIndicator(
                progress = { smoothProgress },
                color = ScanButtonGold,
                trackColor = Color.White.copy(alpha = 0.22f),
                strokeWidth = 3.dp,
                modifier = Modifier.size(22.dp)
            )
            Text(
                text = "Hold steady...",
                style = MaterialTheme.typography.labelLarge,
                fontWeight = FontWeight.SemiBold,
                color = Color.White
            )
        }
    }
}

@Composable
private fun BookSideBadge(
    text: String,
    color: Color,
    rotationDegrees: Float,
    modifier: Modifier = Modifier
) {
    Surface(
        shape = RoundedCornerShape(999.dp),
        color = Color.Black.copy(alpha = 0.65f),
        border = BorderStroke(1.dp, color.copy(alpha = 0.55f)),
        modifier = modifier.graphicsLayer { rotationZ = rotationDegrees }
    ) {
        Text(
            text = text,
            style = MaterialTheme.typography.labelSmall,
            fontWeight = FontWeight.SemiBold,
            color = color,
            modifier = Modifier.padding(horizontal = 10.dp, vertical = 4.dp)
        )
    }
}

@Composable
private fun RotateToLandscapeGuidanceCard(
    modifier: Modifier = Modifier
) {
    val infiniteTransition = rememberInfiniteTransition(label = "rotatePhoneTransition")
    val iconTilt by infiniteTransition.animateFloat(
        initialValue = -18f,
        targetValue = 28f,
        animationSpec = infiniteRepeatable(
            animation = tween(durationMillis = 1200, easing = FastOutSlowInEasing),
            repeatMode = RepeatMode.Reverse
        ),
        label = "rotatePhoneTilt"
    )

    Surface(
        shape = RoundedCornerShape(20.dp),
        color = Color(0xD9121212),
        border = BorderStroke(1.dp, ScanButtonGold.copy(alpha = 0.5f)),
        modifier = modifier
            .padding(horizontal = 24.dp)
            .widthIn(max = 320.dp)
    ) {
        Column(
            modifier = Modifier.padding(horizontal = 22.dp, vertical = 22.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            Box(
                modifier = Modifier
                    .size(64.dp)
                    .clip(CircleShape)
                    .background(ScanButtonGold.copy(alpha = 0.16f)),
                contentAlignment = Alignment.Center
            ) {
                Icon(
                    imageVector = Icons.Rounded.ScreenRotation,
                    contentDescription = "Rotate phone to landscape",
                    tint = ScanButtonGold,
                    modifier = Modifier
                        .size(34.dp)
                        .graphicsLayer { rotationZ = iconTilt }
                )
            }
            Text(
                text = "Rotate to Landscape",
                style = MaterialTheme.typography.titleMedium,
                fontWeight = FontWeight.SemiBold,
                color = Color.White,
                textAlign = TextAlign.Center
            )
            Text(
                text = "Rotate your phone horizontally (Landscape) to scan both book pages clearly",
                style = MaterialTheme.typography.bodySmall,
                color = Color.White.copy(alpha = 0.86f),
                textAlign = TextAlign.Center
            )
        }
    }
}
