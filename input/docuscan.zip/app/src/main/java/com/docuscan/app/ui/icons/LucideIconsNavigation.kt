package com.docuscan.app.ui.icons

import androidx.compose.ui.graphics.vector.ImageVector

internal object LucideNavIcons {

    val Home: ImageVector by lazy {
        lucideIcon("Home") {
            strokePath {
                moveTo(3f, 10f)
                lineTo(12f, 3f)
                lineTo(21f, 10f)
                verticalLineTo(20f)
                arcTo(2f, 2f, 0f, false, true, 19f, 22f)
                horizontalLineTo(5f)
                arcTo(2f, 2f, 0f, false, true, 3f, 20f)
                close()
            }
            strokePath {
                moveTo(9f, 22f)
                verticalLineTo(13f)
                arcTo(1f, 1f, 0f, false, true, 10f, 12f)
                horizontalLineTo(14f)
                arcTo(1f, 1f, 0f, false, true, 15f, 13f)
                verticalLineTo(22f)
            }
        }
    }

    val Settings: ImageVector by lazy {
        lucideIcon("Settings") {
            circle(12f, 12f, 3f)
            strokePath {
                moveTo(19.4f, 15f)
                arcTo(1.65f, 1.65f, 0f, false, false, 19.73f, 16.82f)
                lineTo(19.79f, 16.88f)
                arcTo(2f, 2f, 0f, false, true, 16.96f, 19.71f)
                lineTo(16.9f, 19.65f)
                arcTo(1.65f, 1.65f, 0f, false, false, 15.08f, 19.32f)
                arcTo(1.65f, 1.65f, 0f, false, false, 14.08f, 20.83f)
                verticalLineTo(21f)
                arcTo(2f, 2f, 0f, false, true, 10.08f, 21f)
                verticalLineTo(20.91f)
                arcTo(1.65f, 1.65f, 0f, false, false, 9f, 19.4f)
                arcTo(1.65f, 1.65f, 0f, false, false, 7.18f, 19.73f)
                lineTo(7.12f, 19.79f)
                arcTo(2f, 2f, 0f, false, true, 4.29f, 16.96f)
                lineTo(4.35f, 16.9f)
                arcTo(1.65f, 1.65f, 0f, false, false, 4.68f, 15.08f)
                arcTo(1.65f, 1.65f, 0f, false, false, 3.17f, 14.08f)
                horizontalLineTo(3f)
                arcTo(2f, 2f, 0f, false, true, 3f, 10.08f)
                horizontalLineTo(3.09f)
                arcTo(1.65f, 1.65f, 0f, false, false, 4.6f, 9f)
                arcTo(1.65f, 1.65f, 0f, false, false, 4.27f, 7.18f)
                lineTo(4.21f, 7.12f)
                arcTo(2f, 2f, 0f, false, true, 7.04f, 4.29f)
                lineTo(7.1f, 4.35f)
                arcTo(1.65f, 1.65f, 0f, false, false, 8.92f, 4.68f)
                horizontalLineTo(9f)
                arcTo(1.65f, 1.65f, 0f, false, false, 10f, 3.17f)
                verticalLineTo(3f)
                arcTo(2f, 2f, 0f, false, true, 14f, 3f)
                verticalLineTo(3.09f)
                arcTo(1.65f, 1.65f, 0f, false, false, 15f, 4.6f)
                arcTo(1.65f, 1.65f, 0f, false, false, 16.82f, 4.27f)
                lineTo(16.88f, 4.21f)
                arcTo(2f, 2f, 0f, false, true, 19.71f, 7.04f)
                lineTo(19.65f, 7.1f)
                arcTo(1.65f, 1.65f, 0f, false, false, 19.32f, 8.92f)
                verticalLineTo(9f)
                arcTo(1.65f, 1.65f, 0f, false, false, 20.83f, 10f)
                horizontalLineTo(21f)
                arcTo(2f, 2f, 0f, false, true, 21f, 14f)
                horizontalLineTo(20.91f)
                arcTo(1.65f, 1.65f, 0f, false, false, 19.4f, 15f)
                close()
            }
        }
    }

    val Wrench: ImageVector by lazy {
        lucideIcon("Wrench") {
            strokePath {
                moveTo(14.7f, 6.3f)
                arcTo(1f, 1f, 0f, false, false, 14.7f, 7.7f)
                lineTo(16.3f, 9.3f)
                arcTo(1f, 1f, 0f, false, false, 17.7f, 9.3f)
                lineTo(21.47f, 5.53f)
                arcTo(6f, 6f, 0f, false, true, 13.53f, 13.47f)
                lineTo(6.62f, 20.38f)
                arcTo(2.12f, 2.12f, 0f, false, true, 3.62f, 17.38f)
                lineTo(10.53f, 10.47f)
                arcTo(6f, 6f, 0f, false, true, 18.47f, 2.53f)
                close()
            }
        }
    }

    val Search: ImageVector by lazy {
        lucideIcon("Search") {
            circle(11f, 11f, 8f)
            line(21f, 21f, 16.65f, 16.65f)
        }
    }

    val X: ImageVector by lazy {
        lucideIcon("X") {
            line(18f, 6f, 6f, 18f)
            line(6f, 6f, 18f, 18f)
        }
    }

    val Check: ImageVector by lazy {
        lucideIcon("Check") {
            strokePath {
                moveTo(20f, 6f)
                lineTo(9f, 17f)
                lineTo(4f, 12f)
            }
        }
    }

    val CircleCheck: ImageVector by lazy {
        lucideIcon("CircleCheck") {
            circle(12f, 12f, 10f)
            strokePath {
                moveTo(9f, 12f)
                lineTo(11f, 14f)
                lineTo(15f, 10f)
            }
        }
    }

    val CheckSquare: ImageVector by lazy {
        lucideIcon("CheckSquare") {
            roundRect(3f, 3f, 18f, 18f, 2f)
            strokePath {
                moveTo(9f, 12f)
                lineTo(11f, 14f)
                lineTo(15f, 10f)
            }
        }
    }

    val ArrowLeft: ImageVector by lazy {
        lucideIcon("ArrowLeft", autoMirror = true) {
            strokePath {
                moveTo(12f, 19f)
                lineTo(5f, 12f)
                lineTo(12f, 5f)
            }
            line(19f, 12f, 5f, 12f)
        }
    }

    val ArrowRight: ImageVector by lazy {
        lucideIcon("ArrowRight", autoMirror = true) {
            line(5f, 12f, 19f, 12f)
            strokePath {
                moveTo(12f, 5f)
                lineTo(19f, 12f)
                lineTo(12f, 19f)
            }
        }
    }

    val ArrowUp: ImageVector by lazy {
        lucideIcon("ArrowUp") {
            strokePath {
                moveTo(5f, 12f)
                lineTo(12f, 5f)
                lineTo(19f, 12f)
            }
            line(12f, 19f, 12f, 5f)
        }
    }

    val ArrowDown: ImageVector by lazy {
        lucideIcon("ArrowDown") {
            line(12f, 5f, 12f, 19f)
            strokePath {
                moveTo(19f, 12f)
                lineTo(12f, 19f)
                lineTo(5f, 12f)
            }
        }
    }

    val ChevronLeft: ImageVector by lazy {
        lucideIcon("ChevronLeft", autoMirror = true) {
            strokePath {
                moveTo(15f, 18f)
                lineTo(9f, 12f)
                lineTo(15f, 6f)
            }
        }
    }

    val ChevronRight: ImageVector by lazy {
        lucideIcon("ChevronRight", autoMirror = true) {
            strokePath {
                moveTo(9f, 18f)
                lineTo(15f, 12f)
                lineTo(9f, 6f)
            }
        }
    }

    val Delete: ImageVector by lazy {
        lucideIcon("Delete", autoMirror = true) {
            strokePath {
                moveTo(10f, 5f)
                horizontalLineTo(20f)
                arcTo(2f, 2f, 0f, false, true, 22f, 7f)
                verticalLineTo(17f)
                arcTo(2f, 2f, 0f, false, true, 20f, 19f)
                horizontalLineTo(10f)
                arcTo(2f, 2f, 0f, false, true, 8.6f, 18.4f)
                lineTo(2.7f, 12.7f)
                arcTo(1f, 1f, 0f, false, true, 2.7f, 11.3f)
                lineTo(8.6f, 5.6f)
                arcTo(2f, 2f, 0f, false, true, 10f, 5f)
                close()
            }
            line(12f, 9f, 18f, 15f)
            line(18f, 9f, 12f, 15f)
        }
    }

    val MoreVertical: ImageVector by lazy {
        lucideIcon("MoreVertical") {
            circle(12f, 12f, 1f)
            circle(12f, 5f, 1f)
            circle(12f, 19f, 1f)
        }
    }

    val Share2: ImageVector by lazy {
        lucideIcon("Share2") {
            circle(18f, 5f, 3f)
            circle(6f, 12f, 3f)
            circle(18f, 19f, 3f)
            line(8.59f, 13.51f, 15.42f, 17.49f)
            line(15.41f, 6.51f, 8.59f, 10.49f)
        }
    }

    val Download: ImageVector by lazy {
        lucideIcon("Download") {
            strokePath {
                moveTo(21f, 15f)
                verticalLineTo(19f)
                arcTo(2f, 2f, 0f, false, true, 19f, 21f)
                horizontalLineTo(5f)
                arcTo(2f, 2f, 0f, false, true, 3f, 19f)
                verticalLineTo(15f)
            }
            strokePath {
                moveTo(7f, 10f)
                lineTo(12f, 15f)
                lineTo(17f, 10f)
            }
            line(12f, 15f, 12f, 3f)
        }
    }

    val Save: ImageVector by lazy {
        lucideIcon("Save") {
            strokePath {
                moveTo(15.2f, 3f)
                arcTo(2f, 2f, 0f, false, true, 16.6f, 3.6f)
                lineTo(20.4f, 7.4f)
                arcTo(2f, 2f, 0f, false, true, 21f, 8.8f)
                verticalLineTo(19f)
                arcTo(2f, 2f, 0f, false, true, 19f, 21f)
                horizontalLineTo(5f)
                arcTo(2f, 2f, 0f, false, true, 3f, 19f)
                verticalLineTo(5f)
                arcTo(2f, 2f, 0f, false, true, 5f, 3f)
                close()
            }
            strokePath {
                moveTo(17f, 21f)
                verticalLineTo(13f)
                horizontalLineTo(7f)
                verticalLineTo(21f)
            }
            strokePath {
                moveTo(7f, 3f)
                verticalLineTo(8f)
                horizontalLineTo(15f)
            }
        }
    }

    val Trash2: ImageVector by lazy {
        lucideIcon("Trash2") {
            line(3f, 6f, 21f, 6f)
            strokePath {
                moveTo(19f, 6f)
                verticalLineTo(20f)
                arcTo(2f, 2f, 0f, false, true, 17f, 22f)
                horizontalLineTo(7f)
                arcTo(2f, 2f, 0f, false, true, 5f, 20f)
                verticalLineTo(6f)
            }
            strokePath {
                moveTo(8f, 6f)
                verticalLineTo(4f)
                arcTo(2f, 2f, 0f, false, true, 10f, 2f)
                horizontalLineTo(14f)
                arcTo(2f, 2f, 0f, false, true, 16f, 4f)
                verticalLineTo(6f)
            }
            line(10f, 11f, 10f, 17f)
            line(14f, 11f, 14f, 17f)
        }
    }

    val RotateCw: ImageVector by lazy {
        lucideIcon("RotateCw") {
            strokePath {
                moveTo(21f, 12f)
                arcTo(9f, 9f, 0f, true, true, 18.36f, 5.64f)
                lineTo(21f, 8f)
            }
            strokePath {
                moveTo(21f, 3f)
                verticalLineTo(8f)
                horizontalLineTo(16f)
            }
        }
    }

    val RotateCcw: ImageVector by lazy {
        lucideIcon("RotateCcw") {
            strokePath {
                moveTo(3f, 12f)
                arcTo(9f, 9f, 0f, true, false, 5.64f, 5.64f)
                lineTo(3f, 8f)
            }
            strokePath {
                moveTo(3f, 3f)
                verticalLineTo(8f)
                horizontalLineTo(8f)
            }
        }
    }

    val RefreshCw: ImageVector by lazy {
        lucideIcon("RefreshCw") {
            strokePath {
                moveTo(3f, 12f)
                arcTo(9f, 9f, 0f, false, true, 18.36f, 5.64f)
                lineTo(21f, 8f)
            }
            strokePath {
                moveTo(21f, 3f)
                verticalLineTo(8f)
                horizontalLineTo(16f)
            }
            strokePath {
                moveTo(21f, 12f)
                arcTo(9f, 9f, 0f, false, true, 5.64f, 18.36f)
                lineTo(3f, 16f)
            }
            strokePath {
                moveTo(3f, 21f)
                verticalLineTo(16f)
                horizontalLineTo(8f)
            }
        }
    }

    val Undo2: ImageVector by lazy {
        lucideIcon("Undo2", autoMirror = true) {
            strokePath {
                moveTo(9f, 14f)
                lineTo(4f, 9f)
                lineTo(9f, 4f)
            }
            strokePath {
                moveTo(20f, 20f)
                verticalLineTo(13.5f)
                arcTo(4.5f, 4.5f, 0f, false, false, 15.5f, 9f)
                horizontalLineTo(4f)
            }
        }
    }

    val Pencil: ImageVector by lazy {
        lucideIcon("Pencil") {
            strokePath {
                moveTo(17f, 3f)
                arcTo(2.83f, 2.83f, 0f, false, true, 21f, 7f)
                lineTo(7.5f, 20.5f)
                lineTo(2f, 22f)
                lineTo(3.5f, 16.5f)
                close()
            }
            line(15f, 5f, 19f, 9f)
        }
    }

    val Copy: ImageVector by lazy {
        lucideIcon("Copy") {
            roundRect(8f, 8f, 14f, 14f, 2f)
            strokePath {
                moveTo(4f, 16f)
                curveTo(2.9f, 16f, 2f, 15.1f, 2f, 14f)
                verticalLineTo(4f)
                curveTo(2f, 2.9f, 2.9f, 2f, 4f, 2f)
                horizontalLineTo(14f)
                curveTo(15.1f, 2f, 16f, 2.9f, 16f, 4f)
            }
        }
    }

    val CopyPlus: ImageVector by lazy {
        lucideIcon("CopyPlus") {
            roundRect(8f, 8f, 14f, 14f, 2f)
            strokePath {
                moveTo(4f, 16f)
                curveTo(2.9f, 16f, 2f, 15.1f, 2f, 14f)
                verticalLineTo(4f)
                curveTo(2f, 2.9f, 2.9f, 2f, 4f, 2f)
                horizontalLineTo(14f)
                curveTo(15.1f, 2f, 16f, 2.9f, 16f, 4f)
            }
            line(15f, 12f, 15f, 18f)
            line(12f, 15f, 18f, 15f)
        }
    }

    val ExternalLink: ImageVector by lazy {
        lucideIcon("ExternalLink") {
            line(15f, 3f, 21f, 3f)
            line(21f, 3f, 21f, 9f)
            line(10f, 14f, 21f, 3f)
            strokePath {
                moveTo(18f, 13f)
                verticalLineTo(19f)
                arcTo(2f, 2f, 0f, false, true, 16f, 21f)
                horizontalLineTo(5f)
                arcTo(2f, 2f, 0f, false, true, 3f, 19f)
                verticalLineTo(8f)
                arcTo(2f, 2f, 0f, false, true, 5f, 6f)
                horizontalLineTo(11f)
            }
        }
    }

    val ArrowUpDown: ImageVector by lazy {
        lucideIcon("ArrowUpDown") {
            strokePath {
                moveTo(21f, 16f)
                lineTo(17f, 20f)
                lineTo(13f, 16f)
            }
            line(17f, 20f, 17f, 4f)
            strokePath {
                moveTo(3f, 8f)
                lineTo(7f, 4f)
                lineTo(11f, 8f)
            }
            line(7f, 4f, 7f, 20f)
        }
    }

    val LayoutGrid: ImageVector by lazy {
        lucideIcon("LayoutGrid") {
            roundRect(3f, 3f, 7f, 7f, 1.5f)
            roundRect(14f, 3f, 7f, 7f, 1.5f)
            roundRect(14f, 14f, 7f, 7f, 1.5f)
            roundRect(3f, 14f, 7f, 7f, 1.5f)
        }
    }

    val List: ImageVector by lazy {
        lucideIcon("List") {
            line(8f, 6f, 21f, 6f)
            line(8f, 12f, 21f, 12f)
            line(8f, 18f, 21f, 18f)
            dot(3.5f, 6f)
            dot(3.5f, 12f)
            dot(3.5f, 18f)
        }
    }

    val ListOrdered: ImageVector by lazy {
        lucideIcon("ListOrdered") {
            line(10f, 6f, 21f, 6f)
            line(10f, 12f, 21f, 12f)
            line(10f, 18f, 21f, 18f)
            strokePath {
                moveTo(4f, 6f)
                horizontalLineTo(5f)
                verticalLineTo(10f)
            }
            line(4f, 10f, 6f, 10f)
            strokePath {
                moveTo(6f, 18f)
                horizontalLineTo(4f)
                curveTo(4f, 17f, 6f, 16f, 6f, 15f)
                curveTo(6f, 14.3f, 5.4f, 14f, 4.8f, 14f)
                curveTo(4.3f, 14f, 4f, 14.3f, 4f, 14.7f)
            }
        }
    }

    val ZoomIn: ImageVector by lazy {
        lucideIcon("ZoomIn") {
            circle(11f, 11f, 8f)
            line(21f, 21f, 16.65f, 16.65f)
            line(11f, 8f, 11f, 14f)
            line(8f, 11f, 14f, 11f)
        }
    }

    val ZoomOut: ImageVector by lazy {
        lucideIcon("ZoomOut") {
            circle(11f, 11f, 8f)
            line(21f, 21f, 16.65f, 16.65f)
            line(8f, 11f, 14f, 11f)
        }
    }
}
