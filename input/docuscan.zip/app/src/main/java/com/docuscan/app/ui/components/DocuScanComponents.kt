package com.docuscan.app.ui.components

import androidx.compose.animation.animateColorAsState
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.combinedClickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ColumnScope
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.WindowInsetsSides
import androidx.compose.foundation.layout.displayCutout
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.only
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBars
import androidx.compose.foundation.layout.union
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.windowInsetsPadding
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Switch
import androidx.compose.material3.SwitchDefaults
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.material3.minimumInteractiveComponentSize
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Rect
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.StrokeJoin
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.luminance
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import coil.compose.AsyncImage
import com.docuscan.app.domain.model.DocumentFileType
import com.docuscan.app.domain.model.DocumentItem
import com.docuscan.app.domain.model.StorageSummary
import com.docuscan.app.navigation.BottomNavDestination
import com.docuscan.app.ui.icons.LucideIcons
import com.docuscan.app.ui.theme.NavBarBorderDark
import com.docuscan.app.ui.theme.NavBarBorderLight
import com.docuscan.app.ui.theme.NavBarDarkSurface
import com.docuscan.app.ui.theme.NavBarInactiveGrey
import com.docuscan.app.ui.theme.NavBarLightSurface
import com.docuscan.app.ui.theme.NavBarScanIconDark
import com.docuscan.app.ui.theme.ScanButtonGold
import com.docuscan.app.ui.theme.SwitchCheckedBorder
import com.docuscan.app.ui.theme.SwitchCheckedThumb
import com.docuscan.app.ui.theme.SwitchCheckedTrack
import com.docuscan.app.ui.theme.SwitchUncheckedBorderDark
import com.docuscan.app.ui.theme.SwitchUncheckedBorderLight
import com.docuscan.app.ui.theme.SwitchUncheckedThumbDark
import com.docuscan.app.ui.theme.SwitchUncheckedThumbLight
import com.docuscan.app.ui.theme.SwitchUncheckedTrackDark
import com.docuscan.app.ui.theme.SwitchUncheckedTrackLight
import com.docuscan.app.util.FormatUtils
import com.docuscan.app.util.LocalAppStrings
import java.io.File
import kotlin.math.asin
import kotlin.math.sqrt

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun DocuScanTopBar(
    title: String,
    subtitle: String? = null,
    onBack: (() -> Unit)? = null,
    actions: @Composable () -> Unit = {}
) {
    TopAppBar(
        title = {
            Column {
                Text(
                    text = title,
                    style = MaterialTheme.typography.titleLarge,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis
                )
                if (!subtitle.isNullOrBlank()) {
                    Text(
                        text = subtitle,
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis
                    )
                }
            }
        },
        navigationIcon = {
            if (onBack != null) {
                IconButton(
                    onClick = onBack,
                    modifier = Modifier
                        .minimumInteractiveComponentSize()
                        .testTag("top_bar_back")
                ) {
                    Icon(
                        imageVector = LucideIcons.ArrowLeft,
                        contentDescription = "Navigate back"
                    )
                }
            }
        },
        actions = { actions() },
        colors = TopAppBarDefaults.topAppBarColors(
            containerColor = MaterialTheme.colorScheme.background,
            titleContentColor = MaterialTheme.colorScheme.onBackground,
            navigationIconContentColor = MaterialTheme.colorScheme.onBackground,
            actionIconContentColor = MaterialTheme.colorScheme.onBackground
        ),
        windowInsets = WindowInsets.statusBars.union(
            WindowInsets.displayCutout.only(WindowInsetsSides.Top + WindowInsetsSides.Horizontal)
        )
    )
}

@OptIn(ExperimentalFoundationApi::class)
@Composable
fun DocuScanCard(
    modifier: Modifier = Modifier,
    onClick: (() -> Unit)? = null,
    onLongClick: (() -> Unit)? = null,
    highlighted: Boolean = false,
    content: @Composable ColumnScope.() -> Unit
) {
    val borderColor = if (highlighted) {
        MaterialTheme.colorScheme.primary.copy(alpha = 0.75f)
    } else {
        MaterialTheme.colorScheme.outline
    }
    val containerColor = if (highlighted) {
        MaterialTheme.colorScheme.surfaceContainerHigh
    } else {
        MaterialTheme.colorScheme.surfaceContainer
    }

    Surface(
        modifier = modifier
            .clip(MaterialTheme.shapes.medium)
            .then(
                when {
                    onClick != null && onLongClick != null -> Modifier.combinedClickable(
                        onClick = onClick,
                        onLongClick = onLongClick
                    )
                    onClick != null -> Modifier.clickable(onClick = onClick)
                    else -> Modifier
                }
            ),
        shape = MaterialTheme.shapes.medium,
        color = containerColor,
        border = BorderStroke(1.dp, borderColor),
        tonalElevation = 1.dp
    ) {
        Column(
            modifier = Modifier.padding(16.dp),
            content = content
        )
    }
}

@Composable
fun QuickActionCard(
    title: String,
    subtitle: String,
    icon: ImageVector,
    testTag: String,
    isPrimaryAccent: Boolean = false,
    onClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    val bgBrush = if (isPrimaryAccent) {
        Brush.linearGradient(
            colors = listOf(
                MaterialTheme.colorScheme.primary,
                MaterialTheme.colorScheme.secondary
            )
        )
    } else {
        Brush.linearGradient(
            colors = listOf(
                MaterialTheme.colorScheme.surfaceContainer,
                MaterialTheme.colorScheme.surfaceContainerHigh
            )
        )
    }
    val contentColor = if (isPrimaryAccent) {
        MaterialTheme.colorScheme.onPrimary
    } else {
        MaterialTheme.colorScheme.onSurface
    }
    val subColor = if (isPrimaryAccent) {
        MaterialTheme.colorScheme.onPrimary.copy(alpha = 0.78f)
    } else {
        MaterialTheme.colorScheme.onSurfaceVariant
    }

    Box(
        modifier = modifier
            .clip(MaterialTheme.shapes.medium)
            .background(bgBrush)
            .border(
                width = 1.dp,
                color = if (isPrimaryAccent) Color.Transparent else MaterialTheme.colorScheme.outline,
                shape = MaterialTheme.shapes.medium
            )
            .clickable(onClick = onClick)
            .minimumInteractiveComponentSize()
            .padding(16.dp)
            .testTag(testTag)
    ) {
        Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
            Box(
                modifier = Modifier
                    .size(40.dp)
                    .clip(RoundedCornerShape(12.dp))
                    .background(
                        if (isPrimaryAccent) {
                            MaterialTheme.colorScheme.onPrimary.copy(alpha = 0.14f)
                        } else {
                            MaterialTheme.colorScheme.primaryContainer
                        }
                    ),
                contentAlignment = Alignment.Center
            ) {
                Icon(
                    imageVector = icon,
                    contentDescription = title,
                    tint = if (isPrimaryAccent) contentColor else MaterialTheme.colorScheme.primary,
                    modifier = Modifier.size(22.dp)
                )
            }
            Column(verticalArrangement = Arrangement.spacedBy(2.dp)) {
                Text(
                    text = title,
                    style = MaterialTheme.typography.titleSmall,
                    color = contentColor,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis
                )
                Text(
                    text = subtitle,
                    style = MaterialTheme.typography.bodySmall,
                    color = subColor,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis
                )
            }
        }
    }
}

@Composable
fun DocumentRowCard(
    document: DocumentItem,
    onClick: () -> Unit,
    onMoreClick: (() -> Unit)? = null,
    onLongClick: (() -> Unit)? = null,
    onToggleFavorite: (() -> Unit)? = null,
    selected: Boolean = false,
    selectionMode: Boolean = false,
    modifier: Modifier = Modifier
) {
    DocuScanCard(
        modifier = modifier
            .fillMaxWidth()
            .testTag("doc_card_${document.id}"),
        onClick = onClick,
        onLongClick = onLongClick,
        highlighted = selected
    ) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            Box(
                modifier = Modifier
                    .size(52.dp)
                    .clip(RoundedCornerShape(12.dp))
                    .background(MaterialTheme.colorScheme.surface)
                    .border(
                        1.dp,
                        if (selected) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.outline,
                        RoundedCornerShape(12.dp)
                    ),
                contentAlignment = Alignment.Center
            ) {
                val thumbFile = document.thumbnailPath?.let { File(it) }
                if (thumbFile != null && thumbFile.exists()) {
                    AsyncImage(
                        model = thumbFile,
                        contentDescription = document.title,
                        contentScale = ContentScale.Crop,
                        modifier = Modifier.matchParentSize()
                    )
                } else {
                    Icon(
                        imageVector = when (document.fileType) {
                            DocumentFileType.PDF -> LucideIcons.FileText
                            DocumentFileType.IMAGE -> LucideIcons.Image
                            DocumentFileType.ID_CARD -> LucideIcons.IdCard
                        },
                        contentDescription = document.fileType.badge,
                        tint = MaterialTheme.colorScheme.primary,
                        modifier = Modifier.size(26.dp)
                    )
                }
                if (selectionMode) {
                    Box(
                        modifier = Modifier
                            .matchParentSize()
                            .background(
                                if (selected) MaterialTheme.colorScheme.primary.copy(alpha = 0.35f)
                                else Color.Black.copy(alpha = 0.25f)
                            ),
                        contentAlignment = Alignment.Center
                    ) {
                        if (selected) {
                            Icon(
                                imageVector = LucideIcons.CircleCheck,
                                contentDescription = "Selected",
                                tint = MaterialTheme.colorScheme.primary,
                                modifier = Modifier.size(22.dp)
                            )
                        }
                    }
                }
            }

            Column(
                modifier = Modifier.weight(1f),
                verticalArrangement = Arrangement.spacedBy(4.dp)
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    if (document.isPinned) {
                        Icon(
                            imageVector = LucideIcons.Pin,
                            contentDescription = "Pinned",
                            tint = MaterialTheme.colorScheme.primary,
                            modifier = Modifier.size(14.dp)
                        )
                    }
                    if (document.isPasswordProtected) {
                        Icon(
                            imageVector = LucideIcons.Lock,
                            contentDescription = "Password Protected",
                            tint = MaterialTheme.colorScheme.primary,
                            modifier = Modifier.size(14.dp)
                        )
                    }
                    Text(
                        text = document.title,
                        style = MaterialTheme.typography.titleMedium,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis
                    )
                }
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    PhaseStatusChip(
                        text = "${document.fileType.badge} · ${document.pageCount}p",
                        highlighted = true
                    )
                    Text(
                        text = "${FormatUtils.formatBytes(document.sizeBytes)} · ${FormatUtils.formatShortDate(document.updatedAt)}",
                        style = MaterialTheme.typography.labelSmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis
                    )
                }
                if (!document.folderName.isNullOrBlank()) {
                    Text(
                        text = document.folderName,
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.tertiary,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis
                    )
                }
            }

            if (onToggleFavorite != null && !selectionMode) {
                IconButton(
                    onClick = onToggleFavorite,
                    modifier = Modifier
                        .minimumInteractiveComponentSize()
                        .testTag("doc_fav_${document.id}")
                ) {
                    Icon(
                        imageVector = if (document.isFavorite) LucideIcons.StarFilled else LucideIcons.Star,
                        contentDescription = if (document.isFavorite) "Remove favorite" else "Favorite",
                        tint = if (document.isFavorite) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
            }

            if (onMoreClick != null && !selectionMode) {
                IconButton(
                    onClick = onMoreClick,
                    modifier = Modifier
                        .minimumInteractiveComponentSize()
                        .testTag("doc_more_${document.id}")
                ) {
                    Icon(
                        imageVector = LucideIcons.MoreVertical,
                        contentDescription = "Document options",
                        tint = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
            }
        }
    }
}

@Composable
fun DocumentGridCard(
    document: DocumentItem,
    onClick: () -> Unit,
    onMoreClick: () -> Unit,
    onLongClick: () -> Unit,
    onToggleFavorite: () -> Unit,
    selected: Boolean = false,
    selectionMode: Boolean = false,
    modifier: Modifier = Modifier
) {
    DocuScanCard(
        modifier = modifier
            .fillMaxWidth()
            .testTag("doc_grid_card_${document.id}"),
        onClick = onClick,
        onLongClick = onLongClick,
        highlighted = selected
    ) {
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .height(106.dp)
                .clip(RoundedCornerShape(10.dp))
                .background(MaterialTheme.colorScheme.surface)
                .border(1.dp, MaterialTheme.colorScheme.outline, RoundedCornerShape(10.dp)),
            contentAlignment = Alignment.Center
        ) {
            val thumbFile = document.thumbnailPath?.let { File(it) }
            if (thumbFile != null && thumbFile.exists()) {
                AsyncImage(
                    model = thumbFile,
                    contentDescription = document.title,
                    contentScale = ContentScale.Crop,
                    modifier = Modifier.matchParentSize()
                )
            } else {
                Icon(
                    imageVector = when (document.fileType) {
                        DocumentFileType.PDF -> LucideIcons.FileText
                        DocumentFileType.IMAGE -> LucideIcons.Image
                        DocumentFileType.ID_CARD -> LucideIcons.IdCard
                    },
                    contentDescription = document.fileType.badge,
                    tint = MaterialTheme.colorScheme.primary,
                    modifier = Modifier.size(34.dp)
                )
            }
            if (document.isPasswordProtected) {
                Surface(
                    shape = RoundedCornerShape(6.dp),
                    color = MaterialTheme.colorScheme.surface.copy(alpha = 0.85f),
                    modifier = Modifier
                        .align(Alignment.TopStart)
                        .padding(6.dp)
                ) {
                    Icon(
                        imageVector = LucideIcons.Lock,
                        contentDescription = "Protected",
                        tint = MaterialTheme.colorScheme.primary,
                        modifier = Modifier
                            .padding(4.dp)
                            .size(14.dp)
                    )
                }
            }
            if (selectionMode) {
                Box(
                    modifier = Modifier
                        .align(Alignment.TopEnd)
                        .padding(6.dp)
                ) {
                    if (selected) {
                        Icon(
                            imageVector = LucideIcons.CircleCheck,
                            contentDescription = "Selected",
                            tint = MaterialTheme.colorScheme.primary,
                            modifier = Modifier.size(22.dp)
                        )
                    }
                }
            } else {
                IconButton(
                    onClick = onToggleFavorite,
                    modifier = Modifier
                        .align(Alignment.TopEnd)
                        .size(36.dp)
                ) {
                    Icon(
                        imageVector = if (document.isFavorite) LucideIcons.StarFilled else LucideIcons.Star,
                        contentDescription = "Toggle Favorite",
                        tint = if (document.isFavorite) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.onSurfaceVariant,
                        modifier = Modifier.size(18.dp)
                    )
                }
            }
        }

        Spacer(modifier = Modifier.height(10.dp))

        Text(
            text = document.title,
            style = MaterialTheme.typography.titleSmall,
            maxLines = 1,
            overflow = TextOverflow.Ellipsis
        )
        Spacer(modifier = Modifier.height(4.dp))
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text(
                text = "${document.pageCount}p · ${FormatUtils.formatBytes(document.sizeBytes)}",
                style = MaterialTheme.typography.labelSmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
                maxLines = 1
            )
            if (!selectionMode) {
                IconButton(
                    onClick = onMoreClick,
                    modifier = Modifier.size(32.dp)
                ) {
                    Icon(
                        imageVector = LucideIcons.MoreVertical,
                        contentDescription = "More options",
                        modifier = Modifier.size(18.dp),
                        tint = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
            }
        }
    }
}

@Composable
fun StorageSummaryCard(
    summary: StorageSummary,
    onManageClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    val quotaBytes = 512L * 1024L * 1024L
    val progress = (summary.totalUsedBytes.toFloat() / quotaBytes.toFloat()).coerceIn(0.02f, 1f)

    DocuScanCard(modifier = modifier.fillMaxWidth()) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                Box(
                    modifier = Modifier
                        .size(36.dp)
                        .clip(RoundedCornerShape(10.dp))
                        .background(MaterialTheme.colorScheme.primaryContainer),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(
                        imageVector = LucideIcons.HardDrive,
                        contentDescription = "Local Storage",
                        tint = MaterialTheme.colorScheme.primary,
                        modifier = Modifier.size(18.dp)
                    )
                }
                val strings = LocalAppStrings.current
                Column {
                    Text(
                        text = strings.onDeviceStorage,
                        style = MaterialTheme.typography.titleSmall
                    )
                    Text(
                        text = "${FormatUtils.formatBytes(summary.totalUsedBytes)} used locally",
                        style = MaterialTheme.typography.labelSmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
            }

            Text(
                text = "Backup",
                style = MaterialTheme.typography.labelLarge,
                color = MaterialTheme.colorScheme.primary,
                modifier = Modifier
                    .clip(RoundedCornerShape(8.dp))
                    .clickable(onClick = onManageClick)
                    .padding(horizontal = 10.dp, vertical = 6.dp)
                    .testTag("storage_backup_link")
            )
        }

        Spacer(modifier = Modifier.height(12.dp))

        LinearProgressIndicator(
            progress = { progress },
            modifier = Modifier
                .fillMaxWidth()
                .height(6.dp)
                .clip(RoundedCornerShape(4.dp)),
            color = MaterialTheme.colorScheme.primary,
            trackColor = MaterialTheme.colorScheme.surface
        )

        Spacer(modifier = Modifier.height(10.dp))

        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Text(
                text = "${summary.activeDocumentCount} Docs · ${summary.pdfCount} PDFs",
                style = MaterialTheme.typography.labelSmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
            Text(
                text = "${summary.folderCount} Folders · ${summary.trashCount} Trash",
                style = MaterialTheme.typography.labelSmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
        }
    }
}

@Composable
fun PhaseStatusChip(
    text: String,
    highlighted: Boolean = false,
    modifier: Modifier = Modifier
) {
    Surface(
        modifier = modifier,
        shape = RoundedCornerShape(8.dp),
        color = if (highlighted) {
            MaterialTheme.colorScheme.primaryContainer
        } else {
            MaterialTheme.colorScheme.surface
        },
        border = BorderStroke(
            width = 1.dp,
            color = if (highlighted) {
                MaterialTheme.colorScheme.primary.copy(alpha = 0.4f)
            } else {
                MaterialTheme.colorScheme.outline
            }
        )
    ) {
        Text(
            text = text,
            style = MaterialTheme.typography.labelSmall,
            color = if (highlighted) {
                MaterialTheme.colorScheme.primary
            } else {
                MaterialTheme.colorScheme.onSurfaceVariant
            },
            modifier = Modifier.padding(horizontal = 8.dp, vertical = 3.dp)
        )
    }
}

@Composable
fun EmptyStateView(
    title: String,
    subtitle: String,
    icon: ImageVector = LucideIcons.FileText,
    drawableResId: Int? = null,
    actionLabel: String? = null,
    onAction: (() -> Unit)? = null,
    modifier: Modifier = Modifier
) {
    Column(
        modifier = modifier
            .fillMaxWidth()
            .padding(horizontal = 24.dp, vertical = 20.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.spacedBy(10.dp)
    ) {
        if (drawableResId != null) {
            Image(
                painter = painterResource(id = drawableResId),
                contentDescription = title,
                contentScale = ContentScale.Crop,
                modifier = Modifier
                    .fillMaxWidth(0.72f)
                    .height(150.dp)
                    .clip(MaterialTheme.shapes.large)
                    .border(1.dp, MaterialTheme.colorScheme.outline, MaterialTheme.shapes.large)
            )
        } else {
            Box(
                modifier = Modifier
                    .size(72.dp)
                    .clip(CircleShape)
                    .background(MaterialTheme.colorScheme.primary.copy(alpha = 0.12f)),
                contentAlignment = Alignment.Center
            ) {
                Icon(
                    imageVector = icon,
                    contentDescription = title,
                    tint = MaterialTheme.colorScheme.primary,
                    modifier = Modifier.size(34.dp)
                )
            }
        }
        Text(
            text = title,
            style = MaterialTheme.typography.titleMedium,
            textAlign = TextAlign.Center
        )
        Text(
            text = subtitle,
            style = MaterialTheme.typography.bodyMedium,
            color = MaterialTheme.colorScheme.onSurfaceVariant,
            textAlign = TextAlign.Center
        )
        if (actionLabel != null && onAction != null) {
            Button(
                onClick = onAction,
                colors = ButtonDefaults.buttonColors(
                    containerColor = MaterialTheme.colorScheme.primary,
                    contentColor = MaterialTheme.colorScheme.onPrimary
                ),
                modifier = Modifier
                    .padding(top = 4.dp)
                    .minimumInteractiveComponentSize()
            ) {
                Text(actionLabel)
            }
        }
    }
}

@Composable
fun LoadingStateView(
    label: String = "Loading...",
    modifier: Modifier = Modifier
) {
    Column(
        modifier = modifier
            .fillMaxWidth()
            .padding(32.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        CircularProgressIndicator(color = MaterialTheme.colorScheme.primary)
        Text(
            text = label,
            style = MaterialTheme.typography.bodyMedium,
            color = MaterialTheme.colorScheme.onSurfaceVariant
        )
    }
}

@Composable
fun ErrorStateView(
    message: String,
    onRetry: (() -> Unit)? = null,
    modifier: Modifier = Modifier
) {
    Column(
        modifier = modifier
            .fillMaxWidth()
            .padding(24.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.spacedBy(10.dp)
    ) {
        Icon(
            imageVector = LucideIcons.CircleAlert,
            contentDescription = "Error",
            tint = MaterialTheme.colorScheme.error,
            modifier = Modifier.size(40.dp)
        )
        Text(
            text = message,
            style = MaterialTheme.typography.bodyMedium,
            textAlign = TextAlign.Center
        )
        if (onRetry != null) {
            Button(onClick = onRetry) {
                Text("Retry")
            }
        }
    }
}

val DocuScanBottomBarOverhang = 30.dp
private val NavBarDeckHeight = 66.dp
private val NavBarFabDiameter = 58.dp
private val NavBarCradleGap = 6.dp
private val NavBarShoulderFillet = 12.dp
private val NavBarCenterSlotWidth = 90.dp

@Composable
fun DocuScanBottomBar(
    selectedDestination: BottomNavDestination,
    onSelectDestination: (BottomNavDestination) -> Unit,
    onScanClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    val isDarkTheme = MaterialTheme.colorScheme.background.luminance() < 0.5f
    val barSurfaceColor = if (isDarkTheme) NavBarDarkSurface else NavBarLightSurface
    val barBorderColor = if (isDarkTheme) NavBarBorderDark else NavBarBorderLight
    val strings = LocalAppStrings.current

    Box(
        modifier = modifier.fillMaxWidth()
    ) {
        // Curved-cutout matte surface extending seamlessly down behind the system navigation bar
        Canvas(
            modifier = Modifier.matchParentSize()
        ) {
            val topEdgeY = DocuScanBottomBarOverhang.toPx()
            val cradleRadius = (NavBarFabDiameter / 2f + NavBarCradleGap).toPx()
            val filletRadius = NavBarShoulderFillet.toPx()
            val borderStrokePx = 1.dp.toPx()

            val (fillPath, borderPath) = buildNotchedNavBarPaths(
                width = size.width,
                height = size.height,
                topEdgeY = topEdgeY,
                cradleRadius = cradleRadius,
                filletRadius = filletRadius
            )

            drawPath(
                path = fillPath,
                color = barSurfaceColor
            )
            drawPath(
                path = borderPath,
                color = barBorderColor,
                style = Stroke(
                    width = borderStrokePx,
                    cap = StrokeCap.Butt,
                    join = StrokeJoin.Round
                )
            )
        }

        // Foreground tab row padded cleanly above system navigation bar insets
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(top = DocuScanBottomBarOverhang)
                .navigationBarsPadding()
                .windowInsetsPadding(
                    WindowInsets.displayCutout.only(WindowInsetsSides.Horizontal)
                )
                .height(NavBarDeckHeight)
                .padding(horizontal = 6.dp),
            verticalAlignment = Alignment.Bottom
        ) {
            BottomNavItemView(
                item = BottomNavDestination.HOME,
                selected = selectedDestination == BottomNavDestination.HOME,
                onClick = { onSelectDestination(BottomNavDestination.HOME) },
                modifier = Modifier
                    .weight(1f)
                    .fillMaxHeight()
            )
            BottomNavItemView(
                item = BottomNavDestination.DOCUMENTS,
                selected = selectedDestination == BottomNavDestination.DOCUMENTS,
                onClick = { onSelectDestination(BottomNavDestination.DOCUMENTS) },
                modifier = Modifier
                    .weight(1f)
                    .fillMaxHeight()
            )

            // Center slot aligned vertically with the other tab labels beneath the curved cradle
            Box(
                modifier = Modifier
                    .width(NavBarCenterSlotWidth)
                    .fillMaxHeight()
                    .padding(bottom = 10.dp),
                contentAlignment = Alignment.BottomCenter
            ) {
                Text(
                    text = strings.actionScan,
                    style = MaterialTheme.typography.labelSmall.copy(
                        fontSize = 11.sp,
                        lineHeight = 14.sp,
                        fontWeight = FontWeight.SemiBold
                    ),
                    color = ScanButtonGold,
                    maxLines = 1,
                    softWrap = false,
                    overflow = TextOverflow.Ellipsis,
                    modifier = Modifier
                        .clip(RoundedCornerShape(8.dp))
                        .clickable(onClick = onScanClick)
                        .padding(horizontal = 6.dp)
                )
            }

            BottomNavItemView(
                item = BottomNavDestination.TOOLS,
                selected = selectedDestination == BottomNavDestination.TOOLS,
                onClick = { onSelectDestination(BottomNavDestination.TOOLS) },
                modifier = Modifier
                    .weight(1f)
                    .fillMaxHeight()
            )
            BottomNavItemView(
                item = BottomNavDestination.SETTINGS,
                selected = selectedDestination == BottomNavDestination.SETTINGS,
                onClick = { onSelectDestination(BottomNavDestination.SETTINGS) },
                modifier = Modifier
                    .weight(1f)
                    .fillMaxHeight()
            )
        }

        // Floating 58dp solid gold Scan button nestled inside the curved cradle (~50% above top edge)
        Surface(
            onClick = onScanClick,
            shape = CircleShape,
            color = ScanButtonGold,
            contentColor = NavBarScanIconDark,
            tonalElevation = 0.dp,
            shadowElevation = 6.dp,
            modifier = Modifier
                .align(Alignment.TopCenter)
                .padding(top = DocuScanBottomBarOverhang - NavBarFabDiameter / 2f)
                .size(NavBarFabDiameter)
                .testTag("fab_scan")
        ) {
            Box(contentAlignment = Alignment.Center) {
                Icon(
                    imageVector = LucideIcons.Camera,
                    contentDescription = "Scan Document",
                    tint = NavBarScanIconDark,
                    modifier = Modifier.size(26.dp)
                )
            }
        }
    }
}

/**
 * Constructs tangent-continuous (G1) fill and top-border paths for a bottom navigation bar
 * with a centered circular U-shaped concave cradle and smooth fillet shoulders.
 */
private fun buildNotchedNavBarPaths(
    width: Float,
    height: Float,
    topEdgeY: Float,
    cradleRadius: Float,
    filletRadius: Float
): Pair<Path, Path> {
    val fillPath = Path()
    val borderPath = Path()
    if (width <= 0f || height <= topEdgeY) {
        return fillPath to borderPath
    }

    val centerX = width / 2f
    val effectiveCradleR = cradleRadius.coerceAtMost(width * 0.25f)
    val effectiveFilletR = filletRadius.coerceAtMost(effectiveCradleR * 0.5f)
    val dx = sqrt(effectiveCradleR * effectiveCradleR + 2f * effectiveCradleR * effectiveFilletR)
    val sinAlpha = (effectiveFilletR / (effectiveCradleR + effectiveFilletR)).coerceIn(-1f, 1f)
    val alphaDeg = Math.toDegrees(asin(sinAlpha.toDouble())).toFloat()
    val filletSweepDeg = 90f - alphaDeg
    val cradleSweepDeg = -(180f - 2f * alphaDeg)

    val leftFilletCenterX = (centerX - dx).coerceAtLeast(effectiveFilletR)
    val rightFilletCenterX = (centerX + dx).coerceAtMost(width - effectiveFilletR)
    val filletCenterY = topEdgeY + effectiveFilletR

    borderPath.apply {
        moveTo(0f, topEdgeY)
        lineTo(leftFilletCenterX, topEdgeY)
        arcTo(
            rect = Rect(
                left = leftFilletCenterX - effectiveFilletR,
                top = filletCenterY - effectiveFilletR,
                right = leftFilletCenterX + effectiveFilletR,
                bottom = filletCenterY + effectiveFilletR
            ),
            startAngleDegrees = -90f,
            sweepAngleDegrees = filletSweepDeg,
            forceMoveTo = false
        )
        arcTo(
            rect = Rect(
                left = centerX - effectiveCradleR,
                top = topEdgeY - effectiveCradleR,
                right = centerX + effectiveCradleR,
                bottom = topEdgeY + effectiveCradleR
            ),
            startAngleDegrees = 180f - alphaDeg,
            sweepAngleDegrees = cradleSweepDeg,
            forceMoveTo = false
        )
        arcTo(
            rect = Rect(
                left = rightFilletCenterX - effectiveFilletR,
                top = filletCenterY - effectiveFilletR,
                right = rightFilletCenterX + effectiveFilletR,
                bottom = filletCenterY + effectiveFilletR
            ),
            startAngleDegrees = 180f + alphaDeg,
            sweepAngleDegrees = filletSweepDeg,
            forceMoveTo = false
        )
        lineTo(width, topEdgeY)
    }

    fillPath.apply {
        addPath(borderPath)
        lineTo(width, height)
        lineTo(0f, height)
        close()
    }

    return fillPath to borderPath
}

@Composable
private fun BottomNavItemView(
    item: BottomNavDestination,
    selected: Boolean,
    onClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    val tint by animateColorAsState(
        targetValue = if (selected) ScanButtonGold else NavBarInactiveGrey,
        label = "navTint"
    )
    val strings = LocalAppStrings.current
    val label = item.localizedLabel(strings)
    Column(
        modifier = modifier
            .clip(RoundedCornerShape(14.dp))
            .clickable(onClick = onClick)
            .minimumInteractiveComponentSize()
            .padding(start = 2.dp, end = 2.dp, top = 12.dp, bottom = 10.dp)
            .testTag(item.testTag),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Bottom
    ) {
        Icon(
            imageVector = if (selected) item.selectedIcon else item.unselectedIcon,
            contentDescription = label,
            tint = tint,
            modifier = Modifier.size(22.dp)
        )
        Spacer(modifier = Modifier.height(4.dp))
        Text(
            text = label,
            style = MaterialTheme.typography.labelSmall.copy(
                fontSize = 11.sp,
                lineHeight = 14.sp,
                fontWeight = if (selected) FontWeight.SemiBold else FontWeight.Medium
            ),
            color = tint,
            maxLines = 1,
            softWrap = false,
            overflow = TextOverflow.Ellipsis
        )
    }
}

@Composable
fun DocuScanSwitch(
    checked: Boolean,
    onCheckedChange: ((Boolean) -> Unit)?,
    modifier: Modifier = Modifier,
    enabled: Boolean = true
) {
    val isDarkTheme = MaterialTheme.colorScheme.background.luminance() < 0.5f
    val uncheckedTrack = if (isDarkTheme) SwitchUncheckedTrackDark else SwitchUncheckedTrackLight
    val uncheckedBorder = if (isDarkTheme) SwitchUncheckedBorderDark else SwitchUncheckedBorderLight
    val uncheckedThumb = if (isDarkTheme) SwitchUncheckedThumbDark else SwitchUncheckedThumbLight

    Switch(
        checked = checked,
        onCheckedChange = onCheckedChange,
        enabled = enabled,
        colors = SwitchDefaults.colors(
            checkedThumbColor = SwitchCheckedThumb,
            checkedTrackColor = SwitchCheckedTrack,
            checkedBorderColor = SwitchCheckedBorder,
            uncheckedThumbColor = uncheckedThumb,
            uncheckedTrackColor = uncheckedTrack,
            uncheckedBorderColor = uncheckedBorder,
            disabledCheckedThumbColor = SwitchCheckedThumb.copy(alpha = 0.6f),
            disabledCheckedTrackColor = SwitchCheckedTrack.copy(alpha = 0.45f),
            disabledCheckedBorderColor = SwitchCheckedBorder.copy(alpha = 0.45f),
            disabledUncheckedThumbColor = uncheckedThumb.copy(alpha = 0.45f),
            disabledUncheckedTrackColor = uncheckedTrack.copy(alpha = 0.45f),
            disabledUncheckedBorderColor = uncheckedBorder.copy(alpha = 0.45f)
        ),
        modifier = modifier
    )
}
