package com.docuscan.app

import android.content.Intent
import android.net.Uri
import android.os.Bundle
import androidx.activity.SystemBarStyle
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.core.content.IntentCompat
import androidx.fragment.app.FragmentActivity
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.LifecycleEventObserver
import androidx.lifecycle.compose.LocalLifecycleOwner
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewmodel.compose.viewModel
import com.docuscan.app.domain.model.ThemeMode
import com.docuscan.app.navigation.DocuScanNavHost
import com.docuscan.app.settings.SettingsViewModel
import com.docuscan.app.ui.theme.DocuScanTheme
import com.docuscan.app.ui.viewmodel.DocuScanViewModelFactory
import com.docuscan.app.ui.viewmodel.DocumentsViewModel
import com.docuscan.app.ui.viewmodel.OcrViewModel
import com.docuscan.app.ui.viewmodel.PdfToolsViewModel
import com.docuscan.app.ui.viewmodel.ScannerViewModel
import com.docuscan.app.ui.viewmodel.SignatureViewModel
import com.docuscan.app.ui.viewmodel.ViewerViewModel
import com.docuscan.app.util.AppLocaleHelper
import com.docuscan.app.util.LocalAppStrings
import com.docuscan.app.util.LocalFileManager
import com.docuscan.app.util.stringsForLanguage
import kotlinx.coroutines.flow.MutableStateFlow

data class IncomingExternalContent(
    val uri: Uri,
    val mimeType: String?,
    val isPdf: Boolean,
    val displayName: String,
    val isViewAction: Boolean,
    val eventId: Long = System.nanoTime()
)

class MainActivity : FragmentActivity() {

    private val incomingContentFlow = MutableStateFlow<IncomingExternalContent?>(null)

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge(
            statusBarStyle = SystemBarStyle.dark(android.graphics.Color.TRANSPARENT),
            navigationBarStyle = SystemBarStyle.dark(android.graphics.Color.TRANSPARENT)
        )

        val container = (application as DocuScanApplication).container
        val factory = DocuScanViewModelFactory(container)

        if (savedInstanceState == null) {
            handleIncomingIntent(intent, container.fileManager)
        }

        setContent {
            val settingsViewModel: SettingsViewModel = viewModel(factory = factory)
            val documentsViewModel: DocumentsViewModel = viewModel(factory = factory)
            val scannerViewModel: ScannerViewModel = viewModel(factory = factory)
            val viewerViewModel: ViewerViewModel = viewModel(factory = factory)
            val signatureViewModel: SignatureViewModel = viewModel(factory = factory)
            val ocrViewModel: OcrViewModel = viewModel(factory = factory)
            val pdfToolsViewModel: PdfToolsViewModel = viewModel(factory = factory)

            val lifecycleOwner = LocalLifecycleOwner.current
            DisposableEffect(lifecycleOwner, settingsViewModel) {
                val observer = LifecycleEventObserver { _, event ->
                    when (event) {
                        Lifecycle.Event.ON_STOP -> {
                            if (!isChangingConfigurations) {
                                settingsViewModel.onAppBackgrounded()
                            }
                        }
                        Lifecycle.Event.ON_RESUME -> {
                            settingsViewModel.onAppResumed()
                        }
                        else -> Unit
                    }
                }
                lifecycleOwner.lifecycle.addObserver(observer)
                onDispose {
                    lifecycleOwner.lifecycle.removeObserver(observer)
                }
            }

            val preferences by settingsViewModel.preferences.collectAsStateWithLifecycle()
            val incomingContent by incomingContentFlow.collectAsStateWithLifecycle()
            val systemDark = isSystemInDarkTheme()
            val isDark = when (preferences.themeMode) {
                ThemeMode.DARK -> true
                ThemeMode.LIGHT -> false
                ThemeMode.SYSTEM -> systemDark
            }

            LaunchedEffect(isDark) {
                val barStyle = if (isDark) {
                    SystemBarStyle.dark(android.graphics.Color.TRANSPARENT)
                } else {
                    SystemBarStyle.light(
                        android.graphics.Color.TRANSPARENT,
                        android.graphics.Color.TRANSPARENT
                    )
                }
                enableEdgeToEdge(statusBarStyle = barStyle, navigationBarStyle = barStyle)
            }

            LaunchedEffect(preferences.appLanguage) {
                AppLocaleHelper.applyLocaleToContext(this@MainActivity, preferences.appLanguage)
            }

            val localizedStrings = stringsForLanguage(preferences.appLanguage)
            CompositionLocalProvider(LocalAppStrings provides localizedStrings) {
                DocuScanTheme(
                    themeMode = preferences.themeMode,
                    fontStyle = preferences.fontStyle
                ) {
                    DocuScanNavHost(
                        documentsViewModel = documentsViewModel,
                        scannerViewModel = scannerViewModel,
                        viewerViewModel = viewerViewModel,
                        signatureViewModel = signatureViewModel,
                        ocrViewModel = ocrViewModel,
                        pdfToolsViewModel = pdfToolsViewModel,
                        settingsViewModel = settingsViewModel,
                        incomingContent = incomingContent,
                        onConsumeIncomingContent = { incomingContentFlow.value = null }
                    )
                }
            }
        }
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        setIntent(intent)
        val container = (application as? DocuScanApplication)?.container ?: return
        handleIncomingIntent(intent, container.fileManager)
    }

    private fun handleIncomingIntent(intent: Intent?, fileManager: LocalFileManager) {
        val parsed = parseIncomingIntent(intent, fileManager) ?: return
        incomingContentFlow.value = parsed
    }

    internal fun parseIncomingIntent(
        intent: Intent?,
        fileManager: LocalFileManager
    ): IncomingExternalContent? {
        if (intent == null) return null
        val action = intent.action ?: return null
        val isView = action == Intent.ACTION_VIEW
        val isSend = action == Intent.ACTION_SEND
        if (!isView && !isSend) return null

        val uri: Uri = when {
            isView -> intent.data ?: intent.clipData?.takeIf { it.itemCount > 0 }?.getItemAt(0)?.uri
            isSend -> IntentCompat.getParcelableExtra(intent, Intent.EXTRA_STREAM, Uri::class.java)
                ?: intent.clipData?.takeIf { it.itemCount > 0 }?.getItemAt(0)?.uri
                ?: intent.data
            else -> null
        } ?: return null

        val resolvedMime = (intent.type?.takeIf { it.isNotBlank() && it != "*/*" }
            ?: runCatching { contentResolver.getType(uri) }.getOrNull())
            ?.lowercase()

        val displayName = runCatching { fileManager.resolveDisplayName(uri) }.getOrNull()
            ?.takeIf { it.isNotBlank() }
            ?: uri.lastPathSegment?.substringAfterLast('/')?.takeIf { it.isNotBlank() }
            ?: if (resolvedMime == "application/pdf") "Shared Document.pdf" else "Shared File"

        val isPdf = resolvedMime == "application/pdf" ||
            displayName.endsWith(".pdf", ignoreCase = true) ||
            uri.toString().endsWith(".pdf", ignoreCase = true)

        val isImage = resolvedMime?.startsWith("image/") == true ||
            listOf(".jpg", ".jpeg", ".png", ".webp", ".heic", ".bmp").any {
                displayName.endsWith(it, ignoreCase = true)
            }

        if (!isPdf && !isImage) return null

        return IncomingExternalContent(
            uri = uri,
            mimeType = resolvedMime,
            isPdf = isPdf,
            displayName = displayName,
            isViewAction = isView
        )
    }
}
