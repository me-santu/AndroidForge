package com.docuscan.app.database.entity

import androidx.room.ColumnInfo
import androidx.room.Entity
import androidx.room.ForeignKey
import androidx.room.Index
import androidx.room.PrimaryKey

@Entity(tableName = "folders")
data class FolderEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val name: String,
    val accentHex: Long = 0xFFF5C542,
    val createdAt: Long = System.currentTimeMillis()
)

@Entity(
    tableName = "documents",
    foreignKeys = [
        ForeignKey(
            entity = FolderEntity::class,
            parentColumns = ["id"],
            childColumns = ["folderId"],
            onDelete = ForeignKey.SET_NULL
        )
    ],
    indices = [Index("folderId"), Index("isDeleted")]
)
data class DocumentEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val title: String,
    val folderId: Long? = null,
    val filePath: String,
    val thumbnailPath: String? = null,
    val fileType: String = "PDF",
    val pageCount: Int = 1,
    val sizeBytes: Long = 0L,
    val ocrText: String = "",
    val createdAt: Long = System.currentTimeMillis(),
    val updatedAt: Long = System.currentTimeMillis(),
    val isPinned: Boolean = false,
    @ColumnInfo(defaultValue = "0")
    val isFavorite: Boolean = false,
    @ColumnInfo(defaultValue = "0")
    val isPasswordProtected: Boolean = false,
    @ColumnInfo(defaultValue = "''")
    val bookmarkedPages: String = "",
    val isDeleted: Boolean = false,
    val deletedAt: Long? = null
)

@Entity(
    tableName = "document_pages",
    foreignKeys = [
        ForeignKey(
            entity = DocumentEntity::class,
            parentColumns = ["id"],
            childColumns = ["documentId"],
            onDelete = ForeignKey.CASCADE
        )
    ],
    indices = [Index("documentId")]
)
data class DocumentPageEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val documentId: Long,
    val imagePath: String,
    val pageIndex: Int,
    val filterName: String = "ORIGINAL",
    val rotationDegrees: Int = 0
)

@Entity(tableName = "signatures")
data class SignatureEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val name: String,
    val filePath: String,
    val createdAt: Long = System.currentTimeMillis()
)

@Entity(
    tableName = "deleted_documents",
    indices = [Index("originalDocumentId"), Index("deletedAt")]
)
data class DeletedDocumentEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val originalDocumentId: Long,
    val title: String,
    val folderId: Long? = null,
    val filePath: String,
    val thumbnailPath: String? = null,
    val fileType: String = "PDF",
    val pageCount: Int = 1,
    val sizeBytes: Long = 0L,
    val deletedAt: Long = System.currentTimeMillis()
)
