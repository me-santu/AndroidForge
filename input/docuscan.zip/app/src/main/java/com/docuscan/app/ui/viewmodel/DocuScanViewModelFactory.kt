package com.docuscan.app.ui.viewmodel

import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import com.docuscan.app.settings.SettingsViewModel
import com.docuscan.app.util.AppContainer

class DocuScanViewModelFactory(
    private val container: AppContainer
) : ViewModelProvider.Factory {

    @Suppress("UNCHECKED_CAST")
    override fun <T : ViewModel> create(modelClass: Class<T>): T {
        return when {
            modelClass.isAssignableFrom(DocumentsViewModel::class.java) -> {
                DocumentsViewModel(
                    repository = container.documentRepository,
                    fileManager = container.fileManager,
                    securityManager = container.securityManager
                ) as T
            }
            modelClass.isAssignableFrom(ScannerViewModel::class.java) -> {
                ScannerViewModel(
                    documentRepository = container.documentRepository,
                    settingsRepository = container.settingsRepository,
                    sessionManager = container.scanSessionManager,
                    fileManager = container.fileManager,
                    scannerGateway = container.documentScannerGateway,
                    pdfRendererHelper = container.pdfRendererHelper,
                    securityManager = container.securityManager
                ) as T
            }
            modelClass.isAssignableFrom(ViewerViewModel::class.java) -> {
                ViewerViewModel(
                    documentRepository = container.documentRepository,
                    pdfRendererHelper = container.pdfRendererHelper,
                    fileManager = container.fileManager,
                    securityManager = container.securityManager,
                    ocrEngine = container.ocrEngine
                ) as T
            }
            modelClass.isAssignableFrom(SignatureViewModel::class.java) -> {
                SignatureViewModel(
                    repository = container.documentRepository,
                    pdfRendererHelper = container.pdfRendererHelper
                ) as T
            }
            modelClass.isAssignableFrom(SettingsViewModel::class.java) -> {
                SettingsViewModel(
                    settingsRepository = container.settingsRepository,
                    documentRepository = container.documentRepository,
                    securityManager = container.securityManager
                ) as T
            }
            modelClass.isAssignableFrom(OcrViewModel::class.java) -> {
                OcrViewModel(
                    ocrEngine = container.ocrEngine,
                    documentRepository = container.documentRepository,
                    pdfRendererHelper = container.pdfRendererHelper,
                    fileManager = container.fileManager
                ) as T
            }
            modelClass.isAssignableFrom(PdfToolsViewModel::class.java) -> {
                PdfToolsViewModel(
                    documentRepository = container.documentRepository,
                    pdfRendererHelper = container.pdfRendererHelper,
                    fileManager = container.fileManager,
                    securityManager = container.securityManager,
                    pdfSignatureValidator = container.pdfSignatureValidator
                ) as T
            }
            else -> throw IllegalArgumentException("Unknown ViewModel class: ${modelClass.name}")
        }
    }
}
