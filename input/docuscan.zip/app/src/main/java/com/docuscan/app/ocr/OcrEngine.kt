package com.docuscan.app.ocr

import android.content.Context
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.ColorMatrix
import android.graphics.ColorMatrixColorFilter
import android.graphics.Matrix
import android.graphics.Paint
import com.docuscan.app.domain.model.ScanPage
import com.docuscan.app.pdf.PdfRenderOutcome
import com.docuscan.app.pdf.PdfRendererHelper
import com.docuscan.app.scanner.BitmapFilterEngine
import com.google.android.gms.tasks.Task
import com.google.mlkit.vision.common.InputImage
import com.google.mlkit.vision.text.TextRecognition
import com.google.mlkit.vision.text.TextRecognizer
import com.google.mlkit.vision.text.chinese.ChineseTextRecognizerOptions
import com.google.mlkit.vision.text.devanagari.DevanagariTextRecognizerOptions
import com.google.mlkit.vision.text.japanese.JapaneseTextRecognizerOptions
import com.google.mlkit.vision.text.korean.KoreanTextRecognizerOptions
import com.google.mlkit.vision.text.latin.TextRecognizerOptions
import com.googlecode.tesseract.android.TessBaseAPI
import com.tom_roush.pdfbox.io.MemoryUsageSetting
import com.tom_roush.pdfbox.pdmodel.PDDocument
import com.tom_roush.pdfbox.text.PDFTextStripper
import kotlinx.coroutines.CoroutineDispatcher
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.suspendCancellableCoroutine
import kotlinx.coroutines.withContext
import java.io.File
import java.io.FileOutputStream
import kotlin.coroutines.resume
import kotlin.coroutines.resumeWithException

enum class OcrScript(
    val label: String,
    val shortLabel: String,
    val engineDescription: String,
    val isSupported: Boolean,
    val supportBadge: String
) {
    AUTO(
        label = "Auto Detect (All)",
        shortLabel = "Auto",
        engineDescription = "Auto-detects language & script across Latin (50+ languages), Hindi/Devanagari, Bengali (Tesseract offline ben+eng), Chinese, Japanese & Korean, plus all Unicode PDFs.",
        isSupported = true,
        supportBadge = "Auto"
    ),
    LATIN(
        label = "Latin (EN/ES/FR/DE+)",
        shortLabel = "Latin",
        engineDescription = "Google ML Kit v2 · English, Spanish, French, German, Italian, Portuguese, Dutch, Turkish, Vietnamese, Indonesian & 50+ Latin languages",
        isSupported = true,
        supportBadge = "ML Kit v2"
    ),
    DEVANAGARI(
        label = "Hindi (Devanagari)",
        shortLabel = "Hindi",
        engineDescription = "Google ML Kit v2 · Hindi, Marathi, Nepali, Sanskrit, Konkani & Maithili",
        isSupported = true,
        supportBadge = "ML Kit v2"
    ),
    BENGALI(
        label = "Bengali (বাংলা)",
        shortLabel = "Bengali",
        engineDescription = "Tesseract4Android Offline (ben+eng) · Supports scanned Bengali images, scanned PDFs with grayscale/contrast enhancement, and digital Unicode PDFs.",
        isSupported = true,
        supportBadge = "Tesseract"
    ),
    CHINESE(
        label = "Chinese (中文)",
        shortLabel = "Chinese",
        engineDescription = "Google ML Kit v2 · Simplified & Traditional Chinese",
        isSupported = true,
        supportBadge = "ML Kit v2"
    ),
    JAPANESE(
        label = "Japanese (日本語)",
        shortLabel = "Japanese",
        engineDescription = "Google ML Kit v2 · Japanese (Kanji, Hiragana & Katakana)",
        isSupported = true,
        supportBadge = "ML Kit v2"
    ),
    KOREAN(
        label = "Korean (한국어)",
        shortLabel = "Korean",
        engineDescription = "Google ML Kit v2 · Korean (Hangul)",
        isSupported = true,
        supportBadge = "ML Kit v2"
    )
}

data class OcrPageResult(
    val pageNumberOneBased: Int,
    val text: String,
    val qualityWarning: String? = null,
    val detectedLanguage: DetectedLanguageInfo? = null,
    val recognizedScript: OcrScript? = null
)

data class OcrExtractionResult(
    val script: OcrScript,
    val pages: List<OcrPageResult>,
    val combinedText: String,
    val warnings: List<String> = emptyList(),
    val detectedLanguage: DetectedLanguageInfo? = null,
    val effectiveScript: OcrScript = script
)

interface OcrProvider {
    val script: OcrScript
    val engineName: String
    val isAvailable: Boolean

    suspend fun recognizeBitmap(bitmap: Bitmap, rotationDegrees: Int = 0): Result<String>
}

/**
 * Offline Bengali + English ("ben+eng") OCR provider backed by Tesseract4Android (`TessBaseAPI`).
 * Copies `ben.traineddata` and `eng.traineddata` from `assets/tessdata/` to `context.filesDir/tessdata/`
 * when not already cached, upscales smaller bitmaps (<1500px wide) by 2x with bilinear filtering,
 * applies high-contrast grayscale + slight brightness lift to sharpen Bengali matras and conjuncts
 * (juktakkhor), configures `PSM_AUTO` + `preserve_interword_spaces`, and always recycles both
 * temporary bitmaps and native `TessBaseAPI` inside a `finally` block.
 */
class TesseractBengaliOcrProvider(
    private val context: Context?,
    private val languageCode: String = TESS_BENGALI_LANG
) : OcrProvider {

    override val script: OcrScript = OcrScript.BENGALI
    override val engineName: String = "Tesseract4Android Offline ($languageCode)"
    override val isAvailable: Boolean = true

    /**
     * Checks whether required traineddata files are cached on disk or bundled in assets/tessdata/.
     */
    fun hasTrainedDataReady(): Boolean {
        val ctx = context ?: return false
        return OcrEngine.hasBengaliTrainedData(ctx)
    }

    override suspend fun recognizeBitmap(bitmap: Bitmap, rotationDegrees: Int): Result<String> {
        val ctx = context
            ?: return Result.failure(
                IllegalStateException("Android Context is required to initialize offline Bengali Tesseract OCR.")
            )
        val dataPath = OcrEngine.ensureTessDataCached(ctx)
            .getOrElse { return Result.failure(it) }

        var preparedBitmap: Bitmap? = null
        val tessBaseApi = TessBaseAPI()
        return try {
            preparedBitmap = preprocessBitmapForBengaliOcr(bitmap, rotationDegrees)
            val initialized = tessBaseApi.init(dataPath.absolutePath, languageCode)
            if (!initialized) {
                Result.failure(
                    IllegalStateException(
                        "Unable to initialize Tesseract with '$languageCode'. Verify ben.traineddata and eng.traineddata in tessdata/."
                    )
                )
            } else {
                tessBaseApi.pageSegMode = TessBaseAPI.PageSegMode.PSM_AUTO
                tessBaseApi.setVariable("preserve_interword_spaces", "1")
                tessBaseApi.setImage(preparedBitmap)
                val extracted = tessBaseApi.utF8Text?.trim().orEmpty()
                Result.success(extracted)
            }
        } catch (t: Throwable) {
            Result.failure(t)
        } finally {
            runCatching { tessBaseApi.recycle() }
            if (preparedBitmap != null && preparedBitmap !== bitmap && !preparedBitmap.isRecycled) {
                preparedBitmap.recycle()
            }
        }
    }

    companion object {
        const val TESS_BENGALI_LANG = "ben+eng"
        const val MIN_BENGALI_UPSCALE_WIDTH_PX = 1500
        private const val BENGALI_CONTRAST = 1.4f
        private const val BENGALI_BRIGHTNESS_LIFT = 14f
        val REQUIRED_TRAINED_DATA_FILES = listOf("ben.traineddata", "eng.traineddata")

        /**
         * Preprocesses a bitmap for Bengali Tesseract OCR so complex conjunct characters
         * (juktakkhor) and small matras remain sharp and paper shadows disappear:
         * 1. Applies orientation rotation if needed.
         * 2. Upscales by 2x using bilinear filtering when width < 1500px.
         * 3. Converts to high-contrast grayscale (~1.4x contrast + slight brightness boost).
         * Always recycles temporary intermediate bitmaps in a `finally` block; caller must recycle
         * the returned preprocessed bitmap in its own `finally` block.
         */
        fun preprocessBitmapForBengaliOcr(
            source: Bitmap,
            rotationDegrees: Int = 0
        ): Bitmap {
            val normalizedRotation = ((rotationDegrees % 360) + 360) % 360
            var working: Bitmap = source
            var ownsWorking = false
            try {
                if (normalizedRotation != 0) {
                    val matrix = Matrix().apply { postRotate(normalizedRotation.toFloat()) }
                    val rotated = Bitmap.createBitmap(
                        working,
                        0,
                        0,
                        working.width,
                        working.height,
                        matrix,
                        true
                    )
                    if (rotated !== working) {
                        working = rotated
                        ownsWorking = true
                    }
                }

                if (working.width < MIN_BENGALI_UPSCALE_WIDTH_PX) {
                    val upscaled = try {
                        Bitmap.createScaledBitmap(
                            working,
                            (working.width * 2).coerceAtLeast(1),
                            (working.height * 2).coerceAtLeast(1),
                            true // bilinear filtering
                        )
                    } catch (_: OutOfMemoryError) {
                        working
                    }
                    if (upscaled !== working) {
                        if (ownsWorking && working !== source && !working.isRecycled) {
                            working.recycle()
                        }
                        working = upscaled
                        ownsWorking = true
                    }
                }

                val output = Bitmap.createBitmap(
                    working.width.coerceAtLeast(1),
                    working.height.coerceAtLeast(1),
                    Bitmap.Config.ARGB_8888
                )
                try {
                    val canvas = Canvas(output)
                    val translate = (-0.5f * BENGALI_CONTRAST + 0.5f) * 255f + BENGALI_BRIGHTNESS_LIFT
                    val colorMatrix = ColorMatrix().apply {
                        setSaturation(0f)
                        postConcat(
                            ColorMatrix(
                                floatArrayOf(
                                    BENGALI_CONTRAST, 0f, 0f, 0f, translate,
                                    0f, BENGALI_CONTRAST, 0f, 0f, translate,
                                    0f, 0f, BENGALI_CONTRAST, 0f, translate,
                                    0f, 0f, 0f, 1f, 0f
                                )
                            )
                        )
                    }
                    val paint = Paint(Paint.ANTI_ALIAS_FLAG or Paint.FILTER_BITMAP_FLAG).apply {
                        colorFilter = ColorMatrixColorFilter(colorMatrix)
                    }
                    canvas.drawBitmap(working, 0f, 0f, paint)
                    return output
                } catch (t: Throwable) {
                    if (!output.isRecycled) {
                        output.recycle()
                    }
                    throw t
                }
            } finally {
                if (ownsWorking && working !== source && !working.isRecycled) {
                    working.recycle()
                }
            }
        }
    }
}

class MlKitOcrProvider(
    override val script: OcrScript,
    override val engineName: String,
    private val recognizerFactory: () -> TextRecognizer
) : OcrProvider {

    override val isAvailable: Boolean = script.isSupported

    @Volatile
    private var cachedRecognizer: TextRecognizer? = null

    private fun getOrCreateRecognizer(): TextRecognizer {
        return cachedRecognizer ?: synchronized(this) {
            cachedRecognizer ?: recognizerFactory().also { cachedRecognizer = it }
        }
    }

    override suspend fun recognizeBitmap(bitmap: Bitmap, rotationDegrees: Int): Result<String> {
        return runCatching {
            val normalizedRotation = ((rotationDegrees % 360) + 360) % 360
            val sanitizedRotation = when (normalizedRotation) {
                90, 180, 270 -> normalizedRotation
                else -> 0
            }
            val inputImage = InputImage.fromBitmap(bitmap, sanitizedRotation)
            val resultText = getOrCreateRecognizer().process(inputImage).awaitResult()
            resultText.text.trim()
        }
    }
}

private val ocrDirectExecutor = java.util.concurrent.Executor { command -> command.run() }

private suspend fun <T> Task<T>.awaitResult(): T = suspendCancellableCoroutine { cont ->
    addOnSuccessListener(ocrDirectExecutor) { value ->
        if (cont.isActive) cont.resume(value)
    }
    addOnFailureListener(ocrDirectExecutor) { exc ->
        if (cont.isActive) cont.resumeWithException(exc)
    }
    addOnCanceledListener(ocrDirectExecutor) {
        if (cont.isActive) cont.cancel()
    }
}

class OcrEngine(
    private val context: Context? = null,
    initialProviders: Map<OcrScript, OcrProvider> = defaultProviders(context),
    private val workerDispatcher: CoroutineDispatcher = Dispatchers.Default
) {
    private val providers: MutableMap<OcrScript, OcrProvider> = initialProviders.toMutableMap()

    fun registerProvider(provider: OcrProvider) {
        providers[provider.script] = provider
    }

    fun getProvider(script: OcrScript): OcrProvider? = providers[script]

    fun isScriptSupported(script: OcrScript): Boolean {
        if (script == OcrScript.AUTO) {
            return providers.values.any { it.isAvailable }
        }
        return providers[script]?.isAvailable == true
    }

    suspend fun extractTextFromBitmap(
        bitmap: Bitmap,
        script: OcrScript = OcrScript.AUTO,
        rotationDegrees: Int = 0
    ): Result<OcrExtractionResult> = withContext(workerDispatcher) {
        val safeBitmap = BitmapFilterEngine.ensureWithinMaxDimension(
            bitmap = bitmap,
            maxDimension = BitmapFilterEngine.MAX_SAFE_IMAGE_DIMENSION,
            recycleSourceIfScaled = false
        )
        try {
            extractPageInternal(
                bitmap = safeBitmap,
                pageNumberOneBased = 1,
                script = script,
                rotationDegrees = rotationDegrees
            )
        } finally {
            if (safeBitmap !== bitmap && !safeBitmap.isRecycled) {
                safeBitmap.recycle()
            }
        }
    }

    suspend fun extractTextFromImageFile(
        filePath: String,
        script: OcrScript = OcrScript.AUTO,
        rotationDegrees: Int = 0
    ): Result<OcrExtractionResult> = withContext(workerDispatcher) {
        val file = File(filePath)
        if (!file.exists() || file.length() == 0L) {
            return@withContext Result.failure(IllegalArgumentException("Image file could not be found."))
        }
        val bitmap = BitmapFilterEngine.decodeSampledBitmap(
            filePath = filePath,
            maxDimension = BitmapFilterEngine.MAX_SAFE_IMAGE_DIMENSION
        ) ?: return@withContext Result.failure(IllegalStateException("Unable to decode image for OCR."))
        try {
            extractPageInternal(
                bitmap = bitmap,
                pageNumberOneBased = 1,
                script = script,
                rotationDegrees = rotationDegrees
            )
        } finally {
            if (!bitmap.isRecycled) {
                bitmap.recycle()
            }
        }
    }

    suspend fun extractTextFromScanPages(
        pages: List<ScanPage>,
        script: OcrScript = OcrScript.AUTO,
        onProgress: (current: Int, total: Int) -> Unit = { _, _ -> }
    ): Result<OcrExtractionResult> = withContext(workerDispatcher) {
        if (pages.isEmpty()) {
            return@withContext Result.failure(IllegalArgumentException("No scanned pages selected for OCR."))
        }
        if (script != OcrScript.AUTO) {
            validateProvider(script).getOrElse { return@withContext Result.failure(it) }
        } else if (!isScriptSupported(OcrScript.AUTO)) {
            return@withContext Result.failure(UnsupportedOperationException("No OCR provider is available."))
        }

        val orderedPages = pages.sortedBy { it.orderIndex }
        val results = mutableListOf<OcrPageResult>()
        val warnings = mutableListOf<String>()

        orderedPages.forEachIndexed { index, scanPage ->
            val pageNum = index + 1
            onProgress(pageNum, orderedPages.size)
            val raw = BitmapFilterEngine.decodeSampledBitmap(
                filePath = scanPage.sourcePath,
                maxDimension = BitmapFilterEngine.MAX_SAFE_IMAGE_DIMENSION
            ) ?: return@withContext Result.failure(IllegalStateException("Could not decode page $pageNum image."))
            var transformed: Bitmap? = null
            try {
                transformed = BitmapFilterEngine.cropAndTransform(
                    source = raw,
                    cropRect = scanPage.cropRect,
                    rotationDegrees = scanPage.rotationDegrees,
                    filter = scanPage.filter
                )
                val pageOutcome = recognizeSinglePageBitmap(
                    bitmap = transformed,
                    pageNumberOneBased = pageNum,
                    script = script,
                    rotationDegrees = 0
                ).getOrElse { return@withContext Result.failure(it) }
                pageOutcome.qualityWarning?.let { warnings.add("Page $pageNum: $it") }
                results.add(pageOutcome)
            } finally {
                if (transformed != null && transformed !== raw && !transformed.isRecycled) {
                    transformed.recycle()
                }
                if (!raw.isRecycled) {
                    raw.recycle()
                }
            }
        }

        finalizeMultiPageResults(script, results, warnings)
    }

    suspend fun extractTextFromPdf(
        pdfPath: String,
        pdfRendererHelper: PdfRendererHelper,
        script: OcrScript = OcrScript.AUTO,
        password: String? = null,
        pageIndicesZeroBased: List<Int>? = null,
        onProgress: (current: Int, total: Int) -> Unit = { _, _ -> }
    ): Result<OcrExtractionResult> = withContext(workerDispatcher) {
        val file = File(pdfPath)
        if (!file.exists() || file.length() == 0L) {
            return@withContext Result.failure(IllegalArgumentException("PDF file could not be found on device."))
        }

        // First try direct Unicode embedded text extraction (supports digital Bengali and ALL world languages)
        val embeddedPages = extractEmbeddedPdfPageTexts(pdfPath, password)
        if (embeddedPages != null && embeddedPages.isNotEmpty()) {
            val targetIndices = pageIndicesZeroBased
                ?.filter { it in embeddedPages.indices }
                ?.distinct()
                ?.sorted()
                ?.takeIf { it.isNotEmpty() }
                ?: embeddedPages.indices.toList()

            val hasDigitalText = targetIndices.any { idx ->
                val txt = embeddedPages[idx]
                txt.length >= 6 && txt.any(Char::isLetter)
            }

            if (hasDigitalText) {
                val pageResults = mutableListOf<OcrPageResult>()
                val totalTarget = targetIndices.size
                targetIndices.forEachIndexed { stepIndex, pageIdx ->
                    val pageNum = pageIdx + 1
                    onProgress(stepIndex + 1, totalTarget)
                    val embedded = embeddedPages[pageIdx]
                    if (embedded.length >= 6 && embedded.any(Char::isLetter)) {
                        val lang = OcrLanguageDetector.detectLanguage(embedded, script)
                        pageResults.add(
                            OcrPageResult(
                                pageNumberOneBased = pageNum,
                                text = embedded,
                                detectedLanguage = lang,
                                recognizedScript = lang?.suggestedOcrScript ?: script
                            )
                        )
                    } else if (isScriptSupported(script)) {
                        // Mixed PDF: fall back to bitmap OCR (Tesseract for Bengali, ML Kit for other scripts)
                        val outcome = pdfRendererHelper.renderPageOutcome(pdfPath, pageIdx, 1800, password)
                        if (outcome is PdfRenderOutcome.Success) {
                            val bmp = outcome.bitmap
                            try {
                                val ocrPage = recognizeSinglePageBitmap(bmp, pageNum, script, 0).getOrNull()
                                pageResults.add(ocrPage ?: OcrPageResult(pageNum, ""))
                            } finally {
                                if (!bmp.isRecycled) bmp.recycle()
                            }
                        } else {
                            pageResults.add(OcrPageResult(pageNum, ""))
                        }
                    } else {
                        pageResults.add(OcrPageResult(pageNum, ""))
                    }
                }
                if (pageResults.any { it.text.isNotBlank() }) {
                    return@withContext finalizeMultiPageResults(script, pageResults, emptyList())
                }
            }
        }

        if (script != OcrScript.AUTO) {
            validateProvider(script).getOrElse { return@withContext Result.failure(it) }
        } else if (!isScriptSupported(OcrScript.AUTO)) {
            return@withContext Result.failure(UnsupportedOperationException("No OCR provider is available."))
        }

        val initialIndex = pageIndicesZeroBased?.firstOrNull()?.coerceAtLeast(0) ?: 0
        val firstOutcome = pdfRendererHelper.renderPageOutcome(
            filePath = pdfPath,
            pageIndex = initialIndex,
            targetWidthPx = 1800,
            password = password
        )
        val totalDocPages = when (firstOutcome) {
            is PdfRenderOutcome.Success -> firstOutcome.totalPages.coerceAtLeast(1)
            is PdfRenderOutcome.PasswordRequired -> {
                return@withContext Result.failure(
                    IllegalStateException("This PDF is password protected. Enter the PDF password and retry.")
                )
            }
            is PdfRenderOutcome.Error -> {
                return@withContext Result.failure(IllegalStateException(firstOutcome.message))
            }
        }

        val targetIndices = pageIndicesZeroBased
            ?.filter { it in 0 until totalDocPages }
            ?.distinct()
            ?.sorted()
            ?.takeIf { it.isNotEmpty() }
            ?: (0 until totalDocPages).toList()

        val pageResults = mutableListOf<OcrPageResult>()
        val warnings = mutableListOf<String>()
        val totalTarget = targetIndices.size

        var firstBitmapConsumed = false
        try {
            targetIndices.forEachIndexed { stepIndex, pageIndex ->
                val pageNum = pageIndex + 1
                onProgress(stepIndex + 1, totalTarget)

                val bitmap = if (pageIndex == initialIndex && !firstBitmapConsumed) {
                    firstBitmapConsumed = true
                    (firstOutcome as PdfRenderOutcome.Success).bitmap
                } else {
                    when (val outcome = pdfRendererHelper.renderPageOutcome(pdfPath, pageIndex, 1800, password)) {
                        is PdfRenderOutcome.Success -> outcome.bitmap
                        is PdfRenderOutcome.PasswordRequired -> {
                            return@withContext Result.failure(IllegalStateException("PDF password required."))
                        }
                        is PdfRenderOutcome.Error -> {
                            return@withContext Result.failure(
                                IllegalStateException("Failed rendering page $pageNum: ${outcome.message}")
                            )
                        }
                    }
                }

                try {
                    val pageOutcome = recognizeSinglePageBitmap(
                        bitmap = bitmap,
                        pageNumberOneBased = pageNum,
                        script = script,
                        rotationDegrees = 0
                    ).getOrElse { return@withContext Result.failure(it) }
                    pageOutcome.qualityWarning?.let { warnings.add("Page $pageNum: $it") }
                    pageResults.add(pageOutcome)
                } finally {
                    if (!bitmap.isRecycled) {
                        bitmap.recycle()
                    }
                }
            }
        } finally {
            if (!firstBitmapConsumed) {
                val unused = (firstOutcome as? PdfRenderOutcome.Success)?.bitmap
                if (unused != null && !unused.isRecycled) {
                    unused.recycle()
                }
            }
        }

        finalizeMultiPageResults(script, pageResults, warnings)
    }

    private fun extractEmbeddedPdfPageTexts(pdfPath: String, password: String?): List<String>? {
        return runCatching {
            val mem = MemoryUsageSetting.setupTempFileOnly()
            val doc = if (password.isNullOrEmpty()) {
                PDDocument.load(File(pdfPath), mem)
            } else {
                PDDocument.load(File(pdfPath), password, mem)
            }
            doc.use { pd ->
                val count = pd.numberOfPages
                if (count <= 0) return@use null
                val stripper = PDFTextStripper()
                (1..count).map { pageNum ->
                    stripper.startPage = pageNum
                    stripper.endPage = pageNum
                    stripper.getText(pd).trim()
                }
            }
        }.getOrNull()
    }

    private fun validateProvider(script: OcrScript): Result<OcrProvider> {
        val provider = providers[script]
            ?: return Result.failure(UnsupportedOperationException("No OCR provider registered for ${script.label}."))
        if (!provider.isAvailable) {
            return Result.failure(
                UnsupportedOperationException("${script.label} OCR provider is not currently available.")
            )
        }
        return Result.success(provider)
    }

    private suspend fun extractPageInternal(
        bitmap: Bitmap,
        pageNumberOneBased: Int,
        script: OcrScript,
        rotationDegrees: Int
    ): Result<OcrExtractionResult> {
        if (script != OcrScript.AUTO) {
            validateProvider(script).getOrElse { return Result.failure(it) }
        } else if (!isScriptSupported(OcrScript.AUTO)) {
            return Result.failure(UnsupportedOperationException("No OCR provider is available."))
        }

        val pageResult = recognizeSinglePageBitmap(
            bitmap = bitmap,
            pageNumberOneBased = pageNumberOneBased,
            script = script,
            rotationDegrees = rotationDegrees
        ).getOrElse { return Result.failure(it) }

        val warnings = listOfNotNull(pageResult.qualityWarning)
        if (pageResult.text.isBlank()) {
            val blankReason = if (pageResult.qualityWarning != null) {
                "No readable text recognized (${pageResult.qualityWarning}). Try sharper focus, better lighting, or switching language."
            } else {
                "No readable text found in this image. Ensure clear contrast and try Auto Detect or another script."
            }
            return Result.failure(IllegalStateException(blankReason))
        }
        val detectedLang = pageResult.detectedLanguage
            ?: OcrLanguageDetector.detectLanguage(pageResult.text, pageResult.recognizedScript ?: script)
        return Result.success(
            OcrExtractionResult(
                script = script,
                pages = listOf(pageResult.copy(detectedLanguage = detectedLang)),
                combinedText = pageResult.text,
                warnings = warnings,
                detectedLanguage = detectedLang,
                effectiveScript = pageResult.recognizedScript ?: detectedLang?.suggestedOcrScript ?: script
            )
        )
    }

    private suspend fun recognizeSinglePageBitmap(
        bitmap: Bitmap,
        pageNumberOneBased: Int,
        script: OcrScript,
        rotationDegrees: Int
    ): Result<OcrPageResult> {
        if (bitmap.width <= 0 || bitmap.height <= 0 || bitmap.isRecycled) {
            return Result.failure(IllegalArgumentException("Page $pageNumberOneBased image is invalid or empty."))
        }
        val quality = BitmapFilterEngine.assessImageQuality(bitmap)
        if (quality.isBlankOrUniform) {
            return Result.success(
                OcrPageResult(
                    pageNumberOneBased = pageNumberOneBased,
                    text = "",
                    qualityWarning = "Image appears empty or uniform with minimal visual detail"
                )
            )
        }
        val warning = if (quality.isLikelyBlurry) {
            "Low edge sharpness detected — image may be blurry"
        } else {
            null
        }

        if (script == OcrScript.AUTO) {
            return recognizeAutoDetectBitmap(bitmap, pageNumberOneBased, rotationDegrees, warning)
        }

        // Bypass ML Kit whenever Bengali is selected -> route directly to Tesseract4Android ("ben+eng")
        val provider = validateProvider(script).getOrElse { return Result.failure(it) }
        val text = provider.recognizeBitmap(bitmap, rotationDegrees)
            .getOrElse { return Result.failure(it) }
        val detected = if (text.isNotBlank()) OcrLanguageDetector.detectLanguage(text, script) else null
        return Result.success(
            OcrPageResult(
                pageNumberOneBased = pageNumberOneBased,
                text = text,
                qualityWarning = warning,
                detectedLanguage = detected,
                recognizedScript = script
            )
        )
    }

    private suspend fun recognizeAutoDetectBitmap(
        bitmap: Bitmap,
        pageNumberOneBased: Int,
        rotationDegrees: Int,
        qualityWarning: String?
    ): Result<OcrPageResult> {
        val mlKitCandidateOrder = listOf(
            OcrScript.LATIN,
            OcrScript.DEVANAGARI,
            OcrScript.CHINESE,
            OcrScript.JAPANESE,
            OcrScript.KOREAN
        )
        val mlKitProviders = mlKitCandidateOrder
            .mapNotNull { providers[it] }
            .filter { it.isAvailable }
        val bengaliProvider = providers[OcrScript.BENGALI]?.takeIf { it.isAvailable }

        if (mlKitProviders.isEmpty() && bengaliProvider == null) {
            return Result.failure(UnsupportedOperationException("No OCR script recognizers are available."))
        }

        var bestScript: OcrScript = mlKitProviders.firstOrNull()?.script ?: OcrScript.BENGALI
        var bestText = ""
        var bestScore = -1.0
        var lastError: Throwable? = null

        for (provider in mlKitProviders) {
            val outcome = provider.recognizeBitmap(bitmap, rotationDegrees)
            outcome.onSuccess { raw ->
                val trimmed = raw.trim()
                if (trimmed.isNotEmpty()) {
                    val score = OcrLanguageDetector.scoreCandidateForScript(provider.script, trimmed)
                    if (score > bestScore) {
                        bestScore = score
                        bestText = trimmed
                        bestScript = provider.script
                    }
                }
            }.onFailure { err ->
                lastError = err
            }
        }

        // Evaluate Bengali Tesseract provider when:
        // 1) It's a custom/injected provider (e.g. unit tests) OR traineddata is cached/bundled, OR
        // 2) ML Kit detected Bengali characters or failed to find strong text on the image.
        if (bengaliProvider != null) {
            val detectedSoFar = bestText.takeIf { it.isNotBlank() }?.let {
                OcrLanguageDetector.detectByUnicodeScript(it)
            }
            val shouldRunBengali = when (bengaliProvider) {
                is TesseractBengaliOcrProvider -> {
                    bengaliProvider.hasTrainedDataReady() ||
                        detectedSoFar?.languageCode == "bn" ||
                        bestScore < 12.0
                }
                else -> true
            }
            if (shouldRunBengali) {
                val bnOutcome = bengaliProvider.recognizeBitmap(bitmap, rotationDegrees)
                bnOutcome.onSuccess { raw ->
                    val trimmed = raw.trim()
                    if (trimmed.isNotEmpty()) {
                        val score = OcrLanguageDetector.scoreCandidateForScript(OcrScript.BENGALI, trimmed)
                        if (score > bestScore) {
                            bestScore = score
                            bestText = trimmed
                            bestScript = OcrScript.BENGALI
                        }
                    }
                }.onFailure { err ->
                    // Do not override a valid ML Kit recognition if Bengali traineddata isn't bundled yet
                    if (bestText.isBlank()) {
                        lastError = err
                    }
                }
            }
        }

        if (bestText.isBlank() && lastError != null && bestScore < 0.0) {
            return Result.failure(lastError!!)
        }

        val detected = if (bestText.isNotBlank()) {
            OcrLanguageDetector.detectLanguage(bestText, bestScript)
        } else {
            null
        }

        return Result.success(
            OcrPageResult(
                pageNumberOneBased = pageNumberOneBased,
                text = bestText,
                qualityWarning = qualityWarning,
                detectedLanguage = detected,
                recognizedScript = bestScript
            )
        )
    }

    private suspend fun finalizeMultiPageResults(
        script: OcrScript,
        results: List<OcrPageResult>,
        warnings: List<String>
    ): Result<OcrExtractionResult> {
        if (results.all { it.text.isBlank() }) {
            val detail = warnings.firstOrNull()?.let { " ($it)" }.orEmpty()
            return Result.failure(
                IllegalStateException(
                    "No readable text could be recognized across ${results.size} page(s)$detail. Verify script selection and retry."
                )
            )
        }
        val combined = if (results.size == 1) {
            results.first().text
        } else {
            results.joinToString(separator = "\n\n") { page ->
                val body = page.text.ifBlank { "[No text recognized on this page]" }
                "--- Page ${page.pageNumberOneBased} ---\n$body"
            }
        }
        val dominantScript = results
            .mapNotNull { it.recognizedScript }
            .groupingBy { it }
            .eachCount()
            .maxByOrNull { it.value }
            ?.key ?: script
        val overallLang = OcrLanguageDetector.detectLanguage(combined, dominantScript)
            ?: results.firstNotNullOfOrNull { it.detectedLanguage }

        return Result.success(
            OcrExtractionResult(
                script = script,
                pages = results,
                combinedText = combined,
                warnings = warnings,
                detectedLanguage = overallLang,
                effectiveScript = dominantScript
            )
        )
    }

    companion object {

        /**
         * Copies `ben.traineddata` and `eng.traineddata` from `assets/tessdata/` into
         * `context.filesDir/tessdata/` if not already cached, returning the parent data directory
         * (`context.filesDir`) expected by `TessBaseAPI.init(dataPath, "ben+eng")`.
         */
        fun ensureTessDataCached(context: Context): Result<File> {
            return runCatching {
                val baseDir = context.filesDir
                val tessDir = File(baseDir, "tessdata").apply {
                    if (!exists()) mkdirs()
                }
                val assetManager = context.assets
                for (fileName in TesseractBengaliOcrProvider.REQUIRED_TRAINED_DATA_FILES) {
                    val targetFile = File(tessDir, fileName)
                    if (targetFile.exists() && targetFile.length() > 0L) {
                        continue
                    }
                    val tempFile = File(tessDir, "$fileName.tmp")
                    try {
                        assetManager.open("tessdata/$fileName").use { input ->
                            FileOutputStream(tempFile).use { output ->
                                input.copyTo(output, bufferSize = 16 * 1024)
                            }
                        }
                        if (tempFile.length() <= 0L) {
                            tempFile.delete()
                            throw IllegalStateException("Bundled asset tessdata/$fileName is empty.")
                        }
                        if (targetFile.exists()) targetFile.delete()
                        if (!tempFile.renameTo(targetFile)) {
                            tempFile.copyTo(targetFile, overwrite = true)
                            tempFile.delete()
                        }
                    } catch (e: Exception) {
                        if (tempFile.exists()) tempFile.delete()
                        throw IllegalStateException(
                            "Offline Bengali OCR model 'assets/tessdata/$fileName' was not found. " +
                                "Bundle ben.traineddata and eng.traineddata inside app/src/main/assets/tessdata/.",
                            e
                        )
                    }
                }
                baseDir
            }
        }

        /**
         * Returns true if `ben.traineddata` and `eng.traineddata` are either already cached in
         * `context.filesDir/tessdata/` or bundled inside `assets/tessdata/`.
         */
        fun hasBengaliTrainedData(context: Context): Boolean {
            val tessDir = File(context.filesDir, "tessdata")
            val cachedOnDisk = TesseractBengaliOcrProvider.REQUIRED_TRAINED_DATA_FILES.all { name ->
                val f = File(tessDir, name)
                f.exists() && f.length() > 0L
            }
            if (cachedOnDisk) return true
            val bundledAssets = runCatching { context.assets.list("tessdata")?.toSet().orEmpty() }
                .getOrDefault(emptySet())
            return TesseractBengaliOcrProvider.REQUIRED_TRAINED_DATA_FILES.all { it in bundledAssets }
        }

        fun defaultProviders(context: Context? = null): Map<OcrScript, OcrProvider> = mapOf(
            OcrScript.LATIN to MlKitOcrProvider(
                script = OcrScript.LATIN,
                engineName = "ML Kit Text Recognition v2 (Latin)",
                recognizerFactory = {
                    TextRecognition.getClient(TextRecognizerOptions.DEFAULT_OPTIONS)
                }
            ),
            OcrScript.DEVANAGARI to MlKitOcrProvider(
                script = OcrScript.DEVANAGARI,
                engineName = "ML Kit Text Recognition v2 (Devanagari)",
                recognizerFactory = {
                    TextRecognition.getClient(DevanagariTextRecognizerOptions.Builder().build())
                }
            ),
            OcrScript.BENGALI to TesseractBengaliOcrProvider(context = context),
            OcrScript.CHINESE to MlKitOcrProvider(
                script = OcrScript.CHINESE,
                engineName = "ML Kit Text Recognition v2 (Chinese)",
                recognizerFactory = {
                    TextRecognition.getClient(ChineseTextRecognizerOptions.Builder().build())
                }
            ),
            OcrScript.JAPANESE to MlKitOcrProvider(
                script = OcrScript.JAPANESE,
                engineName = "ML Kit Text Recognition v2 (Japanese)",
                recognizerFactory = {
                    TextRecognition.getClient(JapaneseTextRecognizerOptions.Builder().build())
                }
            ),
            OcrScript.KOREAN to MlKitOcrProvider(
                script = OcrScript.KOREAN,
                engineName = "ML Kit Text Recognition v2 (Korean)",
                recognizerFactory = {
                    TextRecognition.getClient(KoreanTextRecognizerOptions.Builder().build())
                }
            )
        )
    }
}
