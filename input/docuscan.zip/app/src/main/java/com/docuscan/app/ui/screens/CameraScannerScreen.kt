package com.docuscan.app.ui.screens

import android.Manifest
import android.content.pm.PackageManager
import android.content.res.Configuration
import android.hardware.SensorManager
import android.net.Uri
import android.view.OrientationEventListener
import android.view.Surface as AndroidSurface
import android.view.ViewGroup
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.PickVisualMediaRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.camera.core.CameraSelector
import androidx.camera.core.ImageCapture
import androidx.camera.core.ImageCaptureException
import androidx.camera.core.Preview
import androidx.camera.lifecycle.ProcessCameraProvider
import androidx.camera.view.PreviewView
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.tween
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.displayCutoutPadding
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.minimumInteractiveComponentSize
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.movableContentOf
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.platform.LocalConfiguration
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.core.content.ContextCompat
import androidx.lifecycle.compose.LocalLifecycleOwner
import com.docuscan.app.domain.model.CameraScanMode
import com.docuscan.app.ui.components.DocuScanCard
import com.docuscan.app.ui.icons.LucideIcons
import kotlinx.coroutines.delay
import java.io.File

@Composable
fun CameraScannerScreen(
    initialMode: CameraScanMode = CameraScanMode.DOCS,
    pendingPageCount: Int,
    idFrontCaptured: Boolean = false,
    idBackCaptured: Boolean = false,
    createOutputFile: () -> File,
    onCapturedFile: (File) -> Unit,
    onCapturedBookSpread: (File) -> Unit = onCapturedFile,
    onCapturedToText: (File) -> Unit = onCapturedFile,
    onCapturedIdSide: (isFront: Boolean, File) -> Unit = { _, file -> onCapturedFile(file) },
    onImportUri: (Uri) -> Unit,
    onImportUriForOcr: (Uri) -> Unit = onImportUri,
    onImportPdfUri: (Uri) -> Unit = {},
    onImportPdfForOcr: (Uri) -> Unit = onImportPdfUri,
    onOpenPageManager: () -> Unit,
    onOpenIdScanner: () -> Unit,
    onBack: () -> Unit
) {
    val context = LocalContext.current
    val lifecycleOwner = LocalLifecycleOwner.current
    val configuration = LocalConfiguration.current

    var activeModeName by rememberSaveable(initialMode) { mutableStateOf(initialMode.name) }
    val activeMode = CameraScanMode.fromName(activeModeName)

    // Book mode sub-option: Single Page vs Both Sides (defaults to Both Sides for open book spread splitting)
    var bookBothSides by rememberSaveable { mutableStateOf(true) }

    // ID Card mode side tracker (Front then Back)
    var idCaptureFront by rememberSaveable { mutableStateOf(!idFrontCaptured) }

    // Physical accelerometer orientation tracking (works even when Android Auto-Rotate is locked)
    var sensorLandscapeAngle by remember { mutableIntStateOf(0) }
    var sensorSurfaceRotation by remember { mutableIntStateOf(AndroidSurface.ROTATION_0) }

    DisposableEffect(context) {
        val orientationListener = object : OrientationEventListener(context, SensorManager.SENSOR_DELAY_UI) {
            override fun onOrientationChanged(orientation: Int) {
                if (orientation == ORIENTATION_UNKNOWN) return
                when {
                    orientation in 60..120 -> {
                        // Phone rotated clockwise (top edge points right) -> rotate UI counter-clockwise (-90°)
                        sensorLandscapeAngle = -90
                        sensorSurfaceRotation = AndroidSurface.ROTATION_270
                    }
                    orientation in 240..300 -> {
                        // Phone rotated counter-clockwise (top edge points left) -> rotate UI clockwise (+90°)
                        sensorLandscapeAngle = 90
                        sensorSurfaceRotation = AndroidSurface.ROTATION_90
                    }
                    orientation <= 35 || orientation >= 325 -> {
                        sensorLandscapeAngle = 0
                        sensorSurfaceRotation = AndroidSurface.ROTATION_0
                    }
                    orientation in 150..210 -> {
                        sensorLandscapeAngle = 0
                        sensorSurfaceRotation = AndroidSurface.ROTATION_180
                    }
                }
            }
        }
        runCatching {
            if (orientationListener.canDetectOrientation()) {
                orientationListener.enable()
            }
        }
        onDispose {
            runCatching { orientationListener.disable() }
        }
    }

    val isConfigLandscape = configuration.orientation == Configuration.ORIENTATION_LANDSCAPE
    val isLandscape = isConfigLandscape || sensorLandscapeAngle != 0
    val targetUiRotation = if (isConfigLandscape) 0f else sensorLandscapeAngle.toFloat()
    val animatedUiRotation by animateFloatAsState(
        targetValue = targetUiRotation,
        animationSpec = tween(durationMillis = 260),
        label = "cameraUiRotation"
    )

    // Transient confirmation banner (e.g., "Split into Left & Right pages!")
    var statusToast by remember { mutableStateOf<String?>(null) }
    LaunchedEffect(statusToast) {
        if (statusToast != null) {
            delay(2200)
            statusToast = null
        }
    }

    var hasCameraPermission by remember {
        mutableStateOf(
            ContextCompat.checkSelfPermission(context, Manifest.permission.CAMERA) ==
                PackageManager.PERMISSION_GRANTED
        )
    }
    var cameraError by remember { mutableStateOf<String?>(null) }
    var imageCapture by remember { mutableStateOf<ImageCapture?>(null) }
    var isCapturing by remember { mutableStateOf(false) }

    val previewView = remember {
        PreviewView(context).apply {
            layoutParams = ViewGroup.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.MATCH_PARENT
            )
            scaleType = PreviewView.ScaleType.FILL_CENTER
        }
    }

    // Bind CameraX once across orientation layout transitions
    DisposableEffect(previewView, lifecycleOwner, hasCameraPermission) {
        if (!hasCameraPermission) {
            onDispose {}
        } else {
            val cameraProviderFuture = ProcessCameraProvider.getInstance(context)
            var boundProvider: ProcessCameraProvider? = null
            cameraProviderFuture.addListener({
                runCatching {
                    val provider = cameraProviderFuture.get()
                    boundProvider = provider
                    val preview = Preview.Builder().build().apply {
                        setSurfaceProvider(previewView.surfaceProvider)
                    }
                    val initialRotation = previewView.display?.rotation ?: AndroidSurface.ROTATION_0
                    val capture = ImageCapture.Builder()
                        .setCaptureMode(ImageCapture.CAPTURE_MODE_MINIMIZE_LATENCY)
                        .setTargetRotation(initialRotation)
                        .build()
                    imageCapture = capture
                    provider.unbindAll()
                    provider.bindToLifecycle(
                        lifecycleOwner,
                        CameraSelector.DEFAULT_BACK_CAMERA,
                        preview,
                        capture
                    )
                }.onFailure { err ->
                    cameraError = err.message ?: "Camera hardware unavailable on this device."
                }
            }, ContextCompat.getMainExecutor(context))

            onDispose {
                runCatching { boundProvider?.unbindAll() }
                imageCapture = null
            }
        }
    }

    // Keep ImageCapture targetRotation synced with both OS display rotation and physical sensor rotation
    LaunchedEffect(imageCapture, isConfigLandscape, sensorSurfaceRotation, configuration.orientation) {
        val capture = imageCapture ?: return@LaunchedEffect
        val resolvedRotation = if (isConfigLandscape) {
            previewView.display?.rotation ?: sensorSurfaceRotation
        } else if (sensorLandscapeAngle != 0) {
            sensorSurfaceRotation
        } else {
            previewView.display?.rotation ?: AndroidSurface.ROTATION_0
        }
        capture.targetRotation = resolvedRotation
    }

    val permissionLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.RequestPermission(),
        onResult = { granted -> hasCameraPermission = granted }
    )

    val photoPickerLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.PickVisualMedia(),
        onResult = { uri ->
            if (uri != null) {
                when (activeMode) {
                    CameraScanMode.TO_TEXT -> onImportUriForOcr(uri)
                    else -> onImportUri(uri)
                }
            }
        }
    )

    val pdfPickerLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.OpenDocument(),
        onResult = { uri ->
            if (uri != null) {
                when (activeMode) {
                    CameraScanMode.TO_TEXT -> onImportPdfForOcr(uri)
                    else -> onImportPdfUri(uri)
                }
            }
        }
    )

    fun triggerCapture() {
        val capture = imageCapture
        if (capture != null && !isCapturing) {
            isCapturing = true
            capture.targetRotation = if (isConfigLandscape) {
                previewView.display?.rotation ?: sensorSurfaceRotation
            } else if (sensorLandscapeAngle != 0) {
                sensorSurfaceRotation
            } else {
                previewView.display?.rotation ?: AndroidSurface.ROTATION_0
            }
            val file = createOutputFile()
            val outputOptions = ImageCapture.OutputFileOptions.Builder(file).build()
            capture.takePicture(
                outputOptions,
                ContextCompat.getMainExecutor(context),
                object : ImageCapture.OnImageSavedCallback {
                    override fun onImageSaved(outputFileResults: ImageCapture.OutputFileResults) {
                        isCapturing = false
                        when (activeMode) {
                            CameraScanMode.DOCS -> {
                                onCapturedFile(file)
                            }
                            CameraScanMode.BOOK -> {
                                if (bookBothSides) {
                                    statusToast = "Splitting spread into Left & Right pages..."
                                    onCapturedBookSpread(file)
                                } else {
                                    onCapturedFile(file)
                                }
                            }
                            CameraScanMode.ID_CARD -> {
                                val wasFront = idCaptureFront
                                onCapturedIdSide(wasFront, file)
                                if (wasFront) {
                                    idCaptureFront = false
                                    statusToast = "Front saved · Now scan Back side"
                                } else {
                                    statusToast = "Back saved · Opening ID Studio"
                                    onOpenIdScanner()
                                }
                            }
                            CameraScanMode.TO_TEXT -> {
                                onCapturedToText(file)
                            }
                        }
                    }

                    override fun onError(exception: ImageCaptureException) {
                        isCapturing = false
                        cameraError = exception.message
                    }
                }
            )
        }
    }

    // Preserves the live CameraX PreviewView smoothly across Portrait <-> Landscape layout switches
    val liveCameraPreviewContent = remember(previewView) {
        movableContentOf {
            AndroidView(
                factory = {
                    (previewView.parent as? ViewGroup)?.removeView(previewView)
                    previewView
                },
                modifier = Modifier.fillMaxSize()
            )
        }
    }

    BoxWithConstraints(
        modifier = Modifier
            .fillMaxSize()
            .background(Color(0xFF0B0B0B))
            .statusBarsPadding()
            .navigationBarsPadding()
            .displayCutoutPadding()
    ) {
        val useWideLandscapeLayout = isConfigLandscape || maxWidth > maxHeight

        if (useWideLandscapeLayout) {
            // TRUE WIDE LANDSCAPE LAYOUT: full horizontal viewfinder + right thumb capture rail
            Row(modifier = Modifier.fillMaxSize()) {
                Column(
                    modifier = Modifier
                        .weight(1f)
                        .fillMaxHeight()
                        .padding(start = 10.dp, top = 6.dp, bottom = 6.dp, end = 6.dp),
                    verticalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    Box(
                        modifier = Modifier
                            .weight(1f)
                            .fillMaxWidth()
                            .clip(MaterialTheme.shapes.large)
                            .border(
                                1.5.dp,
                                MaterialTheme.colorScheme.primary.copy(alpha = 0.55f),
                                MaterialTheme.shapes.large
                            ),
                        contentAlignment = Alignment.Center
                    ) {
                        if (hasCameraPermission && cameraError == null) {
                            liveCameraPreviewContent()
                            CameraViewfinderOverlay(
                                activeMode = activeMode,
                                bookBothSides = bookBothSides,
                                idCaptureFront = idCaptureFront,
                                isLandscape = true,
                                isConfigLandscape = true,
                                sensorLandscapeAngle = sensorLandscapeAngle,
                                controlRotationDegrees = 0f
                            )
                        } else {
                            CameraFallbackCard(
                                cameraError = cameraError,
                                onRequestPermission = { permissionLauncher.launch(Manifest.permission.CAMERA) },
                                onImportGallery = {
                                    photoPickerLauncher.launch(
                                        PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageOnly)
                                    )
                                }
                            )
                        }

                        // Floating translucent top bar over wide landscape viewfinder
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .align(Alignment.TopCenter)
                                .padding(horizontal = 10.dp, vertical = 8.dp),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Surface(
                                onClick = onBack,
                                shape = CircleShape,
                                color = Color.Black.copy(alpha = 0.55f),
                                modifier = Modifier
                                    .size(44.dp)
                                    .minimumInteractiveComponentSize()
                                    .testTag("camera_back_btn")
                            ) {
                                Box(contentAlignment = Alignment.Center) {
                                    Icon(
                                        imageVector = LucideIcons.ArrowLeft,
                                        contentDescription = "Back",
                                        tint = Color.White,
                                        modifier = Modifier.size(20.dp)
                                    )
                                }
                            }

                            CameraTopCenterBadge(
                                activeMode = activeMode,
                                bookBothSides = bookBothSides,
                                onToggleBookSides = { bookBothSides = it },
                                idCaptureFront = idCaptureFront,
                                idFrontCaptured = idFrontCaptured,
                                idBackCaptured = idBackCaptured,
                                onSelectIdFront = { idCaptureFront = true },
                                onSelectIdBack = { idCaptureFront = false },
                                pendingPageCount = pendingPageCount
                            )

                            if (activeMode == CameraScanMode.ID_CARD) {
                                Surface(
                                    onClick = onOpenIdScanner,
                                    shape = RoundedCornerShape(20.dp),
                                    color = MaterialTheme.colorScheme.primary.copy(alpha = 0.22f),
                                    border = BorderStroke(1.dp, MaterialTheme.colorScheme.primary),
                                    modifier = Modifier.testTag("camera_id_studio_btn")
                                ) {
                                    Text(
                                        text = "Studio",
                                        style = MaterialTheme.typography.labelMedium,
                                        color = MaterialTheme.colorScheme.primary,
                                        modifier = Modifier.padding(horizontal = 12.dp, vertical = 7.dp)
                                    )
                                }
                            } else {
                                Spacer(modifier = Modifier.size(44.dp))
                            }
                        }

                        val toast = statusToast
                        if (toast != null) {
                            Surface(
                                shape = RoundedCornerShape(999.dp),
                                color = MaterialTheme.colorScheme.primary,
                                modifier = Modifier
                                    .align(Alignment.TopCenter)
                                    .padding(top = 56.dp)
                            ) {
                                Text(
                                    text = toast,
                                    style = MaterialTheme.typography.labelMedium,
                                    fontWeight = FontWeight.SemiBold,
                                    color = MaterialTheme.colorScheme.onPrimary,
                                    modifier = Modifier.padding(horizontal = 14.dp, vertical = 6.dp)
                                )
                            }
                        }
                    }

                    // Compact mode selector bar directly below the wide landscape viewfinder
                    CameraModeSelectorBar(
                        activeMode = activeMode,
                        controlRotationDegrees = 0f,
                        onSelectMode = { activeModeName = it.name }
                    )
                }

                // Right vertical capture rail (ergonomic landscape controls)
                Column(
                    modifier = Modifier
                        .width(104.dp)
                        .fillMaxHeight()
                        .padding(horizontal = 8.dp, vertical = 12.dp),
                    horizontalAlignment = Alignment.CenterHorizontally,
                    verticalArrangement = Arrangement.SpaceBetween
                ) {
                    Column(
                        horizontalAlignment = Alignment.CenterHorizontally,
                        verticalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        CompactCameraDockAction(
                            label = "Import",
                            icon = LucideIcons.Images,
                            iconRotationDegrees = 0f,
                            testTag = "camera_gallery_btn",
                            onClick = {
                                photoPickerLauncher.launch(
                                    PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageOnly)
                                )
                            }
                        )
                        CompactCameraDockAction(
                            label = "Import PDF",
                            icon = LucideIcons.FileUp,
                            iconRotationDegrees = 0f,
                            testTag = "camera_import_pdf_btn",
                            onClick = {
                                pdfPickerLauncher.launch(arrayOf("application/pdf"))
                            }
                        )
                    }

                    CameraShutterButton(
                        activeMode = activeMode,
                        enabled = hasCameraPermission && cameraError == null && !isCapturing,
                        isCapturing = isCapturing,
                        iconRotationDegrees = 0f,
                        onClick = ::triggerCapture
                    )

                    if (activeMode == CameraScanMode.ID_CARD) {
                        CompactCameraDockAction(
                            label = "ID Studio",
                            icon = LucideIcons.IdCard,
                            badgeCount = (if (idFrontCaptured) 1 else 0) + (if (idBackCaptured) 1 else 0),
                            iconRotationDegrees = 0f,
                            testTag = "camera_pages_btn",
                            onClick = onOpenIdScanner
                        )
                    } else {
                        CompactCameraDockAction(
                            label = if (pendingPageCount > 0) "Pages ($pendingPageCount)" else "Pages",
                            icon = LucideIcons.Layers,
                            badgeCount = pendingPageCount,
                            iconRotationDegrees = 0f,
                            testTag = "camera_pages_btn",
                            onClick = onOpenPageManager
                        )
                    }
                }
            }
        } else {
            // PORTRAIT LAYOUT (with smooth UI rotation adaptation if physically tilted while portrait-locked)
            Column(modifier = Modifier.fillMaxSize()) {
                // Top Overlay Controls (mode-aware)
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 12.dp, vertical = 10.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    IconButton(
                        onClick = onBack,
                        modifier = Modifier
                            .minimumInteractiveComponentSize()
                            .testTag("camera_back_btn")
                    ) {
                        Icon(
                            imageVector = LucideIcons.ArrowLeft,
                            contentDescription = "Back",
                            tint = Color.White,
                            modifier = Modifier.graphicsLayer { rotationZ = animatedUiRotation }
                        )
                    }

                    CameraTopCenterBadge(
                        activeMode = activeMode,
                        bookBothSides = bookBothSides,
                        onToggleBookSides = { bookBothSides = it },
                        idCaptureFront = idCaptureFront,
                        idFrontCaptured = idFrontCaptured,
                        idBackCaptured = idBackCaptured,
                        onSelectIdFront = { idCaptureFront = true },
                        onSelectIdBack = { idCaptureFront = false },
                        pendingPageCount = pendingPageCount
                    )

                    if (activeMode == CameraScanMode.ID_CARD) {
                        Surface(
                            onClick = onOpenIdScanner,
                            shape = RoundedCornerShape(20.dp),
                            color = MaterialTheme.colorScheme.primary.copy(alpha = 0.16f),
                            border = BorderStroke(1.dp, MaterialTheme.colorScheme.primary),
                            modifier = Modifier.testTag("camera_id_studio_btn")
                        ) {
                            Text(
                                text = "Studio",
                                style = MaterialTheme.typography.labelMedium,
                                color = MaterialTheme.colorScheme.primary,
                                modifier = Modifier.padding(horizontal = 12.dp, vertical = 7.dp)
                            )
                        }
                    } else {
                        Spacer(modifier = Modifier.size(48.dp))
                    }
                }

                // Camera Viewfinder or Permission Card
                Box(
                    modifier = Modifier
                        .weight(1f)
                        .fillMaxWidth()
                        .padding(horizontal = 16.dp)
                        .clip(MaterialTheme.shapes.large)
                        .border(
                            1.5.dp,
                            MaterialTheme.colorScheme.primary.copy(alpha = 0.55f),
                            MaterialTheme.shapes.large
                        ),
                    contentAlignment = Alignment.Center
                ) {
                    if (hasCameraPermission && cameraError == null) {
                        liveCameraPreviewContent()
                        CameraViewfinderOverlay(
                            activeMode = activeMode,
                            bookBothSides = bookBothSides,
                            idCaptureFront = idCaptureFront,
                            isLandscape = isLandscape,
                            isConfigLandscape = false,
                            sensorLandscapeAngle = sensorLandscapeAngle,
                            controlRotationDegrees = animatedUiRotation
                        )
                    } else {
                        CameraFallbackCard(
                            cameraError = cameraError,
                            onRequestPermission = { permissionLauncher.launch(Manifest.permission.CAMERA) },
                            onImportGallery = {
                                photoPickerLauncher.launch(
                                    PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageOnly)
                                )
                            }
                        )
                    }

                    // Live capture status pill
                    val toast = statusToast
                    if (toast != null) {
                        Surface(
                            shape = RoundedCornerShape(999.dp),
                            color = MaterialTheme.colorScheme.primary,
                            modifier = Modifier
                                .align(Alignment.TopCenter)
                                .padding(top = 12.dp)
                                .graphicsLayer { rotationZ = animatedUiRotation }
                        ) {
                            Text(
                                text = toast,
                                style = MaterialTheme.typography.labelMedium,
                                fontWeight = FontWeight.SemiBold,
                                color = MaterialTheme.colorScheme.onPrimary,
                                modifier = Modifier.padding(horizontal = 14.dp, vertical = 6.dp)
                            )
                        }
                    }
                }

                Spacer(modifier = Modifier.height(10.dp))

                // Horizontal Scrollable Mode Selector Bar: Book · To Text · Docs · ID Card
                CameraModeSelectorBar(
                    activeMode = activeMode,
                    controlRotationDegrees = animatedUiRotation,
                    onSelectMode = { activeModeName = it.name }
                )

                // Bottom Capture Dock: Pages/Studio (Left) | Circular Shutter (Center) | Import + Import PDF (Right)
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 16.dp, vertical = 16.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Box(
                        modifier = Modifier.weight(1f),
                        contentAlignment = Alignment.CenterStart
                    ) {
                        if (activeMode == CameraScanMode.ID_CARD) {
                            CompactCameraDockAction(
                                label = "ID Studio",
                                icon = LucideIcons.IdCard,
                                badgeCount = (if (idFrontCaptured) 1 else 0) + (if (idBackCaptured) 1 else 0),
                                iconRotationDegrees = animatedUiRotation,
                                testTag = "camera_pages_btn",
                                onClick = onOpenIdScanner
                            )
                        } else {
                            CompactCameraDockAction(
                                label = if (pendingPageCount > 0) "Pages ($pendingPageCount)" else "Pages",
                                icon = LucideIcons.Layers,
                                badgeCount = pendingPageCount,
                                iconRotationDegrees = animatedUiRotation,
                                testTag = "camera_pages_btn",
                                onClick = onOpenPageManager
                            )
                        }
                    }

                    CameraShutterButton(
                        activeMode = activeMode,
                        enabled = hasCameraPermission && cameraError == null && !isCapturing,
                        isCapturing = isCapturing,
                        iconRotationDegrees = animatedUiRotation,
                        onClick = ::triggerCapture
                    )

                    Row(
                        modifier = Modifier.weight(1f),
                        horizontalArrangement = Arrangement.spacedBy(10.dp, Alignment.End),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        CompactCameraDockAction(
                            label = "Import",
                            icon = LucideIcons.Images,
                            iconRotationDegrees = animatedUiRotation,
                            testTag = "camera_gallery_btn",
                            onClick = {
                                photoPickerLauncher.launch(
                                    PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageOnly)
                                )
                            }
                        )
                        CompactCameraDockAction(
                            label = "Import PDF",
                            icon = LucideIcons.FileUp,
                            iconRotationDegrees = animatedUiRotation,
                            testTag = "camera_import_pdf_btn",
                            onClick = {
                                pdfPickerLauncher.launch(arrayOf("application/pdf"))
                            }
                        )
                    }
                }
            }
        }
    }
}

@Composable
private fun CameraTopCenterBadge(
    activeMode: CameraScanMode,
    bookBothSides: Boolean,
    onToggleBookSides: (Boolean) -> Unit,
    idCaptureFront: Boolean,
    idFrontCaptured: Boolean,
    idBackCaptured: Boolean,
    onSelectIdFront: () -> Unit,
    onSelectIdBack: () -> Unit,
    pendingPageCount: Int
) {
    when (activeMode) {
        CameraScanMode.BOOK -> {
            BookSpreadModeToggle(
                bothSides = bookBothSides,
                onToggle = onToggleBookSides
            )
        }

        CameraScanMode.ID_CARD -> {
            IdSideToggleBar(
                isFront = idCaptureFront,
                frontCaptured = idFrontCaptured,
                backCaptured = idBackCaptured,
                onSelectFront = onSelectIdFront,
                onSelectBack = onSelectIdBack
            )
        }

        CameraScanMode.TO_TEXT -> {
            Surface(
                shape = RoundedCornerShape(20.dp),
                color = MaterialTheme.colorScheme.surfaceContainer,
                border = BorderStroke(1.dp, MaterialTheme.colorScheme.primary.copy(alpha = 0.6f))
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(6.dp),
                    modifier = Modifier.padding(horizontal = 14.dp, vertical = 7.dp)
                ) {
                    Icon(
                        imageVector = LucideIcons.Type,
                        contentDescription = null,
                        tint = MaterialTheme.colorScheme.primary,
                        modifier = Modifier.size(15.dp)
                    )
                    Text(
                        text = "Scan to Text · OCR",
                        style = MaterialTheme.typography.labelLarge,
                        color = MaterialTheme.colorScheme.primary
                    )
                }
            }
        }

        CameraScanMode.DOCS -> {
            Surface(
                shape = RoundedCornerShape(20.dp),
                color = MaterialTheme.colorScheme.surfaceContainer,
                border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline)
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                    modifier = Modifier.padding(horizontal = 14.dp, vertical = 7.dp)
                ) {
                    Text(
                        text = "Docs Scanner",
                        style = MaterialTheme.typography.labelLarge,
                        color = Color.White
                    )
                    if (pendingPageCount > 0) {
                        Surface(
                            shape = CircleShape,
                            color = MaterialTheme.colorScheme.primary,
                            modifier = Modifier.testTag("camera_live_page_badge")
                        ) {
                            Text(
                                text = "$pendingPageCount",
                                style = MaterialTheme.typography.labelSmall,
                                fontWeight = FontWeight.Bold,
                                color = MaterialTheme.colorScheme.onPrimary,
                                modifier = Modifier.padding(horizontal = 7.dp, vertical = 2.dp)
                            )
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun CameraModeSelectorBar(
    activeMode: CameraScanMode,
    controlRotationDegrees: Float,
    onSelectMode: (CameraScanMode) -> Unit
) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .horizontalScroll(rememberScrollState())
            .padding(horizontal = 16.dp),
        horizontalArrangement = Arrangement.spacedBy(8.dp, Alignment.CenterHorizontally),
        verticalAlignment = Alignment.CenterVertically
    ) {
        CameraScanMode.entries.forEach { mode ->
            val isSelected = activeMode == mode
            Surface(
                onClick = { onSelectMode(mode) },
                shape = RoundedCornerShape(999.dp),
                color = if (isSelected) {
                    MaterialTheme.colorScheme.primary
                } else {
                    Color(0xFF1C1C1C)
                },
                border = if (isSelected) {
                    null
                } else {
                    BorderStroke(1.dp, Color(0xFF333333))
                },
                modifier = Modifier
                    .testTag("camera_mode_${mode.name.lowercase()}")
            ) {
                Text(
                    text = mode.label,
                    style = MaterialTheme.typography.labelLarge,
                    fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Medium,
                    color = if (isSelected) {
                        MaterialTheme.colorScheme.onPrimary
                    } else {
                        Color.White.copy(alpha = 0.85f)
                    },
                    maxLines = 1,
                    modifier = Modifier.padding(horizontal = 16.dp, vertical = 8.dp)
                )
            }
        }
    }
}

@Composable
private fun CameraShutterButton(
    activeMode: CameraScanMode,
    enabled: Boolean,
    isCapturing: Boolean,
    iconRotationDegrees: Float,
    onClick: () -> Unit
) {
    Surface(
        onClick = onClick,
        enabled = enabled,
        shape = CircleShape,
        color = if (enabled || isCapturing) {
            MaterialTheme.colorScheme.primary
        } else {
            MaterialTheme.colorScheme.surfaceContainer
        },
        border = BorderStroke(3.dp, Color.White),
        modifier = Modifier
            .size(74.dp)
            .testTag("camera_shutter_btn")
    ) {
        Box(contentAlignment = Alignment.Center) {
            if (isCapturing) {
                CircularProgressIndicator(
                    color = MaterialTheme.colorScheme.onPrimary,
                    strokeWidth = 2.5.dp,
                    modifier = Modifier.size(28.dp)
                )
            } else {
                Icon(
                    imageVector = LucideIcons.Camera,
                    contentDescription = "Capture ${activeMode.label}",
                    tint = if (enabled) {
                        MaterialTheme.colorScheme.onPrimary
                    } else {
                        Color.Gray
                    },
                    modifier = Modifier
                        .size(30.dp)
                        .graphicsLayer { rotationZ = iconRotationDegrees }
                )
            }
        }
    }
}

@Composable
private fun CameraFallbackCard(
    cameraError: String?,
    onRequestPermission: () -> Unit,
    onImportGallery: () -> Unit
) {
    DocuScanCard(modifier = Modifier.padding(24.dp)) {
        Column(
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            Icon(
                imageVector = LucideIcons.Camera,
                contentDescription = "Camera",
                tint = MaterialTheme.colorScheme.primary,
                modifier = Modifier.size(44.dp)
            )
            Text(
                text = if (cameraError != null) "Camera Unavailable" else "Camera Permission Needed",
                style = MaterialTheme.typography.titleMedium,
                textAlign = TextAlign.Center
            )
            Text(
                text = cameraError ?: "Grant camera permission to capture documents live, or import images and PDFs below.",
                style = MaterialTheme.typography.bodyMedium,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
                textAlign = TextAlign.Center
            )
            if (cameraError == null) {
                Button(
                    onClick = onRequestPermission,
                    colors = ButtonDefaults.buttonColors(
                        containerColor = MaterialTheme.colorScheme.primary,
                        contentColor = MaterialTheme.colorScheme.onPrimary
                    ),
                    modifier = Modifier.testTag("grant_camera_btn")
                ) {
                    Text("Enable Camera")
                }
            }
            OutlinedButton(
                onClick = onImportGallery,
                modifier = Modifier.testTag("camera_fallback_import_btn")
            ) {
                Icon(
                    imageVector = LucideIcons.Images,
                    contentDescription = null,
                    modifier = Modifier.size(18.dp)
                )
                Spacer(modifier = Modifier.size(8.dp))
                Text("Import from Gallery")
            }
        }
    }
}

@Composable
private fun BookSpreadModeToggle(
    bothSides: Boolean,
    onToggle: (Boolean) -> Unit
) {
    Surface(
        shape = RoundedCornerShape(999.dp),
        color = Color(0xFF1C1C1C).copy(alpha = 0.92f),
        border = BorderStroke(1.dp, Color(0xFF333333))
    ) {
        Row(
            modifier = Modifier.padding(3.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            BookToggleChip(
                label = "Single Page",
                selected = !bothSides,
                testTag = "book_mode_single",
                onClick = { onToggle(false) }
            )
            BookToggleChip(
                label = "Both Sides",
                selected = bothSides,
                testTag = "book_mode_both",
                onClick = { onToggle(true) }
            )
        }
    }
}

@Composable
private fun BookToggleChip(
    label: String,
    selected: Boolean,
    testTag: String,
    onClick: () -> Unit
) {
    Surface(
        onClick = onClick,
        shape = RoundedCornerShape(999.dp),
        color = if (selected) MaterialTheme.colorScheme.primary else Color.Transparent,
        modifier = Modifier.testTag(testTag)
    ) {
        Text(
            text = label,
            style = MaterialTheme.typography.labelSmall,
            fontWeight = if (selected) FontWeight.Bold else FontWeight.Medium,
            color = if (selected) MaterialTheme.colorScheme.onPrimary else Color.White.copy(alpha = 0.8f),
            modifier = Modifier.padding(horizontal = 12.dp, vertical = 6.dp)
        )
    }
}

@Composable
private fun IdSideToggleBar(
    isFront: Boolean,
    frontCaptured: Boolean,
    backCaptured: Boolean,
    onSelectFront: () -> Unit,
    onSelectBack: () -> Unit
) {
    Surface(
        shape = RoundedCornerShape(999.dp),
        color = Color(0xFF1C1C1C).copy(alpha = 0.92f),
        border = BorderStroke(1.dp, Color(0xFF333333))
    ) {
        Row(
            modifier = Modifier.padding(3.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            BookToggleChip(
                label = if (frontCaptured) "Front ✓" else "Front",
                selected = isFront,
                testTag = "camera_id_front_chip",
                onClick = onSelectFront
            )
            BookToggleChip(
                label = if (backCaptured) "Back ✓" else "Back",
                selected = !isFront,
                testTag = "camera_id_back_chip",
                onClick = onSelectBack
            )
        }
    }
}

@Composable
private fun CompactCameraDockAction(
    label: String,
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    badgeCount: Int = 0,
    iconRotationDegrees: Float = 0f,
    testTag: String,
    onClick: () -> Unit
) {
    Column(
        horizontalAlignment = Alignment.CenterHorizontally,
        modifier = Modifier
            .clip(RoundedCornerShape(12.dp))
            .clickable(onClick = onClick)
            .minimumInteractiveComponentSize()
            .padding(horizontal = 4.dp, vertical = 2.dp)
            .testTag(testTag)
    ) {
        Box {
            Surface(
                shape = CircleShape,
                color = MaterialTheme.colorScheme.surfaceContainer,
                border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline),
                modifier = Modifier.size(46.dp)
            ) {
                Box(contentAlignment = Alignment.Center) {
                    Icon(
                        imageVector = icon,
                        contentDescription = label,
                        tint = MaterialTheme.colorScheme.primary,
                        modifier = Modifier
                            .size(20.dp)
                            .graphicsLayer { rotationZ = iconRotationDegrees }
                    )
                }
            }
            if (badgeCount > 0) {
                Surface(
                    shape = CircleShape,
                    color = MaterialTheme.colorScheme.primary,
                    modifier = Modifier.align(Alignment.TopEnd)
                ) {
                    Text(
                        text = "$badgeCount",
                        style = MaterialTheme.typography.labelSmall,
                        fontWeight = FontWeight.Bold,
                        color = MaterialTheme.colorScheme.onPrimary,
                        modifier = Modifier.padding(horizontal = 5.dp, vertical = 1.dp)
                    )
                }
            }
        }
        Spacer(modifier = Modifier.height(4.dp))
        Text(
            text = label,
            style = MaterialTheme.typography.labelSmall,
            color = Color.White,
            maxLines = 1,
            overflow = TextOverflow.Ellipsis
        )
    }
}
