package com.docuscan.app.pdf

import android.content.Context
import android.graphics.Bitmap
import android.graphics.Color
import android.graphics.pdf.PdfRenderer
import android.os.Bundle
import android.os.CancellationSignal
import android.os.ParcelFileDescriptor
import android.print.PageRange
import android.print.PrintAttributes
import android.print.PrintDocumentAdapter
import android.print.PrintDocumentInfo
import android.print.PrintManager
import com.docuscan.app.scanner.BitmapFilterEngine
import com.tom_roush.pdfbox.android.PDFBoxResourceLoader
import com.tom_roush.pdfbox.io.MemoryUsageSetting
import com.tom_roush.pdfbox.pdmodel.PDDocument
import com.tom_roush.pdfbox.pdmodel.encryption.InvalidPasswordException
import com.tom_roush.pdfbox.rendering.PDFRenderer
import kotlinx.coroutines.CoroutineDispatcher
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.io.File
import java.io.FileInputStream
import java.io.FileOutputStream
import kotlin.math.max
import kotlin.math.roundToInt

sealed interface PdfRenderOutcome {
    data class Success(val bitmap: Bitmap, val totalPages: Int) : PdfRenderOutcome
    data object PasswordRequired : PdfRenderOutcome
    data class Error(val message: String) : PdfRenderOutcome
}

class PdfRendererHelper(
    private val context: Context? = null,
    private val ioDispatcher: CoroutineDispatcher = Dispatchers.IO
) {

    private fun ensurePdfBoxReady() {
        if (context != null && !PDFBoxResourceLoader.isReady()) {
            PDFBoxResourceLoader.init(context.applicationContext)
        }
    }

    suspend fun getPageCount(filePath: String, password: String? = null): Int =
        withContext(ioDispatcher) {
            val file = File(filePath)
            if (!file.exists()) return@withContext 0
            if (password.isNullOrEmpty()) {
                val nativeCount = runCatching {
                    ParcelFileDescriptor.open(file, ParcelFileDescriptor.MODE_READ_ONLY).use { fd ->
                        PdfRenderer(fd).use { it.pageCount }
                    }
                }.getOrDefault(0)
                if (nativeCount > 0) return@withContext nativeCount
            }
            ensurePdfBoxReady()
            runCatching {
                val mem = MemoryUsageSetting.setupTempFileOnly()
                val doc = if (!password.isNullOrEmpty()) {
                    PDDocument.load(file, password, mem)
                } else {
                    PDDocument.load(file, mem)
                }
                doc.use { it.numberOfPages }
            }.getOrDefault(0)
        }

    suspend fun renderPageOutcome(
        filePath: String,
        pageIndex: Int,
        targetWidthPx: Int = 1200,
        password: String? = null
    ): PdfRenderOutcome = withContext(ioDispatcher) {
        val file = File(filePath)
        if (!file.exists()) return@withContext PdfRenderOutcome.Error("PDF file not found on device.")

        val maxDim = BitmapFilterEngine.MAX_SAFE_IMAGE_DIMENSION
        val clampedWidth = targetWidthPx.coerceIn(200, maxDim)

        // Try native Android PdfRenderer first for unencrypted files (fast, single-page, low memory)
        if (password.isNullOrEmpty()) {
            val nativeResult = runCatching {
                ParcelFileDescriptor.open(file, ParcelFileDescriptor.MODE_READ_ONLY).use { fd ->
                    PdfRenderer(fd).use { renderer ->
                        val total = renderer.pageCount
                        if (pageIndex !in 0 until total) return@runCatching null
                        renderer.openPage(pageIndex).use { page ->
                            val rawScale = clampedWidth.toFloat() / page.width.coerceAtLeast(1).toFloat()
                            var width = (page.width * rawScale).roundToInt().coerceAtLeast(200)
                            var height = (page.height * rawScale).roundToInt().coerceAtLeast(200)
                            // Cap longest edge to 2560px to prevent OOM on tall or ultra-wide pages
                            val largest = max(width, height)
                            if (largest > maxDim) {
                                val capRatio = maxDim.toFloat() / largest.toFloat()
                                width = (width * capRatio).roundToInt().coerceAtLeast(1)
                                height = (height * capRatio).roundToInt().coerceAtLeast(1)
                            }
                            val bitmap = Bitmap.createBitmap(width, height, Bitmap.Config.ARGB_8888)
                            try {
                                bitmap.eraseColor(Color.WHITE)
                                page.render(bitmap, null, null, PdfRenderer.Page.RENDER_MODE_FOR_DISPLAY)
                                PdfRenderOutcome.Success(bitmap, total)
                            } catch (t: Throwable) {
                                if (!bitmap.isRecycled) bitmap.recycle()
                                throw t
                            }
                        }
                    }
                }
            }.getOrNull()
            if (nativeResult != null) return@withContext nativeResult
        }

        // Fall back to PDFBox single-page rendering (handles encrypted PDFs and JVM tests)
        ensurePdfBoxReady()
        try {
            val mem = MemoryUsageSetting.setupTempFileOnly()
            val doc = if (!password.isNullOrEmpty()) {
                PDDocument.load(file, password, mem)
            } else {
                PDDocument.load(file, mem)
            }
            doc.use { pdDoc ->
                val total = pdDoc.numberOfPages
                if (pageIndex !in 0 until total) {
                    return@withContext PdfRenderOutcome.Error("Page out of range.")
                }
                val pageBox = pdDoc.getPage(pageIndex).mediaBox
                val pageLongest = max(pageBox.width, pageBox.height).coerceAtLeast(100f)
                val desiredScale = (clampedWidth.toFloat() / pageBox.width.coerceAtLeast(100f)).coerceIn(0.8f, 3.0f)
                val maxSafeScale = maxDim.toFloat() / pageLongest
                val safeScale = minOf(desiredScale, maxSafeScale).coerceAtLeast(0.5f)
                val renderer = PDFRenderer(pdDoc)
                val rawRendered = renderer.renderImage(pageIndex, safeScale)
                val finalBitmap = BitmapFilterEngine.ensureWithinMaxDimension(
                    bitmap = rawRendered,
                    maxDimension = maxDim,
                    recycleSourceIfScaled = true
                )
                PdfRenderOutcome.Success(finalBitmap, total)
            }
        } catch (_: InvalidPasswordException) {
            PdfRenderOutcome.PasswordRequired
        } catch (oom: OutOfMemoryError) {
            PdfRenderOutcome.Error("Page is too large for available memory. Try reducing quality or closing background apps.")
        } catch (t: Throwable) {
            PdfRenderOutcome.Error(t.message ?: "Failed to render PDF page.")
        }
    }

    suspend fun renderPage(
        filePath: String,
        pageIndex: Int,
        targetWidthPx: Int = 1200,
        password: String? = null
    ): Bitmap? = (renderPageOutcome(filePath, pageIndex, targetWidthPx, password) as? PdfRenderOutcome.Success)?.bitmap

    fun printPdf(context: Context, filePath: String, jobName: String): Boolean {
        val file = File(filePath)
        if (!file.exists()) return false
        val printManager = context.getSystemService(Context.PRINT_SERVICE) as? PrintManager ?: return false
        val adapter = object : PrintDocumentAdapter() {
            override fun onLayout(
                oldAttributes: PrintAttributes?,
                newAttributes: PrintAttributes?,
                cancellationSignal: CancellationSignal?,
                callback: LayoutResultCallback?,
                extras: Bundle?
            ) {
                if (cancellationSignal?.isCanceled == true) {
                    callback?.onLayoutCancelled()
                    return
                }
                val info = PrintDocumentInfo.Builder("$jobName.pdf")
                    .setContentType(PrintDocumentInfo.CONTENT_TYPE_DOCUMENT)
                    .setPageCount(PrintDocumentInfo.PAGE_COUNT_UNKNOWN)
                    .build()
                callback?.onLayoutFinished(info, true)
            }

            override fun onWrite(
                pages: Array<out PageRange>?,
                destination: ParcelFileDescriptor?,
                cancellationSignal: CancellationSignal?,
                callback: WriteResultCallback?
            ) {
                if (destination == null) {
                    callback?.onWriteFailed("Invalid print destination")
                    return
                }
                try {
                    FileInputStream(file).use { input ->
                        FileOutputStream(destination.fileDescriptor).use { output ->
                            input.copyTo(output)
                        }
                    }
                    callback?.onWriteFinished(arrayOf(PageRange.ALL_PAGES))
                } catch (e: Exception) {
                    callback?.onWriteFailed(e.message ?: "Print write error")
                }
            }
        }
        printManager.print("DocuScan_$jobName", adapter, PrintAttributes.Builder().build())
        return true
    }
}
