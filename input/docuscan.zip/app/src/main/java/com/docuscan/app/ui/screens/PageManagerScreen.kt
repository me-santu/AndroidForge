package com.docuscan.app.ui.screens

import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.graphics.Bitmap
import android.net.Uri
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.PickVisualMediaRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.WindowInsetsSides
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.only
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.safeDrawing
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.itemsIndexed
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.selection.SelectionContainer
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FilterChipDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.minimumInteractiveComponentSize
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import coil.compose.AsyncImage
import com.docuscan.app.domain.model.IdSideScanState
import com.docuscan.app.domain.model.NormalizedCropRect
import com.docuscan.app.domain.model.ScanFilter
import com.docuscan.app.domain.model.ScanPage
import com.docuscan.app.scanner.BitmapFilterEngine
import com.docuscan.app.ui.components.DocuScanTopBar
import com.docuscan.app.ui.components.EmptyStateView
import com.docuscan.app.ui.components.LoadingStateView
import com.docuscan.app.ui.icons.LucideIcons
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.File

@Composable
fun PageManagerScreen(
    pages: List<ScanPage>,
    activeDocumentTitle: String? = null,
    isEditingExistingPdf: Boolean = false,
    isBatchFiltering: Boolean = false,
    onAddAnotherScan: () -> Unit,
    onImportUri: (Uri) -> Unit,
    onImportMultipleUris: ((List<Uri>) -> Unit)? = null,
    onEditPage: (String) -> Unit,
    onRotatePage: (String, Int) -> Unit,
    onCropPage: (String, NormalizedCropRect) -> Unit = { _, _ -> },
    onSetPageFilter: (String, ScanFilter) -> Unit = { _, _ -> },
    onApplyFilterToAllPages: (ScanFilter) -> Unit = {},
    onMovePage: (String, Int) -> Unit,
    onRemovePage: (String) -> Unit,
    onClearAll: () -> Unit,
    onExportFinalPdf: () -> Unit,
    onSaveEditedPdf: (overwriteOriginal: Boolean, newTitle: String?) -> Unit = { _, _ -> onExportFinalPdf() },
    onExtractPageText: (suspend (ScanPage) -> String)? = null,
    onBack: () -> Unit
) {
    val photoPickerLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.PickMultipleVisualMedia(maxItems = 50),
        onResult = { uris ->
            if (uris.isNotEmpty()) {
                if (onImportMultipleUris != null) {
                    onImportMultipleUris(uris)
                } else {
                    uris.forEach(onImportUri)
                }
            }
        }
    )
    var previewPageId by remember { mutableStateOf<String?>(null) }
    var cropTargetPageId by remember { mutableStateOf<String?>(null) }
    var showBatchFilterDialog by remember { mutableStateOf(false) }
    var showSaveEditDialog by remember { mutableStateOf(false) }

    val previewPage = pages.firstOrNull { it.id == previewPageId }
    val cropTargetPage = pages.firstOrNull { it.id == cropTargetPageId }

    Scaffold(
        modifier = Modifier.fillMaxSize(),
        containerColor = MaterialTheme.colorScheme.background,
        contentWindowInsets = WindowInsets.safeDrawing.only(
            WindowInsetsSides.Bottom + WindowInsetsSides.Horizontal
        ),
        topBar = {
            DocuScanTopBar(
                title = if (isEditingExistingPdf) "Edit Existing PDF" else "Page Manager",
                subtitle = activeDocumentTitle?.let { "$it · ${pages.size} page(s)" }
                    ?: "${pages.size} page(s) in current batch",
                onBack = onBack,
                actions = {
                    if (pages.isNotEmpty()) {
                        TextButton(
                            onClick = onClearAll,
                            modifier = Modifier.testTag("page_mgr_clear_btn")
                        ) {
                            Text("Clear", color = MaterialTheme.colorScheme.error)
                        }
                    }
                }
            )
        }
    ) { innerPadding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
                .padding(horizontal = 16.dp, vertical = 12.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                OutlinedButton(
                    onClick = onAddAnotherScan,
                    modifier = Modifier
                        .weight(1f)
                        .minimumInteractiveComponentSize()
                        .testTag("page_mgr_add_scan_btn")
                ) {
                    Icon(LucideIcons.ScanLine, contentDescription = null, modifier = Modifier.size(16.dp))
                    Spacer(modifier = Modifier.size(6.dp))
                    Text("Add Scan", maxLines = 1)
                }
                OutlinedButton(
                    onClick = {
                        photoPickerLauncher.launch(
                            PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageOnly)
                        )
                    },
                    modifier = Modifier
                        .weight(1f)
                        .minimumInteractiveComponentSize()
                        .testTag("page_mgr_gallery_btn")
                ) {
                    Icon(LucideIcons.ImagePlus, contentDescription = null, modifier = Modifier.size(16.dp))
                    Spacer(modifier = Modifier.size(6.dp))
                    Text("Import", maxLines = 1)
                }
                if (pages.isNotEmpty()) {
                    OutlinedButton(
                        onClick = { showBatchFilterDialog = true },
                        modifier = Modifier
                            .minimumInteractiveComponentSize()
                            .testTag("page_mgr_batch_filter_btn")
                    ) {
                        Icon(
                            LucideIcons.Sparkles,
                            contentDescription = "Batch Filter",
                            tint = MaterialTheme.colorScheme.primary,
                            modifier = Modifier.size(16.dp)
                        )
                    }
                }
            }

            if (pages.isEmpty()) {
                Box(
                    modifier = Modifier
                        .weight(1f)
                        .fillMaxWidth(),
                    contentAlignment = Alignment.Center
                ) {
                    EmptyStateView(
                        title = "No pages in your batch",
                        subtitle = "Scan documents with the camera hub or import images from your gallery.",
                        actionLabel = "Add Scan",
                        onAction = onAddAnotherScan
                    )
                }
            } else {
                LazyVerticalGrid(
                    columns = GridCells.Adaptive(156.dp),
                    modifier = Modifier.weight(1f),
                    contentPadding = PaddingValues(vertical = 4.dp),
                    verticalArrangement = Arrangement.spacedBy(12.dp),
                    horizontalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    itemsIndexed(pages, key = { _, page -> page.id }) { index, page ->
                        Surface(
                            shape = MaterialTheme.shapes.medium,
                            color = MaterialTheme.colorScheme.surfaceContainer,
                            border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline),
                            modifier = Modifier.testTag("page_card_${page.id}")
                        ) {
                            Column(modifier = Modifier.padding(10.dp)) {
                                Box(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .height(160.dp)
                                        .clip(RoundedCornerShape(12.dp))
                                        .background(MaterialTheme.colorScheme.surface)
                                        .clickable { previewPageId = page.id }
                                        .testTag("page_thumb_${index}")
                                ) {
                                    AsyncImage(
                                        model = File(page.sourcePath),
                                        contentDescription = "Page ${index + 1}",
                                        contentScale = ContentScale.Crop,
                                        modifier = Modifier
                                            .fillMaxSize()
                                            .graphicsLayer {
                                                rotationZ = page.rotationDegrees.toFloat()
                                            }
                                    )
                                    Surface(
                                        shape = RoundedCornerShape(8.dp),
                                        color = MaterialTheme.colorScheme.background.copy(alpha = 0.85f),
                                        modifier = Modifier
                                            .align(Alignment.TopStart)
                                            .padding(6.dp)
                                    ) {
                                        Text(
                                            text = "P${index + 1} · ${page.filter.label}",
                                            style = MaterialTheme.typography.labelSmall,
                                            color = MaterialTheme.colorScheme.primary,
                                            modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                                        )
                                    }
                                    Surface(
                                        onClick = { onRemovePage(page.id) },
                                        shape = CircleShape,
                                        color = MaterialTheme.colorScheme.background.copy(alpha = 0.85f),
                                        modifier = Modifier
                                            .align(Alignment.TopEnd)
                                            .padding(6.dp)
                                            .size(28.dp)
                                            .testTag("page_delete_${index}")
                                    ) {
                                        Box(contentAlignment = Alignment.Center) {
                                            Icon(
                                                imageVector = LucideIcons.X,
                                                contentDescription = "Remove page ${index + 1}",
                                                tint = MaterialTheme.colorScheme.error,
                                                modifier = Modifier.size(16.dp)
                                            )
                                        }
                                    }
                                    Surface(
                                        onClick = { previewPageId = page.id },
                                        shape = RoundedCornerShape(8.dp),
                                        color = MaterialTheme.colorScheme.background.copy(alpha = 0.78f),
                                        modifier = Modifier
                                            .align(Alignment.BottomEnd)
                                            .padding(6.dp)
                                    ) {
                                        Icon(
                                            imageVector = LucideIcons.Eye,
                                            contentDescription = "Preview page ${index + 1}",
                                            tint = Color.White,
                                            modifier = Modifier
                                                .padding(4.dp)
                                                .size(15.dp)
                                        )
                                    }
                                }

                                Spacer(modifier = Modifier.height(8.dp))

                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.SpaceBetween,
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    IconButton(
                                        onClick = { onMovePage(page.id, -1) },
                                        enabled = index > 0,
                                        modifier = Modifier
                                            .size(34.dp)
                                            .testTag("page_move_left_${index}")
                                    ) {
                                        Icon(
                                            imageVector = LucideIcons.ArrowLeft,
                                            contentDescription = "Move page earlier",
                                            modifier = Modifier.size(17.dp)
                                        )
                                    }
                                    IconButton(
                                        onClick = { cropTargetPageId = page.id },
                                        modifier = Modifier
                                            .size(34.dp)
                                            .testTag("page_crop_${index}")
                                    ) {
                                        Icon(
                                            imageVector = LucideIcons.Crop,
                                            contentDescription = "Crop page",
                                            tint = MaterialTheme.colorScheme.primary,
                                            modifier = Modifier.size(17.dp)
                                        )
                                    }
                                    IconButton(
                                        onClick = { onRotatePage(page.id, 90) },
                                        modifier = Modifier
                                            .size(34.dp)
                                            .testTag("page_rotate_${index}")
                                    ) {
                                        Icon(
                                            imageVector = LucideIcons.RotateCw,
                                            contentDescription = "Rotate page 90°",
                                            tint = MaterialTheme.colorScheme.primary,
                                            modifier = Modifier.size(17.dp)
                                        )
                                    }
                                    IconButton(
                                        onClick = { onEditPage(page.id) },
                                        modifier = Modifier
                                            .size(34.dp)
                                            .testTag("page_edit_${index}")
                                    ) {
                                        Icon(
                                            imageVector = LucideIcons.Pencil,
                                            contentDescription = "Edit filters",
                                            modifier = Modifier.size(17.dp)
                                        )
                                    }
                                    IconButton(
                                        onClick = { onMovePage(page.id, 1) },
                                        enabled = index < pages.lastIndex,
                                        modifier = Modifier
                                            .size(34.dp)
                                            .testTag("page_move_right_${index}")
                                    ) {
                                        Icon(
                                            imageVector = LucideIcons.ArrowRight,
                                            contentDescription = "Move page later",
                                            modifier = Modifier.size(17.dp)
                                        )
                                    }
                                }
                            }
                        }
                    }
                }
            }

            // Bottom Primary CTA cleanly padded above Android system navigation bar
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .navigationBarsPadding()
                    .padding(top = 6.dp, bottom = 8.dp)
            ) {
                Button(
                    onClick = {
                        if (isEditingExistingPdf) {
                            showSaveEditDialog = true
                        } else {
                            onExportFinalPdf()
                        }
                    },
                    enabled = pages.isNotEmpty() && !isBatchFiltering,
                    colors = ButtonDefaults.buttonColors(
                        containerColor = MaterialTheme.colorScheme.primary,
                        contentColor = MaterialTheme.colorScheme.onPrimary
                    ),
                    shape = MaterialTheme.shapes.medium,
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(52.dp)
                        .testTag("page_mgr_create_pdf_btn")
                ) {
                    if (isBatchFiltering) {
                        CircularProgressIndicator(
                            color = MaterialTheme.colorScheme.onPrimary,
                            strokeWidth = 2.dp,
                            modifier = Modifier.size(18.dp)
                        )
                        Spacer(modifier = Modifier.size(8.dp))
                        Text("Applying Filter to All Pages...")
                    } else {
                        Icon(LucideIcons.FileText, contentDescription = null, modifier = Modifier.size(18.dp))
                        Spacer(modifier = Modifier.size(8.dp))
                        Text(
                            if (isEditingExistingPdf) {
                                "Save PDF Changes (${pages.size})"
                            } else {
                                "Export Final PDF (${pages.size})"
                            }
                        )
                    }
                }
            }
        }
    }

    if (previewPage != null) {
        PagePreviewDialog(
            page = previewPage,
            pageNumber = pages.indexOfFirst { it.id == previewPage.id } + 1,
            totalPages = pages.size,
            isBatchFiltering = isBatchFiltering,
            onCrop = {
                val id = previewPage.id
                cropTargetPageId = id
            },
            onRotate = { onRotatePage(previewPage.id, 90) },
            onSelectFilter = { filter -> onSetPageFilter(previewPage.id, filter) },
            onApplyFilterToAll = onApplyFilterToAllPages,
            onExtractPageText = onExtractPageText,
            onDismiss = { previewPageId = null }
        )
    }

    if (cropTargetPage != null) {
        IdCardCropStudioDialog(
            title = "Crop Page ${pages.indexOfFirst { it.id == cropTargetPage.id } + 1}",
            sideState = IdSideScanState(
                imagePath = cropTargetPage.sourcePath,
                cropRect = cropTargetPage.cropRect,
                filter = cropTargetPage.filter,
                rotationDegrees = cropTargetPage.rotationDegrees
            ),
            aspectRatio = 0.707f,
            onRotate90 = { onRotatePage(cropTargetPage.id, 90) },
            onDismiss = { cropTargetPageId = null },
            onApplyCrop = { newRect ->
                onCropPage(cropTargetPage.id, newRect)
                cropTargetPageId = null
            }
        )
    }

    if (showBatchFilterDialog) {
        var selectedFilter by remember { mutableStateOf(ScanFilter.MAGIC_COLOR) }
        AlertDialog(
            onDismissRequest = { showBatchFilterDialog = false },
            title = { Text("Apply Filter to All Pages") },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
                    Text(
                        text = "Choose an enhancement preset to apply across all ${pages.size} pages in this batch.",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .horizontalScroll(rememberScrollState()),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        ScanFilter.primaryFilters.forEach { filter ->
                            FilterChip(
                                selected = selectedFilter == filter,
                                onClick = { selectedFilter = filter },
                                label = { Text(filter.label) },
                                colors = FilterChipDefaults.filterChipColors(
                                    selectedContainerColor = MaterialTheme.colorScheme.primary,
                                    selectedLabelColor = MaterialTheme.colorScheme.onPrimary
                                )
                            )
                        }
                    }
                }
            },
            confirmButton = {
                Button(
                    onClick = {
                        showBatchFilterDialog = false
                        onApplyFilterToAllPages(selectedFilter)
                    },
                    colors = ButtonDefaults.buttonColors(
                        containerColor = MaterialTheme.colorScheme.primary,
                        contentColor = MaterialTheme.colorScheme.onPrimary
                    ),
                    modifier = Modifier.testTag("batch_filter_confirm_btn")
                ) {
                    Text("Apply to All (${pages.size})")
                }
            },
            dismissButton = {
                TextButton(onClick = { showBatchFilterDialog = false }) { Text("Cancel") }
            }
        )
    }

    if (showSaveEditDialog) {
        var copyTitle by remember(activeDocumentTitle) {
            mutableStateOf("${activeDocumentTitle ?: "Edited_Document"}_Edited")
        }
        AlertDialog(
            onDismissRequest = { showSaveEditDialog = false },
            title = { Text("Save Edited PDF") },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
                    Text(
                        text = "Overwrite the original PDF in place, or save your edits as a separate copy.",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                    OutlinedTextField(
                        value = copyTitle,
                        onValueChange = { copyTitle = it },
                        label = { Text("Title if saving as new copy") },
                        singleLine = true,
                        modifier = Modifier.fillMaxWidth()
                    )
                }
            },
            confirmButton = {
                Button(
                    onClick = {
                        showSaveEditDialog = false
                        onSaveEditedPdf(true, null)
                    },
                    colors = ButtonDefaults.buttonColors(
                        containerColor = MaterialTheme.colorScheme.primary,
                        contentColor = MaterialTheme.colorScheme.onPrimary
                    ),
                    modifier = Modifier.testTag("edit_pdf_overwrite_btn")
                ) {
                    Text("Overwrite Original")
                }
            },
            dismissButton = {
                Row(horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                    TextButton(onClick = { showSaveEditDialog = false }) {
                        Text("Cancel")
                    }
                    TextButton(
                        enabled = copyTitle.isNotBlank(),
                        onClick = {
                            showSaveEditDialog = false
                            onSaveEditedPdf(false, copyTitle.trim())
                        },
                        modifier = Modifier.testTag("edit_pdf_save_copy_btn")
                    ) {
                        Text("Save as New Copy")
                    }
                }
            }
        )
    }
}

@Composable
private fun PagePreviewDialog(
    page: ScanPage,
    pageNumber: Int,
    totalPages: Int,
    isBatchFiltering: Boolean,
    onCrop: () -> Unit,
    onRotate: () -> Unit,
    onSelectFilter: (ScanFilter) -> Unit,
    onApplyFilterToAll: (ScanFilter) -> Unit,
    onExtractPageText: (suspend (ScanPage) -> String)?,
    onDismiss: () -> Unit
) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    var previewBitmap by remember { mutableStateOf<Bitmap?>(null) }
    var showFilterSheet by remember { mutableStateOf(false) }
    var activeTabIsText by remember { mutableStateOf(false) }
    var extractedText by remember(page.id) { mutableStateOf<String?>(null) }
    var isExtractingText by remember { mutableStateOf(false) }

    LaunchedEffect(page.sourcePath, page.cropRect, page.filter, page.rotationDegrees) {
        previewBitmap = withContext(Dispatchers.IO) {
            val base = BitmapFilterEngine.decodeSampledBitmap(page.sourcePath, 1600) ?: return@withContext null
            BitmapFilterEngine.cropAndTransform(base, page.cropRect, page.rotationDegrees, page.filter)
        }
    }

    LaunchedEffect(activeTabIsText, page.id) {
        if (activeTabIsText && extractedText == null && onExtractPageText != null && !isExtractingText) {
            isExtractingText = true
            extractedText = runCatching { onExtractPageText(page) }.getOrElse { "" }
            isExtractingText = false
        }
    }

    Dialog(
        onDismissRequest = onDismiss,
        properties = DialogProperties(
            usePlatformDefaultWidth = false,
            decorFitsSystemWindows = false
        )
    ) {
        Surface(
            modifier = Modifier
                .fillMaxSize()
                .background(MaterialTheme.colorScheme.background)
                .statusBarsPadding(),
            color = MaterialTheme.colorScheme.surface
        ) {
            Column(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(horizontal = 16.dp, vertical = 12.dp),
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                // Header
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column {
                        Text(
                            text = "Page $pageNumber of $totalPages",
                            style = MaterialTheme.typography.titleMedium
                        )
                        Text(
                            text = "${page.filter.label} · ${page.rotationDegrees}°",
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                    IconButton(onClick = onDismiss) {
                        Icon(LucideIcons.X, contentDescription = "Close preview")
                    }
                }

                // Segmented Image | Text Toggle
                if (onExtractPageText != null) {
                    ImageTextSegmentedSwitch(
                        isTextSelected = activeTabIsText,
                        onSelectImage = { activeTabIsText = false },
                        onSelectText = { activeTabIsText = true }
                    )
                }

                // Main Content Viewport
                Box(
                    modifier = Modifier
                        .weight(1f)
                        .fillMaxWidth()
                        .clip(MaterialTheme.shapes.medium)
                        .background(MaterialTheme.colorScheme.background),
                    contentAlignment = Alignment.Center
                ) {
                    if (activeTabIsText) {
                        when {
                            isExtractingText -> LoadingStateView("Extracting page text offline...")
                            extractedText.isNullOrBlank() -> {
                                Column(
                                    horizontalAlignment = Alignment.CenterHorizontally,
                                    verticalArrangement = Arrangement.spacedBy(8.dp),
                                    modifier = Modifier.padding(24.dp)
                                ) {
                                    Text("No text detected on this page", style = MaterialTheme.typography.titleSmall)
                                    OutlinedButton(
                                        onClick = {
                                            if (onExtractPageText != null) {
                                                scope.launch {
                                                    isExtractingText = true
                                                    extractedText = runCatching { onExtractPageText(page) }.getOrElse { "" }
                                                    isExtractingText = false
                                                }
                                            }
                                        }
                                    ) {
                                        Text("Re-scan Text")
                                    }
                                }
                            }
                            else -> {
                                Column(
                                    modifier = Modifier
                                        .fillMaxSize()
                                        .padding(14.dp),
                                    verticalArrangement = Arrangement.spacedBy(10.dp)
                                ) {
                                    Row(
                                        modifier = Modifier.fillMaxWidth(),
                                        horizontalArrangement = Arrangement.End
                                    ) {
                                        OutlinedButton(
                                            onClick = {
                                                val clipboard = context.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
                                                clipboard.setPrimaryClip(ClipData.newPlainText("Page Text", extractedText))
                                            }
                                        ) {
                                            Icon(LucideIcons.Copy, contentDescription = null, modifier = Modifier.size(16.dp))
                                            Spacer(modifier = Modifier.size(6.dp))
                                            Text("Copy Text")
                                        }
                                    }
                                    SelectionContainer(
                                        modifier = Modifier
                                            .weight(1f)
                                            .fillMaxWidth()
                                            .verticalScroll(rememberScrollState())
                                    ) {
                                        Text(
                                            text = extractedText.orEmpty(),
                                            style = MaterialTheme.typography.bodyMedium,
                                            color = MaterialTheme.colorScheme.onBackground
                                        )
                                    }
                                }
                            }
                        }
                    } else {
                        val bmp = previewBitmap
                        if (bmp != null) {
                            Image(
                                bitmap = bmp.asImageBitmap(),
                                contentDescription = "Page $pageNumber preview",
                                contentScale = ContentScale.Fit,
                                modifier = Modifier
                                    .fillMaxSize()
                                    .padding(8.dp)
                            )
                        } else {
                            LoadingStateView("Rendering preview...")
                        }
                    }
                }

                // Inline Filter Sheet with "Apply Filter to All Pages" batch button
                if (showFilterSheet) {
                    Surface(
                        shape = RoundedCornerShape(16.dp),
                        color = MaterialTheme.colorScheme.surfaceContainer,
                        border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Column(
                            modifier = Modifier.padding(12.dp),
                            verticalArrangement = Arrangement.spacedBy(10.dp)
                        ) {
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .horizontalScroll(rememberScrollState()),
                                horizontalArrangement = Arrangement.spacedBy(8.dp)
                            ) {
                                ScanFilter.primaryFilters.forEach { filter ->
                                    FilterChip(
                                        selected = page.filter == filter,
                                        onClick = { onSelectFilter(filter) },
                                        label = { Text(filter.label) },
                                        colors = FilterChipDefaults.filterChipColors(
                                            selectedContainerColor = MaterialTheme.colorScheme.primary,
                                            selectedLabelColor = MaterialTheme.colorScheme.onPrimary
                                        ),
                                        modifier = Modifier.testTag("preview_filter_${filter.name.lowercase()}")
                                    )
                                }
                            }
                            if (totalPages > 1) {
                                OutlinedButton(
                                    onClick = { onApplyFilterToAll(page.filter) },
                                    enabled = !isBatchFiltering,
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .testTag("preview_apply_filter_all_btn")
                                ) {
                                    Icon(
                                        LucideIcons.Sparkles,
                                        contentDescription = null,
                                        tint = MaterialTheme.colorScheme.primary,
                                        modifier = Modifier.size(16.dp)
                                    )
                                    Spacer(modifier = Modifier.size(6.dp))
                                    Text("Apply '${page.filter.label}' to All $totalPages Pages")
                                }
                            }
                        }
                    }
                }

                // Bottom Action Bar — cleanly lifted above Android system navigation bar
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .navigationBarsPadding()
                        .padding(top = 12.dp, bottom = 16.dp),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    OutlinedButton(
                        onClick = onCrop,
                        modifier = Modifier
                            .weight(1f)
                            .minimumInteractiveComponentSize()
                            .testTag("preview_crop_btn")
                    ) {
                        Icon(LucideIcons.Crop, contentDescription = null, modifier = Modifier.size(16.dp))
                        Spacer(modifier = Modifier.size(4.dp))
                        Text("Crop", maxLines = 1)
                    }
                    OutlinedButton(
                        onClick = onRotate,
                        modifier = Modifier
                            .weight(1f)
                            .minimumInteractiveComponentSize()
                            .testTag("preview_rotate_btn")
                    ) {
                        Icon(LucideIcons.RotateCw, contentDescription = null, modifier = Modifier.size(16.dp))
                        Spacer(modifier = Modifier.size(4.dp))
                        Text("Rotate 90°", maxLines = 1)
                    }
                    Button(
                        onClick = { showFilterSheet = !showFilterSheet },
                        colors = ButtonDefaults.buttonColors(
                            containerColor = MaterialTheme.colorScheme.primary,
                            contentColor = MaterialTheme.colorScheme.onPrimary
                        ),
                        modifier = Modifier
                            .weight(1f)
                            .minimumInteractiveComponentSize()
                            .testTag("preview_filters_btn")
                    ) {
                        Icon(LucideIcons.SlidersHorizontal, contentDescription = null, modifier = Modifier.size(16.dp))
                        Spacer(modifier = Modifier.size(4.dp))
                        Text("Filters", maxLines = 1)
                    }
                }
            }
        }
    }
}

@Composable
internal fun ImageTextSegmentedSwitch(
    isTextSelected: Boolean,
    onSelectImage: () -> Unit,
    onSelectText: () -> Unit,
    modifier: Modifier = Modifier
) {
    Surface(
        shape = RoundedCornerShape(14.dp),
        color = MaterialTheme.colorScheme.surfaceContainer,
        border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline),
        modifier = modifier.fillMaxWidth()
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(4.dp),
            horizontalArrangement = Arrangement.spacedBy(4.dp)
        ) {
            SegmentedTabPill(
                label = "Image",
                icon = LucideIcons.Image,
                selected = !isTextSelected,
                testTag = "preview_tab_image",
                onClick = onSelectImage,
                modifier = Modifier.weight(1f)
            )
            SegmentedTabPill(
                label = "Text",
                icon = LucideIcons.Type,
                selected = isTextSelected,
                testTag = "preview_tab_text",
                onClick = onSelectText,
                modifier = Modifier.weight(1f)
            )
        }
    }
}

@Composable
private fun SegmentedTabPill(
    label: String,
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    selected: Boolean,
    testTag: String,
    onClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    Surface(
        onClick = onClick,
        shape = RoundedCornerShape(10.dp),
        color = if (selected) MaterialTheme.colorScheme.primary else Color.Transparent,
        modifier = modifier.testTag(testTag)
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(vertical = 8.dp),
            horizontalArrangement = Arrangement.Center,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Icon(
                imageVector = icon,
                contentDescription = null,
                tint = if (selected) MaterialTheme.colorScheme.onPrimary else MaterialTheme.colorScheme.onSurfaceVariant,
                modifier = Modifier.size(16.dp)
            )
            Spacer(modifier = Modifier.size(6.dp))
            Text(
                text = label,
                style = MaterialTheme.typography.labelLarge,
                fontWeight = if (selected) FontWeight.Bold else FontWeight.Medium,
                color = if (selected) MaterialTheme.colorScheme.onPrimary else MaterialTheme.colorScheme.onSurfaceVariant
            )
        }
    }
}
