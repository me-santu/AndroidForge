package com.docuscan.app.ui.screens

import android.graphics.Bitmap
import android.graphics.Paint
import android.graphics.Path as AndroidPath
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.WindowInsetsSides
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.only
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.safeDrawing
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import com.docuscan.app.ui.icons.LucideIcons
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Slider
import androidx.compose.material3.SnackbarHost
import androidx.compose.material3.SnackbarHostState
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.minimumInteractiveComponentSize
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.StrokeJoin
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.toArgb
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.layout.onSizeChanged
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.unit.IntSize
import androidx.compose.ui.unit.dp
import coil.compose.AsyncImage
import com.docuscan.app.domain.model.SignatureItem
import com.docuscan.app.ui.components.DocuScanCard
import com.docuscan.app.ui.components.DocuScanTopBar
import java.io.ByteArrayOutputStream
import java.io.File

private data class SignatureStroke(
    val points: List<Offset>,
    val color: Color,
    val strokeWidth: Float
)

@Composable
fun SignatureCreatorScreen(
    savedSignatures: List<SignatureItem>,
    statusMessage: String?,
    onSaveSignature: (name: String, pngBytes: ByteArray) -> Unit,
    onDeleteSignature: (Long) -> Unit,
    onApplySignatureToPdf: (signatureId: Long) -> Unit,
    onClearMessage: () -> Unit,
    onBack: () -> Unit
) {
    val snackbarHostState = remember { SnackbarHostState() }
    val strokes = remember { mutableStateListOf<SignatureStroke>() }
    var activePoints by remember { mutableStateOf<List<Offset>>(emptyList()) }
    var selectedColor by remember { mutableStateOf(Color(0xFF141414)) }
    var strokeWidth by remember { mutableFloatStateOf(7f) }
    var signatureName by remember { mutableStateOf("My Signature") }
    var canvasSize by remember { mutableStateOf(IntSize(800, 360)) }

    LaunchedEffect(statusMessage) {
        if (!statusMessage.isNullOrBlank()) {
            snackbarHostState.showSnackbar(statusMessage)
            onClearMessage()
        }
    }

    val colorChoices = listOf(
        Color(0xFF141414),
        Color(0xFF1D4ED8),
        Color(0xFFD99B16)
    )

    Scaffold(
        modifier = Modifier.fillMaxSize(),
        containerColor = MaterialTheme.colorScheme.background,
        contentWindowInsets = WindowInsets.safeDrawing.only(WindowInsetsSides.Bottom + WindowInsetsSides.Horizontal),
        snackbarHost = { SnackbarHost(snackbarHostState) },
        topBar = {
            DocuScanTopBar(
                title = "Signature Creator",
                subtitle = "Draw & save reusable signatures locally",
                onBack = onBack
            )
        }
    ) { innerPadding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
                .verticalScroll(rememberScrollState())
                .padding(horizontal = 16.dp, vertical = 12.dp),
            verticalArrangement = Arrangement.spacedBy(14.dp)
        ) {
            OutlinedTextField(
                value = signatureName,
                onValueChange = { signatureName = it },
                label = { Text("Signature Label") },
                singleLine = true,
                modifier = Modifier
                    .fillMaxWidth()
                    .testTag("signature_name_input")
            )

            // Drawing Pad (Light paper surface for clean dark-ink legibility)
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .height(220.dp)
                    .clip(MaterialTheme.shapes.large)
                    .background(Color(0xFFFAF9F6))
                    .border(1.5.dp, MaterialTheme.colorScheme.primary.copy(alpha = 0.65f), MaterialTheme.shapes.large)
                    .onSizeChanged { canvasSize = it }
                    .pointerInput(selectedColor, strokeWidth) {
                        detectDragGestures(
                            onDragStart = { offset ->
                                activePoints = listOf(offset)
                            },
                            onDrag = { change, _ ->
                                change.consume()
                                activePoints = activePoints + change.position
                            },
                            onDragEnd = {
                                if (activePoints.size >= 2) {
                                    strokes.add(
                                        SignatureStroke(
                                            points = activePoints,
                                            color = selectedColor,
                                            strokeWidth = strokeWidth
                                        )
                                    )
                                }
                                activePoints = emptyList()
                            },
                            onDragCancel = {
                                activePoints = emptyList()
                            }
                        )
                    }
                    .testTag("signature_canvas")
            ) {
                Canvas(modifier = Modifier.fillMaxSize()) {
                    // Subtle baseline guide
                    val guideY = size.height * 0.76f
                    drawLine(
                        color = Color(0xFFD5D1C8),
                        start = Offset(32f, guideY),
                        end = Offset(size.width - 32f, guideY),
                        strokeWidth = 2f
                    )

                    val allStrokes = strokes + if (activePoints.size >= 2) {
                        listOf(SignatureStroke(activePoints, selectedColor, strokeWidth))
                    } else {
                        emptyList()
                    }

                    allStrokes.forEach { stroke ->
                        val path = Path().apply {
                            val first = stroke.points.first()
                            moveTo(first.x, first.y)
                            stroke.points.drop(1).forEach { pt -> lineTo(pt.x, pt.y) }
                        }
                        drawPath(
                            path = path,
                            color = stroke.color,
                            style = Stroke(
                                width = stroke.strokeWidth,
                                cap = StrokeCap.Round,
                                join = StrokeJoin.Round
                            )
                        )
                    }
                }

                if (strokes.isEmpty() && activePoints.isEmpty()) {
                    Text(
                        text = "Sign here with your finger",
                        style = MaterialTheme.typography.bodyMedium,
                        color = Color(0xFF8C8880),
                        modifier = Modifier
                            .align(Alignment.BottomCenter)
                            .padding(bottom = 18.dp)
                    )
                }
            }

            // Ink Color & Width Controls
            DocuScanCard {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text("Ink Color", style = MaterialTheme.typography.titleSmall)
                    Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                        colorChoices.forEach { swatch ->
                            Box(
                                modifier = Modifier
                                    .size(30.dp)
                                    .clip(CircleShape)
                                    .background(swatch)
                                    .border(
                                        width = if (selectedColor == swatch) 3.dp else 1.dp,
                                        color = if (selectedColor == swatch) {
                                            MaterialTheme.colorScheme.primary
                                        } else {
                                            MaterialTheme.colorScheme.outline
                                        },
                                        shape = CircleShape
                                    )
                                    .clickable { selectedColor = swatch }
                            )
                        }
                    }
                }
                Spacer(modifier = Modifier.height(8.dp))
                Text("Stroke Thickness", style = MaterialTheme.typography.titleSmall)
                Slider(
                    value = strokeWidth,
                    onValueChange = { strokeWidth = it },
                    valueRange = 3f..16f
                )
            }

            // Undo, Clear, Save
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                OutlinedButton(
                    onClick = { if (strokes.isNotEmpty()) strokes.removeAt(strokes.lastIndex) },
                    enabled = strokes.isNotEmpty(),
                    modifier = Modifier
                        .weight(1f)
                        .minimumInteractiveComponentSize()
                ) {
                    Icon(LucideIcons.Undo2, contentDescription = "Undo", modifier = Modifier.size(18.dp))
                    Spacer(modifier = Modifier.size(4.dp))
                    Text("Undo")
                }

                OutlinedButton(
                    onClick = { strokes.clear() },
                    enabled = strokes.isNotEmpty(),
                    modifier = Modifier
                        .weight(1f)
                        .minimumInteractiveComponentSize()
                ) {
                    Icon(LucideIcons.X, contentDescription = "Clear", modifier = Modifier.size(18.dp))
                    Spacer(modifier = Modifier.size(4.dp))
                    Text("Clear")
                }
            }

            Button(
                onClick = {
                    val pngBytes = renderSignatureToPng(
                        strokes = strokes.toList(),
                        width = canvasSize.width.coerceAtLeast(400),
                        height = canvasSize.height.coerceAtLeast(200)
                    )
                    onSaveSignature(signatureName, pngBytes)
                    strokes.clear()
                },
                enabled = strokes.isNotEmpty() && signatureName.isNotBlank(),
                colors = ButtonDefaults.buttonColors(
                    containerColor = MaterialTheme.colorScheme.primary,
                    contentColor = MaterialTheme.colorScheme.onPrimary
                ),
                shape = MaterialTheme.shapes.medium,
                modifier = Modifier
                    .fillMaxWidth()
                    .height(52.dp)
                    .testTag("signature_save_btn")
            ) {
                Icon(LucideIcons.Save, contentDescription = null, modifier = Modifier.size(18.dp))
                Spacer(modifier = Modifier.size(8.dp))
                Text("Save Signature")
            }

            if (strokes.isNotEmpty()) {
                DocuScanCard {
                    Text("Live Signature Preview", style = MaterialTheme.typography.titleSmall)
                    Spacer(modifier = Modifier.height(6.dp))
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(82.dp)
                            .clip(RoundedCornerShape(10.dp))
                            .background(Color.White)
                            .border(1.dp, MaterialTheme.colorScheme.outline, RoundedCornerShape(10.dp))
                    ) {
                        Canvas(modifier = Modifier.fillMaxSize()) {
                            val srcW = canvasSize.width.coerceAtLeast(1).toFloat()
                            val srcH = canvasSize.height.coerceAtLeast(1).toFloat()
                            val scaleX = size.width / srcW
                            val scaleY = size.height / srcH
                            strokes.forEach { stroke ->
                                val path = Path().apply {
                                    val first = stroke.points.first()
                                    moveTo(first.x * scaleX, first.y * scaleY)
                                    stroke.points.drop(1).forEach { pt ->
                                        lineTo(pt.x * scaleX, pt.y * scaleY)
                                    }
                                }
                                drawPath(
                                    path = path,
                                    color = stroke.color,
                                    style = Stroke(
                                        width = (stroke.strokeWidth * minOf(scaleX, scaleY)).coerceAtLeast(1.5f),
                                        cap = StrokeCap.Round,
                                        join = StrokeJoin.Round
                                    )
                                )
                            }
                        }
                    }
                }
            }

            if (savedSignatures.isNotEmpty()) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = "Saved Signatures (${savedSignatures.size})",
                        style = MaterialTheme.typography.titleMedium
                    )
                    OutlinedButton(
                        onClick = { onApplySignatureToPdf(savedSignatures.first().id) },
                        modifier = Modifier.testTag("signature_insert_pdf_btn")
                    ) {
                        Icon(LucideIcons.FileText, contentDescription = null, modifier = Modifier.size(16.dp))
                        Spacer(modifier = Modifier.size(6.dp))
                        Text("Sign a PDF")
                    }
                }
                LazyRow(
                    contentPadding = PaddingValues(vertical = 4.dp),
                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    items(savedSignatures, key = { it.id }) { sig ->
                        Surface(
                            shape = MaterialTheme.shapes.medium,
                            color = MaterialTheme.colorScheme.surfaceContainer,
                            border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline)
                        ) {
                            Column(
                                modifier = Modifier.padding(10.dp),
                                verticalArrangement = Arrangement.spacedBy(6.dp)
                            ) {
                                Box(
                                    modifier = Modifier
                                        .size(width = 160.dp, height = 74.dp)
                                        .clip(RoundedCornerShape(10.dp))
                                        .background(Color(0xFFFAF9F6)),
                                    contentAlignment = Alignment.Center
                                ) {
                                    AsyncImage(
                                        model = File(sig.filePath),
                                        contentDescription = sig.name,
                                        contentScale = ContentScale.Fit,
                                        modifier = Modifier
                                            .fillMaxSize()
                                            .padding(6.dp)
                                    )
                                }
                                Row(
                                    modifier = Modifier.size(width = 160.dp, height = 36.dp),
                                    horizontalArrangement = Arrangement.SpaceBetween,
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Text(
                                        text = sig.name,
                                        style = MaterialTheme.typography.labelMedium,
                                        maxLines = 1,
                                        modifier = Modifier.weight(1f)
                                    )
                                    IconButton(
                                        onClick = { onDeleteSignature(sig.id) },
                                        modifier = Modifier.size(32.dp)
                                    ) {
                                        Icon(
                                            imageVector = LucideIcons.Trash2,
                                            contentDescription = "Delete signature",
                                            tint = MaterialTheme.colorScheme.error,
                                            modifier = Modifier.size(18.dp)
                                        )
                                    }
                                }
                                OutlinedButton(
                                    onClick = { onApplySignatureToPdf(sig.id) },
                                    modifier = Modifier.size(width = 160.dp, height = 36.dp),
                                    contentPadding = PaddingValues(horizontal = 8.dp, vertical = 2.dp)
                                ) {
                                    Icon(LucideIcons.FileText, contentDescription = null, modifier = Modifier.size(14.dp))
                                    Spacer(modifier = Modifier.size(4.dp))
                                    Text("Place in PDF", style = MaterialTheme.typography.labelSmall)
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}

private fun renderSignatureToPng(
    strokes: List<SignatureStroke>,
    width: Int,
    height: Int
): ByteArray {
    val bitmap = Bitmap.createBitmap(width, height, Bitmap.Config.ARGB_8888)
    val canvas = android.graphics.Canvas(bitmap)
    canvas.drawColor(android.graphics.Color.TRANSPARENT)

    strokes.forEach { stroke ->
        val paint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = stroke.color.toArgb()
            style = Paint.Style.STROKE
            strokeWidth = stroke.strokeWidth
            strokeCap = Paint.Cap.ROUND
            strokeJoin = Paint.Join.ROUND
        }
        val path = AndroidPath().apply {
            val first = stroke.points.first()
            moveTo(first.x, first.y)
            stroke.points.drop(1).forEach { pt -> lineTo(pt.x, pt.y) }
        }
        canvas.drawPath(path, paint)
    }

    val out = ByteArrayOutputStream()
    bitmap.compress(Bitmap.CompressFormat.PNG, 100, out)
    bitmap.recycle()
    return out.toByteArray()
}
