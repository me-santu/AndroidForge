package com.docuscan.app.ui.screens

import android.net.Uri
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.outlined.DocumentScanner
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.minimumInteractiveComponentSize
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.unit.dp
import com.docuscan.app.domain.model.DocumentItem
import com.docuscan.app.domain.model.StorageSummary
import com.docuscan.app.ui.components.DocumentRowCard
import com.docuscan.app.ui.components.EmptyStateView
import com.docuscan.app.ui.components.QuickActionCard
import com.docuscan.app.ui.icons.LucideIcons
import com.docuscan.app.util.FormatUtils
import com.docuscan.app.util.LocalAppStrings

@Composable
fun HomeScreen(
    searchQuery: String,
    recentDocuments: List<DocumentItem>,
    storageSummary: StorageSummary = StorageSummary(0L, 0, 0, 0, 0),
    activeSessionPageCount: Int,
    onSearchQueryChange: (String) -> Unit,
    onScanDocument: () -> Unit,
    onImportImageUri: (Uri) -> Unit = {},
    onCreatePdf: () -> Unit,
    onExtractText: () -> Unit,
    onOpenIdScanner: () -> Unit,
    onOpenBookScan: () -> Unit = onScanDocument,
    onOpenSignatureCreator: () -> Unit,
    onOpenPdfTools: () -> Unit,
    onOpenRecycleBin: () -> Unit = {},
    onOpenBackup: () -> Unit = {},
    onOpenAllDocuments: () -> Unit,
    onOpenDocument: (Long) -> Unit,
    modifier: Modifier = Modifier
) {
    val strings = LocalAppStrings.current

    LazyColumn(
        modifier = modifier
            .fillMaxSize()
            .background(MaterialTheme.colorScheme.background),
        contentPadding = PaddingValues(start = 16.dp, end = 16.dp, top = 16.dp, bottom = 96.dp),
        verticalArrangement = Arrangement.spacedBy(18.dp)
    ) {
        // Greeting Header
        item {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .widthIn(max = 720.dp),
                verticalArrangement = Arrangement.spacedBy(4.dp)
            ) {
                Text(
                    text = FormatUtils.timeOfDayGreeting(),
                    style = MaterialTheme.typography.bodyMedium,
                    color = MaterialTheme.colorScheme.primary
                )
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = strings.workspaceTitle,
                        style = MaterialTheme.typography.headlineMedium
                    )
                    if (activeSessionPageCount > 0) {
                        Surface(
                            onClick = onCreatePdf,
                            shape = RoundedCornerShape(20.dp),
                            color = MaterialTheme.colorScheme.primaryContainer,
                            modifier = Modifier.testTag("active_session_pill")
                        ) {
                            Text(
                                text = "$activeSessionPageCount pending",
                                style = MaterialTheme.typography.labelSmall,
                                color = MaterialTheme.colorScheme.primary,
                                modifier = Modifier.padding(horizontal = 10.dp, vertical = 6.dp)
                            )
                        }
                    }
                }
            }
        }

        // Search Bar
        item {
            OutlinedTextField(
                value = searchQuery,
                onValueChange = onSearchQueryChange,
                placeholder = { Text("Search documents, folders, or notes...") },
                leadingIcon = {
                    Icon(
                        imageVector = LucideIcons.Search,
                        contentDescription = "Search documents"
                    )
                },
                trailingIcon = {
                    if (searchQuery.isNotEmpty()) {
                        IconButton(onClick = { onSearchQueryChange("") }) {
                            Icon(
                                imageVector = LucideIcons.X,
                                contentDescription = "Clear search"
                            )
                        }
                    }
                },
                singleLine = true,
                shape = MaterialTheme.shapes.medium,
                colors = OutlinedTextFieldDefaults.colors(
                    focusedContainerColor = MaterialTheme.colorScheme.surfaceContainer,
                    unfocusedContainerColor = MaterialTheme.colorScheme.surfaceContainer,
                    focusedBorderColor = MaterialTheme.colorScheme.primary,
                    unfocusedBorderColor = MaterialTheme.colorScheme.outline
                ),
                modifier = Modifier
                    .fillMaxWidth()
                    .testTag("home_search_input")
            )
        }

        // Clean 2-Card Hero Row (Scan Document + Extract Text)
        item {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                QuickActionCard(
                    title = strings.scanDocument,
                    subtitle = strings.scanSubtitle,
                    icon = LucideIcons.ScanLine,
                    testTag = "home_action_scan",
                    isPrimaryAccent = true,
                    onClick = onScanDocument,
                    modifier = Modifier.weight(1f)
                )
                QuickActionCard(
                    title = strings.extractText,
                    subtitle = strings.ocrSubtitle,
                    icon = LucideIcons.Type,
                    testTag = "home_action_ocr",
                    onClick = onExtractText,
                    modifier = Modifier.weight(1f)
                )
            }
        }

        // Streamlined Quick Tools Strip (ID Card, Book Scan, Signature, PDF Tools)
        item {
            Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                Text(
                    text = strings.quickTools,
                    style = MaterialTheme.typography.titleMedium
                )
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .horizontalScroll(rememberScrollState()),
                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    QuickToolPill(
                        label = "ID Card",
                        icon = LucideIcons.IdCard,
                        testTag = "quick_tool_id",
                        onClick = onOpenIdScanner
                    )
                    QuickToolPill(
                        label = "Book Scan",
                        icon = LucideIcons.Layers,
                        testTag = "quick_tool_book",
                        onClick = onOpenBookScan
                    )
                    QuickToolPill(
                        label = "Signature",
                        icon = LucideIcons.PenTool,
                        testTag = "quick_tool_signature",
                        onClick = onOpenSignatureCreator
                    )
                    QuickToolPill(
                        label = "PDF Tools",
                        icon = LucideIcons.Wrench,
                        testTag = "quick_tool_pdf_tools",
                        onClick = onOpenPdfTools
                    )
                }
            }
        }

        // Recent Documents Section
        item {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = if (searchQuery.isBlank()) strings.recentDocuments else "Matching Documents",
                    style = MaterialTheme.typography.titleMedium
                )
                TextButton(
                    onClick = onOpenAllDocuments,
                    modifier = Modifier.testTag("home_see_all_docs")
                ) {
                    Text(strings.seeAll)
                }
            }
        }

        if (recentDocuments.isEmpty()) {
            item {
                EmptyStateView(
                    title = if (searchQuery.isBlank()) "No scanned documents yet" else "No matching documents",
                    subtitle = if (searchQuery.isBlank()) {
                        "Tap Scan Document to capture documents, books, ID cards, or import images and PDFs."
                    } else {
                        "Try a different keyword or clear your search filter."
                    },
                    icon = Icons.Outlined.DocumentScanner
                )
            }
        } else {
            items(recentDocuments, key = { it.id }) { doc ->
                DocumentRowCard(
                    document = doc,
                    onClick = { onOpenDocument(doc.id) }
                )
            }
        }
    }
}

@Composable
private fun QuickToolPill(
    label: String,
    icon: ImageVector,
    testTag: String,
    onClick: () -> Unit
) {
    Row(
        modifier = Modifier
            .clip(RoundedCornerShape(14.dp))
            .background(MaterialTheme.colorScheme.surfaceContainer)
            .border(1.dp, MaterialTheme.colorScheme.outline, RoundedCornerShape(14.dp))
            .clickable(onClick = onClick)
            .minimumInteractiveComponentSize()
            .padding(horizontal = 14.dp, vertical = 10.dp)
            .testTag(testTag),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(8.dp)
    ) {
        Icon(
            imageVector = icon,
            contentDescription = label,
            tint = MaterialTheme.colorScheme.primary,
            modifier = Modifier.size(18.dp)
        )
        Text(
            text = label,
            style = MaterialTheme.typography.labelLarge
        )
    }
}
