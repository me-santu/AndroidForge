package com.docuscan.app.settings

import android.net.Uri
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.docuscan.app.domain.model.AppFontStyle
import com.docuscan.app.domain.model.AppLanguage
import com.docuscan.app.domain.model.CacheSummary
import com.docuscan.app.domain.model.FileNamingFormat
import com.docuscan.app.domain.model.PdfPageSize
import com.docuscan.app.domain.model.ScanQuality
import com.docuscan.app.domain.model.StorageSummary
import com.docuscan.app.domain.model.ThemeMode
import com.docuscan.app.domain.model.UserPreferences
import com.docuscan.app.domain.repository.DocumentRepository
import com.docuscan.app.domain.repository.SettingsRepository
import com.docuscan.app.security.BiometricCapability
import com.docuscan.app.security.SecurityManager
import com.docuscan.app.util.FormatUtils
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch

class SettingsViewModel(
    private val settingsRepository: SettingsRepository,
    private val documentRepository: DocumentRepository,
    val securityManager: SecurityManager
) : ViewModel() {

    val preferences: StateFlow<UserPreferences> = settingsRepository.preferences
        .stateIn(
            scope = viewModelScope,
            started = SharingStarted.WhileSubscribed(5000),
            initialValue = UserPreferences()
        )

    val storageSummary: StateFlow<StorageSummary> = documentRepository.observeStorageSummary()
        .stateIn(
            scope = viewModelScope,
            started = SharingStarted.WhileSubscribed(5000),
            initialValue = StorageSummary()
        )

    private val _cacheSummary = MutableStateFlow(CacheSummary())
    val cacheSummary: StateFlow<CacheSummary> = _cacheSummary.asStateFlow()

    private val _biometricCapability = MutableStateFlow(securityManager.checkBiometricCapability())
    val biometricCapability: StateFlow<BiometricCapability> = _biometricCapability.asStateFlow()

    private val _backupMessage = MutableStateFlow<String?>(null)
    val backupMessage: StateFlow<String?> = _backupMessage.asStateFlow()

    private val _settingsMessage = MutableStateFlow<String?>(null)
    val settingsMessage: StateFlow<String?> = _settingsMessage.asStateFlow()

    private val _isVaultLocked = MutableStateFlow(false)
    val isVaultLocked: StateFlow<Boolean> = _isVaultLocked.asStateFlow()

    @Volatile
    private var suppressNextBackgroundLock: Boolean = false

    init {
        refreshCacheSummary()
        viewModelScope.launch {
            val initial = settingsRepository.preferences.first()
            if (initial.appLockEnabled && (initial.hasPinConfigured || initial.biometricUnlockEnabled)) {
                _isVaultLocked.value = true
            }
        }
    }

    fun suppressNextAutoLock() {
        suppressNextBackgroundLock = true
    }

    fun onAppBackgrounded() {
        if (suppressNextBackgroundLock) return
        val prefs = preferences.value
        if (prefs.appLockEnabled && (prefs.hasPinConfigured || prefs.biometricUnlockEnabled)) {
            _isVaultLocked.value = true
        }
    }

    fun onAppResumed() {
        suppressNextBackgroundLock = false
        refreshBiometricCapability()
    }

    fun refreshBiometricCapability() {
        _biometricCapability.value = securityManager.checkBiometricCapability()
    }

    fun lockVault() {
        val prefs = preferences.value
        if (prefs.hasPinConfigured || prefs.biometricUnlockEnabled) {
            if (!prefs.appLockEnabled) {
                viewModelScope.launch { settingsRepository.setAppLockEnabled(true) }
            }
            _isVaultLocked.value = true
        } else {
            _settingsMessage.value = "Set a Vault PIN or enable Biometric Unlock before locking"
        }
    }

    fun unlockVault() {
        _isVaultLocked.value = false
    }

    fun setThemeMode(mode: ThemeMode) {
        viewModelScope.launch { settingsRepository.setThemeMode(mode) }
    }

    fun setAppLanguage(language: AppLanguage) {
        viewModelScope.launch { settingsRepository.setAppLanguage(language) }
    }

    fun setFontStyle(fontStyle: AppFontStyle) {
        viewModelScope.launch { settingsRepository.setFontStyle(fontStyle) }
    }

    fun setOnboardingCompleted(completed: Boolean) {
        viewModelScope.launch { settingsRepository.setOnboardingCompleted(completed) }
    }

    fun setScanQuality(quality: ScanQuality) {
        viewModelScope.launch { settingsRepository.setScanQuality(quality) }
    }

    fun setDefaultPageSize(pageSize: PdfPageSize) {
        viewModelScope.launch { settingsRepository.setDefaultPageSize(pageSize) }
    }

    fun setAutoEnhance(enabled: Boolean) {
        viewModelScope.launch { settingsRepository.setAutoEnhance(enabled) }
    }

    fun setFileNamingFormat(format: FileNamingFormat) {
        viewModelScope.launch { settingsRepository.setFileNamingFormat(format) }
    }

    fun setEncryptSensitiveFiles(enabled: Boolean) {
        viewModelScope.launch {
            settingsRepository.setEncryptSensitiveFiles(enabled)
            _settingsMessage.value = if (enabled) {
                "New ID scans will be encrypted with Android Keystore"
            } else {
                "Auto Keystore encryption for ID scans disabled"
            }
        }
    }

    fun configureOrUpdatePin(newPin: String, enableLock: Boolean = true): Result<Unit> {
        return runCatching {
            val sealed = securityManager.createSealedPinRecord(newPin)
            viewModelScope.launch {
                settingsRepository.setSealedPinRecord(sealed)
                if (enableLock) {
                    settingsRepository.setAppLockEnabled(true)
                }
                _settingsMessage.value = "Vault PIN saved cleanly in Android Keystore"
            }
        }
    }

    fun removePinAndDisableLock() {
        viewModelScope.launch {
            settingsRepository.setAppLockEnabled(false)
            settingsRepository.setBiometricUnlockEnabled(false)
            settingsRepository.setSealedPinRecord(null)
            _isVaultLocked.value = false
            _settingsMessage.value = "Vault App Lock and PIN removed"
        }
    }

    fun setAppLockEnabled(enabled: Boolean) {
        viewModelScope.launch {
            val current = settingsRepository.preferences.first()
            if (enabled && !current.hasPinConfigured && !current.biometricUnlockEnabled) {
                _settingsMessage.value = "Set a 4–8 digit Vault PIN or enable Biometric Unlock first"
                return@launch
            }
            settingsRepository.setAppLockEnabled(enabled)
            if (!enabled) {
                _isVaultLocked.value = false
            }
        }
    }

    fun setBiometricUnlockEnabled(enabled: Boolean) {
        viewModelScope.launch {
            val current = settingsRepository.preferences.first()
            if (enabled) {
                val cap = securityManager.checkBiometricCapability()
                _biometricCapability.value = cap
                if (!cap.isAvailable) {
                    _settingsMessage.value = cap.statusLabel
                    return@launch
                }
                settingsRepository.setBiometricUnlockEnabled(true)
                if (!current.appLockEnabled) {
                    settingsRepository.setAppLockEnabled(true)
                }
                _settingsMessage.value = "Biometric Unlock enabled for DocuScan Vault"
            } else {
                settingsRepository.setBiometricUnlockEnabled(false)
                if (!current.hasPinConfigured && current.appLockEnabled) {
                    settingsRepository.setAppLockEnabled(false)
                    _isVaultLocked.value = false
                }
                _settingsMessage.value = "Biometric Unlock disabled"
            }
        }
    }

    fun postSettingsMessage(message: String) {
        if (message.isNotBlank()) {
            _settingsMessage.value = message
        }
    }

    fun verifyPin(candidatePin: String): Boolean {
        return securityManager.verifyPin(candidatePin, preferences.value.sealedPinRecord)
    }

    fun refreshCacheSummary() {
        viewModelScope.launch {
            _cacheSummary.value = documentRepository.getCacheSummary()
            _biometricCapability.value = securityManager.checkBiometricCapability()
        }
    }

    fun clearTempCache() {
        viewModelScope.launch {
            documentRepository.clearTempCache()
                .onSuccess { freed ->
                    _cacheSummary.value = documentRepository.getCacheSummary()
                    _settingsMessage.value = if (freed > 0L) {
                        "Cleared ${FormatUtils.formatBytes(freed)} of temporary cache"
                    } else {
                        "Temporary cache is already clean"
                    }
                }
                .onFailure { err ->
                    _settingsMessage.value = err.message ?: "Failed to clear temporary cache"
                }
        }
    }

    fun runLocalBackup() {
        viewModelScope.launch {
            documentRepository.createLocalBackupManifest()
                .onSuccess { path ->
                    settingsRepository.updateLastBackupAt(System.currentTimeMillis())
                    refreshCacheSummary()
                    _backupMessage.value = "Local backup index saved: ${path.substringAfterLast('/')}"
                }
                .onFailure { err ->
                    _backupMessage.value = "Backup failed: ${err.message}"
                }
        }
    }

    fun exportBackupZipToUri(destinationUri: Uri) {
        viewModelScope.launch {
            documentRepository.exportFullBackupArchive(destinationUri)
                .onSuccess { bytes ->
                    settingsRepository.updateLastBackupAt(System.currentTimeMillis())
                    _backupMessage.value = "Exported ZIP backup (${FormatUtils.formatBytes(bytes)})"
                }
                .onFailure { err ->
                    _backupMessage.value = "ZIP backup failed: ${err.message}"
                }
        }
    }

    fun clearBackupMessage() {
        _backupMessage.value = null
    }

    fun clearSettingsMessage() {
        _settingsMessage.value = null
    }
}
