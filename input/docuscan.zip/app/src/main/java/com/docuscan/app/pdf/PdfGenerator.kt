package com.docuscan.app.pdf

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import com.docuscan.app.domain.model.IdDocumentType
import com.docuscan.app.domain.model.IdSideScanState
import com.docuscan.app.domain.model.PdfCompressionLevel
import com.docuscan.app.domain.model.PdfCreationOptions
import com.docuscan.app.domain.model.PdfOrientation
import com.docuscan.app.domain.model.PdfPageSize
import com.docuscan.app.domain.model.PdfSearchMatch
import com.docuscan.app.domain.model.ScanPage
import com.docuscan.app.domain.model.ScanQuality
import com.docuscan.app.ocr.OcrEngine
import com.docuscan.app.ocr.OcrScript
import com.docuscan.app.scanner.BitmapFilterEngine
import com.tom_roush.pdfbox.android.PDFBoxResourceLoader
import com.tom_roush.pdfbox.cos.COSName
import com.tom_roush.pdfbox.io.MemoryUsageSetting
import com.tom_roush.pdfbox.multipdf.PDFMergerUtility
import com.tom_roush.pdfbox.pdmodel.PDDocument
import com.tom_roush.pdfbox.pdmodel.PDPage
import com.tom_roush.pdfbox.pdmodel.PDPageContentStream
import com.tom_roush.pdfbox.pdmodel.common.PDRectangle
import com.tom_roush.pdfbox.pdmodel.encryption.AccessPermission
import com.tom_roush.pdfbox.pdmodel.encryption.StandardProtectionPolicy
import com.tom_roush.pdfbox.pdmodel.font.PDFont
import com.tom_roush.pdfbox.pdmodel.font.PDType0Font
import com.tom_roush.pdfbox.pdmodel.font.PDType1Font
import com.tom_roush.pdfbox.pdmodel.graphics.color.PDColor
import com.tom_roush.pdfbox.pdmodel.graphics.color.PDDeviceRGB
import com.tom_roush.pdfbox.pdmodel.graphics.image.JPEGFactory
import com.tom_roush.pdfbox.pdmodel.graphics.image.LosslessFactory
import com.tom_roush.pdfbox.pdmodel.graphics.image.PDImageXObject
import com.tom_roush.pdfbox.pdmodel.graphics.state.PDExtendedGraphicsState
import com.tom_roush.pdfbox.pdmodel.graphics.state.RenderingMode
import com.tom_roush.pdfbox.pdmodel.interactive.annotation.PDAnnotationText
import com.tom_roush.pdfbox.pdmodel.interactive.annotation.PDAnnotationTextMarkup
import com.tom_roush.pdfbox.text.PDFTextStripper
import com.tom_roush.pdfbox.util.Matrix
import kotlinx.coroutines.CoroutineDispatcher
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.io.File
import java.io.FileOutputStream
import kotlin.math.max
import kotlin.math.min

class PdfGenerator(
    private val context: Context? = null,
    private val ioDispatcher: CoroutineDispatcher = Dispatchers.IO,
    private val ocrEngine: OcrEngine? = null
) {

    private fun ensurePdfBoxReady() {
        if (context != null && !PDFBoxResourceLoader.isReady()) {
            PDFBoxResourceLoader.init(context.applicationContext)
        }
    }

    private fun loadDocument(file: File, password: String? = null): PDDocument {
        ensurePdfBoxReady()
        require(file.exists() && file.length() > 0L) { "PDF file does not exist or is empty." }
        return try {
            val memSetting = MemoryUsageSetting.setupTempFileOnly()
            if (!password.isNullOrEmpty()) {
                PDDocument.load(file, password, memSetting)
            } else {
                PDDocument.load(file, memSetting)
            }
        } catch (e: com.tom_roush.pdfbox.pdmodel.encryption.InvalidPasswordException) {
            throw IllegalStateException(
                if (password.isNullOrEmpty()) {
                    "This PDF is password protected. Enter the password to proceed."
                } else {
                    "Incorrect PDF password. Please verify and try again."
                },
                e
            )
        }
    }

    suspend fun getPdfPageCount(sourceFile: File, password: String? = null): Int =
        withContext(ioDispatcher) {
            if (!sourceFile.exists() || sourceFile.length() == 0L) return@withContext 0
            loadDocument(sourceFile, password).use { it.numberOfPages }
        }

    suspend fun generatePdfFromPages(
        pages: List<ScanPage>,
        outputFile: File,
        pageSize: PdfPageSize,
        quality: ScanQuality,
        embedSearchableText: Boolean = false
    ): Int = generatePdfFromPages(
        pages = pages,
        outputFile = outputFile,
        options = PdfCreationOptions(
            pageSize = pageSize,
            quality = quality,
            embedSearchableText = embedSearchableText
        ),
        embedSearchableText = embedSearchableText
    )

    suspend fun generatePdfFromPages(
        pages: List<ScanPage>,
        outputFile: File,
        options: PdfCreationOptions,
        embedSearchableText: Boolean = options.embedSearchableText,
        pageOcrTexts: Map<Int, String> = emptyMap()
    ): Int = withContext(ioDispatcher) {
        require(pages.isNotEmpty()) { "At least one page is required to generate a PDF." }
        ensurePdfBoxReady()

        val document = PDDocument(MemoryUsageSetting.setupTempFileOnly())
        try {
            var writtenPages = 0
            val jpegQuality = (options.quality.jpegQuality / 100f).coerceIn(0.35f, 0.96f)
            val totalCandidatePages = pages.size
            val searchableFont: PDFont? = if (embedSearchableText) {
                loadSearchableFont(document)
            } else {
                null
            }

            pages.forEachIndexed { pageIdx, scanPage ->
                val rawBitmap = BitmapFilterEngine.decodeSampledBitmap(
                    scanPage.sourcePath,
                    maxDimension = options.quality.maxDimension
                ) ?: return@forEachIndexed

                var processed: Bitmap? = null
                val pageW: Float
                val pageH: Float
                val page: PDPage
                val pdfImage: PDImageXObject
                var extractedPageText: String? = null
                try {
                    processed = BitmapFilterEngine.cropAndTransform(
                        source = rawBitmap,
                        cropRect = scanPage.cropRect,
                        rotationDegrees = scanPage.rotationDegrees,
                        filter = scanPage.filter
                    )
                    if (embedSearchableText) {
                        val preSupplied = pageOcrTexts[pageIdx]?.trim().orEmpty()
                        extractedPageText = if (preSupplied.isNotEmpty()) {
                            preSupplied
                        } else {
                            ocrEngine?.extractTextFromBitmap(
                                bitmap = processed,
                                script = OcrScript.AUTO,
                                rotationDegrees = 0
                            )?.getOrNull()?.combinedText?.trim()
                        }
                    }
                    val pageDimensions = resolvePageDimensions(processed, options)
                    pageW = pageDimensions.first
                    pageH = pageDimensions.second
                    page = PDPage(PDRectangle(pageW, pageH))
                    document.addPage(page)
                    pdfImage = JPEGFactory.createFromImage(document, processed, jpegQuality)
                } finally {
                    if (processed != null && processed !== rawBitmap && !processed.isRecycled) {
                        processed.recycle()
                    }
                    if (!rawBitmap.isRecycled) {
                        rawBitmap.recycle()
                    }
                }

                PDPageContentStream(document, page).use { stream ->
                    val footerReserve = if (options.includePageNumbers) 24f else 0f
                    val margin = if (options.pageSize == PdfPageSize.FIT_IMAGE) 0f else options.marginPt.coerceIn(0f, 96f)
                    val availW = (pageW - margin * 2f).coerceAtLeast(10f)
                    val availH = (pageH - margin * 2f - footerReserve).coerceAtLeast(10f)
                    val scale = min(availW / pdfImage.width.toFloat(), availH / pdfImage.height.toFloat())
                    val drawW = pdfImage.width * scale
                    val drawH = pdfImage.height * scale
                    val x = (pageW - drawW) / 2f
                    val y = footerReserve + ((pageH - footerReserve) - drawH) / 2f

                    // Draw invisible transparent OCR text layer UNDERNEATH the scanned page image
                    // so external PDF viewers can search and select text directly on the scanned page.
                    if (embedSearchableText && !extractedPageText.isNullOrBlank()) {
                        drawInvisibleSearchableTextLayer(
                            stream = stream,
                            font = searchableFont ?: PDType1Font.HELVETICA,
                            text = extractedPageText,
                            boxX = x,
                            boxY = y,
                            boxWidth = drawW,
                            boxHeight = drawH
                        )
                    }

                    stream.drawImage(pdfImage, x, y, drawW, drawH)

                    writtenPages++

                    if (options.watermarkText.isNotBlank()) {
                        drawWatermarkOnStream(stream, pageW, pageH, options.watermarkText.trim(), 0.22f)
                    }

                    if (options.includePageNumbers) {
                        val label = "Page $writtenPages of $totalCandidatePages"
                        val fontSize = 10f
                        val font = PDType1Font.HELVETICA
                        val textWidth = font.getStringWidth(label) / 1000f * fontSize
                        stream.beginText()
                        stream.setNonStrokingColor(0.32f, 0.32f, 0.32f)
                        stream.setFont(font, fontSize)
                        stream.newLineAtOffset(((pageW - textWidth) / 2f).coerceAtLeast(12f), 10f)
                        stream.showText(sanitizePdfText(label))
                        stream.endText()
                    }
                }
            }

            if (writtenPages == 0) {
                error("Could not decode any valid page images.")
            }

            if (options.password.isNotBlank()) {
                applyPasswordProtection(document, options.password)
            }

            document.save(outputFile)
            writtenPages
        } finally {
            document.close()
        }
    }

    private fun loadSearchableFont(document: PDDocument): PDFont {
        val candidateSystemFonts = listOf(
            "/system/fonts/Roboto-Regular.ttf",
            "/system/fonts/NotoSans-Regular.ttf"
        )
        for (path in candidateSystemFonts) {
            val f = File(path)
            if (f.exists() && f.canRead()) {
                val loaded = runCatching { PDType0Font.load(document, f) }.getOrNull()
                if (loaded != null) return loaded
            }
        }
        return PDType1Font.HELVETICA
    }

    private fun drawInvisibleSearchableTextLayer(
        stream: PDPageContentStream,
        font: PDFont,
        text: String,
        boxX: Float,
        boxY: Float,
        boxWidth: Float,
        boxHeight: Float
    ) {
        val lines = text
            .replace("\r\n", "\n")
            .replace('\r', '\n')
            .split('\n')
            .map { it.trim() }
            .filter { it.isNotEmpty() }
        if (lines.isEmpty()) return

        val safeWidth = (boxWidth - 16f).coerceAtLeast(32f)
        val safeHeight = (boxHeight - 16f).coerceAtLeast(32f)
        val lineCount = lines.size.coerceAtLeast(1)
        val lineHeight = (safeHeight / lineCount.coerceAtLeast(12)).coerceIn(8f, 18f)
        val baseFontSize = (lineHeight * 0.78f).coerceIn(6.5f, 13f)

        val transparentGs = PDExtendedGraphicsState().apply {
            nonStrokingAlphaConstant = 0f
            strokingAlphaConstant = 0f
        }

        stream.saveGraphicsState()
        stream.setGraphicsStateParameters(transparentGs)
        stream.beginText()
        stream.setRenderingMode(RenderingMode.NEITHER)

        var cursorY = boxY + boxHeight - 8f - baseFontSize
        val minY = boxY + 4f

        for (rawLine in lines) {
            if (cursorY < minY) break
            val printable = encodeSafeTextForFont(font, rawLine)
            if (printable.isBlank()) {
                cursorY -= lineHeight
                continue
            }

            val measuredW = runCatching { font.getStringWidth(printable) / 1000f * baseFontSize }
                .getOrDefault(safeWidth)
            val effectiveFontSize = if (measuredW > safeWidth && measuredW > 0f) {
                (baseFontSize * (safeWidth / measuredW)).coerceIn(4f, baseFontSize)
            } else {
                baseFontSize
            }

            stream.setFont(font, effectiveFontSize)
            stream.setTextMatrix(Matrix.getTranslateInstance(boxX + 8f, cursorY))
            runCatching { stream.showText(printable) }
            cursorY -= lineHeight
        }

        stream.endText()
        stream.restoreGraphicsState()
    }

    private fun encodeSafeTextForFont(font: PDFont, raw: String): String {
        if (font is PDType1Font) {
            return sanitizePdfText(raw)
        }
        val sb = StringBuilder(raw.length)
        for (ch in raw) {
            if (ch == '\t') {
                sb.append(' ')
            } else if (!ch.isISOControl()) {
                val encodable = runCatching { font.encode(ch.toString()) }.isSuccess
                if (encodable) {
                    sb.append(ch)
                } else if (ch.code in 32..126) {
                    sb.append(ch)
                } else {
                    sb.append(' ')
                }
            }
        }
        return sb.toString().replace(Regex("\\s+"), " ").trim()
    }

    private fun resolvePageDimensions(bitmap: Bitmap, options: PdfCreationOptions): Pair<Float, Float> {
        if (options.pageSize == PdfPageSize.FIT_IMAGE) {
            return bitmap.width.coerceAtLeast(120).toFloat() to bitmap.height.coerceAtLeast(120).toFloat()
        }
        val baseW: Float
        val baseH: Float
        if (options.pageSize == PdfPageSize.CUSTOM) {
            baseW = options.customWidthPt.coerceIn(200, 2400).toFloat()
            baseH = options.customHeightPt.coerceIn(200, 3200).toFloat()
        } else {
            baseW = options.pageSize.widthPt.toFloat()
            baseH = options.pageSize.heightPt.toFloat()
        }
        return if (options.orientation == PdfOrientation.LANDSCAPE) {
            max(baseW, baseH) to min(baseW, baseH)
        } else {
            min(baseW, baseH) to max(baseW, baseH)
        }
    }

    suspend fun mergePdfs(
        sourcePdfFiles: List<File>,
        outputFile: File
    ): Int = withContext(ioDispatcher) {
        val validFiles = sourcePdfFiles.filter { it.exists() && it.length() > 0L }
        require(validFiles.size >= 2) { "Select at least 2 valid PDF files to merge." }
        ensurePdfBoxReady()

        val merger = PDFMergerUtility().apply {
            destinationFileName = outputFile.absolutePath
            validFiles.forEach { addSource(it) }
        }
        merger.mergeDocuments(MemoryUsageSetting.setupTempFileOnly())

        loadDocument(outputFile).use { merged ->
            merged.numberOfPages
        }
    }

    suspend fun splitPdf(
        sourceFile: File,
        outputFile: File,
        startPageOneBased: Int,
        endPageOneBased: Int,
        password: String? = null
    ): Int = withContext(ioDispatcher) {
        loadDocument(sourceFile, password).use { srcDoc ->
            val total = srcDoc.numberOfPages
            require(total > 0) { "Source PDF has no pages." }
            val safeStart = startPageOneBased.coerceIn(1, total)
            val safeEnd = endPageOneBased.coerceIn(safeStart, total)
            val pages = (safeStart..safeEnd).toList()
            copySelectedPages(srcDoc, outputFile, pages)
        }
    }

    suspend fun extractPages(
        sourceFile: File,
        outputFile: File,
        oneBasedPages: List<Int>,
        password: String? = null
    ): Int = withContext(ioDispatcher) {
        loadDocument(sourceFile, password).use { srcDoc ->
            val total = srcDoc.numberOfPages
            val validPages = oneBasedPages.filter { it in 1..total }.distinct()
            require(validPages.isNotEmpty()) { "Select at least one valid page (1..$total) to extract." }
            copySelectedPages(srcDoc, outputFile, validPages)
        }
    }

    private fun copySelectedPages(
        srcDoc: PDDocument,
        outputFile: File,
        oneBasedPages: List<Int>
    ): Int {
        val targetDoc = PDDocument(MemoryUsageSetting.setupTempFileOnly())
        return targetDoc.use { outDoc ->
            oneBasedPages.forEach { pageOneBased ->
                val srcPage = srcDoc.getPage(pageOneBased - 1)
                outDoc.importPage(srcPage)
            }
            outDoc.save(outputFile)
            outDoc.numberOfPages
        }
    }

    suspend fun rotatePdfPages(
        sourceFile: File,
        outputFile: File,
        oneBasedPages: Set<Int> = emptySet(),
        deltaDegrees: Int = 90,
        password: String? = null
    ): Int = withContext(ioDispatcher) {
        loadDocument(sourceFile, password).use { doc ->
            val total = doc.numberOfPages
            require(total > 0) { "Source PDF has no pages." }
            val targets = if (oneBasedPages.isEmpty()) (1..total).toSet() else oneBasedPages
            for (i in 0 until total) {
                if ((i + 1) in targets) {
                    val page = doc.getPage(i)
                    val normalized = ((page.rotation + deltaDegrees) % 360 + 360) % 360
                    page.rotation = normalized
                }
            }
            doc.save(outputFile)
            total
        }
    }

    suspend fun deletePdfPages(
        sourceFile: File,
        outputFile: File,
        oneBasedPagesToDelete: Set<Int>,
        password: String? = null
    ): Int = withContext(ioDispatcher) {
        loadDocument(sourceFile, password).use { doc ->
            val total = doc.numberOfPages
            val validDeletes = oneBasedPagesToDelete.filter { it in 1..total }.toSet()
            require(validDeletes.isNotEmpty()) { "Select at least one page to remove." }
            require(validDeletes.size < total) { "Cannot delete all pages from a PDF." }
            // Remove from highest index down so lower indices remain stable
            validDeletes.sortedDescending().forEach { pageOneBased ->
                doc.removePage(pageOneBased - 1)
            }
            doc.save(outputFile)
            doc.numberOfPages
        }
    }

    suspend fun compressPdf(
        sourceFile: File,
        outputFile: File,
        compressionLevel: PdfCompressionLevel,
        password: String? = null
    ): Int = withContext(ioDispatcher) {
        loadDocument(sourceFile, password).use { doc ->
            val total = doc.numberOfPages
            require(total > 0) { "Source PDF has no pages." }

            for (i in 0 until total) {
                val page = doc.getPage(i)
                val resources = page.resources ?: continue
                val xObjectNames = resources.xObjectNames?.toList().orEmpty()
                for (name in xObjectNames) {
                    val xObj = runCatching { resources.getXObject(name) }.getOrNull()
                    if (xObj is PDImageXObject) {
                        val rawBitmap = runCatching { xObj.image }.getOrNull() ?: continue
                        var scaled: Bitmap? = null
                        try {
                            scaled = downscaleBitmap(rawBitmap, compressionLevel.maxDimension)
                            val recompressed = JPEGFactory.createFromImage(
                                doc,
                                scaled,
                                compressionLevel.jpegQuality
                            )
                            resources.put(name, recompressed)
                        } finally {
                            if (scaled != null && scaled !== rawBitmap && !scaled.isRecycled) {
                                scaled.recycle()
                            }
                            if (!rawBitmap.isRecycled) {
                                rawBitmap.recycle()
                            }
                        }
                    }
                }
            }
            doc.save(outputFile)
            total
        }
    }

    private fun downscaleBitmap(bitmap: Bitmap, maxDim: Int): Bitmap {
        val largest = max(bitmap.width, bitmap.height)
        if (largest <= maxDim) return bitmap
        val ratio = maxDim.toFloat() / largest.toFloat()
        val targetW = (bitmap.width * ratio).toInt().coerceAtLeast(16)
        val targetH = (bitmap.height * ratio).toInt().coerceAtLeast(16)
        return Bitmap.createScaledBitmap(bitmap, targetW, targetH, true)
    }

    suspend fun addWatermark(
        sourceFile: File,
        outputFile: File,
        watermarkText: String,
        opacity: Float = 0.24f,
        password: String? = null
    ): Int = withContext(ioDispatcher) {
        val cleanText = watermarkText.trim()
        require(cleanText.isNotEmpty()) { "Watermark text cannot be empty." }
        loadDocument(sourceFile, password).use { doc ->
            val total = doc.numberOfPages
            for (i in 0 until total) {
                val page = doc.getPage(i)
                val box = page.mediaBox ?: PDRectangle.A4
                PDPageContentStream(
                    doc,
                    page,
                    PDPageContentStream.AppendMode.APPEND,
                    true,
                    true
                ).use { stream ->
                    drawWatermarkOnStream(stream, box.width, box.height, cleanText, opacity)
                }
            }
            doc.save(outputFile)
            total
        }
    }

    private fun drawWatermarkOnStream(
        stream: PDPageContentStream,
        pageWidth: Float,
        pageHeight: Float,
        text: String,
        opacity: Float
    ) {
        val clean = sanitizePdfText(text).take(40)
        val gs = PDExtendedGraphicsState().apply {
            nonStrokingAlphaConstant = opacity.coerceIn(0.08f, 0.7f)
        }
        stream.saveGraphicsState()
        stream.setGraphicsStateParameters(gs)
        val font = PDType1Font.HELVETICA_BOLD
        val fontSize = (min(pageWidth, pageHeight) / 11f).coerceIn(20f, 56f)
        val textWidth = font.getStringWidth(clean) / 1000f * fontSize
        val centerX = pageWidth / 2f
        val centerY = pageHeight / 2f

        stream.beginText()
        stream.setNonStrokingColor(0.65f, 0.48f, 0.06f)
        stream.setFont(font, fontSize)
        val matrix = Matrix.getRotateInstance(Math.toRadians(35.0), centerX, centerY)
        matrix.translate(-textWidth / 2f, -fontSize / 3f)
        stream.setTextMatrix(matrix)
        stream.showText(clean)
        stream.endText()
        stream.restoreGraphicsState()
    }

    suspend fun protectPdfWithPassword(
        sourceFile: File,
        outputFile: File,
        userPassword: String,
        ownerPassword: String = userPassword,
        existingPassword: String? = null
    ): Int = withContext(ioDispatcher) {
        require(userPassword.isNotBlank()) { "Password cannot be blank." }
        loadDocument(sourceFile, existingPassword).use { doc ->
            applyPasswordProtection(doc, userPassword, ownerPassword)
            doc.save(outputFile)
            doc.numberOfPages
        }
    }

    private fun applyPasswordProtection(
        document: PDDocument,
        userPassword: String,
        ownerPassword: String = userPassword
    ) {
        val permissions = AccessPermission().apply {
            setCanPrint(true)
            setCanModify(false)
            setCanExtractContent(true)
        }
        val policy = StandardProtectionPolicy(ownerPassword, userPassword, permissions).apply {
            encryptionKeyLength = 128
        }
        document.protect(policy)
    }

    suspend fun searchTextInPdf(
        sourceFile: File,
        query: String,
        password: String? = null
    ): List<PdfSearchMatch> = withContext(ioDispatcher) {
        val cleanQuery = query.trim()
        if (cleanQuery.isEmpty() || !sourceFile.exists()) return@withContext emptyList()
        loadDocument(sourceFile, password).use { doc ->
            val stripper = PDFTextStripper()
            val matches = mutableListOf<PdfSearchMatch>()
            for (pageOneBased in 1..doc.numberOfPages) {
                stripper.startPage = pageOneBased
                stripper.endPage = pageOneBased
                val pageText = stripper.getText(doc)
                val firstIdx = pageText.indexOf(cleanQuery, ignoreCase = true)
                if (firstIdx >= 0) {
                    var count = 0
                    var cursor = firstIdx
                    while (cursor >= 0) {
                        count++
                        cursor = pageText.indexOf(cleanQuery, cursor + cleanQuery.length, ignoreCase = true)
                    }
                    val start = (firstIdx - 32).coerceAtLeast(0)
                    val end = (firstIdx + cleanQuery.length + 48).coerceAtMost(pageText.length)
                    val snippet = pageText.substring(start, end)
                        .replace('\n', ' ')
                        .replace(Regex("\\s+"), " ")
                        .trim()
                    matches.add(
                        PdfSearchMatch(
                            pageIndex = pageOneBased - 1,
                            snippet = snippet,
                            matchCount = count
                        )
                    )
                }
            }
            matches
        }
    }

    suspend fun extractAllTextFromPdf(
        sourceFile: File,
        password: String? = null
    ): String = withContext(ioDispatcher) {
        if (!sourceFile.exists() || sourceFile.length() == 0L) return@withContext ""
        loadDocument(sourceFile, password).use { doc ->
            PDFTextStripper().getText(doc).trim()
        }
    }

    suspend fun addHighlightOrNoteAnnotation(
        sourceFile: File,
        outputFile: File,
        pageIndexZeroBased: Int,
        noteText: String,
        addHighlightBar: Boolean = true,
        password: String? = null
    ): Int = withContext(ioDispatcher) {
        val cleanNote = noteText.trim()
        require(cleanNote.isNotEmpty() || addHighlightBar) { "Enter a note or enable highlight bar." }
        loadDocument(sourceFile, password).use { doc ->
            require(pageIndexZeroBased in 0 until doc.numberOfPages) { "Invalid target page index." }
            val page = doc.getPage(pageIndexZeroBased)
            val box = page.mediaBox ?: PDRectangle.A4
            val highlightYellow = PDColor(floatArrayOf(0.96f, 0.77f, 0.26f), PDDeviceRGB.INSTANCE)

            if (addHighlightBar) {
                val rect = PDRectangle(
                    box.width * 0.12f,
                    box.height * 0.72f,
                    box.width * 0.76f,
                    22f
                )
                val highlight = PDAnnotationTextMarkup(PDAnnotationTextMarkup.SUB_TYPE_HIGHLIGHT).apply {
                    rectangle = rect
                    quadPoints = floatArrayOf(
                        rect.lowerLeftX, rect.upperRightY,
                        rect.upperRightX, rect.upperRightY,
                        rect.lowerLeftX, rect.lowerLeftY,
                        rect.upperRightX, rect.lowerLeftY
                    )
                    color = highlightYellow
                    contents = cleanNote.ifEmpty { "Highlighted section" }
                }
                page.annotations.add(highlight)
            }

            if (cleanNote.isNotEmpty()) {
                val noteAnnot = PDAnnotationText().apply {
                    rectangle = PDRectangle(box.width * 0.80f, box.height * 0.78f, 24f, 24f)
                    name = PDAnnotationText.NAME_NOTE
                    color = highlightYellow
                    contents = cleanNote
                }
                page.annotations.add(noteAnnot)

                PDPageContentStream(
                    doc,
                    page,
                    PDPageContentStream.AppendMode.APPEND,
                    true,
                    true
                ).use { stream ->
                    stream.beginText()
                    stream.setFont(PDType1Font.HELVETICA_BOLD, 9f)
                    stream.setNonStrokingColor(0.75f, 0.52f, 0.04f)
                    stream.newLineAtOffset(28f, box.height - 24f)
                    stream.showText(sanitizePdfText("Note: $cleanNote").take(85))
                    stream.endText()
                }
            }

            doc.save(outputFile)
            doc.numberOfPages
        }
    }

    suspend fun generateIdCardPdf(
        docType: IdDocumentType,
        frontSide: IdSideScanState,
        backSide: IdSideScanState?,
        singleCombinedSheet: Boolean,
        quality: ScanQuality,
        outputFile: File,
        password: String? = null
    ): Int = withContext(ioDispatcher) {
        val frontPath = frontSide.imagePath
            ?: error("Front side image is required for ${docType.displayName}.")
        ensurePdfBoxReady()

        val jpegQuality = (quality.jpegQuality / 100f).coerceIn(0.45f, 0.96f)
        val document = PDDocument(MemoryUsageSetting.setupTempFileOnly())
        try {
            val frontPdfImage = loadProcessedIdImage(document, frontSide, quality.maxDimension, jpegQuality)
                ?: error("Could not decode front side image.")

            val backPath = backSide?.imagePath
            val backPdfImage = if (!backPath.isNullOrBlank()) {
                loadProcessedIdImage(document, backSide, quality.maxDimension, jpegQuality)
            } else {
                null
            }

            val a4W = PDRectangle.A4.width
            val a4H = PDRectangle.A4.height

            if (singleCombinedSheet) {
                val page = PDPage(PDRectangle.A4)
                document.addPage(page)
                PDPageContentStream(document, page).use { stream ->
                    val marginX = 48f
                    val availW = a4W - marginX * 2f
                    if (backPdfImage != null) {
                        val topSlotBottom = a4H * 0.52f
                        val topSlotHeight = a4H - 52f - topSlotBottom
                        drawImageFittedWithBorder(stream, frontPdfImage, marginX, topSlotBottom, availW, topSlotHeight)

                        val bottomSlotBottom = 48f
                        val bottomSlotHeight = a4H * 0.48f - bottomSlotBottom
                        drawImageFittedWithBorder(stream, backPdfImage, marginX, bottomSlotBottom, availW, bottomSlotHeight)
                    } else {
                        val slotBottom = a4H * 0.28f
                        val slotHeight = a4H * 0.44f
                        drawImageFittedWithBorder(stream, frontPdfImage, marginX, slotBottom, availW, slotHeight)
                    }
                }
            } else {
                val frontPage = PDPage(PDRectangle.A4)
                document.addPage(frontPage)
                PDPageContentStream(document, frontPage).use { stream ->
                    drawImageFittedWithBorder(stream, frontPdfImage, 40f, 48f, a4W - 80f, a4H - 96f)
                }
                if (backPdfImage != null) {
                    val backPage = PDPage(PDRectangle.A4)
                    document.addPage(backPage)
                    PDPageContentStream(document, backPage).use { stream ->
                        drawImageFittedWithBorder(stream, backPdfImage, 40f, 48f, a4W - 80f, a4H - 96f)
                    }
                }
            }

            if (!password.isNullOrBlank()) {
                applyPasswordProtection(document, password)
            }

            document.save(outputFile)
            document.numberOfPages
        } finally {
            document.close()
        }
    }

    private fun loadProcessedIdImage(
        document: PDDocument,
        side: IdSideScanState,
        maxDim: Int,
        jpegQuality: Float
    ): PDImageXObject? {
        val path = side.imagePath ?: return null
        val raw = BitmapFilterEngine.decodeSampledBitmap(path, maxDimension = maxDim) ?: return null
        var transformed: Bitmap? = null
        return try {
            transformed = BitmapFilterEngine.cropAndTransform(
                source = raw,
                cropRect = side.cropRect,
                rotationDegrees = side.rotationDegrees,
                filter = side.filter
            )
            JPEGFactory.createFromImage(document, transformed, jpegQuality)
        } finally {
            if (transformed != null && transformed !== raw && !transformed.isRecycled) {
                transformed.recycle()
            }
            if (!raw.isRecycled) {
                raw.recycle()
            }
        }
    }

    private fun drawImageFittedWithBorder(
        stream: PDPageContentStream,
        image: PDImageXObject,
        slotX: Float,
        slotY: Float,
        slotW: Float,
        slotH: Float
    ) {
        val scale = min(slotW / image.width.toFloat(), slotH / image.height.toFloat())
        val drawW = image.width * scale
        val drawH = image.height * scale
        val x = slotX + (slotW - drawW) / 2f
        val y = slotY + (slotH - drawH) / 2f

        stream.drawImage(image, x, y, drawW, drawH)
        stream.saveGraphicsState()
        stream.setStrokingColor(0.75f, 0.75f, 0.75f)
        stream.setLineWidth(0.75f)
        stream.addRect(x, y, drawW, drawH)
        stream.stroke()
        stream.restoreGraphicsState()
    }

    suspend fun insertSignatureIntoPdf(
        sourceFile: File,
        outputFile: File,
        signaturePngFile: File,
        pageIndexZeroBased: Int,
        normX: Float,
        normY: Float,
        normWidth: Float,
        password: String? = null
    ): Int = withContext(ioDispatcher) {
        require(signaturePngFile.exists() && signaturePngFile.length() > 0L) {
            "Selected signature file could not be found."
        }
        val sigBitmap = BitmapFilterEngine.decodeSampledBitmap(
            signaturePngFile.absolutePath,
            maxDimension = BitmapFilterEngine.MAX_SAFE_IMAGE_DIMENSION
        ) ?: error("Could not decode signature image.")

        try {
            loadDocument(sourceFile, password).use { doc ->
                require(pageIndexZeroBased in 0 until doc.numberOfPages) {
                    "Selected page is out of range (1..${doc.numberOfPages})."
                }
                val page = doc.getPage(pageIndexZeroBased)
                val box = page.cropBox ?: page.mediaBox ?: PDRectangle.A4

                val sigImage = LosslessFactory.createFromImage(doc, sigBitmap)
                val sigAspectH = sigBitmap.height.coerceAtLeast(1).toFloat() / sigBitmap.width.coerceAtLeast(1).toFloat()

                val safeWidthFraction = normWidth.coerceIn(0.06f, 0.90f)
                val sigW = (box.width * safeWidthFraction).coerceAtMost(box.width)
                val sigH = (sigW * sigAspectH).coerceAtMost(box.height * 0.85f)
                val adjustedSigW = if (sigW * sigAspectH > box.height * 0.85f) {
                    sigH / sigAspectH
                } else {
                    sigW
                }

                val relX = (normX.coerceIn(0f, 1f) * box.width)
                    .coerceIn(0f, (box.width - adjustedSigW).coerceAtLeast(0f))
                val topOffset = normY.coerceIn(0f, 1f) * box.height
                val relY = (box.height - topOffset - sigH)
                    .coerceIn(0f, (box.height - sigH).coerceAtLeast(0f))

                val pdfX = box.lowerLeftX + relX
                val pdfY = box.lowerLeftY + relY

                PDPageContentStream(
                    doc,
                    page,
                    PDPageContentStream.AppendMode.APPEND,
                    true,
                    true
                ).use { stream ->
                    stream.drawImage(sigImage, pdfX, pdfY, adjustedSigW, sigH)
                }

                if (!password.isNullOrEmpty()) {
                    applyPasswordProtection(doc, password)
                }
                doc.save(outputFile)
                doc.numberOfPages
            }
        } finally {
            if (!sigBitmap.isRecycled) {
                sigBitmap.recycle()
            }
        }
    }

    private fun sanitizePdfText(raw: String): String =
        raw.map { ch -> if (ch.code in 32..126) ch else ' ' }.joinToString("")
}
