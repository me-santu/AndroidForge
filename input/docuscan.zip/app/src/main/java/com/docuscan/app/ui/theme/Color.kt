package com.docuscan.app.ui.theme

import androidx.compose.ui.graphics.Color

// Brand & Signature Dark + Yellow Palette
val DocuGold = Color(0xFFF5C542)
val ScanButtonGold = Color(0xFFFFC107)
val DocuGoldPressed = Color(0xFFD9A826)
val DocuGoldContainerDark = Color(0xFF3A3012)
val DocuGoldOnContainerDark = Color(0xFFFFE494)

val DarkBackground = Color(0xFF121212)
val DarkSurface = Color(0xFF1E1E1E)
val DarkCard = Color(0xFF252525)
val DarkCardElevated = Color(0xFF2D2D2D)
val DarkBorder = Color(0xFF333333)
val DarkTextPrimary = Color(0xFFFFFFFF)
val DarkTextSecondary = Color(0xFFA3A3A3)

// Crisp Editorial Light Palette
val LightGold = Color(0xFFD49E15)
val LightGoldContainer = Color(0xFFFFF1C7)
val LightGoldOnContainer = Color(0xFF2E2000)

val LightBackground = Color(0xFFF6F5F0)
val LightSurface = Color(0xFFFFFFFF)
val LightCard = Color(0xFFEEECE4)
val LightCardElevated = Color(0xFFE5E2D7)
val LightBorder = Color(0xFFD8D4C7)
val LightTextPrimary = Color(0xFF141414)
val LightTextSecondary = Color(0xFF5C5C5C)

// Semantic Accents
val TealAccent = Color(0xFF4FD1C5)
val TealAccentDark = Color(0xFF0D9488)
val ErrorRedDark = Color(0xFFCF6679)
val ErrorRedLight = Color(0xFFBA1A1A)
val SuccessGreen = Color(0xFF4ADE80)

// High-Contrast Switch Tokens
val SwitchUncheckedTrackDark = Color(0xFF2C2C2E)
val SwitchUncheckedBorderDark = Color(0xFF75757A)
val SwitchUncheckedThumbDark = Color(0xFFD1D1D6)

val SwitchUncheckedTrackLight = Color(0xFFE2E2E6)
val SwitchUncheckedBorderLight = Color(0xFF8E8E93)
val SwitchUncheckedThumbLight = Color(0xFFFFFFFF)

val SwitchCheckedTrack = Color(0xFFFFC107)
val SwitchCheckedThumb = Color(0xFF121212)
val SwitchCheckedBorder = Color(0xFFFFC107)
