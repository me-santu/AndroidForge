package com.docuscan.app.ui.screens

import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.WindowInsetsSides
import androidx.compose.foundation.layout.consumeWindowInsets
import androidx.compose.foundation.layout.displayCutoutPadding
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.imePadding
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.only
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.safeDrawing
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import com.docuscan.app.ui.icons.LucideIcons
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FilterChipDefaults
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Slider
import androidx.compose.material3.SliderDefaults
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.minimumInteractiveComponentSize
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.unit.dp
import com.docuscan.app.domain.model.DocumentItem
import com.docuscan.app.domain.model.FolderItem
import com.docuscan.app.domain.model.PdfCreationOptions
import com.docuscan.app.domain.model.PdfOrientation
import com.docuscan.app.domain.model.PdfPageSize
import com.docuscan.app.domain.model.ScanPage
import com.docuscan.app.domain.model.ScanQuality
import com.docuscan.app.ui.components.DocuScanCard
import com.docuscan.app.ui.components.DocuScanSwitch
import com.docuscan.app.ui.components.DocuScanTopBar
import com.docuscan.app.ui.components.EmptyStateView
import com.docuscan.app.ui.components.ErrorStateView
import com.docuscan.app.ui.viewmodel.OperationState
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import kotlin.math.roundToInt

@Composable
fun PdfCreatorScreen(
    pages: List<ScanPage>,
    folders: List<FolderItem>,
    scanQuality: ScanQuality,
    defaultPageSize: PdfPageSize = PdfPageSize.A4,
    operationState: OperationState,
    initialTitle: String? = null,
    onCreateFolder: (String) -> Unit,
    onGeneratePdf: (title: String, folderId: Long?, options: PdfCreationOptions, onCreated: (DocumentItem) -> Unit) -> Unit,
    onPdfCreated: (Long) -> Unit,
    onGoToPageManager: () -> Unit,
    onBack: () -> Unit
) {
    val defaultTitle = remember(initialTitle) {
        initialTitle?.takeIf { it.isNotBlank() } ?: run {
            val stamp = SimpleDateFormat("yyyyMMdd_HHmm", Locale.US).format(Date())
            "Scan_$stamp"
        }
    }
    var title by remember(defaultTitle) { mutableStateOf(defaultTitle) }
    var selectedFolderId by remember { mutableStateOf<Long?>(null) }
    var selectedPageSize by remember(defaultPageSize) { mutableStateOf(defaultPageSize) }
    var customWidthStr by remember { mutableStateOf("595") }
    var customHeightStr by remember { mutableStateOf("842") }
    var orientation by remember { mutableStateOf(PdfOrientation.PORTRAIT) }
    var marginPt by remember { mutableFloatStateOf(24f) }
    var includePageNumbers by remember { mutableStateOf(true) }
    var embedSearchableText by remember { mutableStateOf(false) }
    var selectedQuality by remember(scanQuality) { mutableStateOf(scanQuality) }
    var watermarkText by remember { mutableStateOf("") }
    var passwordText by remember { mutableStateOf("") }
    var showNewFolderDialog by remember { mutableStateOf(false) }
    var newFolderName by remember { mutableStateOf("") }

    Scaffold(
        modifier = Modifier.fillMaxSize(),
        containerColor = MaterialTheme.colorScheme.background,
        contentWindowInsets = if (pages.isNotEmpty()) {
            WindowInsets.safeDrawing.only(WindowInsetsSides.Horizontal)
        } else {
            WindowInsets.safeDrawing.only(WindowInsetsSides.Bottom + WindowInsetsSides.Horizontal)
        },
        topBar = {
            DocuScanTopBar(
                title = "PDF Creator",
                subtitle = "${pages.size} page(s) · ${selectedQuality.label}",
                onBack = onBack
            )
        },
        bottomBar = {
            if (pages.isNotEmpty()) {
                Surface(
                    color = MaterialTheme.colorScheme.surface,
                    tonalElevation = 0.dp,
                    shadowElevation = 0.dp
                ) {
                    Column(modifier = Modifier.fillMaxWidth()) {
                        HorizontalDivider(
                            thickness = 1.dp,
                            color = MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.4f)
                        )
                        Box(
                            modifier = Modifier
                                .fillMaxWidth()
                                .navigationBarsPadding()
                                .imePadding()
                                .displayCutoutPadding()
                                .padding(horizontal = 16.dp, vertical = 12.dp)
                        ) {
                            Button(
                                onClick = {
                                    val options = PdfCreationOptions(
                                        pageSize = selectedPageSize,
                                        customWidthPt = customWidthStr.toIntOrNull()?.coerceIn(200, 2400) ?: 595,
                                        customHeightPt = customHeightStr.toIntOrNull()?.coerceIn(200, 3200) ?: 842,
                                        orientation = orientation,
                                        marginPt = marginPt,
                                        includePageNumbers = includePageNumbers,
                                        quality = selectedQuality,
                                        watermarkText = watermarkText.trim(),
                                        password = passwordText,
                                        embedSearchableText = embedSearchableText
                                    )
                                    onGeneratePdf(title, selectedFolderId, options) { created ->
                                        onPdfCreated(created.id)
                                    }
                                },
                                enabled = operationState !is OperationState.Working && title.isNotBlank(),
                                colors = ButtonDefaults.buttonColors(
                                    containerColor = MaterialTheme.colorScheme.primary,
                                    contentColor = MaterialTheme.colorScheme.onPrimary
                                ),
                                shape = MaterialTheme.shapes.medium,
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .height(54.dp)
                                    .minimumInteractiveComponentSize()
                                    .testTag("pdf_creator_generate_btn")
                            ) {
                                if (operationState is OperationState.Working) {
                                    CircularProgressIndicator(
                                        color = MaterialTheme.colorScheme.onPrimary,
                                        modifier = Modifier.size(20.dp),
                                        strokeWidth = 2.dp
                                    )
                                    Spacer(modifier = Modifier.size(10.dp))
                                    Text("Generating PDF...")
                                } else {
                                    Icon(LucideIcons.FileText, contentDescription = null, modifier = Modifier.size(20.dp))
                                    Spacer(modifier = Modifier.size(8.dp))
                                    Text("Generate Real PDF (${pages.size} Pages)")
                                }
                            }
                        }
                    }
                }
            }
        }
    ) { innerPadding ->
        if (pages.isEmpty()) {
            EmptyStateView(
                title = "No pages queued for PDF",
                subtitle = "Add scanned or imported pages in Page Manager first to generate a PDF document.",
                actionLabel = "Open Page Manager",
                onAction = onGoToPageManager,
                modifier = Modifier
                    .padding(innerPadding)
                    .consumeWindowInsets(innerPadding)
            )
            return@Scaffold
        }

        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
                .consumeWindowInsets(innerPadding)
                .verticalScroll(rememberScrollState())
                .padding(start = 16.dp, end = 16.dp, top = 12.dp, bottom = 20.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            DocuScanCard {
                Text("Document Details", style = MaterialTheme.typography.titleMedium)
                Spacer(modifier = Modifier.height(10.dp))
                OutlinedTextField(
                    value = title,
                    onValueChange = { title = it },
                    label = { Text("PDF Title") },
                    singleLine = true,
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("pdf_creator_title_input")
                )
            }

            DocuScanCard {
                Text("Page Size & Orientation", style = MaterialTheme.typography.titleMedium)
                Spacer(modifier = Modifier.height(10.dp))
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .horizontalScroll(rememberScrollState()),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    PdfPageSize.entries.forEach { size ->
                        FilterChip(
                            selected = selectedPageSize == size,
                            onClick = { selectedPageSize = size },
                            label = { Text(size.label) },
                            colors = FilterChipDefaults.filterChipColors(
                                selectedContainerColor = MaterialTheme.colorScheme.primary,
                                selectedLabelColor = MaterialTheme.colorScheme.onPrimary
                            ),
                            modifier = Modifier.testTag("pdf_size_${size.name.lowercase()}")
                        )
                    }
                }

                if (selectedPageSize == PdfPageSize.CUSTOM) {
                    Spacer(modifier = Modifier.height(10.dp))
                    Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                        OutlinedTextField(
                            value = customWidthStr,
                            onValueChange = { customWidthStr = it.filter(Char::isDigit) },
                            label = { Text("Width (pt)") },
                            singleLine = true,
                            modifier = Modifier.weight(1f)
                        )
                        OutlinedTextField(
                            value = customHeightStr,
                            onValueChange = { customHeightStr = it.filter(Char::isDigit) },
                            label = { Text("Height (pt)") },
                            singleLine = true,
                            modifier = Modifier.weight(1f)
                        )
                    }
                }

                if (selectedPageSize != PdfPageSize.FIT_IMAGE) {
                    Spacer(modifier = Modifier.height(10.dp))
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        PdfOrientation.entries.forEach { mode ->
                            FilterChip(
                                selected = orientation == mode,
                                onClick = { orientation = mode },
                                label = { Text(mode.label) },
                                colors = FilterChipDefaults.filterChipColors(
                                    selectedContainerColor = MaterialTheme.colorScheme.primary,
                                    selectedLabelColor = MaterialTheme.colorScheme.onPrimary
                                ),
                                modifier = Modifier.testTag("pdf_orient_${mode.name.lowercase()}")
                            )
                        }
                    }

                    Spacer(modifier = Modifier.height(10.dp))
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text("Page Margin", style = MaterialTheme.typography.bodyMedium)
                        Text(
                            text = "${marginPt.roundToInt()} pt",
                            style = MaterialTheme.typography.labelLarge,
                            color = MaterialTheme.colorScheme.primary
                        )
                    }
                    Slider(
                        value = marginPt,
                        onValueChange = { marginPt = it },
                        valueRange = 0f..64f,
                        colors = SliderDefaults.colors(
                            thumbColor = MaterialTheme.colorScheme.primary,
                            activeTrackColor = MaterialTheme.colorScheme.primary
                        )
                    )
                }

                Spacer(modifier = Modifier.height(6.dp))
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column(modifier = Modifier.weight(1f)) {
                        Text("PDF Page Numbers", style = MaterialTheme.typography.bodyMedium)
                        Text(
                            text = "Print 'Page X of N' footer at bottom center",
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                    DocuScanSwitch(
                        checked = includePageNumbers,
                        onCheckedChange = { includePageNumbers = it },
                        modifier = Modifier.testTag("pdf_creator_page_numbers_switch")
                    )
                }

                Spacer(modifier = Modifier.height(10.dp))
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column(modifier = Modifier.weight(1f)) {
                        Text("Searchable PDF (Invisible OCR Layer)", style = MaterialTheme.typography.bodyMedium)
                        Text(
                            text = "Embeds hidden OCR text beneath scanned pages so text is searchable & selectable in PDF viewers",
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                    DocuScanSwitch(
                        checked = embedSearchableText,
                        onCheckedChange = { embedSearchableText = it },
                        modifier = Modifier.testTag("pdf_creator_searchable_switch")
                    )
                }
            }

            DocuScanCard {
                Text("Quality, Watermark & Security", style = MaterialTheme.typography.titleMedium)
                Spacer(modifier = Modifier.height(10.dp))
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .horizontalScroll(rememberScrollState()),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    ScanQuality.entries.forEach { q ->
                        FilterChip(
                            selected = selectedQuality == q,
                            onClick = { selectedQuality = q },
                            label = { Text(q.label) },
                            colors = FilterChipDefaults.filterChipColors(
                                selectedContainerColor = MaterialTheme.colorScheme.primary,
                                selectedLabelColor = MaterialTheme.colorScheme.onPrimary
                            )
                        )
                    }
                }
                Spacer(modifier = Modifier.height(10.dp))
                OutlinedTextField(
                    value = watermarkText,
                    onValueChange = { watermarkText = it },
                    label = { Text("Optional Watermark (e.g. CONFIDENTIAL)") },
                    singleLine = true,
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("pdf_creator_watermark_input")
                )
                Spacer(modifier = Modifier.height(10.dp))
                OutlinedTextField(
                    value = passwordText,
                    onValueChange = { passwordText = it },
                    label = { Text("Optional PDF Password (AES-128)") },
                    visualTransformation = PasswordVisualTransformation(),
                    singleLine = true,
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("pdf_creator_password_input")
                )
            }

            DocuScanCard {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text("Save to Folder", style = MaterialTheme.typography.titleMedium)
                    TextButton(onClick = { showNewFolderDialog = true }) {
                        Icon(
                            imageVector = LucideIcons.FolderPlus,
                            contentDescription = "New Folder",
                            modifier = Modifier.size(16.dp)
                        )
                        Spacer(modifier = Modifier.size(6.dp))
                        Text("New Folder")
                    }
                }
                Spacer(modifier = Modifier.height(8.dp))
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .horizontalScroll(rememberScrollState()),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    FilterChip(
                        selected = selectedFolderId == null,
                        onClick = { selectedFolderId = null },
                        label = { Text("All Documents (Root)") },
                        colors = FilterChipDefaults.filterChipColors(
                            selectedContainerColor = MaterialTheme.colorScheme.primary,
                            selectedLabelColor = MaterialTheme.colorScheme.onPrimary
                        )
                    )
                    folders.forEach { folder ->
                        FilterChip(
                            selected = selectedFolderId == folder.id,
                            onClick = { selectedFolderId = folder.id },
                            label = { Text(folder.name) },
                            colors = FilterChipDefaults.filterChipColors(
                                selectedContainerColor = MaterialTheme.colorScheme.primary,
                                selectedLabelColor = MaterialTheme.colorScheme.onPrimary
                            )
                        )
                    }
                }
            }

            if (operationState is OperationState.Error) {
                ErrorStateView(message = operationState.message)
            }

        }
    }

    if (showNewFolderDialog) {
        AlertDialog(
            onDismissRequest = { showNewFolderDialog = false },
            title = { Text("Create Folder") },
            text = {
                OutlinedTextField(
                    value = newFolderName,
                    onValueChange = { newFolderName = it },
                    label = { Text("Folder name") },
                    singleLine = true
                )
            },
            confirmButton = {
                TextButton(
                    onClick = {
                        if (newFolderName.isNotBlank()) {
                            onCreateFolder(newFolderName)
                            newFolderName = ""
                            showNewFolderDialog = false
                        }
                    }
                ) { Text("Create") }
            },
            dismissButton = {
                TextButton(onClick = { showNewFolderDialog = false }) { Text("Cancel") }
            }
        )
    }
}
