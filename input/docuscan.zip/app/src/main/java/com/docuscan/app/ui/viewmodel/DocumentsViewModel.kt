package com.docuscan.app.ui.viewmodel

import android.net.Uri
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.docuscan.app.domain.model.DeletedDocumentItem
import com.docuscan.app.domain.model.DocumentFileType
import com.docuscan.app.domain.model.DocumentItem
import com.docuscan.app.domain.model.DocumentSortOption
import com.docuscan.app.domain.model.DocumentViewMode
import com.docuscan.app.domain.model.FolderItem
import com.docuscan.app.domain.model.StorageSummary
import com.docuscan.app.domain.repository.DocumentRepository
import com.docuscan.app.security.SecurityManager
import com.docuscan.app.util.LocalFileManager
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.catch
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch

sealed interface DocumentsUiState {
    data object Loading : DocumentsUiState
    data class Success(
        val documents: List<DocumentItem>,
        val folders: List<FolderItem>,
        val selectedFolderId: Long?,
        val searchQuery: String,
        val sortOption: DocumentSortOption = DocumentSortOption.DATE_DESC,
        val viewMode: DocumentViewMode = DocumentViewMode.LIST,
        val favoritesOnly: Boolean = false,
        val selectedDocumentIds: Set<Long> = emptySet()
    ) : DocumentsUiState
    data class Error(val message: String) : DocumentsUiState
}

class DocumentsViewModel(
    private val repository: DocumentRepository,
    private val fileManager: LocalFileManager,
    private val securityManager: SecurityManager? = null
) : ViewModel() {

    private val _searchQuery = MutableStateFlow("")
    val searchQuery: StateFlow<String> = _searchQuery.asStateFlow()

    private val _selectedFolderId = MutableStateFlow<Long?>(null)
    val selectedFolderId: StateFlow<Long?> = _selectedFolderId.asStateFlow()

    private val _sortOption = MutableStateFlow(DocumentSortOption.DATE_DESC)
    val sortOption: StateFlow<DocumentSortOption> = _sortOption.asStateFlow()

    private val _viewMode = MutableStateFlow(DocumentViewMode.LIST)
    val viewMode: StateFlow<DocumentViewMode> = _viewMode.asStateFlow()

    private val _favoritesOnly = MutableStateFlow(false)
    val favoritesOnly: StateFlow<Boolean> = _favoritesOnly.asStateFlow()

    private val _selectedDocumentIds = MutableStateFlow<Set<Long>>(emptySet())
    val selectedDocumentIds: StateFlow<Set<Long>> = _selectedDocumentIds.asStateFlow()

    private val _statusMessage = MutableStateFlow<String?>(null)
    val statusMessage: StateFlow<String?> = _statusMessage.asStateFlow()

    val recentDocuments: StateFlow<List<DocumentItem>> = repository.observeRecentDocuments(8)
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val storageSummary: StateFlow<StorageSummary> = repository.observeStorageSummary()
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), StorageSummary())

    val trashDocuments: StateFlow<List<DocumentItem>> = repository.observeTrashDocuments()
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val deletedDocuments: StateFlow<List<DeletedDocumentItem>> = repository.observeDeletedDocuments()
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    private data class FilterPreferences(
        val selectedFolderId: Long?,
        val searchQuery: String,
        val sortOption: DocumentSortOption,
        val viewMode: DocumentViewMode,
        val favoritesOnly: Boolean
    )

    private val filterPreferencesFlow = combine(
        _selectedFolderId,
        _searchQuery,
        _sortOption,
        _viewMode,
        _favoritesOnly
    ) { folderId, query, sort, mode, favOnly ->
        FilterPreferences(folderId, query, sort, mode, favOnly)
    }

    val documentsUiState: StateFlow<DocumentsUiState> = combine(
        repository.observeActiveDocuments(),
        repository.observeFolders(),
        filterPreferencesFlow,
        _selectedDocumentIds
    ) { docs, folders, prefs, selectedIds ->
        val filtered = docs.filter { doc ->
            val matchesFolder = prefs.selectedFolderId == null || doc.folderId == prefs.selectedFolderId
            val matchesFav = !prefs.favoritesOnly || doc.isFavorite
            val matchesQuery = prefs.searchQuery.isBlank() ||
                doc.title.contains(prefs.searchQuery, ignoreCase = true) ||
                (doc.folderName?.contains(prefs.searchQuery, ignoreCase = true) == true) ||
                doc.ocrText.contains(prefs.searchQuery, ignoreCase = true)
            matchesFolder && matchesFav && matchesQuery
        }

        val sorted = when (prefs.sortOption) {
            DocumentSortOption.DATE_DESC -> filtered.sortedWith(
                compareByDescending<DocumentItem> { it.isPinned }.thenByDescending { it.updatedAt }
            )
            DocumentSortOption.DATE_ASC -> filtered.sortedWith(
                compareByDescending<DocumentItem> { it.isPinned }.thenBy { it.updatedAt }
            )
            DocumentSortOption.NAME_ASC -> filtered.sortedWith(
                compareByDescending<DocumentItem> { it.isPinned }.thenBy { it.title.lowercase() }
            )
            DocumentSortOption.SIZE_DESC -> filtered.sortedWith(
                compareByDescending<DocumentItem> { it.isPinned }.thenByDescending { it.sizeBytes }
            )
        }

        val validSelection = selectedIds.intersect(sorted.map { it.id }.toSet())

        DocumentsUiState.Success(
            documents = sorted,
            folders = folders,
            selectedFolderId = prefs.selectedFolderId,
            searchQuery = prefs.searchQuery,
            sortOption = prefs.sortOption,
            viewMode = prefs.viewMode,
            favoritesOnly = prefs.favoritesOnly,
            selectedDocumentIds = validSelection
        ) as DocumentsUiState
    }.catch { err ->
        emit(DocumentsUiState.Error(err.message ?: "Unable to load documents"))
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), DocumentsUiState.Loading)

    val filteredHomeDocuments: StateFlow<List<DocumentItem>> = combine(
        repository.observeActiveDocuments(),
        _searchQuery
    ) { docs, query ->
        if (query.isBlank()) docs.take(6)
        else docs.filter {
            it.title.contains(query, ignoreCase = true) ||
                (it.folderName?.contains(query, ignoreCase = true) == true) ||
                it.ocrText.contains(query, ignoreCase = true)
        }
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    fun updateSearchQuery(query: String) {
        _searchQuery.value = query
    }

    fun selectFolder(folderId: Long?) {
        _selectedFolderId.value = folderId
    }

    fun setSortOption(option: DocumentSortOption) {
        _sortOption.value = option
    }

    fun toggleViewMode() {
        _viewMode.value = if (_viewMode.value == DocumentViewMode.LIST) {
            DocumentViewMode.GRID
        } else {
            DocumentViewMode.LIST
        }
    }

    fun toggleFavoritesOnly() {
        _favoritesOnly.value = !_favoritesOnly.value
    }

    fun toggleSelection(documentId: Long) {
        val current = _selectedDocumentIds.value
        _selectedDocumentIds.value = if (documentId in current) current - documentId else current + documentId
    }

    fun selectAll(documents: List<DocumentItem>) {
        _selectedDocumentIds.value = documents.map { it.id }.toSet()
    }

    fun clearSelection() {
        _selectedDocumentIds.value = emptySet()
    }

    fun createFolder(name: String) {
        viewModelScope.launch {
            repository.createFolder(name)
                .onSuccess { _statusMessage.value = "Folder '${it.name}' created" }
                .onFailure { _statusMessage.value = it.message ?: "Could not create folder" }
        }
    }

    fun renameFolder(folderId: Long, newName: String) {
        viewModelScope.launch {
            repository.renameFolder(folderId, newName)
                .onSuccess { _statusMessage.value = "Folder renamed" }
                .onFailure { _statusMessage.value = it.message ?: "Could not rename folder" }
        }
    }

    fun deleteFolder(folderId: Long) {
        viewModelScope.launch {
            repository.deleteFolder(folderId)
                .onSuccess {
                    if (_selectedFolderId.value == folderId) _selectedFolderId.value = null
                    _statusMessage.value = "Folder removed"
                }
                .onFailure { _statusMessage.value = it.message ?: "Could not remove folder" }
        }
    }

    fun renameDocument(documentId: Long, newTitle: String) {
        viewModelScope.launch {
            repository.renameDocument(documentId, newTitle)
                .onSuccess { _statusMessage.value = "Document renamed" }
                .onFailure { _statusMessage.value = it.message ?: "Could not rename document" }
        }
    }

    fun togglePin(documentId: Long) {
        viewModelScope.launch { repository.togglePin(documentId) }
    }

    fun toggleFavorite(documentId: Long) {
        viewModelScope.launch {
            repository.toggleFavorite(documentId)
                .onFailure { _statusMessage.value = it.message }
        }
    }

    fun moveDocumentToFolder(documentId: Long, folderId: Long?) {
        viewModelScope.launch {
            repository.moveDocumentToFolder(documentId, folderId)
                .onSuccess { _statusMessage.value = "Document moved" }
                .onFailure { _statusMessage.value = it.message ?: "Move failed" }
        }
    }

    fun moveSelectedToFolder(folderId: Long?) {
        val ids = _selectedDocumentIds.value.toList()
        if (ids.isEmpty()) return
        viewModelScope.launch {
            repository.moveDocumentsToFolder(ids, folderId)
                .onSuccess {
                    _selectedDocumentIds.value = emptySet()
                    _statusMessage.value = "${ids.size} document(s) moved"
                }
                .onFailure { _statusMessage.value = it.message ?: "Batch move failed" }
        }
    }

    fun setSelectedFavorites(isFavorite: Boolean) {
        val ids = _selectedDocumentIds.value.toList()
        if (ids.isEmpty()) return
        viewModelScope.launch {
            repository.setFavorites(ids, isFavorite)
                .onSuccess {
                    _selectedDocumentIds.value = emptySet()
                    _statusMessage.value = if (isFavorite) "Added to Favorites" else "Removed from Favorites"
                }
        }
    }

    fun trashSelected() {
        val ids = _selectedDocumentIds.value.toList()
        if (ids.isEmpty()) return
        viewModelScope.launch {
            repository.moveDocumentsToTrash(ids)
                .onSuccess {
                    _selectedDocumentIds.value = emptySet()
                    _statusMessage.value = "${ids.size} document(s) moved to Recycle Bin"
                }
                .onFailure { _statusMessage.value = it.message ?: "Batch delete failed" }
        }
    }

    fun mergeSelectedPdfs(title: String, onCreated: (DocumentItem) -> Unit = {}) {
        val ids = _selectedDocumentIds.value.toList()
        if (ids.size < 2) {
            _statusMessage.value = "Select at least 2 PDFs to merge"
            return
        }
        viewModelScope.launch {
            repository.mergePdfDocuments(title, ids, _selectedFolderId.value)
                .onSuccess { doc ->
                    _selectedDocumentIds.value = emptySet()
                    _statusMessage.value = "Merged '${doc.title}' (${doc.pageCount}p)"
                    onCreated(doc)
                }
                .onFailure { _statusMessage.value = it.message ?: "Merge failed" }
        }
    }

    fun importExternalPdfUri(uri: Uri, onImported: (DocumentItem) -> Unit = {}) {
        viewModelScope.launch {
            repository.importExternalPdfUri(uri, _selectedFolderId.value)
                .onSuccess { doc ->
                    _statusMessage.value = "Imported '${doc.title}' (${doc.pageCount}p)"
                    onImported(doc)
                }
                .onFailure { err ->
                    _statusMessage.value = err.message ?: "Could not import PDF"
                }
        }
    }

    fun exportDocumentToUri(documentId: Long, destinationUri: Uri) {
        viewModelScope.launch {
            repository.exportDocumentToUri(documentId, destinationUri)
                .onSuccess { _statusMessage.value = "Exported copy safely" }
                .onFailure { err -> _statusMessage.value = err.message ?: "Export failed" }
        }
    }

    fun moveToTrash(documentId: Long) {
        viewModelScope.launch {
            repository.moveDocumentToTrash(documentId)
                .onSuccess { _statusMessage.value = "Moved to Recycle Bin" }
        }
    }

    fun restoreFromTrash(documentId: Long) {
        viewModelScope.launch {
            repository.restoreDocument(documentId)
                .onSuccess { _statusMessage.value = "Document restored" }
                .onFailure { _statusMessage.value = it.message ?: "Could not restore document" }
        }
    }

    fun permanentlyDelete(documentId: Long) {
        viewModelScope.launch {
            repository.permanentlyDeleteDocument(documentId)
                .onSuccess { _statusMessage.value = "Permanently deleted" }
        }
    }

    fun emptyRecycleBin() {
        viewModelScope.launch {
            repository.emptyRecycleBin()
                .onSuccess { _statusMessage.value = "Recycle Bin emptied" }
        }
    }

    fun toggleVaultEncryption(documentId: Long) {
        viewModelScope.launch {
            val isSealed = repository.isDocumentVaultEncrypted(documentId)
            val result = if (isSealed) {
                repository.unsealDocumentInVault(documentId)
            } else {
                repository.sealDocumentInVault(documentId)
            }
            result.onSuccess {
                _statusMessage.value = if (isSealed) {
                    "Removed Keystore vault encryption"
                } else {
                    "Encrypted file with Android Keystore"
                }
            }.onFailure { err ->
                _statusMessage.value = err.message ?: "Vault encryption update failed"
            }
        }
    }

    fun shareDocument(doc: DocumentItem) {
        val mime = if (doc.fileType == DocumentFileType.PDF || doc.fileType == DocumentFileType.ID_CARD) {
            "application/pdf"
        } else {
            "image/jpeg"
        }
        fileManager.shareFile(doc.filePath, mime, "Share ${doc.title}", securityManager)
    }

    fun clearStatusMessage() {
        _statusMessage.value = null
    }
}
