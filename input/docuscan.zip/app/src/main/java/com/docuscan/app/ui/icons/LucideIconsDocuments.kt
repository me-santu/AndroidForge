package com.docuscan.app.ui.icons

import androidx.compose.ui.graphics.vector.ImageVector

internal object LucideDocIcons {

    val ScanLine: ImageVector by lazy {
        lucideIcon("ScanLine") {
            strokePath {
                moveTo(3f, 7f)
                verticalLineTo(5f)
                arcTo(2f, 2f, 0f, false, true, 5f, 3f)
                horizontalLineTo(7f)
            }
            strokePath {
                moveTo(17f, 3f)
                horizontalLineTo(19f)
                arcTo(2f, 2f, 0f, false, true, 21f, 5f)
                verticalLineTo(7f)
            }
            strokePath {
                moveTo(21f, 17f)
                verticalLineTo(19f)
                arcTo(2f, 2f, 0f, false, true, 19f, 21f)
                horizontalLineTo(17f)
            }
            strokePath {
                moveTo(7f, 21f)
                horizontalLineTo(5f)
                arcTo(2f, 2f, 0f, false, true, 3f, 19f)
                verticalLineTo(17f)
            }
            line(7f, 12f, 17f, 12f)
        }
    }

    val FileText: ImageVector by lazy {
        lucideIcon("FileText") {
            strokePath {
                moveTo(15f, 2f)
                horizontalLineTo(6f)
                arcTo(2f, 2f, 0f, false, false, 4f, 4f)
                verticalLineTo(20f)
                arcTo(2f, 2f, 0f, false, false, 6f, 22f)
                horizontalLineTo(18f)
                arcTo(2f, 2f, 0f, false, false, 20f, 20f)
                verticalLineTo(7f)
                close()
            }
            strokePath {
                moveTo(14f, 2f)
                verticalLineTo(8f)
                horizontalLineTo(20f)
            }
            line(16f, 13f, 8f, 13f)
            line(16f, 17f, 8f, 17f)
            line(10f, 9f, 8f, 9f)
        }
    }

    val FileUp: ImageVector by lazy {
        lucideIcon("FileUp") {
            strokePath {
                moveTo(15f, 2f)
                horizontalLineTo(6f)
                arcTo(2f, 2f, 0f, false, false, 4f, 4f)
                verticalLineTo(20f)
                arcTo(2f, 2f, 0f, false, false, 6f, 22f)
                horizontalLineTo(18f)
                arcTo(2f, 2f, 0f, false, false, 20f, 20f)
                verticalLineTo(7f)
                close()
            }
            strokePath {
                moveTo(14f, 2f)
                verticalLineTo(8f)
                horizontalLineTo(20f)
            }
            line(12f, 12f, 12f, 18f)
            strokePath {
                moveTo(15f, 15f)
                lineTo(12f, 12f)
                lineTo(9f, 15f)
            }
        }
    }

    val FilePen: ImageVector by lazy {
        lucideIcon("FilePen") {
            strokePath {
                moveTo(12.5f, 22f)
                horizontalLineTo(6f)
                arcTo(2f, 2f, 0f, false, true, 4f, 20f)
                verticalLineTo(4f)
                arcTo(2f, 2f, 0f, false, true, 6f, 2f)
                horizontalLineTo(14f)
                lineTo(20f, 8f)
                verticalLineTo(10f)
            }
            strokePath {
                moveTo(14f, 2f)
                verticalLineTo(8f)
                horizontalLineTo(20f)
            }
            strokePath {
                moveTo(18.5f, 13.5f)
                arcTo(2.12f, 2.12f, 0f, false, true, 21.5f, 16.5f)
                lineTo(16f, 22f)
                lineTo(12f, 22f)
                lineTo(12.5f, 18.5f)
                close()
            }
        }
    }

    val Folder: ImageVector by lazy {
        lucideIcon("Folder") {
            strokePath {
                moveTo(20f, 20f)
                arcTo(2f, 2f, 0f, false, false, 22f, 18f)
                verticalLineTo(8f)
                arcTo(2f, 2f, 0f, false, false, 20f, 6f)
                horizontalLineTo(12.1f)
                arcTo(2f, 2f, 0f, false, true, 10.4f, 5.1f)
                lineTo(9.6f, 3.9f)
                arcTo(2f, 2f, 0f, false, false, 7.9f, 3f)
                horizontalLineTo(4f)
                arcTo(2f, 2f, 0f, false, false, 2f, 5f)
                verticalLineTo(18f)
                arcTo(2f, 2f, 0f, false, false, 4f, 20f)
                close()
            }
        }
    }

    val FolderOpen: ImageVector by lazy {
        lucideIcon("FolderOpen") {
            strokePath {
                moveTo(6f, 14f)
                lineTo(4.55f, 18.9f)
                arcTo(1.5f, 1.5f, 0f, false, false, 6f, 21f)
                horizontalLineTo(18.8f)
                arcTo(2f, 2f, 0f, false, false, 20.7f, 19.6f)
                lineTo(22f, 13f)
                arcTo(1f, 1f, 0f, false, false, 21f, 12f)
                horizontalLineTo(8f)
                arcTo(2f, 2f, 0f, false, false, 6f, 14f)
                close()
            }
            strokePath {
                moveTo(2f, 18f)
                verticalLineTo(5f)
                arcTo(2f, 2f, 0f, false, true, 4f, 3f)
                horizontalLineTo(8f)
                lineTo(10f, 6f)
                horizontalLineTo(18f)
                arcTo(2f, 2f, 0f, false, true, 20f, 8f)
                verticalLineTo(12f)
            }
        }
    }

    val FolderPlus: ImageVector by lazy {
        lucideIcon("FolderPlus") {
            strokePath {
                moveTo(20f, 20f)
                arcTo(2f, 2f, 0f, false, false, 22f, 18f)
                verticalLineTo(8f)
                arcTo(2f, 2f, 0f, false, false, 20f, 6f)
                horizontalLineTo(12.1f)
                arcTo(2f, 2f, 0f, false, true, 10.4f, 5.1f)
                lineTo(9.6f, 3.9f)
                arcTo(2f, 2f, 0f, false, false, 7.9f, 3f)
                horizontalLineTo(4f)
                arcTo(2f, 2f, 0f, false, false, 2f, 5f)
                verticalLineTo(18f)
                arcTo(2f, 2f, 0f, false, false, 4f, 20f)
                close()
            }
            line(12f, 10f, 12f, 16f)
            line(9f, 13f, 15f, 13f)
        }
    }

    val FolderInput: ImageVector by lazy {
        lucideIcon("FolderInput", autoMirror = true) {
            strokePath {
                moveTo(2f, 9f)
                verticalLineTo(5f)
                arcTo(2f, 2f, 0f, false, true, 4f, 3f)
                horizontalLineTo(7.9f)
                arcTo(2f, 2f, 0f, false, true, 9.6f, 3.9f)
                lineTo(10.4f, 5.1f)
                arcTo(2f, 2f, 0f, false, false, 12.1f, 6f)
                horizontalLineTo(20f)
                arcTo(2f, 2f, 0f, false, true, 22f, 8f)
                verticalLineTo(18f)
                arcTo(2f, 2f, 0f, false, true, 20f, 20f)
                horizontalLineTo(4f)
                arcTo(2f, 2f, 0f, false, true, 2f, 18f)
            }
            line(2f, 13f, 12f, 13f)
            strokePath {
                moveTo(9f, 10f)
                lineTo(12f, 13f)
                lineTo(9f, 16f)
            }
        }
    }

    val Folders: ImageVector by lazy {
        lucideIcon("Folders") {
            strokePath {
                moveTo(20f, 17f)
                arcTo(2f, 2f, 0f, false, false, 22f, 15f)
                verticalLineTo(7f)
                arcTo(2f, 2f, 0f, false, false, 20f, 5f)
                horizontalLineTo(14f)
                lineTo(12f, 3f)
                horizontalLineTo(8f)
                arcTo(2f, 2f, 0f, false, false, 6f, 5f)
                verticalLineTo(15f)
                arcTo(2f, 2f, 0f, false, false, 8f, 17f)
                close()
            }
            strokePath {
                moveTo(2f, 8f)
                verticalLineTo(19f)
                arcTo(2f, 2f, 0f, false, false, 4f, 21f)
                horizontalLineTo(18f)
            }
        }
    }

    val Image: ImageVector by lazy {
        lucideIcon("Image") {
            roundRect(3f, 3f, 18f, 18f, 2f)
            circle(9f, 9f, 2f)
            strokePath {
                moveTo(21f, 15f)
                lineTo(16f, 10f)
                lineTo(5f, 21f)
            }
        }
    }

    val Images: ImageVector by lazy {
        lucideIcon("Images") {
            roundRect(6f, 4f, 16f, 13f, 2f)
            circle(11f, 8.5f, 1.5f)
            strokePath {
                moveTo(22f, 13f)
                lineTo(18f, 9.5f)
                lineTo(10f, 17f)
            }
            strokePath {
                moveTo(2f, 9f)
                verticalLineTo(19f)
                arcTo(2f, 2f, 0f, false, false, 4f, 21f)
                horizontalLineTo(17f)
            }
        }
    }

    val ImagePlus: ImageVector by lazy {
        lucideIcon("ImagePlus") {
            strokePath {
                moveTo(21f, 12f)
                verticalLineTo(19f)
                arcTo(2f, 2f, 0f, false, true, 19f, 21f)
                horizontalLineTo(5f)
                arcTo(2f, 2f, 0f, false, true, 3f, 19f)
                verticalLineTo(5f)
                arcTo(2f, 2f, 0f, false, true, 5f, 3f)
                horizontalLineTo(12f)
            }
            circle(9f, 9f, 2f)
            strokePath {
                moveTo(21f, 15f)
                lineTo(16f, 10f)
                lineTo(5f, 21f)
            }
            line(16f, 5f, 22f, 5f)
            line(19f, 2f, 19f, 8f)
        }
    }

    val Camera: ImageVector by lazy {
        lucideIcon("Camera") {
            strokePath {
                moveTo(14.5f, 4f)
                horizontalLineTo(9.5f)
                lineTo(7f, 7f)
                horizontalLineTo(4f)
                arcTo(2f, 2f, 0f, false, false, 2f, 9f)
                verticalLineTo(18f)
                arcTo(2f, 2f, 0f, false, false, 4f, 20f)
                horizontalLineTo(20f)
                arcTo(2f, 2f, 0f, false, false, 22f, 18f)
                verticalLineTo(9f)
                arcTo(2f, 2f, 0f, false, false, 20f, 7f)
                horizontalLineTo(17f)
                close()
            }
            circle(12f, 13f, 3f)
        }
    }

    val IdCard: ImageVector by lazy {
        lucideIcon("IdCard") {
            roundRect(2f, 5f, 20f, 14f, 2f)
            circle(8.5f, 10.5f, 2f)
            strokePath {
                moveTo(5.5f, 16f)
                curveTo(6.1f, 14.4f, 7.2f, 13.7f, 8.5f, 13.7f)
                curveTo(9.8f, 13.7f, 10.9f, 14.4f, 11.5f, 16f)
            }
            line(14.5f, 10f, 19f, 10f)
            line(14.5f, 14f, 18f, 14f)
        }
    }

    val PenTool: ImageVector by lazy {
        lucideIcon("PenTool") {
            strokePath {
                moveTo(12f, 19f)
                lineTo(19f, 12f)
                lineTo(22f, 15f)
                lineTo(15f, 22f)
                close()
            }
            strokePath {
                moveTo(18f, 13f)
                lineTo(16.5f, 5.5f)
                lineTo(2f, 2f)
                lineTo(5.5f, 16.5f)
                lineTo(13f, 18f)
                close()
            }
            line(2f, 2f, 9.586f, 9.586f)
            circle(11f, 11f, 2f)
        }
    }

    val Printer: ImageVector by lazy {
        lucideIcon("Printer") {
            strokePath {
                moveTo(6f, 18f)
                horizontalLineTo(4f)
                arcTo(2f, 2f, 0f, false, true, 2f, 16f)
                verticalLineTo(11f)
                arcTo(2f, 2f, 0f, false, true, 4f, 9f)
                horizontalLineTo(20f)
                arcTo(2f, 2f, 0f, false, true, 22f, 11f)
                verticalLineTo(16f)
                arcTo(2f, 2f, 0f, false, true, 20f, 18f)
                horizontalLineTo(18f)
            }
            strokePath {
                moveTo(6f, 9f)
                verticalLineTo(3f)
                horizontalLineTo(18f)
                verticalLineTo(9f)
            }
            roundRect(6f, 14f, 12f, 8f, 1f)
        }
    }

    val Layers: ImageVector by lazy {
        lucideIcon("Layers") {
            strokePath {
                moveTo(12f, 2f)
                lineTo(2f, 7f)
                lineTo(12f, 12f)
                lineTo(22f, 7f)
                close()
            }
            strokePath {
                moveTo(2f, 12f)
                lineTo(12f, 17f)
                lineTo(22f, 12f)
            }
            strokePath {
                moveTo(2f, 17f)
                lineTo(12f, 22f)
                lineTo(22f, 17f)
            }
        }
    }

    val LayersOff: ImageVector by lazy {
        lucideIcon("LayersOff") {
            strokePath {
                moveTo(12f, 2f)
                lineTo(22f, 7f)
                lineTo(16.5f, 9.75f)
            }
            strokePath {
                moveTo(6f, 5f)
                lineTo(2f, 7f)
                lineTo(12f, 12f)
            }
            strokePath {
                moveTo(2f, 12f)
                lineTo(12f, 17f)
                lineTo(16f, 15f)
            }
            strokePath {
                moveTo(2f, 17f)
                lineTo(12f, 22f)
                lineTo(19f, 18.5f)
            }
            line(2f, 2f, 22f, 22f)
        }
    }

    val Scissors: ImageVector by lazy {
        lucideIcon("Scissors") {
            circle(6f, 6f, 3f)
            circle(6f, 18f, 3f)
            line(8.12f, 8.12f, 20f, 20f)
            line(20f, 4f, 8.12f, 15.88f)
        }
    }

    val Merge: ImageVector by lazy {
        lucideIcon("Merge") {
            strokePath {
                moveTo(8f, 6f)
                lineTo(12f, 2f)
                lineTo(16f, 6f)
            }
            strokePath {
                moveTo(12f, 2f)
                verticalLineTo(12.3f)
                arcTo(4f, 4f, 0f, false, true, 10.8f, 15.1f)
                lineTo(4f, 22f)
            }
            strokePath {
                moveTo(20f, 22f)
                lineTo(15f, 17f)
            }
        }
    }

    val Archive: ImageVector by lazy {
        lucideIcon("Archive") {
            roundRect(2f, 3f, 20f, 5f, 1f)
            strokePath {
                moveTo(4f, 8f)
                verticalLineTo(19f)
                arcTo(2f, 2f, 0f, false, false, 6f, 21f)
                horizontalLineTo(18f)
                arcTo(2f, 2f, 0f, false, false, 20f, 19f)
                verticalLineTo(8f)
            }
            line(10f, 12f, 14f, 12f)
        }
    }

    val Star: ImageVector by lazy {
        lucideIcon("Star") {
            strokePath {
                moveTo(12f, 2f)
                lineTo(15.09f, 8.26f)
                lineTo(22f, 9.27f)
                lineTo(17f, 14.14f)
                lineTo(18.18f, 21.02f)
                lineTo(12f, 17.77f)
                lineTo(5.82f, 21.02f)
                lineTo(7f, 14.14f)
                lineTo(2f, 9.27f)
                lineTo(8.91f, 8.26f)
                close()
            }
        }
    }

    val StarFilled: ImageVector by lazy {
        lucideIcon("StarFilled") {
            filledStrokePath {
                moveTo(12f, 2f)
                lineTo(15.09f, 8.26f)
                lineTo(22f, 9.27f)
                lineTo(17f, 14.14f)
                lineTo(18.18f, 21.02f)
                lineTo(12f, 17.77f)
                lineTo(5.82f, 21.02f)
                lineTo(7f, 14.14f)
                lineTo(2f, 9.27f)
                lineTo(8.91f, 8.26f)
                close()
            }
        }
    }

    val Bookmark: ImageVector by lazy {
        lucideIcon("Bookmark") {
            strokePath {
                moveTo(19f, 21f)
                lineTo(12f, 17f)
                lineTo(5f, 21f)
                verticalLineTo(5f)
                arcTo(2f, 2f, 0f, false, true, 7f, 3f)
                horizontalLineTo(17f)
                arcTo(2f, 2f, 0f, false, true, 19f, 5f)
                close()
            }
        }
    }

    val BookmarkFilled: ImageVector by lazy {
        lucideIcon("BookmarkFilled") {
            filledStrokePath {
                moveTo(19f, 21f)
                lineTo(12f, 17f)
                lineTo(5f, 21f)
                verticalLineTo(5f)
                arcTo(2f, 2f, 0f, false, true, 7f, 3f)
                horizontalLineTo(17f)
                arcTo(2f, 2f, 0f, false, true, 19f, 5f)
                close()
            }
        }
    }

    val Pin: ImageVector by lazy {
        lucideIcon("Pin") {
            line(12f, 17f, 12f, 22f)
            strokePath {
                moveTo(5f, 17f)
                horizontalLineTo(19f)
                verticalLineTo(15.2f)
                arcTo(2f, 2f, 0f, false, false, 18.2f, 13.6f)
                lineTo(16.5f, 12.2f)
                verticalLineTo(6f)
                lineTo(18f, 4f)
                horizontalLineTo(6f)
                lineTo(7.5f, 6f)
                verticalLineTo(12.2f)
                lineTo(5.8f, 13.6f)
                arcTo(2f, 2f, 0f, false, false, 5f, 15.2f)
                close()
            }
        }
    }
}
