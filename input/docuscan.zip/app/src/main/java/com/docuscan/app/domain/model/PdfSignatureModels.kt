package com.docuscan.app.domain.model

data class PdfSignatureDetail(
    val index: Int,
    val fieldName: String,
    val signerCommonName: String,
    val signerOrganization: String?,
    val issuerCommonName: String,
    val issuerOrganization: String?,
    val signedAtMillis: Long?,
    val validFromMillis: Long?,
    val validToMillis: Long?,
    val subFilter: String,
    val reason: String?,
    val location: String?,
    val serialNumberHex: String?,
    val cryptographicValid: Boolean,
    val coversWholeDocument: Boolean,
    val isLatestRevision: Boolean,
    val isCertificateExpiredNow: Boolean,
    val isValid: Boolean,
    val statusSummary: String
)

sealed interface PdfSignatureValidationOutcome {
    data class Verified(
        val fileName: String,
        val fileSizeBytes: Long,
        val pageCount: Int,
        val isEncrypted: Boolean,
        val signatures: List<PdfSignatureDetail>,
        val allValid: Boolean
    ) : PdfSignatureValidationOutcome

    data class NoSignatureFound(
        val fileName: String,
        val fileSizeBytes: Long,
        val pageCount: Int,
        val isEncrypted: Boolean,
        val unsignedSignatureFieldCount: Int
    ) : PdfSignatureValidationOutcome

    data class PasswordRequired(
        val fileName: String,
        val incorrectPassword: Boolean
    ) : PdfSignatureValidationOutcome

    data class Failed(
        val fileName: String,
        val reason: String
    ) : PdfSignatureValidationOutcome
}
