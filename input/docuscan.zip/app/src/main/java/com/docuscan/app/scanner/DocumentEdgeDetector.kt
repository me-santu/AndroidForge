package com.docuscan.app.scanner

import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Matrix
import android.graphics.Paint
import androidx.camera.core.ImageProxy
import java.io.File
import java.io.FileOutputStream
import kotlin.math.abs
import kotlin.math.hypot
import kotlin.math.max
import kotlin.math.min
import kotlin.math.roundToInt
import kotlin.math.sqrt

data class NormalizedPoint(
    val x: Float,
    val y: Float
)

/**
 * 4 document corners ordered clockwise in normalized upright frame coordinates [0f..1f]:
 * topLeft -> topRight -> bottomRight -> bottomLeft.
 */
data class DetectedDocumentQuad(
    val topLeft: NormalizedPoint,
    val topRight: NormalizedPoint,
    val bottomRight: NormalizedPoint,
    val bottomLeft: NormalizedPoint,
    val sourceAspectRatio: Float = 0.75f,
    val confidence: Float = 1f
) {
    fun lerp(target: DetectedDocumentQuad, alpha: Float): DetectedDocumentQuad {
        val a = alpha.coerceIn(0f, 1f)
        fun mix(p0: NormalizedPoint, p1: NormalizedPoint) = NormalizedPoint(
            x = p0.x + (p1.x - p0.x) * a,
            y = p0.y + (p1.y - p0.y) * a
        )
        return DetectedDocumentQuad(
            topLeft = mix(topLeft, target.topLeft),
            topRight = mix(topRight, target.topRight),
            bottomRight = mix(bottomRight, target.bottomRight),
            bottomLeft = mix(bottomLeft, target.bottomLeft),
            sourceAspectRatio = target.sourceAspectRatio,
            confidence = confidence + (target.confidence - confidence) * a
        )
    }

    fun maxCornerDrift(other: DetectedDocumentQuad): Float {
        val d1 = hypot(topLeft.x - other.topLeft.x, topLeft.y - other.topLeft.y)
        val d2 = hypot(topRight.x - other.topRight.x, topRight.y - other.topRight.y)
        val d3 = hypot(bottomRight.x - other.bottomRight.x, bottomRight.y - other.bottomRight.y)
        val d4 = hypot(bottomLeft.x - other.bottomLeft.x, bottomLeft.y - other.bottomLeft.y)
        return max(max(d1, d2), max(d3, d4))
    }

    fun areaFraction(): Float {
        val xs = floatArrayOf(topLeft.x, topRight.x, bottomRight.x, bottomLeft.x)
        val ys = floatArrayOf(topLeft.y, topRight.y, bottomRight.y, bottomLeft.y)
        var sum = 0f
        for (i in 0 until 4) {
            val j = (i + 1) % 4
            sum += xs[i] * ys[j] - xs[j] * ys[i]
        }
        return abs(sum) * 0.5f
    }

    fun isValidConvexQuad(): Boolean {
        val pts = arrayOf(topLeft, topRight, bottomRight, bottomLeft)
        // Ensure all points are inside valid bounds
        for (p in pts) {
            if (!p.x.isFinite() || !p.y.isFinite()) return false
            if (p.x < -0.02f || p.x > 1.02f || p.y < -0.02f || p.y > 1.02f) return false
        }
        // Check minimum edge lengths
        for (i in 0 until 4) {
            val a = pts[i]
            val b = pts[(i + 1) % 4]
            if (hypot(b.x - a.x, b.y - a.y) < 0.14f) return false
        }
        // Check strict convexity (all 4 cross products must share sign)
        var sign = 0
        for (i in 0 until 4) {
            val p0 = pts[i]
            val p1 = pts[(i + 1) % 4]
            val p2 = pts[(i + 2) % 4]
            val cross = (p1.x - p0.x) * (p2.y - p1.y) - (p1.y - p0.y) * (p2.x - p1.x)
            if (abs(cross) < 1e-4f) return false
            val curSign = if (cross > 0f) 1 else -1
            if (sign == 0) sign = curSign else if (sign != curSign) return false
        }
        val area = areaFraction()
        return area in 0.10f..0.96f
    }

    /**
     * Maps normalized analysis-frame coordinates [0..1] onto a FILL_CENTER PreviewView canvas.
     */
    fun mapToFillCenterCanvas(viewWidth: Float, viewHeight: Float): List<Pair<Float, Float>> {
        if (viewWidth <= 0f || viewHeight <= 0f) return emptyList()
        val viewAspect = viewWidth / viewHeight
        val srcAspect = sourceAspectRatio.coerceIn(0.25f, 4f)
        val scaleX: Float
        val scaleY: Float
        val offsetX: Float
        val offsetY: Float

        if (srcAspect > viewAspect) {
            // Source is wider than view -> cropped horizontally
            scaleY = viewHeight
            scaleX = viewHeight * srcAspect
            offsetX = (viewWidth - scaleX) / 2f
            offsetY = 0f
        } else {
            // Source is taller than view -> cropped vertically
            scaleX = viewWidth
            scaleY = viewWidth / srcAspect
            offsetX = 0f
            offsetY = (viewHeight - scaleY) / 2f
        }

        fun mapPt(p: NormalizedPoint): Pair<Float, Float> {
            val px = (p.x * scaleX + offsetX).coerceIn(4f, viewWidth - 4f)
            val py = (p.y * scaleY + offsetY).coerceIn(4f, viewHeight - 4f)
            return px to py
        }

        return listOf(
            mapPt(topLeft),
            mapPt(topRight),
            mapPt(bottomRight),
            mapPt(bottomLeft)
        )
    }
}

/**
 * Pure-Kotlin real-time document edge/contour detector and 4-point projective homography
 * auto-crop & deskew engine.
 */
object DocumentEdgeDetector {

    private const val WORKING_LONG_EDGE = 160

    /**
     * Analyzes a live CameraX YUV_420_888 [ImageProxy] directly from its Y (luminance) plane
     * with zero Bitmap allocations, returning the detected 4-corner document quadrilateral
     * in upright display coordinates, or null if no clear document page is visible.
     */
    fun detectFromImageProxy(imageProxy: ImageProxy): DetectedDocumentQuad? {
        val rawW = imageProxy.width
        val rawH = imageProxy.height
        if (rawW < 32 || rawH < 32 || imageProxy.planes.isEmpty()) return null

        val yPlane = imageProxy.planes[0]
        val yBuffer = yPlane.buffer
        val rowStride = yPlane.rowStride
        val pixelStride = yPlane.pixelStride
        val rotation = ((imageProxy.imageInfo.rotationDegrees % 360) + 360) % 360

        val isSwapped = rotation == 90 || rotation == 270
        val uprightW = if (isSwapped) rawH else rawW
        val uprightH = if (isSwapped) rawW else rawH

        val scale = WORKING_LONG_EDGE.toFloat() / max(uprightW, uprightH).toFloat()
        val gridW = (uprightW * scale).roundToInt().coerceIn(48, WORKING_LONG_EDGE)
        val gridH = (uprightH * scale).roundToInt().coerceIn(48, WORKING_LONG_EDGE)
        val lum = IntArray(gridW * gridH)
        val limit = yBuffer.limit()

        for (gy in 0 until gridH) {
            val uy = ((gy + 0.5f) * uprightH / gridH).toInt().coerceIn(0, uprightH - 1)
            val rowOff = gy * gridW
            for (gx in 0 until gridW) {
                val ux = ((gx + 0.5f) * uprightW / gridW).toInt().coerceIn(0, uprightW - 1)
                val sx: Int
                val sy: Int
                when (rotation) {
                    90 -> {
                        sx = uy
                        sy = rawH - 1 - ux
                    }
                    180 -> {
                        sx = rawW - 1 - ux
                        sy = rawH - 1 - uy
                    }
                    270 -> {
                        sx = rawW - 1 - uy
                        sy = ux
                    }
                    else -> {
                        sx = ux
                        sy = uy
                    }
                }
                val idx = sy * rowStride + sx * pixelStride
                lum[rowOff + gx] = if (idx in 0 until limit) (yBuffer.get(idx).toInt() and 0xFF) else 0
            }
        }

        return detectFromLuminanceGrid(
            lum = lum,
            w = gridW,
            h = gridH,
            sourceAspectRatio = uprightW.toFloat() / uprightH.toFloat()
        )
    }

    /**
     * Detects a 4-corner document quadrilateral directly from a decoded upright [Bitmap].
     * Used as a fallback for manual captures if no live quad was locked at shutter press.
     */
    fun detectFromBitmap(bitmap: Bitmap): DetectedDocumentQuad? {
        val bw = bitmap.width
        val bh = bitmap.height
        if (bw < 32 || bh < 32) return null

        val scale = WORKING_LONG_EDGE.toFloat() / max(bw, bh).toFloat()
        val gridW = (bw * scale).roundToInt().coerceIn(48, WORKING_LONG_EDGE)
        val gridH = (bh * scale).roundToInt().coerceIn(48, WORKING_LONG_EDGE)
        val scaled = Bitmap.createScaledBitmap(bitmap, gridW, gridH, true)
        val pixels = IntArray(gridW * gridH)
        try {
            scaled.getPixels(pixels, 0, gridW, 0, 0, gridW, gridH)
        } finally {
            if (scaled !== bitmap && !scaled.isRecycled) {
                scaled.recycle()
            }
        }

        val lum = IntArray(gridW * gridH)
        for (i in pixels.indices) {
            val px = pixels[i]
            val r = (px shr 16) and 0xFF
            val g = (px shr 8) and 0xFF
            val b = px and 0xFF
            lum[i] = ((77 * r + 150 * g + 29 * b) shr 8)
        }

        return detectFromLuminanceGrid(
            lum = lum,
            w = gridW,
            h = gridH,
            sourceAspectRatio = bw.toFloat() / bh.toFloat()
        )
    }

    /**
     * Applies a true 4-point projective perspective transform (Auto-Crop & Deskew) to [file]
     * in place using [detectedQuad] (or automatic fallback detection on the captured image).
     * Returns true if perspective deskew/crop was applied.
     */
    fun autoCropAndDeskewFile(
        file: File,
        detectedQuad: DetectedDocumentQuad?
    ): Boolean {
        if (!file.exists() || file.length() == 0L) return false
        val source = BitmapFilterEngine.decodeSampledBitmap(
            filePath = file.absolutePath,
            maxDimension = BitmapFilterEngine.MAX_SAFE_IMAGE_DIMENSION
        ) ?: return false

        var warped: Bitmap? = null
        return try {
            val quad = detectedQuad?.takeIf { it.isValidConvexQuad() }
                ?: detectFromBitmap(source)?.takeIf { it.isValidConvexQuad() }
                ?: return false

            // Avoid unnecessary warp if the quad already covers >96% of the frame axis-aligned
            if (quad.areaFraction() > 0.94f) {
                return false
            }

            warped = perspectiveWarpBitmap(source, quad) ?: return false
            FileOutputStream(file).use { out ->
                warped.compress(Bitmap.CompressFormat.JPEG, 94, out)
            }
            true
        } catch (_: Throwable) {
            false
        } finally {
            if (warped != null && warped !== source && !warped.isRecycled) {
                warped.recycle()
            }
            if (!source.isRecycled) {
                source.recycle()
            }
        }
    }

    /**
     * Rectifies the 4-corner quadrilateral [quad] inside [source] into a flat, upright
     * rectangular Bitmap using Android's 4-point projective homography (`Matrix.setPolyToPoly`).
     */
    fun perspectiveWarpBitmap(
        source: Bitmap,
        quad: DetectedDocumentQuad
    ): Bitmap? {
        val sw = source.width.toFloat()
        val sh = source.height.toFloat()
        if (sw < 32f || sh < 32f) return null

        // Map quad coordinates cleanly into the captured photo aspect ratio if it differs slightly from preview
        val imgAspect = sw / sh
        val quadAspect = quad.sourceAspectRatio.coerceIn(0.25f, 4f)
        fun toPixel(p: NormalizedPoint): Pair<Float, Float> {
            val nx: Float
            val ny: Float
            if (abs(imgAspect - quadAspect) > 0.04f) {
                if (quadAspect > imgAspect) {
                    val ratio = quadAspect / imgAspect
                    nx = ((p.x - 0.5f) * ratio + 0.5f).coerceIn(0f, 1f)
                    ny = p.y.coerceIn(0f, 1f)
                } else {
                    val ratio = imgAspect / quadAspect
                    nx = p.x.coerceIn(0f, 1f)
                    ny = ((p.y - 0.5f) * ratio + 0.5f).coerceIn(0f, 1f)
                }
            } else {
                nx = p.x.coerceIn(0f, 1f)
                ny = p.y.coerceIn(0f, 1f)
            }
            return (nx * sw) to (ny * sh)
        }

        // Expand corners outward by ~0.8% from centroid so document edge text is never clipped
        val cx = (quad.topLeft.x + quad.topRight.x + quad.bottomRight.x + quad.bottomLeft.x) * 0.25f
        val cy = (quad.topLeft.y + quad.topRight.y + quad.bottomRight.y + quad.bottomLeft.y) * 0.25f
        fun expand(p: NormalizedPoint): NormalizedPoint {
            val dx = p.x - cx
            val dy = p.y - cy
            return NormalizedPoint(
                x = (cx + dx * 1.015f).coerceIn(0f, 1f),
                y = (cy + dy * 1.015f).coerceIn(0f, 1f)
            )
        }

        val (tlX, tlY) = toPixel(expand(quad.topLeft))
        val (trX, trY) = toPixel(expand(quad.topRight))
        val (brX, brY) = toPixel(expand(quad.bottomRight))
        val (blX, blY) = toPixel(expand(quad.bottomLeft))

        val widthTop = hypot(trX - tlX, trY - tlY)
        val widthBottom = hypot(brX - blX, brY - blY)
        val heightLeft = hypot(blX - tlX, blY - tlY)
        val heightRight = hypot(brX - trX, brY - trY)

        var outW = max(widthTop, widthBottom).roundToInt().coerceAtLeast(120)
        var outH = max(heightLeft, heightRight).roundToInt().coerceAtLeast(120)
        val maxEdge = max(outW, outH)
        if (maxEdge > BitmapFilterEngine.MAX_SAFE_IMAGE_DIMENSION) {
            val s = BitmapFilterEngine.MAX_SAFE_IMAGE_DIMENSION.toFloat() / maxEdge.toFloat()
            outW = (outW * s).roundToInt().coerceAtLeast(120)
            outH = (outH * s).roundToInt().coerceAtLeast(120)
        }

        val srcPts = floatArrayOf(
            tlX, tlY,
            trX, trY,
            brX, brY,
            blX, blY
        )
        val dstPts = floatArrayOf(
            0f, 0f,
            outW.toFloat(), 0f,
            outW.toFloat(), outH.toFloat(),
            0f, outH.toFloat()
        )

        val matrix = Matrix()
        if (!matrix.setPolyToPoly(srcPts, 0, dstPts, 0, 4)) {
            return null
        }

        val output = Bitmap.createBitmap(outW, outH, Bitmap.Config.ARGB_8888)
        return try {
            val canvas = Canvas(output)
            val paint = Paint(Paint.ANTI_ALIAS_FLAG or Paint.FILTER_BITMAP_FLAG)
            canvas.drawBitmap(source, matrix, paint)
            output
        } catch (_: Throwable) {
            if (!output.isRecycled) output.recycle()
            null
        }
    }

    private fun detectFromLuminanceGrid(
        lum: IntArray,
        w: Int,
        h: Int,
        sourceAspectRatio: Float
    ): DetectedDocumentQuad? {
        val total = w * h
        // 1. 3x3 box blur to suppress text strokes and camera sensor noise
        val blurred = IntArray(total)
        for (y in 1 until h - 1) {
            val row = y * w
            for (x in 1 until w - 1) {
                val sum = lum[row - w + x - 1] + lum[row - w + x] + lum[row - w + x + 1] +
                    lum[row + x - 1] + lum[row + x] + lum[row + x + 1] +
                    lum[row + w + x - 1] + lum[row + w + x] + lum[row + w + x + 1]
                blurred[row + x] = sum / 9
            }
        }
        // Copy edges
        for (x in 0 until w) {
            blurred[x] = lum[x]
            blurred[(h - 1) * w + x] = lum[(h - 1) * w + x]
        }
        for (y in 0 until h) {
            blurred[y * w] = lum[y * w]
            blurred[y * w + w - 1] = lum[y * w + w - 1]
        }

        // 2. Compute Sobel edge magnitude
        val grad = IntArray(total)
        var maxGrad = 0
        for (y in 1 until h - 1) {
            val row = y * w
            for (x in 1 until w - 1) {
                val gx = -blurred[row - w + x - 1] + blurred[row - w + x + 1] -
                    2 * blurred[row + x - 1] + 2 * blurred[row + x + 1] -
                    blurred[row + w + x - 1] + blurred[row + w + x + 1]
                val gy = -blurred[row - w + x - 1] - 2 * blurred[row - w + x] - blurred[row - w + x + 1] +
                    blurred[row + w + x - 1] + 2 * blurred[row + w + x] + blurred[row + w + x + 1]
                val mag = abs(gx) + abs(gy)
                grad[row + x] = mag
                if (mag > maxGrad) maxGrad = mag
            }
        }
        // Uniform / blank scene rejection
        if (maxGrad < 65) return null

        // 3. Primary strategy: Otsu bright-paper region segmentation + largest connected component
        val otsuResult = computeOtsuThreshold(blurred)
        var candidate: DetectedDocumentQuad? = null
        if (otsuResult.separation >= 22f) {
            candidate = extractQuadFromBrightRegion(
                blurred = blurred,
                grad = grad,
                w = w,
                h = h,
                threshold = otsuResult.threshold,
                sourceAspectRatio = sourceAspectRatio
            )
        }

        // 4. Secondary strategy: Strong Sobel contour bounding quad (for low-contrast or colored paper)
        if (candidate == null) {
            candidate = extractQuadFromStrongEdges(
                grad = grad,
                w = w,
                h = h,
                maxGrad = maxGrad,
                sourceAspectRatio = sourceAspectRatio
            )
        }

        return candidate?.takeIf { it.isValidConvexQuad() }
    }

    private data class OtsuResult(val threshold: Int, val separation: Float)

    private fun computeOtsuThreshold(values: IntArray): OtsuResult {
        val hist = IntArray(256)
        var sumAll = 0.0
        for (v in values) {
            val clamped = v.coerceIn(0, 255)
            hist[clamped]++
            sumAll += clamped
        }
        val total = values.size.toDouble()
        var sumB = 0.0
        var wB = 0.0
        var maxVar = -1.0
        var bestT = 128
        var bestSep = 0f

        for (t in 0 until 256) {
            wB += hist[t]
            if (wB <= 0.0) continue
            val wF = total - wB
            if (wF <= 0.0) break
            sumB += t * hist[t]
            val mB = sumB / wB
            val mF = (sumAll - sumB) / wF
            val diff = mF - mB
            val betweenVar = wB * wF * diff * diff
            if (betweenVar > maxVar) {
                maxVar = betweenVar
                bestT = t
                bestSep = abs(diff).toFloat()
            }
        }
        return OtsuResult(threshold = bestT, separation = bestSep)
    }

    private fun extractQuadFromBrightRegion(
        blurred: IntArray,
        grad: IntArray,
        w: Int,
        h: Int,
        threshold: Int,
        sourceAspectRatio: Float
    ): DetectedDocumentQuad? {
        val total = w * h
        val visited = BooleanArray(total)
        val queue = IntArray(total)
        var bestCount = 0
        var bestSeed = -1

        // Find the largest connected bright foreground component
        for (y in 2 until h - 2) {
            val row = y * w
            for (x in 2 until w - 2) {
                val start = row + x
                if (visited[start] || blurred[start] < threshold) continue
                var head = 0
                var tail = 0
                queue[tail++] = start
                visited[start] = true
                var touchesAllFourBorders = 0
                var touchesTop = false
                var touchesBottom = false
                var touchesLeft = false
                var touchesRight = false

                while (head < tail) {
                    val idx = queue[head++]
                    val cx = idx % w
                    val cy = idx / w
                    if (cx <= 1) touchesLeft = true
                    if (cx >= w - 2) touchesRight = true
                    if (cy <= 1) touchesTop = true
                    if (cy >= h - 2) touchesBottom = true

                    if (cx > 0) {
                        val n = idx - 1
                        if (!visited[n] && blurred[n] >= threshold) {
                            visited[n] = true
                            queue[tail++] = n
                        }
                    }
                    if (cx < w - 1) {
                        val n = idx + 1
                        if (!visited[n] && blurred[n] >= threshold) {
                            visited[n] = true
                            queue[tail++] = n
                        }
                    }
                    if (cy > 0) {
                        val n = idx - w
                        if (!visited[n] && blurred[n] >= threshold) {
                            visited[n] = true
                            queue[tail++] = n
                        }
                    }
                    if (cy < h - 1) {
                        val n = idx + w
                        if (!visited[n] && blurred[n] >= threshold) {
                            visited[n] = true
                            queue[tail++] = n
                        }
                    }
                }

                if (touchesTop) touchesAllFourBorders++
                if (touchesBottom) touchesAllFourBorders++
                if (touchesLeft) touchesAllFourBorders++
                if (touchesRight) touchesAllFourBorders++

                val areaRatio = tail.toFloat() / total.toFloat()
                // Ignore tiny noise or full-frame bright wall background
                if (areaRatio in 0.11f..0.90f && touchesAllFourBorders < 4 && tail > bestCount) {
                    bestCount = tail
                    bestSeed = start
                }
            }
        }

        if (bestSeed < 0) return null

        // Re-walk the winning component to collect its boundary pixels
        val inBest = BooleanArray(total)
        var head = 0
        var tail = 0
        queue[tail++] = bestSeed
        inBest[bestSeed] = true
        while (head < tail) {
            val idx = queue[head++]
            val cx = idx % w
            val cy = idx / w
            val neighbors = intArrayOf(
                if (cx > 0) idx - 1 else -1,
                if (cx < w - 1) idx + 1 else -1,
                if (cy > 0) idx - w else -1,
                if (cy < h - 1) idx + w else -1
            )
            for (n in neighbors) {
                if (n >= 0 && !inBest[n] && blurred[n] >= threshold) {
                    inBest[n] = true
                    queue[tail++] = n
                }
            }
        }

        val boundaryXs = ArrayList<Float>(512)
        val boundaryYs = ArrayList<Float>(512)
        for (i in 0 until tail) {
            val idx = queue[i]
            val cx = idx % w
            val cy = idx / w
            val isEdge = cx <= 1 || cx >= w - 2 || cy <= 1 || cy >= h - 2 ||
                !inBest[idx - 1] || !inBest[idx + 1] || !inBest[idx - w] || !inBest[idx + w]
            if (isEdge) {
                boundaryXs.add(cx.toFloat())
                boundaryYs.add(cy.toFloat())
            }
        }
        if (boundaryXs.size < 24) return null

        return fitQuadToBoundaryPoints(boundaryXs, boundaryYs, grad, w, h, sourceAspectRatio)
    }

    private fun extractQuadFromStrongEdges(
        grad: IntArray,
        w: Int,
        h: Int,
        maxGrad: Int,
        sourceAspectRatio: Float
    ): DetectedDocumentQuad? {
        val edgeThresh = max(70, (maxGrad * 0.34f).roundToInt())
        val xs = ArrayList<Float>(512)
        val ys = ArrayList<Float>(512)
        for (y in 3 until h - 3) {
            val row = y * w
            for (x in 3 until w - 3) {
                if (grad[row + x] >= edgeThresh) {
                    xs.add(x.toFloat())
                    ys.add(y.toFloat())
                }
            }
        }
        if (xs.size < 36) return null
        return fitQuadToBoundaryPoints(xs, ys, grad, w, h, sourceAspectRatio)
    }

    private fun fitQuadToBoundaryPoints(
        xs: List<Float>,
        ys: List<Float>,
        grad: IntArray,
        w: Int,
        h: Int,
        sourceAspectRatio: Float
    ): DetectedDocumentQuad? {
        val n = xs.size
        // Extreme diagonal projection initial 4 corners
        var tlIdx = 0
        var trIdx = 0
        var brIdx = 0
        var blIdx = 0
        var minSum = Float.MAX_VALUE
        var maxSum = -Float.MAX_VALUE
        var maxDiff = -Float.MAX_VALUE
        var minDiff = Float.MAX_VALUE

        for (i in 0 until n) {
            val x = xs[i]
            val y = ys[i]
            val sum = x + y
            val diff = x - y
            if (sum < minSum) { minSum = sum; tlIdx = i }
            if (sum > maxSum) { maxSum = sum; brIdx = i }
            if (diff > maxDiff) { maxDiff = diff; trIdx = i }
            if (diff < minDiff) { minDiff = diff; blIdx = i }
        }

        var tl = Pair(xs[tlIdx], ys[tlIdx])
        var tr = Pair(xs[trIdx], ys[trIdx])
        var br = Pair(xs[brIdx], ys[brIdx])
        var bl = Pair(xs[blIdx], ys[blIdx])

        // Refine corners by fitting 4 straight lines along each side and intersecting them
        val refined = refineQuadBySideLines(xs, ys, tl, tr, br, bl, w.toFloat(), h.toFloat())
        if (refined != null) {
            tl = refined[0]
            tr = refined[1]
            br = refined[2]
            bl = refined[3]
        }

        val quad = DetectedDocumentQuad(
            topLeft = NormalizedPoint((tl.first / (w - 1)).coerceIn(0.01f, 0.99f), (tl.second / (h - 1)).coerceIn(0.01f, 0.99f)),
            topRight = NormalizedPoint((tr.first / (w - 1)).coerceIn(0.01f, 0.99f), (tr.second / (h - 1)).coerceIn(0.01f, 0.99f)),
            bottomRight = NormalizedPoint((br.first / (w - 1)).coerceIn(0.01f, 0.99f), (br.second / (h - 1)).coerceIn(0.01f, 0.99f)),
            bottomLeft = NormalizedPoint((bl.first / (w - 1)).coerceIn(0.01f, 0.99f), (bl.second / (h - 1)).coerceIn(0.01f, 0.99f)),
            sourceAspectRatio = sourceAspectRatio
        )

        if (!quad.isValidConvexQuad()) return null

        // Verify actual edge support along the 4 edges so uniform scenes don't produce false locks
        val edgeSupport = measurePerimeterEdgeSupport(quad, grad, w, h)
        if (edgeSupport < 32f) return null

        return quad.copy(confidence = (edgeSupport / 110f).coerceIn(0.4f, 1f))
    }

    private fun refineQuadBySideLines(
        xs: List<Float>,
        ys: List<Float>,
        tl: Pair<Float, Float>,
        tr: Pair<Float, Float>,
        br: Pair<Float, Float>,
        bl: Pair<Float, Float>,
        w: Float,
        h: Float
    ): List<Pair<Float, Float>>? {
        val edges = listOf(tl to tr, tr to br, br to bl, bl to tl)
        val tol = max(3.5f, min(w, h) * 0.045f)
        val lines = arrayOfNulls<Triple<Float, Float, Float>>(4)

        for (eIdx in 0 until 4) {
            val (a, b) = edges[eIdx]
            val segLen = hypot(b.first - a.first, b.second - a.second)
            if (segLen < 8f) return null

            val sideX = ArrayList<Float>()
            val sideY = ArrayList<Float>()
            val dx = b.first - a.first
            val dy = b.second - a.second
            val invLen = 1f / segLen

            for (i in xs.indices) {
                val px = xs[i]
                val py = ys[i]
                val proj = ((px - a.first) * dx + (py - a.second) * dy) * invLen
                if (proj < segLen * 0.08f || proj > segLen * 0.92f) continue
                val dist = abs((px - a.first) * dy - (py - a.second) * dx) * invLen
                if (dist <= tol) {
                    sideX.add(px)
                    sideY.add(py)
                }
            }
            if (sideX.size < 6) return null
            lines[eIdx] = fitLineAxByC(sideX, sideY) ?: return null
        }

        val lTop = lines[0] ?: return null
        val lRight = lines[1] ?: return null
        val lBottom = lines[2] ?: return null
        val lLeft = lines[3] ?: return null

        val pTL = intersectLines(lLeft, lTop) ?: return null
        val pTR = intersectLines(lTop, lRight) ?: return null
        val pBR = intersectLines(lRight, lBottom) ?: return null
        val pBL = intersectLines(lBottom, lLeft) ?: return null

        val margin = min(w, h) * 0.05f
        val pts = listOf(pTL, pTR, pBR, pBL)
        for ((px, py) in pts) {
            if (!px.isFinite() || !py.isFinite()) return null
            if (px < -margin || px > w + margin || py < -margin || py > h + margin) return null
        }
        return pts
    }

    /**
     * Fits a normalized line ax + by + c = 0 via total least squares (2D PCA minor eigenvector).
     */
    private fun fitLineAxByC(xs: List<Float>, ys: List<Float>): Triple<Float, Float, Float>? {
        val n = xs.size.toFloat()
        if (n < 2f) return null
        var mx = 0f
        var my = 0f
        for (i in xs.indices) {
            mx += xs[i]
            my += ys[i]
        }
        mx /= n
        my /= n
        var sxx = 0.0
        var syy = 0.0
        var sxy = 0.0
        for (i in xs.indices) {
            val dx = (xs[i] - mx).toDouble()
            val dy = (ys[i] - my).toDouble()
            sxx += dx * dx
            syy += dy * dy
            sxy += dx * dy
        }
        val diff = sxx - syy
        val disc = sqrt(diff * diff + 4.0 * sxy * sxy)
        if (disc < 1e-6) return null
        // Minor eigenvector of covariance matrix = normal vector (a, b)
        val lambdaMin = 0.5 * (sxx + syy - disc)
        var nx = sxy
        var ny = lambdaMin - sxx
        if (abs(nx) + abs(ny) < 1e-6) {
            nx = lambdaMin - syy
            ny = sxy
        }
        val norm = sqrt(nx * nx + ny * ny)
        if (norm < 1e-6) return null
        val a = (nx / norm).toFloat()
        val b = (ny / norm).toFloat()
        val c = -(a * mx + b * my)
        return Triple(a, b, c)
    }

    private fun intersectLines(
        l1: Triple<Float, Float, Float>,
        l2: Triple<Float, Float, Float>
    ): Pair<Float, Float>? {
        val det = l1.first * l2.second - l2.first * l1.second
        if (abs(det) < 1e-4f) return null
        val x = (l1.second * l2.third - l2.second * l1.third) / det
        val y = (l2.first * l1.third - l1.first * l2.third) / det
        return x to y
    }

    private fun measurePerimeterEdgeSupport(
        quad: DetectedDocumentQuad,
        grad: IntArray,
        w: Int,
        h: Int
    ): Float {
        val pts = arrayOf(quad.topLeft, quad.topRight, quad.bottomRight, quad.bottomLeft)
        var totalMaxGrad = 0f
        var sampleCount = 0

        for (e in 0 until 4) {
            val a = pts[e]
            val b = pts[(e + 1) % 4]
            val steps = 14
            for (s in 1 until steps) {
                val t = s.toFloat() / steps.toFloat()
                val gx = ((a.x + (b.x - a.x) * t) * (w - 1)).roundToInt().coerceIn(2, w - 3)
                val gy = ((a.y + (b.y - a.y) * t) * (h - 1)).roundToInt().coerceIn(2, h - 3)
                // Take local 5x5 peak gradient around expected edge line
                var localPeak = 0
                for (dy in -2..2) {
                    val row = (gy + dy) * w
                    for (dx in -2..2) {
                        val g = grad[row + gx + dx]
                        if (g > localPeak) localPeak = g
                    }
                }
                totalMaxGrad += localPeak
                sampleCount++
            }
        }
        return if (sampleCount > 0) totalMaxGrad / sampleCount else 0f
    }
}
