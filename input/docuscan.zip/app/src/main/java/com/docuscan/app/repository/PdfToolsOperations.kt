package com.docuscan.app.repository

import android.net.Uri
import com.docuscan.app.database.dao.DocumentDao
import com.docuscan.app.database.entity.DocumentEntity
import com.docuscan.app.domain.model.DocumentFileType
import com.docuscan.app.domain.model.DocumentItem
import com.docuscan.app.domain.model.PageNumberFormat
import com.docuscan.app.domain.model.PageNumberPosition
import com.docuscan.app.domain.model.PdfDocxConversionResult
import com.docuscan.app.domain.model.PdfDocumentInfo
import com.docuscan.app.domain.model.PdfImageFormat
import com.docuscan.app.domain.model.PdfImagesExportResult
import com.docuscan.app.domain.model.PdfOrientation
import com.docuscan.app.domain.model.PdfPageSize
import com.docuscan.app.domain.model.PdfReduceSizeResult
import com.docuscan.app.domain.model.PdfRepairResult
import com.docuscan.app.domain.model.PdfTextExtractionResult
import com.docuscan.app.domain.model.WatermarkRemovalResult
import com.docuscan.app.pdf.PdfAdvancedEngine
import com.docuscan.app.pdf.PdfConversionEngine
import com.docuscan.app.security.SecurityManager
import com.docuscan.app.util.LocalFileManager
import java.io.File

internal class PdfToolsOperations(
    private val documentDao: DocumentDao,
    private val fileManager: LocalFileManager,
    private val pdfAdvancedEngine: PdfAdvancedEngine,
    private val pdfConversionEngine: PdfConversionEngine,
    private val securityManager: SecurityManager?,
    private val requirePdfSource: suspend (Long) -> DocumentEntity,
    private val insertDerivedDocument: suspend (
        title: String,
        outFile: File,
        folderId: Long?,
        thumbnailPath: String?,
        pageCount: Int,
        isPasswordProtected: Boolean,
        fileType: DocumentFileType
    ) -> DocumentItem,
    private val getDocumentById: suspend (Long) -> DocumentItem?
) {

    private inline fun <T> withReadableFile(filePath: String, block: (File) -> T): T {
        val raw = File(filePath)
        val temp = if (securityManager != null && securityManager.isVaultEncryptedFile(raw)) {
            securityManager.createTempUnsealedCopy(raw, fileManager.appCacheDir)
        } else {
            null
        }
        return try {
            block(temp ?: raw)
        } finally {
            temp?.delete()
        }
    }

    suspend fun duplicatePdfDocument(sourceDocumentId: Long, newTitle: String): Result<DocumentItem> =
        runCatching {
            fileManager.checkStorageAvailable().getOrThrow()
            val source = requirePdfSource(sourceDocumentId)
            val cleanTitle = newTitle.trim().ifBlank { "${source.title}_Copy" }
            val copyFile = fileManager.duplicateLocalFile(
                sourceFilePath = source.filePath,
                newTitle = cleanTitle,
                extension = "pdf",
                securityManager = securityManager
            )
            insertDerivedDocument(
                cleanTitle,
                copyFile,
                source.folderId,
                source.thumbnailPath,
                source.pageCount,
                source.isPasswordProtected,
                DocumentFileType.PDF
            )
        }

    suspend fun inspectPdfInfo(documentId: Long, password: String?): Result<PdfDocumentInfo> =
        runCatching {
            val source = requirePdfSource(documentId)
            withReadableFile(source.filePath) { readable ->
                pdfAdvancedEngine.inspectPdfInfo(readable, password)
            }
        }

    suspend fun reorderPdfPages(
        sourceDocumentId: Long,
        newTitle: String,
        oneBasedNewOrder: List<Int>,
        password: String?
    ): Result<DocumentItem> = runCatching {
        fileManager.checkStorageAvailable().getOrThrow()
        val source = requirePdfSource(sourceDocumentId)
        val cleanTitle = newTitle.trim().ifBlank { "${source.title}_Reordered" }
        val outFile = fileManager.createPdfFile(cleanTitle)
        val pageCount = withReadableFile(source.filePath) { readable ->
            pdfAdvancedEngine.reorderPages(readable, outFile, oneBasedNewOrder, password)
        }
        insertDerivedDocument(cleanTitle, outFile, source.folderId, source.thumbnailPath, pageCount, false, DocumentFileType.PDF)
    }

    suspend fun duplicatePdfPages(
        sourceDocumentId: Long,
        newTitle: String,
        oneBasedPagesToDuplicate: List<Int>,
        insertAdjacent: Boolean,
        password: String?
    ): Result<DocumentItem> = runCatching {
        fileManager.checkStorageAvailable().getOrThrow()
        val source = requirePdfSource(sourceDocumentId)
        val cleanTitle = newTitle.trim().ifBlank { "${source.title}_DupPages" }
        val outFile = fileManager.createPdfFile(cleanTitle)
        val pageCount = withReadableFile(source.filePath) { readable ->
            pdfAdvancedEngine.duplicatePages(readable, outFile, oneBasedPagesToDuplicate, insertAdjacent, password)
        }
        insertDerivedDocument(cleanTitle, outFile, source.folderId, source.thumbnailPath, pageCount, false, DocumentFileType.PDF)
    }

    suspend fun createPdfFromText(
        title: String,
        text: String,
        folderId: Long?,
        pageSize: PdfPageSize,
        orientation: PdfOrientation,
        marginPt: Float,
        fontSizePt: Float,
        includePageNumbers: Boolean,
        password: String
    ): Result<DocumentItem> = runCatching {
        fileManager.checkStorageAvailable().getOrThrow()
        val cleanTitle = title.trim().ifBlank { "TextPDF_${System.currentTimeMillis() % 10000}" }
        val outFile = fileManager.createPdfFile(cleanTitle)
        val pageCount = pdfConversionEngine.createPdfFromText(
            text = text,
            headerTitle = cleanTitle,
            outputFile = outFile,
            pageSize = pageSize,
            orientation = orientation,
            marginPt = marginPt,
            fontSizePt = fontSizePt,
            includePageNumbers = includePageNumbers,
            password = password
        )
        insertDerivedDocument(cleanTitle, outFile, folderId, null, pageCount, password.isNotBlank(), DocumentFileType.PDF)
    }

    suspend fun extractTextFromPdf(
        sourceDocumentId: Long,
        startPageOneBased: Int,
        endPageOneBased: Int,
        password: String?
    ): Result<PdfTextExtractionResult> = runCatching {
        val source = requirePdfSource(sourceDocumentId)
        withReadableFile(source.filePath) { readable ->
            pdfConversionEngine.extractTextFromPdf(readable, startPageOneBased, endPageOneBased, password)
        }
    }

    suspend fun convertPdfToDocx(
        sourceDocumentId: Long,
        outputTitle: String,
        includePageImagesFallback: Boolean,
        password: String?
    ): Result<PdfDocxConversionResult> = runCatching {
        fileManager.checkStorageAvailable().getOrThrow()
        val source = requirePdfSource(sourceDocumentId)
        val cleanTitle = outputTitle.trim().ifBlank { source.title }
        val outDocx = fileManager.createDocxFile(cleanTitle)
        withReadableFile(source.filePath) { readable ->
            pdfConversionEngine.convertPdfToDocx(
                sourceFile = readable,
                outputFile = outDocx,
                title = cleanTitle,
                includePageImagesFallback = includePageImagesFallback,
                password = password
            )
        }
    }

    suspend fun exportPdfToImages(
        sourceDocumentId: Long,
        format: PdfImageFormat,
        pageIndicesOneBased: List<Int>,
        quality: Int,
        saveToLibrary: Boolean,
        password: String?
    ): Result<PdfImagesExportResult> = runCatching {
        fileManager.checkStorageAvailable().getOrThrow()
        val source = requirePdfSource(sourceDocumentId)
        val outDir = if (saveToLibrary) fileManager.documentsDir else fileManager.appCacheDir
        val files = withReadableFile(source.filePath) { readable ->
            pdfConversionEngine.exportPdfToImages(
                sourceFile = readable,
                outputDir = outDir,
                baseName = source.title,
                format = format,
                pageIndicesOneBased = pageIndicesOneBased,
                quality = quality,
                password = password
            )
        }

        val savedIds = mutableListOf<Long>()
        if (saveToLibrary) {
            val now = System.currentTimeMillis()
            files.forEachIndexed { idx, file ->
                val pageNum = pageIndicesOneBased.getOrNull(idx) ?: (idx + 1)
                val entity = DocumentEntity(
                    title = "${source.title}_Page$pageNum",
                    folderId = source.folderId,
                    filePath = file.absolutePath,
                    thumbnailPath = file.absolutePath,
                    fileType = DocumentFileType.IMAGE.name,
                    pageCount = 1,
                    sizeBytes = file.length(),
                    createdAt = now,
                    updatedAt = now
                )
                savedIds += documentDao.insertDocument(entity)
            }
        }

        val zipFile = if (files.size > 1) {
            val targetZip = fileManager.createZipFile("${source.title}_${format.name}")
            fileManager.createZipFromFiles(files, targetZip).absolutePath
        } else {
            null
        }

        PdfImagesExportResult(
            imageFilePaths = files.map { it.absolutePath },
            savedDocumentIds = savedIds,
            zipFilePath = zipFile,
            format = format
        )
    }

    suspend fun unlockPdfDocument(
        sourceDocumentId: Long,
        newTitle: String,
        password: String
    ): Result<DocumentItem> = runCatching {
        fileManager.checkStorageAvailable().getOrThrow()
        val source = requirePdfSource(sourceDocumentId)
        val cleanTitle = newTitle.trim().ifBlank { "${source.title}_Unlocked" }
        val outFile = fileManager.createPdfFile(cleanTitle)
        val pageCount = withReadableFile(source.filePath) { readable ->
            pdfAdvancedEngine.unlockPdf(readable, outFile, password)
        }
        insertDerivedDocument(cleanTitle, outFile, source.folderId, source.thumbnailPath, pageCount, false, DocumentFileType.PDF)
    }

    suspend fun removeWatermarkFromPdf(
        sourceDocumentId: Long,
        newTitle: String,
        matchText: String?,
        password: String?
    ): Result<WatermarkRemovalResult> = runCatching {
        fileManager.checkStorageAvailable().getOrThrow()
        val source = requirePdfSource(sourceDocumentId)
        val cleanTitle = newTitle.trim().ifBlank { "${source.title}_Clean" }
        val outFile = fileManager.createPdfFile(cleanTitle)
        val counts = withReadableFile(source.filePath) { readable ->
            pdfAdvancedEngine.removeWatermark(readable, outFile, matchText, password)
        }
        val pageCount = pdfAdvancedEngine.inspectPdfInfo(outFile, password).pageCount.coerceAtLeast(1)
        val created = insertDerivedDocument(cleanTitle, outFile, source.folderId, source.thumbnailPath, pageCount, false, DocumentFileType.PDF)
        WatermarkRemovalResult(
            document = created,
            removedAnnotations = counts.first,
            removedTextBlocks = counts.second,
            removedOcgCount = counts.third
        )
    }

    suspend fun addPageNumbersToPdf(
        sourceDocumentId: Long,
        newTitle: String,
        position: PageNumberPosition,
        format: PageNumberFormat,
        startNumber: Int,
        password: String?
    ): Result<DocumentItem> = runCatching {
        fileManager.checkStorageAvailable().getOrThrow()
        val source = requirePdfSource(sourceDocumentId)
        val cleanTitle = newTitle.trim().ifBlank { "${source.title}_Numbered" }
        val outFile = fileManager.createPdfFile(cleanTitle)
        val pageCount = withReadableFile(source.filePath) { readable ->
            pdfAdvancedEngine.addPageNumbers(readable, outFile, position, format, startNumber, password = password)
        }
        insertDerivedDocument(cleanTitle, outFile, source.folderId, source.thumbnailPath, pageCount, false, DocumentFileType.PDF)
    }

    suspend fun addHeaderFooterToPdf(
        sourceDocumentId: Long,
        newTitle: String,
        headerText: String,
        footerText: String,
        includeDate: Boolean,
        fontSizePt: Float,
        password: String?
    ): Result<DocumentItem> = runCatching {
        fileManager.checkStorageAvailable().getOrThrow()
        val source = requirePdfSource(sourceDocumentId)
        val cleanTitle = newTitle.trim().ifBlank { "${source.title}_HeaderFooter" }
        val outFile = fileManager.createPdfFile(cleanTitle)
        val pageCount = withReadableFile(source.filePath) { readable ->
            pdfAdvancedEngine.addHeaderFooter(readable, outFile, headerText, footerText, includeDate, fontSizePt, password)
        }
        insertDerivedDocument(cleanTitle, outFile, source.folderId, source.thumbnailPath, pageCount, false, DocumentFileType.PDF)
    }

    suspend fun reducePdfSizeDocument(
        sourceDocumentId: Long,
        newTitle: String,
        maxImageDimension: Int,
        jpegQuality: Float,
        stripMetadata: Boolean,
        password: String?
    ): Result<PdfReduceSizeResult> = runCatching {
        fileManager.checkStorageAvailable().getOrThrow()
        val source = requirePdfSource(sourceDocumentId)
        val cleanTitle = newTitle.trim().ifBlank { "${source.title}_Reduced" }
        val outFile = fileManager.createPdfFile(cleanTitle)
        val (pageCount, sizes) = withReadableFile(source.filePath) { readable ->
            pdfAdvancedEngine.reducePdfSize(
                sourceFile = readable,
                outputFile = outFile,
                maxImageDimension = maxImageDimension,
                jpegQuality = jpegQuality,
                stripMetadata = stripMetadata,
                password = password
            )
        }
        val doc = insertDerivedDocument(cleanTitle, outFile, source.folderId, source.thumbnailPath, pageCount, false, DocumentFileType.PDF)
        PdfReduceSizeResult(
            document = doc,
            originalBytes = sizes.first,
            outputBytes = sizes.second
        )
    }

    suspend fun repairPdfDocument(
        sourceDocumentId: Long,
        newTitle: String,
        password: String?
    ): Result<PdfRepairResult> = runCatching {
        fileManager.checkStorageAvailable().getOrThrow()
        val source = requirePdfSource(sourceDocumentId)
        val cleanTitle = newTitle.trim().ifBlank { "${source.title}_Repaired" }
        val outFile = fileManager.createPdfFile(cleanTitle)
        val (recoveredPages, summary) = withReadableFile(source.filePath) { readable ->
            pdfAdvancedEngine.repairPdf(readable, outFile, password)
        }
        val doc = insertDerivedDocument(cleanTitle, outFile, source.folderId, source.thumbnailPath, recoveredPages, false, DocumentFileType.PDF)
        PdfRepairResult(
            document = doc,
            recoveredPages = recoveredPages,
            methodSummary = summary
        )
    }

    suspend fun repairExternalPdfUri(
        uri: Uri,
        newTitle: String,
        password: String?
    ): Result<PdfRepairResult> = runCatching {
        fileManager.checkStorageAvailable().getOrThrow()
        val rawName = fileManager.resolveDisplayName(uri)
            ?.substringBeforeLast('.')
            ?.ifBlank { null }
            ?: "DamagedPDF_${System.currentTimeMillis() % 10000}"
        val cleanTitle = newTitle.trim().ifBlank { "${rawName}_Repaired" }
        val tempCopy = fileManager.copyUriToPdfFile(uri, "repair_src_${System.currentTimeMillis()}")
        val outFile = fileManager.createPdfFile(cleanTitle)
        try {
            val (recoveredPages, summary) = pdfAdvancedEngine.repairPdf(tempCopy, outFile, password)
            val doc = insertDerivedDocument(cleanTitle, outFile, null, null, recoveredPages, false, DocumentFileType.PDF)
            PdfRepairResult(
                document = doc,
                recoveredPages = recoveredPages,
                methodSummary = summary
            )
        } catch (t: Throwable) {
            if (outFile.exists()) outFile.delete()
            throw t
        } finally {
            if (tempCopy.exists()) tempCopy.delete()
        }
    }
}
