package com.docuscan.app.scanner

import android.app.Activity
import android.content.Context
import android.content.Intent
import android.content.IntentSender
import android.net.Uri
import com.google.android.gms.common.ConnectionResult
import com.google.android.gms.common.GoogleApiAvailability
import com.google.mlkit.common.MlKitException
import com.google.mlkit.vision.documentscanner.GmsDocumentScannerOptions
import com.google.mlkit.vision.documentscanner.GmsDocumentScanning
import com.google.mlkit.vision.documentscanner.GmsDocumentScanningResult

data class ParsedScanResult(
    val pageImageUris: List<Uri>,
    val pdfUri: Uri?,
    val pdfPageCount: Int
)

sealed interface ScannerStartOutcome {
    data class Ready(val intentSender: IntentSender) : ScannerStartOutcome
    data class Error(
        val message: String,
        val isPlayServicesUnavailable: Boolean = false,
        val isUnsupportedDevice: Boolean = false
    ) : ScannerStartOutcome
}

interface DocumentScannerGateway {
    fun buildDefaultOptions(pageLimit: Int = 50): GmsDocumentScannerOptions
    fun prepareScanIntent(
        activity: Activity,
        pageLimit: Int = 50,
        onResult: (ScannerStartOutcome) -> Unit
    )
    fun parseActivityResult(resultCode: Int, data: Intent?): ScannerActivityOutcome
}

sealed interface ScannerActivityOutcome {
    data object Cancelled : ScannerActivityOutcome
    data class Success(val result: ParsedScanResult) : ScannerActivityOutcome
    data class Error(val message: String) : ScannerActivityOutcome
}

class MlKitDocumentScannerManager(
    private val context: Context
) : DocumentScannerGateway {

    override fun buildDefaultOptions(pageLimit: Int): GmsDocumentScannerOptions {
        return GmsDocumentScannerOptions.Builder()
            .setScannerMode(GmsDocumentScannerOptions.SCANNER_MODE_FULL)
            .setGalleryImportAllowed(true)
            .setPageLimit(pageLimit.coerceIn(1, 50))
            .setResultFormats(
                GmsDocumentScannerOptions.RESULT_FORMAT_JPEG,
                GmsDocumentScannerOptions.RESULT_FORMAT_PDF
            )
            .build()
    }

    override fun prepareScanIntent(
        activity: Activity,
        pageLimit: Int,
        onResult: (ScannerStartOutcome) -> Unit
    ) {
        val availability = GoogleApiAvailability.getInstance()
        val gmsStatus = availability.isGooglePlayServicesAvailable(context)
        if (gmsStatus != ConnectionResult.SUCCESS) {
            val statusStr = availability.getErrorString(gmsStatus)
            onResult(
                ScannerStartOutcome.Error(
                    message = "Google Play Services is unavailable ($statusStr). Update Google Play Services or use Gallery Import / In-App Camera.",
                    isPlayServicesUnavailable = true
                )
            )
            return
        }

        val options = buildDefaultOptions(pageLimit)
        val scanner = GmsDocumentScanning.getClient(options)
        scanner.getStartScanIntent(activity)
            .addOnSuccessListener { intentSender ->
                onResult(ScannerStartOutcome.Ready(intentSender))
            }
            .addOnFailureListener { exception ->
                val outcome = mapScannerException(exception)
                onResult(outcome)
            }
    }

    override fun parseActivityResult(resultCode: Int, data: Intent?): ScannerActivityOutcome {
        if (resultCode == Activity.RESULT_CANCELED) {
            return ScannerActivityOutcome.Cancelled
        }
        if (resultCode != Activity.RESULT_OK || data == null) {
            return ScannerActivityOutcome.Error("Document scanner did not return a valid result (code $resultCode).")
        }
        val scanningResult = GmsDocumentScanningResult.fromActivityResultIntent(data)
            ?: return ScannerActivityOutcome.Error("Could not read scanned document result from Google Play Services.")

        val pageUris = scanningResult.pages?.map { it.imageUri }.orEmpty()
        val pdfUri = scanningResult.pdf?.uri
        val pdfPageCount = scanningResult.pdf?.pageCount ?: pageUris.size

        if (pageUris.isEmpty() && pdfUri == null) {
            return ScannerActivityOutcome.Error("No scanned pages or PDF output were returned.")
        }

        return ScannerActivityOutcome.Success(
            ParsedScanResult(
                pageImageUris = pageUris,
                pdfUri = pdfUri,
                pdfPageCount = pdfPageCount
            )
        )
    }

    private fun mapScannerException(exception: Exception): ScannerStartOutcome.Error {
        if (exception is MlKitException) {
            return when (exception.errorCode) {
                MlKitException.UNSUPPORTED -> ScannerStartOutcome.Error(
                    message = "ML Kit Document Scanner is unsupported on this device (requires Android 5.0+ and at least 1.7 GB RAM). You can use Gallery Import or the In-App Camera instead.",
                    isUnsupportedDevice = true
                )
                MlKitException.UNAVAILABLE,
                MlKitException.NOT_ENOUGH_SPACE -> ScannerStartOutcome.Error(
                    message = "Google Play Services scanner module is currently unavailable (${exception.localizedMessage}). Check Play Services or available storage.",
                    isPlayServicesUnavailable = true
                )
                else -> ScannerStartOutcome.Error(
                    message = "Unable to start ML Kit Document Scanner: ${exception.localizedMessage ?: "error ${exception.errorCode}"}"
                )
            }
        }
        return ScannerStartOutcome.Error(
            message = "Unable to start document scanner: ${exception.localizedMessage ?: "unknown error"}"
        )
    }
}
