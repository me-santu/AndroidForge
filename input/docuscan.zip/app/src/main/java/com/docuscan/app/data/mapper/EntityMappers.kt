package com.docuscan.app.data.mapper

import com.docuscan.app.database.entity.DeletedDocumentEntity
import com.docuscan.app.database.entity.DocumentEntity
import com.docuscan.app.database.entity.FolderEntity
import com.docuscan.app.database.entity.SignatureEntity
import com.docuscan.app.domain.model.DeletedDocumentItem
import com.docuscan.app.domain.model.DocumentFileType
import com.docuscan.app.domain.model.DocumentItem
import com.docuscan.app.domain.model.FolderItem
import com.docuscan.app.domain.model.SignatureItem

fun DocumentEntity.toDomain(folderName: String? = null): DocumentItem {
    val parsedType = DocumentFileType.entries.firstOrNull { it.name == fileType }
        ?: DocumentFileType.PDF
    val bookmarks = bookmarkedPages
        .split(",")
        .mapNotNull { it.trim().toIntOrNull() }
        .distinct()
        .sorted()
    return DocumentItem(
        id = id,
        title = title,
        folderId = folderId,
        folderName = folderName,
        filePath = filePath,
        thumbnailPath = thumbnailPath,
        fileType = parsedType,
        pageCount = pageCount,
        sizeBytes = sizeBytes,
        ocrText = ocrText,
        createdAt = createdAt,
        updatedAt = updatedAt,
        isPinned = isPinned,
        isFavorite = isFavorite,
        isPasswordProtected = isPasswordProtected,
        bookmarkedPages = bookmarks,
        isDeleted = isDeleted,
        deletedAt = deletedAt
    )
}

fun FolderEntity.toDomain(documentCount: Int = 0): FolderItem = FolderItem(
    id = id,
    name = name,
    accentHex = accentHex,
    createdAt = createdAt,
    documentCount = documentCount
)

fun SignatureEntity.toDomain(): SignatureItem = SignatureItem(
    id = id,
    name = name,
    filePath = filePath,
    createdAt = createdAt
)

fun DeletedDocumentEntity.toDomain(): DeletedDocumentItem {
    val parsedType = DocumentFileType.entries.firstOrNull { it.name == fileType }
        ?: DocumentFileType.PDF
    return DeletedDocumentItem(
        id = id,
        originalDocumentId = originalDocumentId,
        title = title,
        folderId = folderId,
        filePath = filePath,
        thumbnailPath = thumbnailPath,
        fileType = parsedType,
        pageCount = pageCount,
        sizeBytes = sizeBytes,
        deletedAt = deletedAt
    )
}
