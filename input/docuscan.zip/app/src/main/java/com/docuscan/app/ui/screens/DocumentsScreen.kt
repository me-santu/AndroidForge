package com.docuscan.app.ui.screens

import android.net.Uri
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items as gridItems
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import com.docuscan.app.ui.icons.LucideIcons
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.outlined.DocumentScanner
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FilterChipDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.RadioButton
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.minimumInteractiveComponentSize
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.unit.dp
import com.docuscan.app.domain.model.DocumentItem
import com.docuscan.app.domain.model.DocumentSortOption
import com.docuscan.app.domain.model.DocumentViewMode
import com.docuscan.app.domain.model.FolderItem
import com.docuscan.app.ui.components.DocumentGridCard
import com.docuscan.app.ui.components.DocumentRowCard
import com.docuscan.app.ui.components.EmptyStateView
import com.docuscan.app.ui.components.ErrorStateView
import com.docuscan.app.ui.components.LoadingStateView
import com.docuscan.app.ui.viewmodel.DocumentsUiState

@Composable
fun DocumentsScreen(
    uiState: DocumentsUiState,
    onSearchChange: (String) -> Unit,
    onSelectFolder: (Long?) -> Unit,
    onCreateFolder: (String) -> Unit,
    onRenameFolder: (Long, String) -> Unit,
    onDeleteFolder: (Long) -> Unit,
    onSetSortOption: (DocumentSortOption) -> Unit,
    onToggleViewMode: () -> Unit,
    onToggleFavoritesOnly: () -> Unit,
    onToggleSelection: (Long) -> Unit,
    onSelectAll: (List<DocumentItem>) -> Unit,
    onClearSelection: () -> Unit,
    onMoveSelectedToFolder: (Long?) -> Unit,
    onSetSelectedFavorites: (Boolean) -> Unit,
    onTrashSelected: () -> Unit,
    onMergeSelectedPdfs: (String) -> Unit,
    onImportPdfUri: (Uri) -> Unit,
    onExportDocumentToUri: (Long, Uri) -> Unit,
    onOpenDocument: (Long) -> Unit,
    onRenameDocument: (Long, String) -> Unit,
    onTogglePin: (Long) -> Unit,
    onToggleFavorite: (Long) -> Unit,
    onMoveDocumentToFolder: (Long, Long?) -> Unit,
    onShareDocument: (DocumentItem) -> Unit,
    onMoveToTrash: (Long) -> Unit,
    onOpenRecycleBin: () -> Unit,
    onScanNew: () -> Unit,
    onToggleVaultEncryption: (Long) -> Unit = {},
    modifier: Modifier = Modifier
) {
    var showNewFolderDialog by remember { mutableStateOf(false) }
    var newFolderName by remember { mutableStateOf("") }
    var renameFolderTarget by remember { mutableStateOf<FolderItem?>(null) }
    var renameFolderInput by remember { mutableStateOf("") }

    var renameTarget by remember { mutableStateOf<DocumentItem?>(null) }
    var renameInput by remember { mutableStateOf("") }
    var moveDocTarget by remember { mutableStateOf<DocumentItem?>(null) }
    var showMoveBatchDialog by remember { mutableStateOf(false) }
    var showMergeBatchDialog by remember { mutableStateOf(false) }
    var mergeBatchTitle by remember { mutableStateOf("Merged_${System.currentTimeMillis() % 10000}") }

    var activeMenuDocId by remember { mutableStateOf<Long?>(null) }
    var showSortMenu by remember { mutableStateOf(false) }
    var pendingExportDocId by remember { mutableStateOf<Long?>(null) }

    val importPdfLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.OpenDocument()
    ) { uri ->
        if (uri != null) {
            onImportPdfUri(uri)
        }
    }

    val exportSafLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.CreateDocument("application/pdf")
    ) { uri ->
        val docId = pendingExportDocId
        pendingExportDocId = null
        if (uri != null && docId != null) {
            onExportDocumentToUri(docId, uri)
        }
    }

    Column(
        modifier = modifier
            .fillMaxSize()
            .background(MaterialTheme.colorScheme.background)
            .padding(horizontal = 16.dp, vertical = 12.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp)
    ) {
        // Header Row
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Column(modifier = Modifier.weight(1f)) {
                Text(
                    text = "Documents & Folders",
                    style = MaterialTheme.typography.headlineMedium
                )
                Text(
                    text = "App-private storage Vault",
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
            Row {
                IconButton(
                    onClick = { importPdfLauncher.launch(arrayOf("application/pdf")) },
                    modifier = Modifier
                        .minimumInteractiveComponentSize()
                        .testTag("docs_import_pdf_btn")
                ) {
                    Icon(
                        imageVector = LucideIcons.FileUp,
                        contentDescription = "Import PDF",
                        tint = MaterialTheme.colorScheme.primary
                    )
                }
                IconButton(
                    onClick = { showNewFolderDialog = true },
                    modifier = Modifier
                        .minimumInteractiveComponentSize()
                        .testTag("docs_new_folder_btn")
                ) {
                    Icon(
                        imageVector = LucideIcons.FolderPlus,
                        contentDescription = "New Folder",
                        tint = MaterialTheme.colorScheme.primary
                    )
                }
                IconButton(
                    onClick = onOpenRecycleBin,
                    modifier = Modifier
                        .minimumInteractiveComponentSize()
                        .testTag("docs_recycle_bin_btn")
                ) {
                    Icon(
                        imageVector = LucideIcons.Trash2,
                        contentDescription = "Recycle Bin"
                    )
                }
            }
        }

        when (uiState) {
            is DocumentsUiState.Loading -> LoadingStateView("Loading your documents...")
            is DocumentsUiState.Error -> ErrorStateView(message = uiState.message)
            is DocumentsUiState.Success -> {
                val selectionActive = uiState.selectedDocumentIds.isNotEmpty()
                val selectedFolderObj = uiState.folders.firstOrNull { it.id == uiState.selectedFolderId }

                if (selectionActive) {
                    Surface(
                        shape = RoundedCornerShape(14.dp),
                        color = MaterialTheme.colorScheme.primaryContainer,
                        border = BorderStroke(1.dp, MaterialTheme.colorScheme.primary),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(horizontal = 10.dp, vertical = 4.dp),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Text(
                                text = "${uiState.selectedDocumentIds.size} selected",
                                style = MaterialTheme.typography.titleSmall,
                                color = MaterialTheme.colorScheme.primary
                            )
                            Row {
                                IconButton(onClick = { onSelectAll(uiState.documents) }) {
                                    Icon(LucideIcons.CheckSquare, contentDescription = "Select all")
                                }
                                IconButton(onClick = { onSetSelectedFavorites(true) }) {
                                    Icon(LucideIcons.StarFilled, contentDescription = "Favorite selected")
                                }
                                IconButton(onClick = { showMoveBatchDialog = true }) {
                                    Icon(LucideIcons.FolderInput, contentDescription = "Move selected")
                                }
                                if (uiState.selectedDocumentIds.size >= 2) {
                                    IconButton(onClick = { showMergeBatchDialog = true }) {
                                        Icon(LucideIcons.Merge, contentDescription = "Merge selected")
                                    }
                                }
                                IconButton(onClick = onTrashSelected) {
                                    Icon(
                                        LucideIcons.Trash2,
                                        contentDescription = "Delete selected",
                                        tint = MaterialTheme.colorScheme.error
                                    )
                                }
                                IconButton(onClick = onClearSelection) {
                                    Icon(LucideIcons.X, contentDescription = "Clear selection")
                                }
                            }
                        }
                    }
                }

                // Search + Sort + Grid/List Controls
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    OutlinedTextField(
                        value = uiState.searchQuery,
                        onValueChange = onSearchChange,
                        placeholder = { Text("Search files, folders, notes...") },
                        leadingIcon = { Icon(LucideIcons.Search, contentDescription = null) },
                        trailingIcon = {
                            if (uiState.searchQuery.isNotEmpty()) {
                                IconButton(onClick = { onSearchChange("") }) {
                                    Icon(LucideIcons.X, contentDescription = "Clear filter")
                                }
                            }
                        },
                        singleLine = true,
                        shape = MaterialTheme.shapes.medium,
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedContainerColor = MaterialTheme.colorScheme.surfaceContainer,
                            unfocusedContainerColor = MaterialTheme.colorScheme.surfaceContainer,
                            focusedBorderColor = MaterialTheme.colorScheme.primary,
                            unfocusedBorderColor = MaterialTheme.colorScheme.outline
                        ),
                        modifier = Modifier
                            .weight(1f)
                            .testTag("docs_search_input")
                    )

                    Box {
                        IconButton(
                            onClick = { showSortMenu = true },
                            modifier = Modifier
                                .minimumInteractiveComponentSize()
                                .testTag("docs_sort_btn")
                        ) {
                            Icon(LucideIcons.ArrowUpDown, contentDescription = "Sort documents")
                        }
                        DropdownMenu(
                            expanded = showSortMenu,
                            onDismissRequest = { showSortMenu = false }
                        ) {
                            DocumentSortOption.entries.forEach { option ->
                                DropdownMenuItem(
                                    text = { Text(option.label) },
                                    leadingIcon = {
                                        if (uiState.sortOption == option) {
                                            Icon(
                                                LucideIcons.CheckSquare,
                                                contentDescription = null,
                                                tint = MaterialTheme.colorScheme.primary
                                            )
                                        }
                                    },
                                    onClick = {
                                        showSortMenu = false
                                        onSetSortOption(option)
                                    }
                                )
                            }
                        }
                    }

                    IconButton(
                        onClick = onToggleViewMode,
                        modifier = Modifier
                            .minimumInteractiveComponentSize()
                            .testTag("docs_view_mode_btn")
                    ) {
                        Icon(
                            imageVector = if (uiState.viewMode == DocumentViewMode.LIST) {
                                LucideIcons.LayoutGrid
                            } else {
                                LucideIcons.List
                            },
                            contentDescription = "Toggle grid or list view"
                        )
                    }
                }

                // Folder & Favorites Filter Chips
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .horizontalScroll(rememberScrollState()),
                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    FilterChip(
                        selected = uiState.favoritesOnly,
                        onClick = onToggleFavoritesOnly,
                        label = { Text("Favorites") },
                        leadingIcon = {
                            Icon(
                                imageVector = if (uiState.favoritesOnly) LucideIcons.StarFilled else LucideIcons.Star,
                                contentDescription = null,
                                modifier = Modifier.size(16.dp)
                            )
                        },
                        colors = FilterChipDefaults.filterChipColors(
                            selectedContainerColor = MaterialTheme.colorScheme.primary,
                            selectedLabelColor = MaterialTheme.colorScheme.onPrimary
                        ),
                        modifier = Modifier.testTag("docs_favorites_chip")
                    )
                    FilterChip(
                        selected = uiState.selectedFolderId == null,
                        onClick = { onSelectFolder(null) },
                        label = { Text("All") },
                        leadingIcon = {
                            Icon(
                                imageVector = LucideIcons.Folder,
                                contentDescription = null,
                                modifier = Modifier.size(16.dp)
                            )
                        },
                        colors = FilterChipDefaults.filterChipColors(
                            selectedContainerColor = MaterialTheme.colorScheme.primary,
                            selectedLabelColor = MaterialTheme.colorScheme.onPrimary
                        )
                    )
                    uiState.folders.forEach { folder ->
                        FilterChip(
                            selected = uiState.selectedFolderId == folder.id,
                            onClick = { onSelectFolder(folder.id) },
                            label = { Text("${folder.name} (${folder.documentCount})") },
                            colors = FilterChipDefaults.filterChipColors(
                                selectedContainerColor = MaterialTheme.colorScheme.primary,
                                selectedLabelColor = MaterialTheme.colorScheme.onPrimary
                            )
                        )
                    }
                }

                // Folder Rename / Delete inline bar when a folder is actively selected
                if (selectedFolderObj != null) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = "Folder: ${selectedFolderObj.name}",
                            style = MaterialTheme.typography.labelLarge,
                            color = MaterialTheme.colorScheme.primary
                        )
                        Row {
                            TextButton(
                                onClick = {
                                    renameFolderTarget = selectedFolderObj
                                    renameFolderInput = selectedFolderObj.name
                                }
                            ) {
                                Text("Rename")
                            }
                            TextButton(
                                onClick = { onDeleteFolder(selectedFolderObj.id) }
                            ) {
                                Text("Delete Folder", color = MaterialTheme.colorScheme.error)
                            }
                        }
                    }
                }

                if (uiState.documents.isEmpty()) {
                    Box(
                        modifier = Modifier
                            .weight(1f)
                            .fillMaxWidth()
                            .padding(bottom = 96.dp),
                        contentAlignment = Alignment.Center
                    ) {
                        EmptyStateView(
                            title = "No documents in this view",
                            subtitle = "Tap Scan to capture, or tap the Import PDF icon to bring in a PDF from your device.",
                            icon = Icons.Outlined.DocumentScanner,
                            actionLabel = "Scan Document",
                            onAction = onScanNew
                        )
                    }
                } else if (uiState.viewMode == DocumentViewMode.GRID) {
                    LazyVerticalGrid(
                        columns = GridCells.Adaptive(160.dp),
                        modifier = Modifier.weight(1f),
                        contentPadding = PaddingValues(bottom = 96.dp),
                        horizontalArrangement = Arrangement.spacedBy(10.dp),
                        verticalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        gridItems(uiState.documents, key = { it.id }) { doc ->
                            val isSelected = doc.id in uiState.selectedDocumentIds
                            Box {
                                DocumentGridCard(
                                    document = doc,
                                    selected = isSelected,
                                    selectionMode = selectionActive,
                                    onClick = {
                                        if (selectionActive) onToggleSelection(doc.id) else onOpenDocument(doc.id)
                                    },
                                    onLongClick = { onToggleSelection(doc.id) },
                                    onToggleFavorite = { onToggleFavorite(doc.id) },
                                    onMoreClick = { activeMenuDocId = doc.id }
                                )
                                DocumentActionMenu(
                                    expanded = activeMenuDocId == doc.id,
                                    document = doc,
                                    onDismiss = { activeMenuDocId = null },
                                    onTogglePin = { onTogglePin(doc.id) },
                                    onToggleFavorite = { onToggleFavorite(doc.id) },
                                    onRename = {
                                        renameTarget = doc
                                        renameInput = doc.title
                                    },
                                    onMove = { moveDocTarget = doc },
                                    onExportSaf = {
                                        pendingExportDocId = doc.id
                                        exportSafLauncher.launch("${doc.title}.pdf")
                                    },
                                    onShare = { onShareDocument(doc) },
                                    onToggleVaultEncryption = { onToggleVaultEncryption(doc.id) },
                                    onMoveToTrash = { onMoveToTrash(doc.id) }
                                )
                            }
                        }
                    }
                } else {
                    LazyColumn(
                        modifier = Modifier.weight(1f),
                        contentPadding = PaddingValues(bottom = 96.dp),
                        verticalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        items(uiState.documents, key = { it.id }) { doc ->
                            val isSelected = doc.id in uiState.selectedDocumentIds
                            Box {
                                DocumentRowCard(
                                    document = doc,
                                    selected = isSelected,
                                    selectionMode = selectionActive,
                                    onClick = {
                                        if (selectionActive) onToggleSelection(doc.id) else onOpenDocument(doc.id)
                                    },
                                    onLongClick = { onToggleSelection(doc.id) },
                                    onToggleFavorite = { onToggleFavorite(doc.id) },
                                    onMoreClick = { activeMenuDocId = doc.id }
                                )
                                DocumentActionMenu(
                                    expanded = activeMenuDocId == doc.id,
                                    document = doc,
                                    onDismiss = { activeMenuDocId = null },
                                    onTogglePin = { onTogglePin(doc.id) },
                                    onToggleFavorite = { onToggleFavorite(doc.id) },
                                    onRename = {
                                        renameTarget = doc
                                        renameInput = doc.title
                                    },
                                    onMove = { moveDocTarget = doc },
                                    onExportSaf = {
                                        pendingExportDocId = doc.id
                                        exportSafLauncher.launch("${doc.title}.pdf")
                                    },
                                    onShare = { onShareDocument(doc) },
                                    onToggleVaultEncryption = { onToggleVaultEncryption(doc.id) },
                                    onMoveToTrash = { onMoveToTrash(doc.id) }
                                )
                            }
                        }
                    }
                }
            }
        }
    }

    if (showNewFolderDialog) {
        AlertDialog(
            onDismissRequest = { showNewFolderDialog = false },
            title = { Text("New Folder") },
            text = {
                OutlinedTextField(
                    value = newFolderName,
                    onValueChange = { newFolderName = it },
                    label = { Text("Folder name") },
                    singleLine = true
                )
            },
            confirmButton = {
                TextButton(
                    onClick = {
                        if (newFolderName.isNotBlank()) {
                            onCreateFolder(newFolderName)
                            newFolderName = ""
                            showNewFolderDialog = false
                        }
                    }
                ) { Text("Create") }
            },
            dismissButton = {
                TextButton(onClick = { showNewFolderDialog = false }) { Text("Cancel") }
            }
        )
    }

    renameFolderTarget?.let { folder ->
        AlertDialog(
            onDismissRequest = { renameFolderTarget = null },
            title = { Text("Rename Folder") },
            text = {
                OutlinedTextField(
                    value = renameFolderInput,
                    onValueChange = { renameFolderInput = it },
                    label = { Text("Folder name") },
                    singleLine = true
                )
            },
            confirmButton = {
                TextButton(
                    onClick = {
                        if (renameFolderInput.isNotBlank()) {
                            onRenameFolder(folder.id, renameFolderInput)
                            renameFolderTarget = null
                        }
                    }
                ) { Text("Save") }
            },
            dismissButton = {
                TextButton(onClick = { renameFolderTarget = null }) { Text("Cancel") }
            }
        )
    }

    renameTarget?.let { doc ->
        AlertDialog(
            onDismissRequest = { renameTarget = null },
            title = { Text("Rename Document") },
            text = {
                OutlinedTextField(
                    value = renameInput,
                    onValueChange = { renameInput = it },
                    label = { Text("Document title") },
                    singleLine = true
                )
            },
            confirmButton = {
                TextButton(
                    onClick = {
                        if (renameInput.isNotBlank()) {
                            onRenameDocument(doc.id, renameInput)
                            renameTarget = null
                        }
                    }
                ) { Text("Save") }
            },
            dismissButton = {
                TextButton(onClick = { renameTarget = null }) { Text("Cancel") }
            }
        )
    }

    val foldersList = (uiState as? DocumentsUiState.Success)?.folders.orEmpty()

    moveDocTarget?.let { doc ->
        MoveToFolderDialog(
            title = "Move '${doc.title}' to Folder",
            folders = foldersList,
            currentFolderId = doc.folderId,
            onDismiss = { moveDocTarget = null },
            onSelectFolder = { targetId ->
                onMoveDocumentToFolder(doc.id, targetId)
                moveDocTarget = null
            }
        )
    }

    if (showMoveBatchDialog) {
        MoveToFolderDialog(
            title = "Move Selected Documents",
            folders = foldersList,
            currentFolderId = null,
            onDismiss = { showMoveBatchDialog = false },
            onSelectFolder = { targetId ->
                onMoveSelectedToFolder(targetId)
                showMoveBatchDialog = false
            }
        )
    }

    if (showMergeBatchDialog) {
        AlertDialog(
            onDismissRequest = { showMergeBatchDialog = false },
            title = { Text("Merge Selected PDFs") },
            text = {
                OutlinedTextField(
                    value = mergeBatchTitle,
                    onValueChange = { mergeBatchTitle = it },
                    label = { Text("Merged PDF Title") },
                    singleLine = true
                )
            },
            confirmButton = {
                TextButton(
                    enabled = mergeBatchTitle.isNotBlank(),
                    onClick = {
                        onMergeSelectedPdfs(mergeBatchTitle)
                        showMergeBatchDialog = false
                    }
                ) { Text("Merge") }
            },
            dismissButton = {
                TextButton(onClick = { showMergeBatchDialog = false }) { Text("Cancel") }
            }
        )
    }
}

@Composable
private fun DocumentActionMenu(
    expanded: Boolean,
    document: DocumentItem,
    onDismiss: () -> Unit,
    onTogglePin: () -> Unit,
    onToggleFavorite: () -> Unit,
    onRename: () -> Unit,
    onMove: () -> Unit,
    onExportSaf: () -> Unit,
    onShare: () -> Unit,
    onToggleVaultEncryption: () -> Unit,
    onMoveToTrash: () -> Unit
) {
    DropdownMenu(
        expanded = expanded,
        onDismissRequest = onDismiss
    ) {
        DropdownMenuItem(
            text = { Text(if (document.isPinned) "Unpin" else "Pin to Top") },
            leadingIcon = { Icon(LucideIcons.Pin, contentDescription = null) },
            onClick = { onDismiss(); onTogglePin() }
        )
        DropdownMenuItem(
            text = { Text(if (document.isFavorite) "Remove Favorite" else "Add to Favorites") },
            leadingIcon = {
                Icon(
                    if (document.isFavorite) LucideIcons.StarFilled else LucideIcons.Star,
                    contentDescription = null
                )
            },
            onClick = { onDismiss(); onToggleFavorite() }
        )
        DropdownMenuItem(
            text = { Text("Rename") },
            leadingIcon = { Icon(LucideIcons.FilePen, contentDescription = null) },
            onClick = { onDismiss(); onRename() }
        )
        DropdownMenuItem(
            text = { Text("Move to Folder") },
            leadingIcon = { Icon(LucideIcons.FolderInput, contentDescription = null) },
            onClick = { onDismiss(); onMove() }
        )
        if (document.fileType.name != "IMAGE") {
            DropdownMenuItem(
                text = { Text("Save Copy (SAF)") },
                leadingIcon = { Icon(LucideIcons.Download, contentDescription = null) },
                onClick = { onDismiss(); onExportSaf() }
            )
        }
        DropdownMenuItem(
            text = { Text("Toggle Keystore Encryption") },
            leadingIcon = { Icon(LucideIcons.Lock, contentDescription = null) },
            onClick = { onDismiss(); onToggleVaultEncryption() }
        )
        DropdownMenuItem(
            text = { Text("Share") },
            leadingIcon = { Icon(LucideIcons.Share2, contentDescription = null) },
            onClick = { onDismiss(); onShare() }
        )
        DropdownMenuItem(
            text = { Text("Move to Recycle Bin", color = MaterialTheme.colorScheme.error) },
            leadingIcon = {
                Icon(
                    LucideIcons.Trash2,
                    contentDescription = null,
                    tint = MaterialTheme.colorScheme.error
                )
            },
            onClick = { onDismiss(); onMoveToTrash() }
        )
    }
}

@Composable
private fun MoveToFolderDialog(
    title: String,
    folders: List<FolderItem>,
    currentFolderId: Long?,
    onDismiss: () -> Unit,
    onSelectFolder: (Long?) -> Unit
) {
    var chosenId by remember(currentFolderId) { mutableStateOf(currentFolderId) }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text(title) },
        text = {
            Column(modifier = Modifier.heightIn(max = 320.dp)) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clickable { chosenId = null },
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    RadioButton(selected = chosenId == null, onClick = { chosenId = null })
                    Text("All Documents (Root)")
                }
                folders.forEach { folder ->
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clickable { chosenId = folder.id },
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        RadioButton(selected = chosenId == folder.id, onClick = { chosenId = folder.id })
                        Text(folder.name)
                    }
                }
            }
        },
        confirmButton = {
            TextButton(onClick = { onSelectFolder(chosenId) }) { Text("Move") }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) { Text("Cancel") }
        }
    )
}
