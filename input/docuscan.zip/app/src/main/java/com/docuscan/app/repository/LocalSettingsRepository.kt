package com.docuscan.app.repository

import com.docuscan.app.data.datastore.UserPreferencesDataSource
import com.docuscan.app.domain.model.AppFontStyle
import com.docuscan.app.domain.model.AppLanguage
import com.docuscan.app.domain.model.FileNamingFormat
import com.docuscan.app.domain.model.PdfPageSize
import com.docuscan.app.domain.model.ScanQuality
import com.docuscan.app.domain.model.ThemeMode
import com.docuscan.app.domain.model.UserPreferences
import com.docuscan.app.domain.repository.SettingsRepository
import kotlinx.coroutines.flow.Flow

class LocalSettingsRepository(
    private val dataSource: UserPreferencesDataSource
) : SettingsRepository {

    override val preferences: Flow<UserPreferences> = dataSource.preferences

    override suspend fun setThemeMode(mode: ThemeMode) = dataSource.setThemeMode(mode)

    override suspend fun setAppLanguage(language: AppLanguage) =
        dataSource.setAppLanguage(language)

    override suspend fun setFontStyle(fontStyle: AppFontStyle) =
        dataSource.setFontStyle(fontStyle)

    override suspend fun setOnboardingCompleted(completed: Boolean) =
        dataSource.setOnboardingCompleted(completed)

    override suspend fun setScanQuality(quality: ScanQuality) =
        dataSource.setScanQuality(quality)

    override suspend fun setDefaultPageSize(pageSize: PdfPageSize) =
        dataSource.setDefaultPageSize(pageSize)

    override suspend fun setAutoEnhance(enabled: Boolean) =
        dataSource.setAutoEnhance(enabled)

    override suspend fun setAppLockEnabled(enabled: Boolean) =
        dataSource.setAppLockEnabled(enabled)

    override suspend fun setBiometricUnlockEnabled(enabled: Boolean) =
        dataSource.setBiometricUnlockEnabled(enabled)

    override suspend fun setEncryptSensitiveFiles(enabled: Boolean) =
        dataSource.setEncryptSensitiveFiles(enabled)

    override suspend fun setSealedPinRecord(record: String?) =
        dataSource.setSealedPinRecord(record)

    override suspend fun updateLastBackupAt(timestamp: Long) =
        dataSource.updateLastBackupAt(timestamp)

    override suspend fun setFileNamingFormat(format: FileNamingFormat) =
        dataSource.setFileNamingFormat(format)
}
