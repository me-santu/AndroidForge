package com.docuscan.app.pdf

import android.content.Context
import com.docuscan.app.domain.model.PdfSignatureDetail
import com.docuscan.app.domain.model.PdfSignatureValidationOutcome
import com.tom_roush.pdfbox.android.PDFBoxResourceLoader
import com.tom_roush.pdfbox.cos.COSArray
import com.tom_roush.pdfbox.cos.COSName
import com.tom_roush.pdfbox.cos.COSString
import com.tom_roush.pdfbox.io.MemoryUsageSetting
import com.tom_roush.pdfbox.pdmodel.PDDocument
import com.tom_roush.pdfbox.pdmodel.encryption.InvalidPasswordException
import com.tom_roush.pdfbox.pdmodel.interactive.digitalsignature.PDSignature
import com.tom_roush.pdfbox.pdmodel.interactive.form.PDSignatureField
import kotlinx.coroutines.CoroutineDispatcher
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import org.bouncycastle.asn1.ASN1GeneralizedTime
import org.bouncycastle.asn1.ASN1ObjectIdentifier
import org.bouncycastle.asn1.ASN1UTCTime
import org.bouncycastle.asn1.cms.CMSAttributes
import org.bouncycastle.asn1.x500.X500Name
import org.bouncycastle.asn1.x500.style.BCStyle
import org.bouncycastle.asn1.x500.style.IETFUtils
import org.bouncycastle.cert.X509CertificateHolder
import org.bouncycastle.cert.jcajce.JcaX509CertificateConverter
import org.bouncycastle.cms.CMSProcessableByteArray
import org.bouncycastle.cms.CMSSignedData
import org.bouncycastle.cms.SignerInformation
import org.bouncycastle.cms.jcajce.JcaSimpleSignerInfoVerifierBuilder
import org.bouncycastle.jce.provider.BouncyCastleProvider
import org.bouncycastle.util.Selector
import java.io.ByteArrayInputStream
import java.io.ByteArrayOutputStream
import java.io.File
import java.io.FileInputStream
import java.io.RandomAccessFile
import java.security.MessageDigest
import java.security.Signature
import java.security.cert.CertificateFactory
import java.security.cert.X509Certificate
import java.util.Date
import java.util.Locale

class PdfSignatureValidator(
    private val context: Context? = null,
    private val ioDispatcher: CoroutineDispatcher = Dispatchers.IO
) {

    private val bcProvider: BouncyCastleProvider by lazy { BouncyCastleProvider() }

    private fun ensurePdfBoxReady() {
        if (context != null && !PDFBoxResourceLoader.isReady()) {
            PDFBoxResourceLoader.init(context.applicationContext)
        }
    }

    suspend fun validateFile(
        file: File,
        displayName: String,
        password: String? = null
    ): PdfSignatureValidationOutcome = withContext(ioDispatcher) {
        if (!file.exists() || file.length() <= 0L) {
            return@withContext PdfSignatureValidationOutcome.Failed(
                fileName = displayName,
                reason = "Selected PDF file is missing or empty."
            )
        }

        ensurePdfBoxReady()
        val fileLength = file.length()

        val document = try {
            val mem = MemoryUsageSetting.setupTempFileOnly()
            if (!password.isNullOrEmpty()) {
                PDDocument.load(file, password, mem)
            } else {
                PDDocument.load(file, mem)
            }
        } catch (_: InvalidPasswordException) {
            return@withContext PdfSignatureValidationOutcome.PasswordRequired(
                fileName = displayName,
                incorrectPassword = !password.isNullOrEmpty()
            )
        } catch (t: Throwable) {
            return@withContext PdfSignatureValidationOutcome.Failed(
                fileName = displayName,
                reason = t.message?.takeIf { it.isNotBlank() }
                    ?: "Unable to parse PDF file. Ensure the file is a valid PDF."
            )
        }

        document.use { doc ->
            val pageCount = doc.numberOfPages.coerceAtLeast(1)
            val isEncrypted = doc.isEncrypted

            val (sigEntries, unsignedFieldCount) = collectSignatures(doc)
            if (sigEntries.isEmpty()) {
                return@withContext PdfSignatureValidationOutcome.NoSignatureFound(
                    fileName = displayName,
                    fileSizeBytes = fileLength,
                    pageCount = pageCount,
                    isEncrypted = isEncrypted,
                    unsignedSignatureFieldCount = unsignedFieldCount
                )
            }

            // Sort chronologically / by covered byte offset so the latest revision is last
            val sortedEntries = sigEntries.sortedBy { entry ->
                val br = entry.signature.byteRange
                if (br != null && br.size == 4) {
                    br[2].toLong() + br[3].toLong()
                } else {
                    0L
                }
            }
            val latestIndex = sortedEntries.lastIndex

            val details = sortedEntries.mapIndexed { idx, entry ->
                verifySingleSignature(
                    file = file,
                    fileLength = fileLength,
                    index = idx + 1,
                    fieldName = entry.fieldName,
                    signature = entry.signature,
                    isLatestRevision = idx == latestIndex
                )
            }

            val allValid = details.isNotEmpty() && details.all { it.isValid }
            PdfSignatureValidationOutcome.Verified(
                fileName = displayName,
                fileSizeBytes = fileLength,
                pageCount = pageCount,
                isEncrypted = isEncrypted,
                signatures = details,
                allValid = allValid
            )
        }
    }

    private data class CollectedSignature(
        val fieldName: String,
        val signature: PDSignature
    )

    private fun collectSignatures(doc: PDDocument): Pair<List<CollectedSignature>, Int> {
        val collected = mutableListOf<CollectedSignature>()
        val seenDictionaries = mutableSetOf<Any>()
        var unsignedCount = 0

        val acroForm = doc.documentCatalog?.acroForm
        if (acroForm != null) {
            for (field in acroForm.fieldTree) {
                if (field is PDSignatureField) {
                    val sig = field.signature
                    val fieldName = field.fullyQualifiedName?.takeIf { it.isNotBlank() }
                        ?: field.partialName?.takeIf { it.isNotBlank() }
                        ?: "Signature ${collected.size + 1}"
                    if (sig != null && hasSignaturePayload(sig)) {
                        if (seenDictionaries.add(sig.cosObject)) {
                            collected.add(CollectedSignature(fieldName, sig))
                        }
                    } else {
                        unsignedCount++
                    }
                }
            }
        }

        // Fallback / catch-all for signature dictionaries not linked through fieldTree
        runCatching { doc.signatureDictionaries }.getOrDefault(emptyList()).forEach { sig ->
            if (hasSignaturePayload(sig) && seenDictionaries.add(sig.cosObject)) {
                val label = sig.name?.takeIf { it.isNotBlank() } ?: "Signature ${collected.size + 1}"
                collected.add(CollectedSignature(label, sig))
            }
        }

        return collected to unsignedCount
    }

    private fun hasSignaturePayload(signature: PDSignature): Boolean {
        val hasContents = signature.cosObject.containsKey(COSName.CONTENTS)
        val hasByteRange = signature.byteRange?.size == 4
        return hasContents || hasByteRange
    }

    private fun verifySingleSignature(
        file: File,
        fileLength: Long,
        index: Int,
        fieldName: String,
        signature: PDSignature,
        isLatestRevision: Boolean
    ): PdfSignatureDetail {
        val subFilter = signature.subFilter?.takeIf { it.isNotBlank() } ?: "Unknown"
        val pdfSignDateMillis = signature.signDate?.timeInMillis
        val reason = signature.reason?.takeIf { it.isNotBlank() }
        val location = signature.location?.takeIf { it.isNotBlank() }
        val fallbackName = signature.name?.takeIf { it.isNotBlank() } ?: fieldName

        val byteRange = signature.byteRange
        if (byteRange == null || byteRange.size != 4) {
            return invalidDetail(
                index = index,
                fieldName = fieldName,
                signerName = fallbackName,
                signedAtMillis = pdfSignDateMillis,
                subFilter = subFilter,
                reason = reason,
                location = location,
                isLatestRevision = isLatestRevision,
                statusSummary = "Invalid / Missing ByteRange in PDF signature dictionary."
            )
        }

        val off1 = byteRange[0].toLong()
        val len1 = byteRange[1].toLong()
        val off2 = byteRange[2].toLong()
        val len2 = byteRange[3].toLong()

        if (off1 < 0L || len1 < 0L || off2 < 0L || len2 < 0L ||
            off1 + len1 > off2 || off2 + len2 > fileLength
        ) {
            return invalidDetail(
                index = index,
                fieldName = fieldName,
                signerName = fallbackName,
                signedAtMillis = pdfSignDateMillis,
                subFilter = subFilter,
                reason = reason,
                location = location,
                isLatestRevision = isLatestRevision,
                statusSummary = "Signature ByteRange exceeds document boundaries (corrupted or tampered)."
            )
        }

        val coveredEnd = off2 + len2
        val coversWholeDocument = off1 == 0L && isOnlyTrailingWhitespaceAfter(file, coveredEnd, fileLength)

        val signedBytes = runCatching {
            readByteRange(file, off1, len1, off2, len2)
        }.getOrNull() ?: return invalidDetail(
            index = index,
            fieldName = fieldName,
            signerName = fallbackName,
            signedAtMillis = pdfSignDateMillis,
            subFilter = subFilter,
            reason = reason,
            location = location,
            isLatestRevision = isLatestRevision,
            statusSummary = "Failed to read signed byte range from PDF."
        )

        val contentsBytes = runCatching {
            FileInputStream(file).use { input -> signature.getContents(input) }
        }.getOrNull()

        if (contentsBytes == null || contentsBytes.isEmpty() || contentsBytes.all { it == 0.toByte() }) {
            return invalidDetail(
                index = index,
                fieldName = fieldName,
                signerName = fallbackName,
                signedAtMillis = pdfSignDateMillis,
                subFilter = subFilter,
                reason = reason,
                location = location,
                isLatestRevision = isLatestRevision,
                statusSummary = "Digital signature payload is empty."
            )
        }

        val cryptoResult = verifyCryptographicPayload(
            signature = signature,
            subFilter = subFilter,
            signedBytes = signedBytes,
            contentsBytes = contentsBytes
        )

        val cert = cryptoResult.certificate
        val subjectX500 = cryptoResult.certHolder?.subject
            ?: cert?.let { runCatching { X500Name.getInstance(it.subjectX500Principal.encoded) }.getOrNull() }
        val issuerX500 = cryptoResult.certHolder?.issuer
            ?: cert?.let { runCatching { X500Name.getInstance(it.issuerX500Principal.encoded) }.getOrNull() }
        val subjectInfo = subjectX500?.let { extractDnInfo(it) }
        val issuerInfo = issuerX500?.let { extractDnInfo(it) }

        val signerCn = subjectInfo?.commonName?.takeIf { it.isNotBlank() }
            ?: subjectInfo?.organization?.takeIf { it.isNotBlank() }
            ?: fallbackName
        val signerOrg = subjectInfo?.organization?.takeIf { it.isNotBlank() && it != signerCn }

        val issuerCn = issuerInfo?.commonName?.takeIf { it.isNotBlank() }
            ?: issuerInfo?.organization?.takeIf { it.isNotBlank() }
            ?: "Unknown Issuer CA"
        val issuerOrg = issuerInfo?.organization?.takeIf { it.isNotBlank() && it != issuerCn }

        val effectiveSignTime = pdfSignDateMillis ?: cryptoResult.cmsSigningTimeMillis
        val validFromMillis = cert?.notBefore?.time ?: cryptoResult.certHolder?.notBefore?.time
        val validToMillis = cert?.notAfter?.time ?: cryptoResult.certHolder?.notAfter?.time
        val isExpiredNow = validToMillis != null && System.currentTimeMillis() > validToMillis
        val serialHex = (cert?.serialNumber ?: cryptoResult.certHolder?.serialNumber)
            ?.toString(16)
            ?.uppercase(Locale.ROOT)

        val integrityOk = if (isLatestRevision) coversWholeDocument else true
        val overallValid = cryptoResult.verified && integrityOk

        val statusSummary = when {
            !cryptoResult.verified -> cryptoResult.errorMessage ?: "Cryptographic signature verification failed (document may be modified)."
            isLatestRevision && !coversWholeDocument -> "Document was modified after this signature was applied."
            !isLatestRevision && !coversWholeDocument -> "Signature valid for its signed revision (subsequent revision signed later)."
            else -> "Signature Valid (Document Unmodified)"
        }

        return PdfSignatureDetail(
            index = index,
            fieldName = fieldName,
            signerCommonName = signerCn,
            signerOrganization = signerOrg,
            issuerCommonName = issuerCn,
            issuerOrganization = issuerOrg,
            signedAtMillis = effectiveSignTime,
            validFromMillis = validFromMillis,
            validToMillis = validToMillis,
            subFilter = subFilter,
            reason = reason,
            location = location,
            serialNumberHex = serialHex,
            cryptographicValid = cryptoResult.verified,
            coversWholeDocument = coversWholeDocument,
            isLatestRevision = isLatestRevision,
            isCertificateExpiredNow = isExpiredNow,
            isValid = overallValid,
            statusSummary = statusSummary
        )
    }

    private data class CryptoVerificationResult(
        val verified: Boolean,
        val certificate: X509Certificate? = null,
        val certHolder: X509CertificateHolder? = null,
        val cmsSigningTimeMillis: Long? = null,
        val errorMessage: String? = null
    )

    private fun verifyCryptographicPayload(
        signature: PDSignature,
        subFilter: String,
        signedBytes: ByteArray,
        contentsBytes: ByteArray
    ): CryptoVerificationResult {
        return try {
            when {
                subFilter.equals("adbe.x509.rsa_sha1", ignoreCase = true) -> {
                    verifyX509RsaSha1(signature, signedBytes, contentsBytes)
                }
                subFilter.equals("adbe.pkcs7.sha1", ignoreCase = true) -> {
                    verifyPkcs7Sha1(signedBytes, contentsBytes)
                }
                subFilter.equals("ETSI.RFC3161", ignoreCase = true) -> {
                    verifyEncapsulatedCms(contentsBytes)
                }
                else -> {
                    // Covers adbe.pkcs7.detached, ETSI.CAdES.detached, and standard detached CMS
                    verifyCmsDetached(signedBytes, contentsBytes)
                }
            }
        } catch (t: Throwable) {
            CryptoVerificationResult(
                verified = false,
                errorMessage = "Cryptographic verification error: ${t.message ?: t.javaClass.simpleName}"
            )
        }
    }

    @Suppress("UNCHECKED_CAST")
    private fun verifyEncapsulatedCms(contentsBytes: ByteArray): CryptoVerificationResult {
        val cms = CMSSignedData(contentsBytes)
        val signer = cms.signerInfos.signers.firstOrNull()
            ?: return CryptoVerificationResult(false, errorMessage = "No SignerInfo entries found in timestamp signature.")
        val signingTime = extractCmsSigningTime(signer)
        val matches = cms.certificates.getMatches(signer.sid as Selector<X509CertificateHolder>)
        val certHolder = matches.firstOrNull() as? X509CertificateHolder
            ?: (cms.certificates.getMatches(null).firstOrNull() as? X509CertificateHolder)
            ?: return CryptoVerificationResult(false, cmsSigningTimeMillis = signingTime, errorMessage = "Timestamp certificate not embedded.")
        val x509Cert = JcaX509CertificateConverter().setProvider(bcProvider).getCertificate(certHolder)
        val verifier = JcaSimpleSignerInfoVerifierBuilder().setProvider(bcProvider).build(x509Cert)
        val verified = runCatching { signer.verify(verifier) }.getOrElse { false }
        return CryptoVerificationResult(
            verified = verified,
            certificate = x509Cert,
            certHolder = certHolder,
            cmsSigningTimeMillis = signingTime,
            errorMessage = if (verified) null else "Timestamp signature verification failed."
        )
    }

    @Suppress("UNCHECKED_CAST")
    private fun verifyCmsDetached(
        signedBytes: ByteArray,
        contentsBytes: ByteArray
    ): CryptoVerificationResult {
        val cms = CMSSignedData(CMSProcessableByteArray(signedBytes), contentsBytes)
        val signer = cms.signerInfos.signers.firstOrNull()
            ?: return CryptoVerificationResult(false, errorMessage = "No SignerInfo entries found in CMS signature.")

        val signingTime = extractCmsSigningTime(signer)
        val matches = cms.certificates.getMatches(signer.sid as Selector<X509CertificateHolder>)
        val certHolder = matches.firstOrNull() as? X509CertificateHolder
            ?: (cms.certificates.getMatches(null).firstOrNull() as? X509CertificateHolder)
            ?: return CryptoVerificationResult(
                verified = false,
                cmsSigningTimeMillis = signingTime,
                errorMessage = "Signer certificate not embedded in signature."
            )

        val x509Cert = JcaX509CertificateConverter()
            .setProvider(bcProvider)
            .getCertificate(certHolder)

        val verifier = JcaSimpleSignerInfoVerifierBuilder()
            .setProvider(bcProvider)
            .build(x509Cert)

        val verified = runCatching { signer.verify(verifier) }.getOrElse { false }
        return CryptoVerificationResult(
            verified = verified,
            certificate = x509Cert,
            certHolder = certHolder,
            cmsSigningTimeMillis = signingTime,
            errorMessage = if (verified) null else "Cryptographic digest or signature mismatch — document appears modified."
        )
    }

    @Suppress("UNCHECKED_CAST")
    private fun verifyPkcs7Sha1(
        signedBytes: ByteArray,
        contentsBytes: ByteArray
    ): CryptoVerificationResult {
        val cms = CMSSignedData(contentsBytes)
        val signer = cms.signerInfos.signers.firstOrNull()
            ?: return CryptoVerificationResult(false, errorMessage = "No SignerInfo found in PKCS#7 SHA-1 signature.")

        val signingTime = extractCmsSigningTime(signer)
        val matches = cms.certificates.getMatches(signer.sid as Selector<X509CertificateHolder>)
        val certHolder = matches.firstOrNull() as? X509CertificateHolder
            ?: (cms.certificates.getMatches(null).firstOrNull() as? X509CertificateHolder)
            ?: return CryptoVerificationResult(false, cmsSigningTimeMillis = signingTime, errorMessage = "Signer certificate missing.")

        val x509Cert = JcaX509CertificateConverter()
            .setProvider(bcProvider)
            .getCertificate(certHolder)

        val expectedHash = MessageDigest.getInstance("SHA-1").digest(signedBytes)
        val encapsulatedHash = cms.signedContent?.content as? ByteArray
        val digestMatches = encapsulatedHash != null && expectedHash.contentEquals(encapsulatedHash)

        val verifier = JcaSimpleSignerInfoVerifierBuilder()
            .setProvider(bcProvider)
            .build(x509Cert)
        val sigOk = runCatching { signer.verify(verifier) }.getOrElse { false }

        val verified = digestMatches && sigOk
        return CryptoVerificationResult(
            verified = verified,
            certificate = x509Cert,
            certHolder = certHolder,
            cmsSigningTimeMillis = signingTime,
            errorMessage = if (verified) null else "SHA-1 digest or PKCS#7 signature mismatch."
        )
    }

    private fun verifyX509RsaSha1(
        signature: PDSignature,
        signedBytes: ByteArray,
        contentsBytes: ByteArray
    ): CryptoVerificationResult {
        val certBase = signature.cosObject.getDictionaryObject(COSName.CERT)
        val certBytes = when (certBase) {
            is COSString -> certBase.bytes
            is COSArray -> (certBase.getObject(0) as? COSString)?.bytes
            else -> null
        } ?: return CryptoVerificationResult(false, errorMessage = "No X.509 certificate found in Cert entry.")

        val cf = CertificateFactory.getInstance("X.509", bcProvider)
        val x509Cert = cf.generateCertificate(ByteArrayInputStream(certBytes)) as? X509Certificate
            ?: return CryptoVerificationResult(false, errorMessage = "Failed to parse X.509 certificate.")

        val verifier = Signature.getInstance("SHA1withRSA", bcProvider)
        verifier.initVerify(x509Cert.publicKey)
        verifier.update(signedBytes)
        val verified = runCatching { verifier.verify(contentsBytes) }.getOrElse { false }

        return CryptoVerificationResult(
            verified = verified,
            certificate = x509Cert,
            errorMessage = if (verified) null else "RSA-SHA1 signature verification failed."
        )
    }

    private fun extractCmsSigningTime(signer: SignerInformation): Long? {
        return runCatching {
            val attr = signer.signedAttributes?.get(CMSAttributes.signingTime) ?: return null
            val obj = attr.attrValues?.getObjectAt(0)?.toASN1Primitive() ?: return null
            when (obj) {
                is ASN1UTCTime -> obj.date.time
                is ASN1GeneralizedTime -> obj.date.time
                else -> null
            }
        }.getOrNull()
    }

    private data class DnInfo(
        val commonName: String?,
        val organization: String?
    )

    private fun extractDnInfo(name: X500Name): DnInfo {
        fun firstValue(oid: ASN1ObjectIdentifier): String? {
            val rdns = name.getRDNs(oid)
            if (rdns.isNullOrEmpty()) return null
            val first = rdns[0].first ?: return null
            return IETFUtils.valueToString(first.value)?.trim()?.takeIf { it.isNotBlank() }
        }
        val cn = firstValue(BCStyle.CN)
            ?: firstValue(BCStyle.SURNAME)
            ?: firstValue(BCStyle.EmailAddress)
        val org = firstValue(BCStyle.O) ?: firstValue(BCStyle.OU)
        return DnInfo(commonName = cn, organization = org)
    }

    private fun readByteRange(
        file: File,
        off1: Long,
        len1: Long,
        off2: Long,
        len2: Long
    ): ByteArray {
        val total = (len1 + len2).toInt()
        val out = ByteArrayOutputStream(total.coerceAtLeast(0))
        RandomAccessFile(file, "r").use { raf ->
            copySlice(raf, off1, len1, out)
            copySlice(raf, off2, len2, out)
        }
        return out.toByteArray()
    }

    private fun copySlice(raf: RandomAccessFile, offset: Long, length: Long, out: ByteArrayOutputStream) {
        if (length <= 0L) return
        raf.seek(offset)
        val buf = ByteArray(8192)
        var remaining = length
        while (remaining > 0L) {
            val toRead = minOf(buf.size.toLong(), remaining).toInt()
            val read = raf.read(buf, 0, toRead)
            if (read <= 0) break
            out.write(buf, 0, read)
            remaining -= read
        }
    }

    private fun isOnlyTrailingWhitespaceAfter(file: File, coveredEnd: Long, fileLength: Long): Boolean {
        if (coveredEnd == fileLength) return true
        val trailingCount = fileLength - coveredEnd
        if (trailingCount <= 0L || trailingCount > 64L) return false
        return runCatching {
            RandomAccessFile(file, "r").use { raf ->
                raf.seek(coveredEnd)
                val buf = ByteArray(trailingCount.toInt())
                raf.readFully(buf)
                buf.all { b ->
                    val ch = b.toInt() and 0xFF
                    ch == 0x20 || ch == 0x09 || ch == 0x0A || ch == 0x0D || ch == 0x00
                }
            }
        }.getOrDefault(false)
    }

    private fun invalidDetail(
        index: Int,
        fieldName: String,
        signerName: String,
        signedAtMillis: Long?,
        subFilter: String,
        reason: String?,
        location: String?,
        isLatestRevision: Boolean,
        statusSummary: String
    ): PdfSignatureDetail = PdfSignatureDetail(
        index = index,
        fieldName = fieldName,
        signerCommonName = signerName,
        signerOrganization = null,
        issuerCommonName = "Unavailable",
        issuerOrganization = null,
        signedAtMillis = signedAtMillis,
        validFromMillis = null,
        validToMillis = null,
        subFilter = subFilter,
        reason = reason,
        location = location,
        serialNumberHex = null,
        cryptographicValid = false,
        coversWholeDocument = false,
        isLatestRevision = isLatestRevision,
        isCertificateExpiredNow = false,
        isValid = false,
        statusSummary = statusSummary
    )
}
