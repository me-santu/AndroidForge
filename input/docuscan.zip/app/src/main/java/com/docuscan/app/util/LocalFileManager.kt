package com.docuscan.app.util

import android.content.Context
import android.content.Intent
import android.net.Uri
import android.provider.OpenableColumns
import androidx.core.content.FileProvider
import com.docuscan.app.domain.model.CacheSummary
import com.docuscan.app.security.SecurityManager
import kotlinx.coroutines.CoroutineDispatcher
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.io.File
import java.io.FileInputStream
import java.io.FileOutputStream
import java.io.IOException
import java.util.zip.ZipEntry
import java.util.zip.ZipOutputStream

class LocalFileManager(
    private val context: Context,
    val ioDispatcher: CoroutineDispatcher = Dispatchers.IO
) {

    val scansDir: File
        get() = File(context.filesDir, "scans").apply { mkdirs() }

    val documentsDir: File
        get() = File(context.filesDir, "documents").apply { mkdirs() }

    val signaturesDir: File
        get() = File(context.filesDir, "signatures").apply { mkdirs() }

    val backupsDir: File
        get() = File(context.filesDir, "backups").apply { mkdirs() }

    val appCacheDir: File
        get() = context.cacheDir

    private fun sanitizeBaseName(baseTitle: String, fallback: String): String =
        baseTitle
            .trim()
            .replace(Regex("[^a-zA-Z0-9._-]"), "_")
            .ifBlank { fallback }
            .take(48)

    fun createUniqueFile(directory: File, baseTitle: String, extension: String, fallback: String): File {
        val cleanBase = sanitizeBaseName(baseTitle, fallback)
        val stamp = System.currentTimeMillis()
        var candidate = File(directory, "${cleanBase}_${stamp}.$extension")
        var counter = 1
        while (candidate.exists()) {
            candidate = File(directory, "${cleanBase}_${stamp}_$counter.$extension")
            counter++
        }
        return candidate
    }

    fun usableStorageBytes(): Long = runCatching { context.filesDir.usableSpace }.getOrDefault(0L)

    fun checkStorageAvailable(
        minimumRequiredBytes: Long = 2L * 1024L * 1024L,
        availableBytes: Long = usableStorageBytes()
    ): Result<Unit> {
        if (availableBytes in 1L until minimumRequiredBytes) {
            return Result.failure(
                IOException(
                    "Low device storage (${FormatUtils.formatBytes(availableBytes)} free). " +
                        "Please free up space or empty Recycle Bin before creating files."
                )
            )
        }
        return Result.success(Unit)
    }

    suspend fun copyUriToScanFile(uri: Uri, pageIndex: Int? = null): File = withContext(ioDispatcher) {
        val suffix = if (pageIndex != null) "p${pageIndex + 1}" else "${(100..999).random()}"
        val target = createUniqueFile(scansDir, "scan_$suffix", "jpg", "scan")
        context.contentResolver.openInputStream(uri)?.use { input ->
            FileOutputStream(target).use { output ->
                input.copyTo(output)
            }
        } ?: error("Unable to open selected media stream")
        if (target.length() == 0L) {
            target.delete()
            error("Scanned image stream was empty")
        }
        target
    }

    suspend fun copyUriToPdfFile(uri: Uri, baseTitle: String): File = withContext(ioDispatcher) {
        val target = createPdfFile(baseTitle)
        context.contentResolver.openInputStream(uri)?.use { input ->
            FileOutputStream(target).use { output ->
                input.copyTo(output)
            }
        } ?: error("Unable to open generated PDF stream")
        if (target.length() == 0L) {
            target.delete()
            error("Generated PDF stream was empty")
        }
        target
    }

    suspend fun copyFileToContentUri(
        sourceFilePath: String,
        destinationUri: Uri,
        securityManager: SecurityManager? = null
    ): Long = withContext(ioDispatcher) {
        val source = File(sourceFilePath)
        require(source.exists() && source.length() > 0L) { "Source file does not exist on device." }
        if (securityManager != null && securityManager.isVaultEncryptedFile(source)) {
            val plain = securityManager.readFilePlainBytes(source)
            context.contentResolver.openOutputStream(destinationUri)?.use { output ->
                output.write(plain)
            } ?: error("Unable to open destination URI for writing.")
            val len = plain.size.toLong()
            plain.fill(0)
            len
        } else {
            context.contentResolver.openOutputStream(destinationUri)?.use { output ->
                FileInputStream(source).use { input ->
                    input.copyTo(output)
                }
            } ?: error("Unable to open destination URI for writing.")
            source.length()
        }
    }

    suspend fun exportZipArchiveToUri(
        jsonEntries: List<Pair<String, ByteArray>>,
        fileEntries: List<Pair<String, File>>,
        destinationUri: Uri,
        securityManager: SecurityManager? = null
    ): Long = withContext(ioDispatcher) {
        var totalWritten = 0L
        context.contentResolver.openOutputStream(destinationUri)?.use { out ->
            ZipOutputStream(out).use { zip ->
                jsonEntries.forEach { (entryName, bytes) ->
                    zip.putNextEntry(ZipEntry(entryName))
                    zip.write(bytes)
                    zip.closeEntry()
                    totalWritten += bytes.size
                }
                fileEntries.forEach { (entryName, file) ->
                    if (file.exists() && file.length() > 0L) {
                        zip.putNextEntry(ZipEntry(entryName))
                        if (securityManager != null && securityManager.isVaultEncryptedFile(file)) {
                            val plain = securityManager.readFilePlainBytes(file)
                            zip.write(plain)
                            totalWritten += plain.size
                            plain.fill(0)
                        } else {
                            FileInputStream(file).use { input ->
                                totalWritten += input.copyTo(zip)
                            }
                        }
                        zip.closeEntry()
                    }
                }
            }
        } ?: error("Unable to open backup destination URI.")
        totalWritten
    }

    fun resolveDisplayName(uri: Uri): String? {
        runCatching {
            context.contentResolver.query(uri, arrayOf(OpenableColumns.DISPLAY_NAME), null, null, null)
                ?.use { cursor ->
                    if (cursor.moveToFirst()) {
                        val idx = cursor.getColumnIndex(OpenableColumns.DISPLAY_NAME)
                        if (idx >= 0) return cursor.getString(idx)
                    }
                }
        }
        return uri.lastPathSegment
    }

    fun createTempCameraFile(): File =
        createUniqueFile(scansDir, "cam", "jpg", "cam")

    fun createPdfFile(baseTitle: String): File =
        createUniqueFile(documentsDir, baseTitle, "pdf", "DocuScan")

    fun createDocxFile(baseTitle: String): File =
        createUniqueFile(documentsDir, baseTitle, "docx", "DocuScan_Word")

    fun createZipFile(baseTitle: String): File =
        createUniqueFile(appCacheDir, baseTitle, "zip", "DocuScan_Export")

    fun createImageDocumentFile(baseTitle: String): File =
        createUniqueFile(documentsDir, baseTitle, "jpg", "DocuScan_Page")

    fun createImageExportFile(baseTitle: String, extension: String): File =
        createUniqueFile(documentsDir, baseTitle, extension, "DocuScan_Page")

    fun createTextDocumentFile(baseTitle: String): File =
        createUniqueFile(documentsDir, baseTitle, "txt", "DocuScan_OCR")

    suspend fun duplicateLocalFile(
        sourceFilePath: String,
        newTitle: String,
        extension: String = "pdf",
        securityManager: SecurityManager? = null
    ): File = withContext(ioDispatcher) {
        val source = File(sourceFilePath)
        require(source.exists() && source.length() > 0L) { "Source file does not exist on device." }
        val target = createUniqueFile(documentsDir, newTitle, extension, "DocuScan_Copy")
        if (securityManager != null && securityManager.isVaultEncryptedFile(source)) {
            val plain = securityManager.readFilePlainBytes(source)
            FileOutputStream(target).use { it.write(plain) }
            plain.fill(0)
            securityManager.sealFileInPlace(target)
        } else {
            FileInputStream(source).use { input ->
                FileOutputStream(target).use { output ->
                    input.copyTo(output)
                }
            }
        }
        target
    }

    suspend fun createZipFromFiles(files: List<File>, outputZip: File): File = withContext(ioDispatcher) {
        ZipOutputStream(FileOutputStream(outputZip)).use { zip ->
            val usedNames = mutableSetOf<String>()
            files.filter { it.exists() && it.length() > 0L }.forEach { file ->
                var entryName = file.name
                var idx = 1
                while (!usedNames.add(entryName)) {
                    entryName = "${file.nameWithoutExtension}_$idx.${file.extension}"
                    idx++
                }
                zip.putNextEntry(ZipEntry(entryName))
                FileInputStream(file).use { input -> input.copyTo(zip) }
                zip.closeEntry()
            }
        }
        outputZip
    }

    suspend fun exportFilesToSafTree(
        treeUri: Uri,
        files: List<File>,
        mimeType: String
    ): Int = withContext(ioDispatcher) {
        val treeDocId = android.provider.DocumentsContract.getTreeDocumentId(treeUri)
        val parentDocUri = android.provider.DocumentsContract.buildDocumentUriUsingTree(treeUri, treeDocId)
        var exportedCount = 0
        files.filter { it.exists() && it.length() > 0L }.forEach { file ->
            val createdUri = android.provider.DocumentsContract.createDocument(
                context.contentResolver,
                parentDocUri,
                mimeType,
                file.name
            ) ?: error("Unable to create ${file.name} in selected folder.")
            context.contentResolver.openOutputStream(createdUri)?.use { out ->
                FileInputStream(file).use { input -> input.copyTo(out) }
            } ?: error("Unable to write ${file.name} to selected folder.")
            exportedCount++
        }
        exportedCount
    }

    suspend fun readTextFromUri(uri: Uri): String = withContext(ioDispatcher) {
        context.contentResolver.openInputStream(uri)?.bufferedReader(Charsets.UTF_8)?.use {
            it.readText()
        } ?: error("Unable to read text from selected file.")
    }

    suspend fun writeTextFile(baseTitle: String, text: String): File = withContext(ioDispatcher) {
        val file = createTextDocumentFile(baseTitle)
        file.writeText(text, Charsets.UTF_8)
        file
    }

    suspend fun writeTextToUri(text: String, destinationUri: Uri): Long = withContext(ioDispatcher) {
        val bytes = text.toByteArray(Charsets.UTF_8)
        context.contentResolver.openOutputStream(destinationUri)?.use { output ->
            output.write(bytes)
        } ?: error("Unable to open destination file for text export.")
        bytes.size.toLong()
    }

    fun createSignatureFile(): File =
        createUniqueFile(signaturesDir, "sig", "png", "sig")

    fun createBackupManifestFile(): File =
        createUniqueFile(backupsDir, "docuscan_backup", "json", "docuscan_backup")

    fun deleteFileIfExists(path: String?) {
        if (path.isNullOrBlank()) return
        runCatching {
            val file = File(path)
            if (file.exists()) file.delete()
        }
    }

    fun shareFile(
        filePath: String,
        mimeType: String,
        chooserTitle: String,
        securityManager: SecurityManager? = null
    ) {
        val source = File(filePath)
        if (!source.exists()) return
        val fileToShare = if (securityManager != null && securityManager.isVaultEncryptedFile(source)) {
            val ext = source.extension.ifBlank { "pdf" }
            val tempDir = File(appCacheDir, "shared_unsealed").apply { mkdirs() }
            val tempOut = File(tempDir, "${source.nameWithoutExtension}.$ext")
            val plain = securityManager.readFilePlainBytes(source)
            tempOut.writeBytes(plain)
            plain.fill(0)
            tempOut
        } else {
            source
        }
        val contentUri = FileProvider.getUriForFile(
            context,
            "${context.packageName}.fileprovider",
            fileToShare
        )
        val shareIntent = Intent(Intent.ACTION_SEND).apply {
            type = mimeType
            putExtra(Intent.EXTRA_STREAM, contentUri)
            addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
        }
        val chooser = Intent.createChooser(shareIntent, chooserTitle).apply {
            addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        }
        context.startActivity(chooser)
    }

    private fun dirSize(dir: File): Long =
        dir.listFiles()?.sumOf { if (it.isDirectory) dirSize(it) else it.length() } ?: 0L

    fun calculateAppStorageBytes(): Long =
        dirSize(documentsDir) + dirSize(scansDir) + dirSize(signaturesDir) + dirSize(backupsDir)

    fun computeCacheSummary(referencedPaths: Set<String>): CacheSummary {
        val orphanedScans = scansDir.listFiles()
            ?.filter { it.isFile && it.absolutePath !in referencedPaths }
            ?.sumOf { it.length() } ?: 0L
        return CacheSummary(
            cacheDirBytes = dirSize(appCacheDir),
            orphanedTempScanBytes = orphanedScans,
            documentsBytes = dirSize(documentsDir),
            signaturesBytes = dirSize(signaturesDir),
            backupsBytes = dirSize(backupsDir),
            usableSpaceBytes = usableStorageBytes(),
            saveDirectoryPath = documentsDir.absolutePath
        )
    }

    suspend fun clearTemporaryCache(referencedPaths: Set<String>): Long = withContext(ioDispatcher) {
        var freed = 0L
        appCacheDir.listFiles()?.forEach { child ->
            val size = if (child.isDirectory) dirSize(child) else child.length()
            if (child.deleteRecursively()) {
                freed += size
            }
        }
        scansDir.listFiles()?.forEach { file ->
            if (file.isFile && file.absolutePath !in referencedPaths) {
                val size = file.length()
                if (file.delete()) {
                    freed += size
                }
            }
        }
        freed
    }
}
