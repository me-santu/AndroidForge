package com.docuscan.app.ui.screens

import android.graphics.Bitmap
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.WindowInsetsSides
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.only
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.safeDrawing
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.rememberScrollState
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FilterChipDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.minimumInteractiveComponentSize
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.unit.dp
import com.docuscan.app.domain.model.IdSideScanState
import com.docuscan.app.domain.model.NormalizedCropRect
import com.docuscan.app.domain.model.ScanFilter
import com.docuscan.app.domain.model.ScanPage
import com.docuscan.app.scanner.BitmapFilterEngine
import com.docuscan.app.ui.components.DocuScanTopBar
import com.docuscan.app.ui.components.EmptyStateView
import com.docuscan.app.ui.components.LoadingStateView
import com.docuscan.app.ui.components.PhaseStatusChip
import com.docuscan.app.ui.icons.LucideIcons
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

@Composable
fun ImageEditorScreen(
    page: ScanPage?,
    totalPages: Int = 1,
    onSetFilter: (String, ScanFilter) -> Unit,
    onApplyFilterToAll: ((ScanFilter) -> Unit)? = null,
    onCrop: (String, NormalizedCropRect) -> Unit = { _, _ -> },
    onRotate: (String, Int) -> Unit,
    onDone: () -> Unit,
    onBack: () -> Unit
) {
    var previewBitmap by remember { mutableStateOf<Bitmap?>(null) }
    var isProcessing by remember { mutableStateOf(false) }
    var qualityLabel by remember { mutableStateOf("Ready") }
    var showCropStudio by remember { mutableStateOf(false) }

    LaunchedEffect(page?.sourcePath, page?.cropRect, page?.filter, page?.rotationDegrees) {
        if (page == null) return@LaunchedEffect
        isProcessing = true
        val (rendered, qualityStatus) = withContext(Dispatchers.IO) {
            val base = BitmapFilterEngine.decodeSampledBitmap(page.sourcePath, 1600)
                ?: return@withContext null to "Unavailable"
            val processed = BitmapFilterEngine.cropAndTransform(base, page.cropRect, page.rotationDegrees, page.filter)
            val assessment = BitmapFilterEngine.assessImageQuality(processed)
            val label = when {
                assessment.isBlankOrUniform -> "Blank Frame"
                assessment.isLikelyBlurry -> "Soft Focus"
                else -> "Crisp · ${page.filter.label}"
            }
            processed to label
        }
        previewBitmap = rendered
        qualityLabel = qualityStatus
        isProcessing = false
    }

    Scaffold(
        modifier = Modifier.fillMaxSize(),
        containerColor = MaterialTheme.colorScheme.background,
        contentWindowInsets = WindowInsets.safeDrawing.only(
            WindowInsetsSides.Bottom + WindowInsetsSides.Horizontal
        ),
        topBar = {
            DocuScanTopBar(
                title = "Image Editor",
                subtitle = page?.let { "${it.filter.label} · ${it.rotationDegrees}°" },
                onBack = onBack,
                actions = {
                    PhaseStatusChip(
                        text = qualityLabel,
                        highlighted = qualityLabel.startsWith("Crisp"),
                        modifier = Modifier.padding(end = 12.dp)
                    )
                }
            )
        }
    ) { innerPadding ->
        if (page == null) {
            EmptyStateView(
                title = "No page selected",
                subtitle = "Select or capture a page first to edit filters, crop, and rotation.",
                actionLabel = "Go Back",
                onAction = onBack,
                modifier = Modifier.padding(innerPadding)
            )
            return@Scaffold
        }

        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
                .padding(horizontal = 16.dp, vertical = 12.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            // Canvas Preview
            Box(
                modifier = Modifier
                    .weight(1f)
                    .fillMaxWidth()
                    .clip(MaterialTheme.shapes.large)
                    .background(MaterialTheme.colorScheme.surface)
                    .border(1.dp, MaterialTheme.colorScheme.outline, MaterialTheme.shapes.large),
                contentAlignment = Alignment.Center
            ) {
                val bmp = previewBitmap
                when {
                    isProcessing && bmp == null -> LoadingStateView("Applying filter...")
                    bmp != null -> {
                        Image(
                            bitmap = bmp.asImageBitmap(),
                            contentDescription = "Edited scan preview",
                            contentScale = ContentScale.Fit,
                            modifier = Modifier
                                .fillMaxSize()
                                .padding(12.dp)
                        )
                    }
                    else -> {
                        EmptyStateView(
                            title = "Preview unavailable",
                            subtitle = "Unable to decode selected image file."
                        )
                    }
                }
            }

            // Filter Selector + Apply to All Pages
            Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = "Enhancement Filter",
                        style = MaterialTheme.typography.titleSmall
                    )
                    if (onApplyFilterToAll != null && totalPages > 1) {
                        TextButton(
                            onClick = { onApplyFilterToAll(page.filter) },
                            modifier = Modifier.testTag("editor_apply_filter_all_btn")
                        ) {
                            Icon(
                                LucideIcons.Sparkles,
                                contentDescription = null,
                                tint = MaterialTheme.colorScheme.primary,
                                modifier = Modifier.size(15.dp)
                            )
                            Spacer(modifier = Modifier.size(4.dp))
                            Text("Apply to All ($totalPages)")
                        }
                    }
                }
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .horizontalScroll(rememberScrollState()),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    ScanFilter.primaryFilters.forEach { filter ->
                        val selected = page.filter == filter
                        FilterChip(
                            selected = selected,
                            onClick = { onSetFilter(page.id, filter) },
                            label = { Text(filter.label) },
                            colors = FilterChipDefaults.filterChipColors(
                                selectedContainerColor = MaterialTheme.colorScheme.primary,
                                selectedLabelColor = MaterialTheme.colorScheme.onPrimary
                            ),
                            modifier = Modifier.testTag("filter_${filter.name.lowercase()}")
                        )
                    }
                }
            }

            // Bottom Action Bar — cleanly lifted above system navigation bar
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .navigationBarsPadding()
                    .padding(top = 6.dp, bottom = 12.dp),
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    OutlinedButton(
                        onClick = { showCropStudio = true },
                        modifier = Modifier
                            .weight(1f)
                            .minimumInteractiveComponentSize()
                            .testTag("editor_crop_btn")
                    ) {
                        Icon(
                            imageVector = LucideIcons.Crop,
                            contentDescription = "Crop page",
                            modifier = Modifier.size(16.dp)
                        )
                        Spacer(modifier = Modifier.size(4.dp))
                        Text("Crop", maxLines = 1)
                    }

                    OutlinedButton(
                        onClick = { onRotate(page.id, -90) },
                        modifier = Modifier
                            .weight(1f)
                            .minimumInteractiveComponentSize()
                            .testTag("editor_rotate_left")
                    ) {
                        Icon(
                            imageVector = LucideIcons.RotateCcw,
                            contentDescription = "Rotate left",
                            modifier = Modifier.size(16.dp)
                        )
                        Spacer(modifier = Modifier.size(4.dp))
                        Text("-90°", maxLines = 1)
                    }

                    OutlinedButton(
                        onClick = { onRotate(page.id, 90) },
                        modifier = Modifier
                            .weight(1f)
                            .minimumInteractiveComponentSize()
                            .testTag("editor_rotate_right")
                    ) {
                        Icon(
                            imageVector = LucideIcons.RotateCw,
                            contentDescription = "Rotate right",
                            modifier = Modifier.size(16.dp)
                        )
                        Spacer(modifier = Modifier.size(4.dp))
                        Text("+90°", maxLines = 1)
                    }
                }

                Button(
                    onClick = onDone,
                    colors = ButtonDefaults.buttonColors(
                        containerColor = MaterialTheme.colorScheme.primary,
                        contentColor = MaterialTheme.colorScheme.onPrimary
                    ),
                    shape = MaterialTheme.shapes.medium,
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(52.dp)
                        .testTag("editor_done_btn")
                ) {
                    Icon(
                        imageVector = LucideIcons.Check,
                        contentDescription = null,
                        modifier = Modifier.size(18.dp)
                    )
                    Spacer(modifier = Modifier.size(8.dp))
                    Text("Continue to Page Manager")
                }
            }
        }
    }

    if (showCropStudio && page != null) {
        IdCardCropStudioDialog(
            title = "Crop Scan Page",
            sideState = IdSideScanState(
                imagePath = page.sourcePath,
                cropRect = page.cropRect,
                filter = page.filter,
                rotationDegrees = page.rotationDegrees
            ),
            aspectRatio = 0.707f,
            onRotate90 = { onRotate(page.id, 90) },
            onDismiss = { showCropStudio = false },
            onApplyCrop = { newRect ->
                onCrop(page.id, newRect)
                showCropStudio = false
            }
        )
    }
}
