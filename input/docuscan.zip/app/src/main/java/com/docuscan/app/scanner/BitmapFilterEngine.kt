package com.docuscan.app.scanner

import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Canvas
import android.graphics.ColorMatrix
import android.graphics.ColorMatrixColorFilter
import android.graphics.Matrix
import android.graphics.Paint
import android.media.ExifInterface
import com.docuscan.app.domain.model.NormalizedCropRect
import com.docuscan.app.domain.model.ScanFilter
import java.io.File
import java.io.FileOutputStream
import kotlin.math.abs
import kotlin.math.max
import kotlin.math.min
import kotlin.math.roundToInt

data class ImageQualityReport(
    val isBlankOrUniform: Boolean,
    val isLikelyBlurry: Boolean,
    val sharpnessScore: Double
)

object BitmapFilterEngine {

    /**
     * Hard upper bound for decoded camera/gallery images before filters or OCR
     * to prevent OutOfMemoryError on low-RAM Android devices.
     */
    const val MAX_SAFE_IMAGE_DIMENSION: Int = 2560

    /**
     * Crisp scan processing cap for Magic Color (Pro Crisp) and high-res page editing.
     */
    const val PRO_CRISP_MAX_DIMENSION: Int = 2400

    fun decodeSampledBitmap(
        filePath: String,
        maxDimension: Int = MAX_SAFE_IMAGE_DIMENSION
    ): Bitmap? {
        val safeMaxDim = maxDimension.coerceIn(256, MAX_SAFE_IMAGE_DIMENSION)
        val options = BitmapFactory.Options().apply { inJustDecodeBounds = true }
        BitmapFactory.decodeFile(filePath, options)
        val rawW = options.outWidth
        val rawH = options.outHeight
        if (rawW <= 0 || rawH <= 0) return null

        var inSampleSize = 1
        val largest = max(rawW, rawH)
        while (largest / inSampleSize > safeMaxDim) {
            inSampleSize *= 2
        }

        val decodeOptions = BitmapFactory.Options().apply {
            this.inSampleSize = inSampleSize
            inPreferredConfig = Bitmap.Config.ARGB_8888
        }
        val decoded = BitmapFactory.decodeFile(filePath, decodeOptions) ?: return null
        val oriented = applyExifOrientation(decoded, filePath)
        return ensureWithinMaxDimension(oriented, safeMaxDim, recycleSourceIfScaled = true)
    }

    /**
     * Ensures [bitmap] never exceeds [maxDimension] on its longest edge.
     * If downscaling occurs and [recycleSourceIfScaled] is true, the original bitmap is recycled immediately.
     */
    fun ensureWithinMaxDimension(
        bitmap: Bitmap,
        maxDimension: Int = MAX_SAFE_IMAGE_DIMENSION,
        recycleSourceIfScaled: Boolean = false
    ): Bitmap {
        val safeMaxDim = maxDimension.coerceIn(256, MAX_SAFE_IMAGE_DIMENSION)
        val largest = max(bitmap.width, bitmap.height)
        if (largest <= safeMaxDim || bitmap.width <= 0 || bitmap.height <= 0) {
            return bitmap
        }
        val scale = safeMaxDim.toFloat() / largest.toFloat()
        val targetW = (bitmap.width * scale).roundToInt().coerceAtLeast(1)
        val targetH = (bitmap.height * scale).roundToInt().coerceAtLeast(1)
        return try {
            val scaled = Bitmap.createScaledBitmap(bitmap, targetW, targetH, true)
            if (recycleSourceIfScaled && scaled !== bitmap && !bitmap.isRecycled) {
                bitmap.recycle()
            }
            scaled
        } catch (_: OutOfMemoryError) {
            bitmap
        }
    }

    /**
     * Prepares a high-contrast grayscale bitmap (100% grayscale + 140% contrast)
     * optimized for Tesseract OCR on Bengali matras and conjunct glyphs.
     * Always returns a newly allocated Bitmap; callers must recycle it in a finally block.
     */
    fun prepareForTesseractOcr(
        source: Bitmap,
        rotationDegrees: Int = 0
    ): Bitmap {
        val normalizedRotation = ((rotationDegrees % 360) + 360) % 360
        var working: Bitmap = source
        var ownsWorking = false
        try {
            if (normalizedRotation != 0) {
                val matrix = Matrix().apply { postRotate(normalizedRotation.toFloat()) }
                val rotated = Bitmap.createBitmap(working, 0, 0, working.width, working.height, matrix, true)
                working = rotated
                ownsWorking = rotated !== source
            }

            val capped = ensureWithinMaxDimension(
                bitmap = working,
                maxDimension = MAX_SAFE_IMAGE_DIMENSION,
                recycleSourceIfScaled = ownsWorking
            )
            if (capped !== working) {
                working = capped
                ownsWorking = true
            }

            val output = Bitmap.createBitmap(working.width, working.height, Bitmap.Config.ARGB_8888)
            val canvas = Canvas(output)
            val paint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
                val contrast = 1.40f
                val translate = (-0.5f * contrast + 0.5f) * 255f
                val colorMatrix = ColorMatrix().apply {
                    setSaturation(0f)
                    postConcat(
                        ColorMatrix(
                            floatArrayOf(
                                contrast, 0f, 0f, 0f, translate,
                                0f, contrast, 0f, 0f, translate,
                                0f, 0f, contrast, 0f, translate,
                                0f, 0f, 0f, 1f, 0f
                            )
                        )
                    )
                }
                colorFilter = ColorMatrixColorFilter(colorMatrix)
            }
            canvas.drawBitmap(working, 0f, 0f, paint)
            return output
        } finally {
            if (ownsWorking && working !== source && !working.isRecycled) {
                working.recycle()
            }
        }
    }

    private fun applyExifOrientation(bitmap: Bitmap, filePath: String): Bitmap {
        val orientation = runCatching {
            ExifInterface(filePath).getAttributeInt(
                ExifInterface.TAG_ORIENTATION,
                ExifInterface.ORIENTATION_NORMAL
            )
        }.getOrDefault(ExifInterface.ORIENTATION_NORMAL)

        val matrix = Matrix()
        when (orientation) {
            ExifInterface.ORIENTATION_ROTATE_90 -> matrix.postRotate(90f)
            ExifInterface.ORIENTATION_ROTATE_180 -> matrix.postRotate(180f)
            ExifInterface.ORIENTATION_ROTATE_270 -> matrix.postRotate(270f)
            ExifInterface.ORIENTATION_FLIP_HORIZONTAL -> matrix.postScale(-1f, 1f)
            ExifInterface.ORIENTATION_FLIP_VERTICAL -> matrix.postScale(1f, -1f)
            ExifInterface.ORIENTATION_TRANSPOSE -> {
                matrix.postRotate(90f)
                matrix.postScale(-1f, 1f)
            }
            ExifInterface.ORIENTATION_TRANSVERSE -> {
                matrix.postRotate(270f)
                matrix.postScale(-1f, 1f)
            }
            else -> return bitmap
        }

        return runCatching {
            val oriented = Bitmap.createBitmap(bitmap, 0, 0, bitmap.width, bitmap.height, matrix, true)
            if (oriented !== bitmap && !bitmap.isRecycled) {
                bitmap.recycle()
            }
            oriented
        }.getOrDefault(bitmap)
    }

    fun computeCenteredAspectCrop(
        imageWidth: Int,
        imageHeight: Int,
        targetAspectRatio: Float,
        fillFraction: Float = 0.88f
    ): NormalizedCropRect {
        if (imageWidth <= 0 || imageHeight <= 0 || targetAspectRatio <= 0f) {
            return NormalizedCropRect(0.06f, 0.12f, 0.94f, 0.88f)
        }
        val safeFill = fillFraction.coerceIn(0.30f, 0.98f)
        val imageAspect = imageWidth.toFloat() / imageHeight.toFloat()
        val normWidth: Float
        val normHeight: Float
        if (imageAspect >= targetAspectRatio) {
            normHeight = safeFill
            normWidth = (normHeight * targetAspectRatio / imageAspect).coerceIn(0.16f, safeFill)
        } else {
            normWidth = safeFill
            normHeight = (normWidth * imageAspect / targetAspectRatio).coerceIn(0.16f, safeFill)
        }
        val left = ((1f - normWidth) / 2f).coerceIn(0f, 0.84f)
        val top = ((1f - normHeight) / 2f).coerceIn(0f, 0.84f)
        return NormalizedCropRect(
            left = left,
            top = top,
            right = (left + normWidth).coerceIn(left + 0.14f, 1f),
            bottom = (top + normHeight).coerceIn(top + 0.14f, 1f)
        ).sanitized()
    }

    fun applyTransformAndFilter(
        source: Bitmap,
        rotationDegrees: Int,
        filter: ScanFilter
    ): Bitmap = cropAndTransform(
        source = source,
        cropRect = NormalizedCropRect(),
        rotationDegrees = rotationDegrees,
        filter = filter
    )

    fun cropAndTransform(
        source: Bitmap,
        cropRect: NormalizedCropRect,
        rotationDegrees: Int,
        filter: ScanFilter
    ): Bitmap {
        var current: Bitmap = ensureWithinMaxDimension(
            bitmap = source,
            maxDimension = MAX_SAFE_IMAGE_DIMENSION,
            recycleSourceIfScaled = false
        )

        try {
            if (rotationDegrees % 360 != 0) {
                val matrix = Matrix().apply { postRotate((rotationDegrees % 360).toFloat()) }
                val rotated = Bitmap.createBitmap(current, 0, 0, current.width, current.height, matrix, true)
                if (current !== source && rotated !== current && !current.isRecycled) {
                    current.recycle()
                }
                current = rotated
            }

            val cleanCrop = cropRect.sanitized()
            if (!cleanCrop.isFullFrame && current.width >= 20 && current.height >= 20) {
                val cropX = (cleanCrop.left * current.width).roundToInt().coerceIn(0, current.width - 10)
                val cropY = (cleanCrop.top * current.height).roundToInt().coerceIn(0, current.height - 10)
                val cropW = ((cleanCrop.right - cleanCrop.left) * current.width).roundToInt()
                    .coerceIn(10, current.width - cropX)
                val cropH = ((cleanCrop.bottom - cleanCrop.top) * current.height).roundToInt()
                    .coerceIn(10, current.height - cropY)
                val cropped = Bitmap.createBitmap(current, cropX, cropY, cropW, cropH)
                if (current !== source && cropped !== current && !current.isRecycled) {
                    current.recycle()
                }
                current = cropped
            }

            if (filter == ScanFilter.ORIGINAL) {
                return current
            }

            if (filter == ScanFilter.MAGIC_COLOR) {
                val capped = ensureWithinMaxDimension(
                    bitmap = current,
                    maxDimension = PRO_CRISP_MAX_DIMENSION,
                    recycleSourceIfScaled = current !== source
                )
                if (capped !== current) {
                    current = capped
                }
                val magicResult = applyMagicColorProCrisp(current)
                if (current !== source && !current.isRecycled) {
                    current.recycle()
                }
                return magicResult
            }

            val filtered = Bitmap.createBitmap(current.width, current.height, Bitmap.Config.ARGB_8888)
            try {
                val canvas = Canvas(filtered)
                val paint = Paint(Paint.ANTI_ALIAS_FLAG)
                val colorMatrix = when (filter) {
                    ScanFilter.ORIGINAL, ScanFilter.MAGIC_COLOR -> ColorMatrix()
                    ScanFilter.GRAYSCALE -> {
                        ColorMatrix().apply {
                            setSaturation(0f)
                            val contrast = 1.18f
                            val translate = (-0.5f * contrast + 0.5f) * 255f + 10f
                            postConcat(
                                ColorMatrix(
                                    floatArrayOf(
                                        contrast, 0f, 0f, 0f, translate,
                                        0f, contrast, 0f, 0f, translate,
                                        0f, 0f, contrast, 0f, translate,
                                        0f, 0f, 0f, 1f, 0f
                                    )
                                )
                            )
                        }
                    }
                    ScanFilter.DOCUMENT_BW -> {
                        ColorMatrix().apply {
                            setSaturation(0f)
                            val contrast = 1.55f
                            val translate = (-0.5f * contrast + 0.5f) * 255f + 12f
                            postConcat(
                                ColorMatrix(
                                    floatArrayOf(
                                        contrast, 0f, 0f, 0f, translate,
                                        0f, contrast, 0f, 0f, translate,
                                        0f, 0f, contrast, 0f, translate,
                                        0f, 0f, 0f, 1f, 0f
                                    )
                                )
                            )
                        }
                    }
                    ScanFilter.HIGH_CONTRAST -> {
                        val contrast = 1.28f
                        val translate = (-0.5f * contrast + 0.5f) * 255f + 12f
                        ColorMatrix(
                            floatArrayOf(
                                contrast, 0f, 0f, 0f, translate,
                                0f, contrast, 0f, 0f, translate,
                                0f, 0f, contrast, 0f, translate,
                                0f, 0f, 0f, 1f, 0f
                            )
                        )
                    }
                    ScanFilter.WARM_PAPER -> {
                        ColorMatrix(
                            floatArrayOf(
                                1.06f, 0f, 0f, 0f, 8f,
                                0f, 1.02f, 0f, 0f, 4f,
                                0f, 0f, 0.90f, 0f, -4f,
                                0f, 0f, 0f, 1f, 0f
                            )
                        )
                    }
                }
                paint.colorFilter = ColorMatrixColorFilter(colorMatrix)
                canvas.drawBitmap(current, 0f, 0f, paint)
            } catch (t: Throwable) {
                if (!filtered.isRecycled) filtered.recycle()
                throw t
            }

            if (current !== source && !current.isRecycled) {
                current.recycle()
            }
            return filtered
        } catch (t: Throwable) {
            if (current !== source && !current.isRecycled) {
                current.recycle()
            }
            throw t
        }
    }

    /**
     * Oken-style "Magic Color (Pro Crisp)" enhancement pipeline:
     * 1. Pushes shadowed/off-white low-saturation paper backgrounds cleanly toward pure white (#FFFFFF).
     * 2. Preserves and gently enhances vivid colored elements (blue ink stamps, handwritten signatures, seals).
     * 3. Boosts contrast ~1.25x so black text and QR codes stay crisp.
     * 4. Applies a 3x3 edge-sharpening convolution kernel for razor-sharp characters.
     */
    fun applyMagicColorProCrisp(source: Bitmap): Bitmap {
        val w = source.width
        val h = source.height
        if (w <= 0 || h <= 0) return source
        val total = w * h
        val srcPixels = IntArray(total)
        val stagePixels = IntArray(total)
        source.getPixels(srcPixels, 0, w, 0, 0, w, h)

        val contrast = 1.25f
        for (i in 0 until total) {
            val px = srcPixels[i]
            val a = (px ushr 24) and 0xFF
            val r0 = (px shr 16) and 0xFF
            val g0 = (px shr 8) and 0xFF
            val b0 = px and 0xFF

            val maxC = max(r0, max(g0, b0))
            val minC = min(r0, min(g0, b0))
            val chroma = maxC - minC
            val sat = if (maxC > 0) chroma.toFloat() / maxC.toFloat() else 0f
            val luma = 0.299f * r0 + 0.587f * g0 + 0.114f * b0

            var rf: Float
            var gf: Float
            var bf: Float

            if (sat < 0.22f && luma >= 145f) {
                // Smoothly lift shadowed/off-white paper background cleanly toward pure white (#FFFFFF)
                val t = ((luma - 145f) / 62f).coerceIn(0f, 1f)
                val smooth = t * t * (3f - 2f * t)
                val liftedR = ((r0 - 128f) * contrast + 134f).coerceIn(0f, 255f)
                val liftedG = ((g0 - 128f) * contrast + 134f).coerceIn(0f, 255f)
                val liftedB = ((b0 - 128f) * contrast + 134f).coerceIn(0f, 255f)
                rf = liftedR + (255f - liftedR) * smooth
                gf = liftedG + (255f - liftedG) * smooth
                bf = liftedB + (255f - liftedB) * smooth
            } else {
                // Crisp 1.25x contrast boost for text, QR codes, and ink
                rf = ((r0 - 128f) * contrast + 132f).coerceIn(0f, 255f)
                gf = ((g0 - 128f) * contrast + 132f).coerceIn(0f, 255f)
                bf = ((b0 - 128f) * contrast + 132f).coerceIn(0f, 255f)

                // Preserve & subtly boost vivid ink stamps and signatures
                if (sat >= 0.16f && luma < 235f) {
                    val yNew = 0.299f * rf + 0.587f * gf + 0.114f * bf
                    val satBoost = 1.22f
                    rf = (yNew + (rf - yNew) * satBoost).coerceIn(0f, 255f)
                    gf = (yNew + (gf - yNew) * satBoost).coerceIn(0f, 255f)
                    bf = (yNew + (bf - yNew) * satBoost).coerceIn(0f, 255f)
                }
            }

            val ri = rf.roundToInt().coerceIn(0, 255)
            val gi = gf.roundToInt().coerceIn(0, 255)
            val bi = bf.roundToInt().coerceIn(0, 255)
            stagePixels[i] = (a shl 24) or (ri shl 16) or (gi shl 8) or bi
        }

        // 3x3 edge-sharpening convolution kernel: [0, -1, 0; -1, 5, -1; 0, -1, 0] blended smoothly
        val sharpPixels = stagePixels.copyOf()
        val strength = 0.42f
        if (w >= 3 && h >= 3) {
            for (y in 1 until h - 1) {
                val rowOffset = y * w
                for (x in 1 until w - 1) {
                    val idx = rowOffset + x
                    val c = stagePixels[idx]
                    val top = stagePixels[idx - w]
                    val bottom = stagePixels[idx + w]
                    val left = stagePixels[idx - 1]
                    val right = stagePixels[idx + 1]

                    val a = (c ushr 24) and 0xFF
                    val cr = (c shr 16) and 0xFF
                    val cg = (c shr 8) and 0xFF
                    val cb = c and 0xFF

                    val lapR = 4 * cr - ((top shr 16) and 0xFF) - ((bottom shr 16) and 0xFF) -
                        ((left shr 16) and 0xFF) - ((right shr 16) and 0xFF)
                    val lapG = 4 * cg - ((top shr 8) and 0xFF) - ((bottom shr 8) and 0xFF) -
                        ((left shr 8) and 0xFF) - ((right shr 8) and 0xFF)
                    val lapB = 4 * cb - (top and 0xFF) - (bottom and 0xFF) -
                        (left and 0xFF) - (right and 0xFF)

                    val nr = (cr + lapR * strength).roundToInt().coerceIn(0, 255)
                    val ng = (cg + lapG * strength).roundToInt().coerceIn(0, 255)
                    val nb = (cb + lapB * strength).roundToInt().coerceIn(0, 255)
                    sharpPixels[idx] = (a shl 24) or (nr shl 16) or (ng shl 8) or nb
                }
            }
        }

        val output = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888)
        output.setPixels(sharpPixels, 0, w, 0, 0, w, h)
        return output
    }

    /**
     * Splits an open two-page book spread capture down the vertical center spine
     * into Left Page (Page 1) and Right Page (Page 2) in reading order.
     */
    fun splitBookSpreadToFiles(
        sourceFile: File,
        leftOutFile: File,
        rightOutFile: File
    ): Result<Pair<File, File>> = runCatching {
        val full = decodeSampledBitmap(sourceFile.absolutePath, MAX_SAFE_IMAGE_DIMENSION)
            ?: error("Could not decode book spread image.")
        var leftBmp: Bitmap? = null
        var rightBmp: Bitmap? = null
        try {
            val midX = (full.width / 2).coerceAtLeast(1)
            val rightW = (full.width - midX).coerceAtLeast(1)
            leftBmp = Bitmap.createBitmap(full, 0, 0, midX, full.height)
            rightBmp = Bitmap.createBitmap(full, midX, 0, rightW, full.height)

            FileOutputStream(leftOutFile).use { out ->
                leftBmp.compress(Bitmap.CompressFormat.JPEG, 94, out)
            }
            FileOutputStream(rightOutFile).use { out ->
                rightBmp.compress(Bitmap.CompressFormat.JPEG, 94, out)
            }
            leftOutFile to rightOutFile
        } finally {
            if (leftBmp != null && !leftBmp.isRecycled) leftBmp.recycle()
            if (rightBmp != null && !rightBmp.isRecycled) rightBmp.recycle()
            if (!full.isRecycled) full.recycle()
        }
    }

    fun assessImageQuality(bitmap: Bitmap): ImageQualityReport {
        val maxDim = 220
        val scaleRatio = minOf(
            1f,
            maxDim.toFloat() / max(bitmap.width, bitmap.height).coerceAtLeast(1)
        )
        val sampleW = (bitmap.width * scaleRatio).roundToInt().coerceAtLeast(1)
        val sampleH = (bitmap.height * scaleRatio).roundToInt().coerceAtLeast(1)
        val scaled = if (sampleW != bitmap.width || sampleH != bitmap.height) {
            Bitmap.createScaledBitmap(bitmap, sampleW, sampleH, false)
        } else {
            bitmap
        }

        val count = sampleW * sampleH
        val pixels = IntArray(count)
        try {
            scaled.getPixels(pixels, 0, sampleW, 0, 0, sampleW, sampleH)
        } finally {
            if (scaled !== bitmap && !scaled.isRecycled) {
                scaled.recycle()
            }
        }

        val luma = DoubleArray(count)
        var sum = 0.0
        var minLuma = 255.0
        var maxLuma = 0.0
        for (i in 0 until count) {
            val px = pixels[i]
            val r = (px shr 16) and 0xFF
            val g = (px shr 8) and 0xFF
            val b = px and 0xFF
            val y = 0.299 * r + 0.587 * g + 0.114 * b
            luma[i] = y
            sum += y
            if (y < minLuma) minLuma = y
            if (y > maxLuma) maxLuma = y
        }
        val mean = sum / count.coerceAtLeast(1)
        var varSum = 0.0
        for (i in 0 until count) {
            val d = luma[i] - mean
            varSum += d * d
        }
        val variance = varSum / count.coerceAtLeast(1)
        val contrastRange = maxLuma - minLuma
        val isBlank = variance < 10.0 && contrastRange < 28.0

        var edgeSum = 0.0
        var edgeMax = 0.0
        var edgeSamples = 0
        for (y in 1 until sampleH - 1) {
            for (x in 1 until sampleW - 1) {
                val idx = y * sampleW + x
                val gx = abs(luma[idx + 1] - luma[idx - 1])
                val gy = abs(luma[idx + sampleW] - luma[idx - sampleW])
                val mag = gx + gy
                edgeSum += mag
                if (mag > edgeMax) edgeMax = mag
                edgeSamples++
            }
        }
        val avgEdge = if (edgeSamples > 0) edgeSum / edgeSamples else 0.0
        val isBlurry = !isBlank && edgeMax < 42.0 && avgEdge < 6.0

        return ImageQualityReport(
            isBlankOrUniform = isBlank,
            isLikelyBlurry = isBlurry,
            sharpnessScore = edgeMax
        )
    }
}
