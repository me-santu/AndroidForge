# DocuScan ProGuard / R8 Keep Rules

-keepattributes SourceFile,LineNumberTable
-keepattributes *Annotation*,Signature,InnerClasses,EnclosingMethod

# ---------- App Package ----------
-keep class com.docuscan.app.DocuScanApplication { *; }
-keep class com.docuscan.app.MainActivity { *; }

# ---------- Tesseract4Android (JNI & Native OCR Wrapper) ----------
-keep class cz.adaptech.tesseract4android.** { *; }
-keep class com.googlecode.tesseract.android.** { *; }
-keep class com.googlecode.leptonica.android.** { *; }
-keepclasseswithmembernames class * {
    native <methods>;
}
-dontwarn cz.adaptech.tesseract4android.**
-dontwarn com.googlecode.tesseract.android.**
-dontwarn com.googlecode.leptonica.android.**

# ---------- Google ML Kit & Play Services ----------
-keep class com.google.mlkit.** { *; }
-keep interface com.google.mlkit.** { *; }
-keep class com.google.android.gms.vision.** { *; }
-keep class com.google.android.libraries.vision.** { *; }
-keep class com.google.android.odml.** { *; }
-dontwarn com.google.mlkit.**
-dontwarn com.google.android.gms.**

# ---------- Room Database (Entities, DAOs & Database) ----------
-keep class * extends androidx.room.RoomDatabase { *; }
-keep @androidx.room.Entity class * { *; }
-keep @androidx.room.Dao interface * { *; }
-keep @androidx.room.Database class * { *; }
-keep class androidx.room.** { *; }
-keep class com.docuscan.app.database.** { *; }
-keepclassmembers class * extends androidx.room.RoomDatabase {
    <init>(...);
}

# ---------- Jetpack Compose & Lifecycle ----------
-keep class androidx.compose.** { *; }
-keep class androidx.lifecycle.** { *; }
-keepclassmembers class * implements androidx.lifecycle.LifecycleObserver {
    <init>(...);
}
-keepclassmembers class * extends androidx.lifecycle.ViewModel {
    <init>(...);
}
-keep @androidx.compose.runtime.Immutable class * { *; }
-keep @androidx.compose.runtime.Stable class * { *; }

# ---------- Kotlinx Serialization & Type-Safe Navigation ----------
-keepattributes RuntimeVisibleAnnotations,AnnotationDefault
-keep class kotlinx.serialization.** { *; }
-keep class com.docuscan.app.navigation.** { *; }
-keepclassmembers class * {
    @kotlinx.serialization.Serializable <fields>;
    @kotlinx.serialization.Serializable <methods>;
}
-keep,includedescriptorclasses class com.docuscan.app.**$$serializer { *; }
-keepclassmembers class com.docuscan.app.** {
    *** Companion;
}

# ---------- PDFBox-Android & BouncyCastle ----------
-keep class com.tom_roush.pdfbox.** { *; }
-keep class com.tom_roush.fontbox.** { *; }
-keep class org.bouncycastle.** { *; }
-dontwarn com.tom_roush.pdfbox.**
-dontwarn com.tom_roush.fontbox.**
-dontwarn org.bouncycastle.**
-dontwarn java.awt.**
-dontwarn javax.imageio.**

# ---------- CameraX & Biometric ----------
-keep class androidx.camera.** { *; }
-keep class androidx.biometric.** { *; }
