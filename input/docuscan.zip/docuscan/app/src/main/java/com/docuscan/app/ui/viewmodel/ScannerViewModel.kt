package com.docuscan.app.ui.viewmodel

import android.app.Activity
import android.content.Intent
import android.content.IntentSender
import android.net.Uri
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.docuscan.app.domain.model.DocumentFileType
import com.docuscan.app.domain.model.DocumentItem
import com.docuscan.app.domain.model.FolderItem
import com.docuscan.app.domain.model.IdDocumentType
import com.docuscan.app.domain.model.IdSideScanState
import com.docuscan.app.domain.model.NormalizedCropRect
import com.docuscan.app.domain.model.PdfCompressionLevel
import com.docuscan.app.domain.model.PdfCreationOptions
import com.docuscan.app.domain.model.PdfPageSize
import com.docuscan.app.domain.model.ScanFilter
import com.docuscan.app.domain.model.ScanPage
import com.docuscan.app.domain.repository.DocumentRepository
import com.docuscan.app.domain.repository.SettingsRepository
import com.docuscan.app.scanner.DocumentScannerGateway
import com.docuscan.app.scanner.ScanSessionManager
import com.docuscan.app.scanner.ScannerActivityOutcome
import com.docuscan.app.scanner.ScannerStartOutcome
import com.docuscan.app.util.LocalFileManager
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch
import java.io.File
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.UUID

sealed interface OperationState {
    data object Idle : OperationState
    data object Working : OperationState
    data class Success(val document: DocumentItem, val message: String? = null) : OperationState
    data class Error(val message: String) : OperationState
}

sealed interface MlKitScanUiState {
    data object Idle : MlKitScanUiState
    data object PreparingScanner : MlKitScanUiState
    data class SavingResults(val pageCount: Int) : MlKitScanUiState
    data class Cancelled(val message: String = "Document scan cancelled.") : MlKitScanUiState
    data class Error(
        val message: String,
        val canFallbackToCamera: Boolean = true
    ) : MlKitScanUiState
}

class ScannerViewModel(
    private val documentRepository: DocumentRepository,
    private val settingsRepository: SettingsRepository,
    private val sessionManager: ScanSessionManager,
    private val fileManager: LocalFileManager,
    private val scannerGateway: DocumentScannerGateway
) : ViewModel() {

    val sessionPages: StateFlow<List<ScanPage>> = sessionManager.pages
    val activeDocumentId: StateFlow<Long?> = sessionManager.activeDocumentId
    val activeDocumentTitle: StateFlow<String?> = sessionManager.activeDocumentTitle

    val folders: StateFlow<List<FolderItem>> = documentRepository.observeFolders()
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val pdfDocuments: StateFlow<List<DocumentItem>> = documentRepository.observeActiveDocuments()
        .map { list -> list.filter { it.fileType == DocumentFileType.PDF || it.fileType == DocumentFileType.ID_CARD } }
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    private val _operationState = MutableStateFlow<OperationState>(OperationState.Idle)
    val operationState: StateFlow<OperationState> = _operationState.asStateFlow()

    private val _mlKitScanUiState = MutableStateFlow<MlKitScanUiState>(MlKitScanUiState.Idle)
    val mlKitScanUiState: StateFlow<MlKitScanUiState> = _mlKitScanUiState.asStateFlow()

    private val _idDocumentType = MutableStateFlow(IdDocumentType.AADHAAR)
    val idDocumentType: StateFlow<IdDocumentType> = _idDocumentType.asStateFlow()

    private val _idFrontSide = MutableStateFlow(IdSideScanState())
    val idFrontSide: StateFlow<IdSideScanState> = _idFrontSide.asStateFlow()

    private val _idBackSide = MutableStateFlow(IdSideScanState())
    val idBackSide: StateFlow<IdSideScanState> = _idBackSide.asStateFlow()

    private val _idSingleCombinedSheet = MutableStateFlow(true)
    val idSingleCombinedSheet: StateFlow<Boolean> = _idSingleCombinedSheet.asStateFlow()

    fun prepareMlKitScan(
        activity: Activity,
        pageLimit: Int = 50,
        onIntentSenderReady: (IntentSender) -> Unit
    ) {
        _mlKitScanUiState.value = MlKitScanUiState.PreparingScanner
        scannerGateway.prepareScanIntent(activity, pageLimit) { outcome ->
            when (outcome) {
                is ScannerStartOutcome.Ready -> {
                    _mlKitScanUiState.value = MlKitScanUiState.Idle
                    onIntentSenderReady(outcome.intentSender)
                }
                is ScannerStartOutcome.Error -> {
                    _mlKitScanUiState.value = MlKitScanUiState.Error(
                        message = outcome.message,
                        canFallbackToCamera = outcome.isPlayServicesUnavailable || outcome.isUnsupportedDevice
                    )
                }
            }
        }
    }

    fun handleMlKitActivityResult(
        resultCode: Int,
        data: Intent?,
        appendToCurrentSession: Boolean,
        onCompletedOpenPageManager: () -> Unit
    ) {
        when (val outcome = scannerGateway.parseActivityResult(resultCode, data)) {
            is ScannerActivityOutcome.Cancelled -> {
                _mlKitScanUiState.value = MlKitScanUiState.Cancelled()
            }
            is ScannerActivityOutcome.Error -> {
                _mlKitScanUiState.value = MlKitScanUiState.Error(
                    message = outcome.message,
                    canFallbackToCamera = true
                )
            }
            is ScannerActivityOutcome.Success -> {
                val parsed = outcome.result
                viewModelScope.launch {
                    _mlKitScanUiState.value = MlKitScanUiState.SavingResults(
                        pageCount = maxOf(parsed.pageImageUris.size, parsed.pdfPageCount).coerceAtLeast(1)
                    )
                    if (appendToCurrentSession && sessionManager.pages.value.isNotEmpty()) {
                        runCatching {
                            val copiedNewPages = parsed.pageImageUris.mapIndexed { index, uri ->
                                val file = fileManager.copyUriToScanFile(uri, pageIndex = index)
                                ScanPage(
                                    id = UUID.randomUUID().toString(),
                                    sourcePath = file.absolutePath,
                                    filter = ScanFilter.ORIGINAL,
                                    rotationDegrees = 0,
                                    orderIndex = index
                                )
                            }
                            sessionManager.appendPagesFromMlKit(copiedNewPages)
                            val docId = sessionManager.activeDocumentId.value
                            if (docId != null) {
                                val docTitle = sessionManager.activeDocumentTitle.value ?: defaultScanTitle()
                                val prefs = settingsRepository.preferences.first()
                                documentRepository.updatePdfDocument(
                                    documentId = docId,
                                    title = docTitle,
                                    pages = sessionManager.pages.value,
                                    folderId = null,
                                    pageSize = prefs.defaultPageSize,
                                    quality = prefs.scanQuality
                                )
                            }
                        }.onSuccess {
                            _mlKitScanUiState.value = MlKitScanUiState.Idle
                            onCompletedOpenPageManager()
                        }.onFailure { err ->
                            _mlKitScanUiState.value = MlKitScanUiState.Error(
                                message = err.message ?: "Failed to store additional scanned pages."
                            )
                        }
                    } else {
                        val title = defaultScanTitle()
                        documentRepository.saveScannedBatch(
                            title = title,
                            pageImageUris = parsed.pageImageUris,
                            pdfUri = parsed.pdfUri,
                            pdfPageCount = parsed.pdfPageCount
                        ).onSuccess { (doc, copiedPages) ->
                            sessionManager.startNewSessionFromMlKit(
                                documentId = doc.id,
                                title = doc.title,
                                scannedPages = copiedPages
                            )
                            _mlKitScanUiState.value = MlKitScanUiState.Idle
                            onCompletedOpenPageManager()
                        }.onFailure { err ->
                            _mlKitScanUiState.value = MlKitScanUiState.Error(
                                message = err.message ?: "Failed to save scanned pages locally."
                            )
                        }
                    }
                }
            }
        }
    }

    fun clearMlKitScanUiState() {
        _mlKitScanUiState.value = MlKitScanUiState.Idle
    }

    private fun defaultScanTitle(): String {
        val stamp = SimpleDateFormat("yyyyMMdd_HHmm", Locale.US).format(Date())
        return "DocuScan_$stamp"
    }

    fun createCameraOutputFile(): File = fileManager.createTempCameraFile()

    fun importMediaUri(uri: Uri, onPageAdded: (ScanPage) -> Unit = {}) {
        viewModelScope.launch {
            val prefs = settingsRepository.preferences.first()
            documentRepository.importUriToScanFile(uri)
                .onSuccess { path ->
                    val page = sessionManager.addPage(path, autoEnhance = prefs.autoEnhance)
                    onPageAdded(page)
                }
                .onFailure { err ->
                    _operationState.value = OperationState.Error(err.message ?: "Failed to import image")
                }
        }
    }

    fun importMultipleMediaUris(uris: List<Uri>, onCompleted: () -> Unit = {}) {
        if (uris.isEmpty()) return
        viewModelScope.launch {
            val prefs = settingsRepository.preferences.first()
            uris.forEach { uri ->
                documentRepository.importUriToScanFile(uri)
                    .onSuccess { path -> sessionManager.addPage(path, autoEnhance = prefs.autoEnhance) }
                    .onFailure { err ->
                        _operationState.value = OperationState.Error(err.message ?: "Failed to import selected image")
                    }
            }
            onCompleted()
        }
    }

    fun addCapturedFile(file: File, onPageAdded: (ScanPage) -> Unit = {}) {
        viewModelScope.launch {
            if (!file.exists() || file.length() == 0L) {
                _operationState.value = OperationState.Error("Captured photo was empty.")
                return@launch
            }
            val prefs = settingsRepository.preferences.first()
            val page = sessionManager.addPage(file.absolutePath, autoEnhance = prefs.autoEnhance)
            onPageAdded(page)
        }
    }

    fun setFilter(pageId: String, filter: ScanFilter) = sessionManager.updateFilter(pageId, filter)

    fun rotatePage(pageId: String, deltaDegrees: Int) = sessionManager.rotatePage(pageId, deltaDegrees)

    fun movePage(pageId: String, direction: Int) = sessionManager.movePage(pageId, direction)

    fun removePage(pageId: String) = sessionManager.removePage(pageId)

    fun clearSession() = sessionManager.clearSession()

    fun generatePdf(
        title: String,
        folderId: Long?,
        pageSize: PdfPageSize,
        onCreated: (DocumentItem) -> Unit
    ) {
        viewModelScope.launch {
            val quality = settingsRepository.preferences.first().scanQuality
            generatePdfInternal(
                title = title,
                folderId = folderId,
                options = PdfCreationOptions(pageSize = pageSize, quality = quality),
                onCreated = onCreated
            )
        }
    }

    fun generatePdf(
        title: String,
        folderId: Long?,
        options: PdfCreationOptions,
        onCreated: (DocumentItem) -> Unit
    ) {
        viewModelScope.launch {
            generatePdfInternal(title, folderId, options, onCreated)
        }
    }

    private suspend fun generatePdfInternal(
        title: String,
        folderId: Long?,
        options: PdfCreationOptions,
        onCreated: (DocumentItem) -> Unit
    ) {
        val pages = sessionPages.value
        if (pages.isEmpty()) {
            _operationState.value = OperationState.Error("Add at least one scanned or imported page first.")
            return
        }
        _operationState.value = OperationState.Working
        val existingDocId = sessionManager.activeDocumentId.value
        val result = if (existingDocId != null) {
            documentRepository.updatePdfDocument(
                documentId = existingDocId,
                title = title,
                pages = pages,
                folderId = folderId,
                options = options
            )
        } else {
            documentRepository.createPdfDocument(
                title = title,
                pages = pages,
                folderId = folderId,
                options = options
            )
        }
        result.onSuccess { doc ->
            sessionManager.clearSession()
            _operationState.value = OperationState.Success(doc)
            onCreated(doc)
        }.onFailure { err ->
            _operationState.value = OperationState.Error(err.message ?: "Failed to build PDF")
        }
    }

    fun selectIdDocumentType(docType: IdDocumentType) {
        _idDocumentType.value = docType
    }

    fun setIdSingleCombinedSheet(singleSheet: Boolean) {
        _idSingleCombinedSheet.value = singleSheet
    }

    fun setIdFrontFromUri(uri: Uri) {
        viewModelScope.launch {
            documentRepository.importUriToScanFile(uri)
                .onSuccess { path ->
                    _idFrontSide.value = IdSideScanState(
                        imagePath = path,
                        filter = ScanFilter.HIGH_CONTRAST
                    )
                }
                .onFailure { _operationState.value = OperationState.Error(it.message ?: "Failed to load front side") }
        }
    }

    fun setIdFrontFromFile(file: File) {
        if (!file.exists() || file.length() == 0L) {
            _operationState.value = OperationState.Error("Captured front ID image was empty.")
            return
        }
        _idFrontSide.value = IdSideScanState(
            imagePath = file.absolutePath,
            filter = ScanFilter.HIGH_CONTRAST
        )
    }

    fun setIdBackFromUri(uri: Uri) {
        viewModelScope.launch {
            documentRepository.importUriToScanFile(uri)
                .onSuccess { path ->
                    _idBackSide.value = IdSideScanState(
                        imagePath = path,
                        filter = ScanFilter.HIGH_CONTRAST
                    )
                }
                .onFailure { _operationState.value = OperationState.Error(it.message ?: "Failed to load back side") }
        }
    }

    fun setIdBackFromFile(file: File) {
        if (!file.exists() || file.length() == 0L) {
            _operationState.value = OperationState.Error("Captured back ID image was empty.")
            return
        }
        _idBackSide.value = IdSideScanState(
            imagePath = file.absolutePath,
            filter = ScanFilter.HIGH_CONTRAST
        )
    }

    fun updateIdSideCrop(isFront: Boolean, cropRect: NormalizedCropRect) {
        val sanitized = cropRect.sanitized()
        if (isFront) {
            _idFrontSide.value = _idFrontSide.value.copy(cropRect = sanitized)
        } else {
            _idBackSide.value = _idBackSide.value.copy(cropRect = sanitized)
        }
    }

    fun updateIdSideFilter(isFront: Boolean, filter: ScanFilter) {
        if (isFront) {
            _idFrontSide.value = _idFrontSide.value.copy(filter = filter)
        } else {
            _idBackSide.value = _idBackSide.value.copy(filter = filter)
        }
    }

    fun rotateIdSide(isFront: Boolean, deltaDegrees: Int = 90) {
        if (isFront) {
            val next = ((_idFrontSide.value.rotationDegrees + deltaDegrees) % 360 + 360) % 360
            _idFrontSide.value = _idFrontSide.value.copy(rotationDegrees = next)
        } else {
            val next = ((_idBackSide.value.rotationDegrees + deltaDegrees) % 360 + 360) % 360
            _idBackSide.value = _idBackSide.value.copy(rotationDegrees = next)
        }
    }

    fun clearIdSide(isFront: Boolean) {
        if (isFront) {
            _idFrontSide.value = IdSideScanState()
        } else {
            _idBackSide.value = IdSideScanState()
        }
    }

    fun generateIdCardPdf(
        title: String,
        password: String? = null,
        onCreated: (DocumentItem) -> Unit
    ) {
        val front = _idFrontSide.value
        val back = _idBackSide.value.takeIf { !it.imagePath.isNullOrBlank() }
        val docType = _idDocumentType.value
        if (front.imagePath.isNullOrBlank()) {
            _operationState.value = OperationState.Error("Capture or select the front side first.")
            return
        }
        viewModelScope.launch {
            _operationState.value = OperationState.Working
            val prefs = settingsRepository.preferences.first()
            documentRepository.createIdCardPdfDocument(
                title = title.trim().ifBlank { "${docType.displayName}_${System.currentTimeMillis() % 10000}" },
                docType = docType,
                frontSide = front,
                backSide = back,
                singleCombinedSheet = _idSingleCombinedSheet.value,
                quality = prefs.scanQuality,
                password = password?.takeIf { it.isNotBlank() },
                encryptInVault = prefs.encryptSensitiveFiles
            ).onSuccess { doc ->
                _idFrontSide.value = IdSideScanState()
                _idBackSide.value = IdSideScanState()
                _operationState.value = OperationState.Success(doc, "ID scan saved locally")
                onCreated(doc)
            }.onFailure { err ->
                _operationState.value = OperationState.Error(err.message ?: "Could not create ID PDF")
            }
        }
    }

    fun mergePdfs(title: String, selectedIds: List<Long>, onCreated: (DocumentItem) -> Unit) {
        viewModelScope.launch {
            _operationState.value = OperationState.Working
            documentRepository.mergePdfDocuments(title, selectedIds, null)
                .onSuccess { doc ->
                    _operationState.value = OperationState.Success(doc, "Merged PDF created (${doc.pageCount}p)")
                    onCreated(doc)
                }
                .onFailure { err ->
                    _operationState.value = OperationState.Error(err.message ?: "Merge failed")
                }
        }
    }

    fun splitPdf(
        sourceId: Long,
        newTitle: String,
        startPage: Int,
        endPage: Int,
        password: String? = null,
        onCreated: (DocumentItem) -> Unit
    ) {
        viewModelScope.launch {
            _operationState.value = OperationState.Working
            documentRepository.splitPdfDocument(sourceId, newTitle, startPage, endPage, password)
                .onSuccess { doc ->
                    _operationState.value = OperationState.Success(doc, "Split PDF created (${doc.pageCount}p)")
                    onCreated(doc)
                }
                .onFailure { err ->
                    _operationState.value = OperationState.Error(err.message ?: "Split failed")
                }
        }
    }

    fun extractPdfPages(
        sourceId: Long,
        newTitle: String,
        oneBasedPages: List<Int>,
        password: String? = null,
        onCreated: (DocumentItem) -> Unit
    ) {
        viewModelScope.launch {
            _operationState.value = OperationState.Working
            documentRepository.extractPdfPages(sourceId, newTitle, oneBasedPages, password)
                .onSuccess { doc ->
                    _operationState.value = OperationState.Success(doc, "Extracted ${doc.pageCount} page(s)")
                    onCreated(doc)
                }
                .onFailure { err ->
                    _operationState.value = OperationState.Error(err.message ?: "Extract pages failed")
                }
        }
    }

    fun rotatePdfPages(
        sourceId: Long,
        newTitle: String,
        oneBasedPages: Set<Int>,
        deltaDegrees: Int,
        password: String? = null,
        onCreated: (DocumentItem) -> Unit
    ) {
        viewModelScope.launch {
            _operationState.value = OperationState.Working
            documentRepository.rotatePdfPages(sourceId, newTitle, oneBasedPages, deltaDegrees, password)
                .onSuccess { doc ->
                    _operationState.value = OperationState.Success(doc, "Rotated PDF saved cleanly")
                    onCreated(doc)
                }
                .onFailure { err ->
                    _operationState.value = OperationState.Error(err.message ?: "Rotate failed")
                }
        }
    }

    fun deletePdfPages(
        sourceId: Long,
        newTitle: String,
        oneBasedPagesToDelete: Set<Int>,
        password: String? = null,
        onCreated: (DocumentItem) -> Unit
    ) {
        viewModelScope.launch {
            _operationState.value = OperationState.Working
            documentRepository.deletePdfPages(sourceId, newTitle, oneBasedPagesToDelete, password)
                .onSuccess { doc ->
                    _operationState.value = OperationState.Success(doc, "Updated PDF (${doc.pageCount}p)")
                    onCreated(doc)
                }
                .onFailure { err ->
                    _operationState.value = OperationState.Error(err.message ?: "Delete pages failed")
                }
        }
    }

    fun compressPdf(
        sourceId: Long,
        newTitle: String,
        level: PdfCompressionLevel,
        password: String? = null,
        onCreated: (DocumentItem) -> Unit
    ) {
        viewModelScope.launch {
            _operationState.value = OperationState.Working
            documentRepository.compressPdfDocument(sourceId, newTitle, level, password)
                .onSuccess { doc ->
                    _operationState.value = OperationState.Success(doc, "Compressed PDF saved")
                    onCreated(doc)
                }
                .onFailure { err ->
                    _operationState.value = OperationState.Error(err.message ?: "Compression failed")
                }
        }
    }

    fun watermarkPdf(
        sourceId: Long,
        newTitle: String,
        watermarkText: String,
        password: String? = null,
        onCreated: (DocumentItem) -> Unit
    ) {
        viewModelScope.launch {
            _operationState.value = OperationState.Working
            documentRepository.watermarkPdfDocument(sourceId, newTitle, watermarkText, password)
                .onSuccess { doc ->
                    _operationState.value = OperationState.Success(doc, "Watermark applied to new PDF")
                    onCreated(doc)
                }
                .onFailure { err ->
                    _operationState.value = OperationState.Error(err.message ?: "Watermark failed")
                }
        }
    }

    fun protectPdf(
        sourceId: Long,
        newTitle: String,
        userPassword: String,
        existingPassword: String? = null,
        onCreated: (DocumentItem) -> Unit
    ) {
        viewModelScope.launch {
            _operationState.value = OperationState.Working
            documentRepository.protectPdfDocument(sourceId, newTitle, userPassword, existingPassword)
                .onSuccess { doc ->
                    _operationState.value = OperationState.Success(doc, "Password protection applied")
                    onCreated(doc)
                }
                .onFailure { err ->
                    _operationState.value = OperationState.Error(err.message ?: "Encryption failed")
                }
        }
    }

    private fun runPdfToolOperation(
        fallbackError: String,
        block: suspend () -> Result<DocumentItem>
    ) = viewModelScope.launch {
        _operationState.value = OperationState.Working
        block()
            .onSuccess { doc ->
                _operationState.value = OperationState.Success(doc)
            }
            .onFailure { err ->
                _operationState.value = OperationState.Error(err.message ?: fallbackError)
            }
    }.let { null }

    fun resetOperationState() {
        _operationState.value = OperationState.Idle
    }
}
