package com.docuscan.app.navigation

import android.app.Activity
import android.content.Context
import android.content.ContextWrapper
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.IntentSenderRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.AnimatedContentTransitionScope
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.consumeWindowInsets
import androidx.compose.foundation.layout.displayCutoutPadding
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.FloatingActionButton
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.NavigationRail
import androidx.compose.material3.NavigationRailItem
import androidx.compose.material3.NavigationRailItemDefaults
import androidx.compose.material3.Scaffold
import androidx.compose.material3.SnackbarHost
import androidx.compose.material3.SnackbarHostState
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.compose.ui.window.Dialog
import androidx.compose.foundation.layout.Box
import androidx.fragment.app.FragmentActivity
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.navigation.NavDestination.Companion.hasRoute
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.currentBackStackEntryAsState
import androidx.navigation.compose.rememberNavController
import androidx.navigation.toRoute
import com.docuscan.app.settings.SettingsViewModel
import com.docuscan.app.ui.components.DocuScanBottomBar
import com.docuscan.app.ui.icons.LucideIcons
import com.docuscan.app.ui.screens.AboutPrivacyScreen
import com.docuscan.app.ui.screens.BackupScreen
import com.docuscan.app.ui.screens.CameraScannerScreen
import com.docuscan.app.ui.screens.DocumentsScreen
import com.docuscan.app.ui.screens.HomeScreen
import com.docuscan.app.ui.screens.IdScannerScreen
import com.docuscan.app.ui.screens.ImageEditorScreen
import com.docuscan.app.ui.screens.OcrExtractorScreen
import com.docuscan.app.ui.screens.OnboardingScreen
import com.docuscan.app.ui.screens.PageManagerScreen
import com.docuscan.app.ui.screens.PdfCreatorScreen
import com.docuscan.app.ui.screens.PdfToolsScreen
import com.docuscan.app.ui.screens.PdfViewerScreen
import com.docuscan.app.ui.screens.RecycleBinScreen
import com.docuscan.app.ui.screens.SettingsScreen
import com.docuscan.app.ui.screens.SignPdfScreen
import com.docuscan.app.ui.screens.SignatureCreatorScreen
import com.docuscan.app.ui.screens.SplashScreen
import com.docuscan.app.ui.screens.VaultLockScreen
import com.docuscan.app.ui.viewmodel.DocumentsUiState
import com.docuscan.app.ui.viewmodel.DocumentsViewModel
import com.docuscan.app.ui.viewmodel.MlKitScanUiState
import com.docuscan.app.ui.viewmodel.OcrViewModel
import com.docuscan.app.ui.viewmodel.PdfToolsViewModel
import com.docuscan.app.ui.viewmodel.ScannerViewModel
import com.docuscan.app.ui.viewmodel.SignatureViewModel
import com.docuscan.app.ui.viewmodel.ViewerViewModel
import com.docuscan.app.util.LocalAppStrings

private tailrec fun Context.findActivity(): Activity? = when (this) {
    is Activity -> this
    is ContextWrapper -> baseContext.findActivity()
    else -> null
}

private tailrec fun Context.findFragmentActivity(): FragmentActivity? = when (this) {
    is FragmentActivity -> this
    is ContextWrapper -> baseContext.findFragmentActivity()
    else -> null
}

@Composable
fun DocuScanNavHost(
    documentsViewModel: DocumentsViewModel,
    scannerViewModel: ScannerViewModel,
    viewerViewModel: ViewerViewModel,
    signatureViewModel: SignatureViewModel,
    ocrViewModel: OcrViewModel,
    pdfToolsViewModel: PdfToolsViewModel,
    settingsViewModel: SettingsViewModel
) {
    val navController = rememberNavController()
    val context = LocalContext.current
    val backStackEntry by navController.currentBackStackEntryAsState()
    val currentDestination = backStackEntry?.destination

    val strings = LocalAppStrings.current
    val preferences by settingsViewModel.preferences.collectAsStateWithLifecycle()
    val storageSummary by documentsViewModel.storageSummary.collectAsStateWithLifecycle()
    val cacheSummary by settingsViewModel.cacheSummary.collectAsStateWithLifecycle()
    val biometricCapability by settingsViewModel.biometricCapability.collectAsStateWithLifecycle()
    val isVaultLocked by settingsViewModel.isVaultLocked.collectAsStateWithLifecycle()
    val settingsStatusMsg by settingsViewModel.settingsMessage.collectAsStateWithLifecycle()
    val sessionPages by scannerViewModel.sessionPages.collectAsStateWithLifecycle()
    val activeDocTitle by scannerViewModel.activeDocumentTitle.collectAsStateWithLifecycle()
    val mlKitScanState by scannerViewModel.mlKitScanUiState.collectAsStateWithLifecycle()
    val docsStatusMsg by documentsViewModel.statusMessage.collectAsStateWithLifecycle()
    val snackbarHostState = remember { SnackbarHostState() }

    var appendModeOnNextResult by remember { mutableStateOf(false) }

    val mlKitScannerLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.StartIntentSenderForResult()
    ) { activityResult ->
        scannerViewModel.handleMlKitActivityResult(
            resultCode = activityResult.resultCode,
            data = activityResult.data,
            appendToCurrentSession = appendModeOnNextResult,
            onCompletedOpenPageManager = {
                navController.navigate(PageManagerRoute) {
                    launchSingleTop = true
                }
            }
        )
    }

    fun launchMlKitScanner(appendMode: Boolean = false) {
        val activity = context.findActivity()
        if (activity == null) {
            navController.navigate(CameraScannerRoute)
            return
        }
        appendModeOnNextResult = appendMode
        settingsViewModel.suppressNextAutoLock()
        scannerViewModel.prepareMlKitScan(activity) { intentSender ->
            runCatching {
                mlKitScannerLauncher.launch(IntentSenderRequest.Builder(intentSender).build())
            }.onFailure {
                navController.navigate(CameraScannerRoute)
            }
        }
    }

    LaunchedEffect(docsStatusMsg) {
        if (!docsStatusMsg.isNullOrBlank()) {
            snackbarHostState.showSnackbar(docsStatusMsg!!)
            documentsViewModel.clearStatusMessage()
        }
    }

    LaunchedEffect(settingsStatusMsg) {
        if (!settingsStatusMsg.isNullOrBlank()) {
            snackbarHostState.showSnackbar(settingsStatusMsg!!)
            settingsViewModel.clearSettingsMessage()
        }
    }

    LaunchedEffect(mlKitScanState) {
        val state = mlKitScanState
        if (state is MlKitScanUiState.Cancelled) {
            snackbarHostState.showSnackbar(state.message)
            scannerViewModel.clearMlKitScanUiState()
        }
    }

    val topLevelTab: BottomNavDestination? = when {
        currentDestination?.hasRoute<HomeRoute>() == true -> BottomNavDestination.HOME
        currentDestination?.hasRoute<DocumentsRoute>() == true -> BottomNavDestination.DOCUMENTS
        currentDestination?.hasRoute<PdfToolsRoute>() == true -> BottomNavDestination.TOOLS
        currentDestination?.hasRoute<SettingsRoute>() == true -> BottomNavDestination.SETTINGS
        else -> null
    }

    fun navigateToTopTab(tab: BottomNavDestination) {
        val targetRoute: Any = when (tab) {
            BottomNavDestination.HOME -> HomeRoute
            BottomNavDestination.DOCUMENTS -> DocumentsRoute()
            BottomNavDestination.TOOLS -> PdfToolsRoute
            BottomNavDestination.SETTINGS -> SettingsRoute
        }
        navController.navigate(targetRoute) {
            popUpTo(HomeRoute) {
                saveState = true
            }
            launchSingleTop = true
            restoreState = true
        }
    }

    BoxWithConstraints(modifier = Modifier.fillMaxSize()) {
        val useNavigationRail = maxWidth >= 640.dp && topLevelTab != null

        Row(modifier = Modifier.fillMaxSize()) {
            if (useNavigationRail) {
                NavigationRail(
                    containerColor = MaterialTheme.colorScheme.surface,
                    header = {
                        FloatingActionButton(
                            onClick = { launchMlKitScanner(appendMode = false) },
                            containerColor = MaterialTheme.colorScheme.primary,
                            contentColor = MaterialTheme.colorScheme.onPrimary,
                            modifier = Modifier.padding(top = 12.dp, bottom = 8.dp)
                        ) {
                            Icon(LucideIcons.ScanLine, contentDescription = "Scan Document")
                        }
                    },
                    modifier = Modifier
                        .fillMaxHeight()
                        .statusBarsPadding()
                        .navigationBarsPadding()
                        .displayCutoutPadding()
                ) {
                    Spacer(modifier = Modifier.weight(0.2f))
                    BottomNavDestination.entries.forEach { dest ->
                        val selected = topLevelTab == dest
                        val localizedLabel = dest.localizedLabel(strings)
                        NavigationRailItem(
                            selected = selected,
                            onClick = { navigateToTopTab(dest) },
                            icon = {
                                Icon(
                                    imageVector = if (selected) dest.selectedIcon else dest.unselectedIcon,
                                    contentDescription = localizedLabel
                                )
                            },
                            label = { Text(localizedLabel) },
                            colors = NavigationRailItemDefaults.colors(
                                selectedIconColor = MaterialTheme.colorScheme.primary,
                                selectedTextColor = MaterialTheme.colorScheme.primary,
                                indicatorColor = MaterialTheme.colorScheme.primaryContainer
                            )
                        )
                    }
                    Spacer(modifier = Modifier.weight(1f))
                }
            }

            Scaffold(
                modifier = Modifier.fillMaxSize(),
                containerColor = MaterialTheme.colorScheme.background,
                contentWindowInsets = WindowInsets(0, 0, 0, 0),
                snackbarHost = {
                    SnackbarHost(
                        hostState = snackbarHostState,
                        modifier = if (topLevelTab == null) Modifier.navigationBarsPadding() else Modifier
                    )
                },
                bottomBar = {
                    if (!useNavigationRail && topLevelTab != null) {
                        DocuScanBottomBar(
                            selectedDestination = topLevelTab,
                            onSelectDestination = ::navigateToTopTab,
                            onScanClick = { launchMlKitScanner(appendMode = false) }
                        )
                    }
                }
            ) { innerPadding ->
                NavHost(
                    navController = navController,
                    startDestination = SplashRoute,
                    enterTransition = {
                        fadeIn(animationSpec = tween(220)) +
                            slideIntoContainer(
                                towards = AnimatedContentTransitionScope.SlideDirection.Start,
                                animationSpec = tween(220)
                            )
                    },
                    exitTransition = {
                        fadeOut(animationSpec = tween(180))
                    },
                    popEnterTransition = {
                        fadeIn(animationSpec = tween(200))
                    },
                    popExitTransition = {
                        fadeOut(animationSpec = tween(180)) +
                            slideOutOfContainer(
                                towards = AnimatedContentTransitionScope.SlideDirection.End,
                                animationSpec = tween(200)
                            )
                    },
                    modifier = if (topLevelTab != null) {
                        Modifier
                            .fillMaxSize()
                            .padding(innerPadding)
                            .consumeWindowInsets(innerPadding)
                            .statusBarsPadding()
                            .displayCutoutPadding()
                            .then(if (useNavigationRail) Modifier.navigationBarsPadding() else Modifier)
                    } else {
                        Modifier.fillMaxSize()
                    }
                ) {
                    // 1. Splash
                    composable<SplashRoute> {
                        SplashScreen(
                            onboardingCompleted = preferences.onboardingCompleted,
                            onNavigateToOnboarding = {
                                navController.navigate(OnboardingRoute) {
                                    popUpTo<SplashRoute> { inclusive = true }
                                }
                            },
                            onNavigateToHome = {
                                navController.navigate(HomeRoute) {
                                    popUpTo<SplashRoute> { inclusive = true }
                                }
                            }
                        )
                    }

                    // 2. Onboarding
                    composable<OnboardingRoute> {
                        OnboardingScreen(
                            onFinishOnboarding = {
                                settingsViewModel.setOnboardingCompleted(true)
                                navController.navigate(HomeRoute) {
                                    popUpTo<OnboardingRoute> { inclusive = true }
                                }
                            }
                        )
                    }

                    // 3. Home Dashboard
                    composable<HomeRoute> {
                        val searchQuery by documentsViewModel.searchQuery.collectAsStateWithLifecycle()
                        val recentDocs by documentsViewModel.filteredHomeDocuments.collectAsStateWithLifecycle()

                        HomeScreen(
                            searchQuery = searchQuery,
                            recentDocuments = recentDocs,
                            storageSummary = storageSummary,
                            activeSessionPageCount = sessionPages.size,
                            onSearchQueryChange = documentsViewModel::updateSearchQuery,
                            onScanDocument = { launchMlKitScanner(appendMode = false) },
                            onImportImageUri = { uri ->
                                scannerViewModel.importMediaUri(uri) { page ->
                                    navController.navigate(ImageEditorRoute(page.id))
                                }
                            },
                            onCreatePdf = {
                                if (sessionPages.isEmpty()) {
                                    navController.navigate(PageManagerRoute)
                                } else {
                                    navController.navigate(PdfCreatorRoute)
                                }
                            },
                            onExtractText = { navController.navigate(OcrExtractorRoute()) },
                            onOpenIdScanner = { navController.navigate(IdScannerRoute) },
                            onOpenSignatureCreator = { navController.navigate(SignatureCreatorRoute) },
                            onOpenPdfTools = { navigateToTopTab(BottomNavDestination.TOOLS) },
                            onOpenRecycleBin = { navController.navigate(RecycleBinRoute) },
                            onOpenBackup = { navController.navigate(BackupRoute) },
                            onOpenAllDocuments = { navigateToTopTab(BottomNavDestination.DOCUMENTS) },
                            onOpenDocument = { docId -> navController.navigate(PdfViewerRoute(docId)) }
                        )
                    }

                    // 4. Camera Scanner Entry
                    composable<CameraScannerRoute> {
                        CameraScannerScreen(
                            pendingPageCount = sessionPages.size,
                            createOutputFile = scannerViewModel::createCameraOutputFile,
                            onCapturedFile = { file ->
                                scannerViewModel.addCapturedFile(file) { page ->
                                    navController.navigate(ImageEditorRoute(page.id))
                                }
                            },
                            onImportUri = { uri ->
                                scannerViewModel.importMediaUri(uri) { page ->
                                    navController.navigate(ImageEditorRoute(page.id))
                                }
                            },
                            onOpenPageManager = { navController.navigate(PageManagerRoute) },
                            onOpenIdScanner = { navController.navigate(IdScannerRoute) },
                            onBack = { navController.popBackStack() }
                        )
                    }

                    // 5. Image Editor
                    composable<ImageEditorRoute> { entry ->
                        val args = entry.toRoute<ImageEditorRoute>()
                        val currentPage = sessionPages.firstOrNull { it.id == args.pageId }
                        ImageEditorScreen(
                            page = currentPage,
                            onSetFilter = scannerViewModel::setFilter,
                            onRotate = scannerViewModel::rotatePage,
                            onDone = {
                                navController.navigate(PageManagerRoute) {
                                    popUpTo(ImageEditorRoute(args.pageId)) { inclusive = true }
                                }
                            },
                            onBack = { navController.popBackStack() }
                        )
                    }

                    // 6. Page Manager
                    composable<PageManagerRoute> {
                        PageManagerScreen(
                            pages = sessionPages,
                            activeDocumentTitle = activeDocTitle,
                            onAddAnotherScan = { launchMlKitScanner(appendMode = true) },
                            onImportUri = { uri ->
                                scannerViewModel.importMediaUri(uri) { page ->
                                    navController.navigate(ImageEditorRoute(page.id))
                                }
                            },
                            onImportMultipleUris = { uris ->
                                if (uris.size == 1) {
                                    scannerViewModel.importMediaUri(uris.first()) { page ->
                                        navController.navigate(ImageEditorRoute(page.id))
                                    }
                                } else {
                                    scannerViewModel.importMultipleMediaUris(uris) {}
                                }
                            },
                            onEditPage = { pageId -> navController.navigate(ImageEditorRoute(pageId)) },
                            onRotatePage = scannerViewModel::rotatePage,
                            onMovePage = scannerViewModel::movePage,
                            onRemovePage = scannerViewModel::removePage,
                            onClearAll = scannerViewModel::clearSession,
                            onExportFinalPdf = { navController.navigate(PdfCreatorRoute) },
                            onBack = { navController.popBackStack() }
                        )
                    }

                    // 7. PDF Creator
                    composable<PdfCreatorRoute> {
                        val folders by scannerViewModel.folders.collectAsStateWithLifecycle()
                        val opState by scannerViewModel.operationState.collectAsStateWithLifecycle()

                        PdfCreatorScreen(
                            pages = sessionPages,
                            folders = folders,
                            scanQuality = preferences.scanQuality,
                            defaultPageSize = preferences.defaultPageSize,
                            operationState = opState,
                            initialTitle = activeDocTitle,
                            onCreateFolder = documentsViewModel::createFolder,
                            onGeneratePdf = scannerViewModel::generatePdf,
                            onPdfCreated = { docId ->
                                scannerViewModel.resetOperationState()
                                navController.navigate(PdfViewerRoute(docId)) {
                                    popUpTo(HomeRoute) { inclusive = false }
                                }
                            },
                            onGoToPageManager = { navController.navigate(PageManagerRoute) },
                            onBack = { navController.popBackStack() }
                        )
                    }

                    // 8. OCR Extractor
                    composable<OcrExtractorRoute> { entry ->
                        val args = entry.toRoute<OcrExtractorRoute>()
                        val docsState by documentsViewModel.documentsUiState.collectAsStateWithLifecycle()
                        val allDocs = (docsState as? DocumentsUiState.Success)?.documents.orEmpty()
                        val ocrUiState by ocrViewModel.uiState.collectAsStateWithLifecycle()

                        OcrExtractorScreen(
                            documents = allDocs,
                            activeSessionPages = sessionPages,
                            initialDocumentId = args.documentId,
                            uiState = ocrUiState,
                            createCameraTempFile = scannerViewModel::createCameraOutputFile,
                            onInitializeDocument = ocrViewModel::initializeWithDocument,
                            onSelectDocument = ocrViewModel::selectDocument,
                            onImportImageUri = ocrViewModel::importImageUriForOcr,
                            onImportPdfUri = ocrViewModel::importExternalPdfForOcr,
                            onCapturedImageFile = { file -> ocrViewModel.loadImageFileForOcr(file.absolutePath) },
                            onSelectScanSession = { pages -> ocrViewModel.selectScanSession(pages) },
                            onSelectScript = ocrViewModel::selectScript,
                            onUpdatePdfPassword = ocrViewModel::updatePdfPassword,
                            onRunExtraction = ocrViewModel::runExtraction,
                            onUpdateEditableText = ocrViewModel::updateEditableText,
                            onUpdateSearchQuery = ocrViewModel::updateSearchQuery,
                            onSaveNotesToDocument = { ocrViewModel.saveExtractedNotesToDocument() },
                            onSaveAsTxtToUri = ocrViewModel::saveAsTxtToUri,
                            onClearStatusMessage = ocrViewModel::clearStatusMessage,
                            onScanFirstDocument = { launchMlKitScanner(appendMode = false) },
                            onBack = { navController.popBackStack() }
                        )
                    }

                    // 9. Documents & Folders
                    composable<DocumentsRoute> { entry ->
                        val args = entry.toRoute<DocumentsRoute>()
                        LaunchedEffect(args.folderId) {
                            if (args.folderId > 0L) {
                                documentsViewModel.selectFolder(args.folderId)
                            }
                        }
                        val uiState by documentsViewModel.documentsUiState.collectAsStateWithLifecycle()
                        DocumentsScreen(
                            uiState = uiState,
                            onSearchChange = documentsViewModel::updateSearchQuery,
                            onSelectFolder = documentsViewModel::selectFolder,
                            onCreateFolder = documentsViewModel::createFolder,
                            onRenameFolder = documentsViewModel::renameFolder,
                            onDeleteFolder = documentsViewModel::deleteFolder,
                            onSetSortOption = documentsViewModel::setSortOption,
                            onToggleViewMode = documentsViewModel::toggleViewMode,
                            onToggleFavoritesOnly = documentsViewModel::toggleFavoritesOnly,
                            onToggleSelection = documentsViewModel::toggleSelection,
                            onSelectAll = documentsViewModel::selectAll,
                            onClearSelection = documentsViewModel::clearSelection,
                            onMoveSelectedToFolder = documentsViewModel::moveSelectedToFolder,
                            onSetSelectedFavorites = documentsViewModel::setSelectedFavorites,
                            onTrashSelected = documentsViewModel::trashSelected,
                            onMergeSelectedPdfs = { title ->
                                documentsViewModel.mergeSelectedPdfs(title) { created ->
                                    navController.navigate(PdfViewerRoute(created.id))
                                }
                            },
                            onImportPdfUri = { uri ->
                                documentsViewModel.importExternalPdfUri(uri) { imported ->
                                    navController.navigate(PdfViewerRoute(imported.id))
                                }
                            },
                            onExportDocumentToUri = documentsViewModel::exportDocumentToUri,
                            onOpenDocument = { docId -> navController.navigate(PdfViewerRoute(docId)) },
                            onRenameDocument = documentsViewModel::renameDocument,
                            onTogglePin = documentsViewModel::togglePin,
                            onToggleFavorite = documentsViewModel::toggleFavorite,
                            onMoveDocumentToFolder = documentsViewModel::moveDocumentToFolder,
                            onShareDocument = documentsViewModel::shareDocument,
                            onMoveToTrash = documentsViewModel::moveToTrash,
                            onOpenRecycleBin = { navController.navigate(RecycleBinRoute) },
                            onScanNew = { launchMlKitScanner(appendMode = false) },
                            onToggleVaultEncryption = documentsViewModel::toggleVaultEncryption
                        )
                    }

                    // 10. PDF Viewer
                    composable<PdfViewerRoute> { entry ->
                        val args = entry.toRoute<PdfViewerRoute>()
                        val viewerState by viewerViewModel.uiState.collectAsStateWithLifecycle()
                        val viewerMsg by viewerViewModel.statusMessage.collectAsStateWithLifecycle()
                        PdfViewerScreen(
                            documentId = args.documentId,
                            uiState = viewerState,
                            statusMessage = viewerMsg,
                            onClearStatusMessage = viewerViewModel::clearStatusMessage,
                            onLoadDocument = { id -> viewerViewModel.loadDocument(id) },
                            onUnlockWithPassword = viewerViewModel::unlockWithPassword,
                            onSelectPage = viewerViewModel::goToPage,
                            onToggleBookmark = viewerViewModel::toggleBookmark,
                            onSearchText = viewerViewModel::searchText,
                            onClearSearch = viewerViewModel::clearSearch,
                            onAddAnnotation = viewerViewModel::addAnnotation,
                            onExportToUri = viewerViewModel::exportToUri,
                            onPrint = { viewerViewModel.printCurrentDocument(context) },
                            onShare = viewerViewModel::shareCurrentDocument,
                            onOpenOcr = { docId -> navController.navigate(OcrExtractorRoute(docId)) },
                            onOpenSignPdf = { docId -> navController.navigate(SignPdfRoute(documentId = docId)) },
                            onOpenDocument = { newId -> navController.navigate(PdfViewerRoute(newId)) },
                            onDeleteToTrash = documentsViewModel::moveToTrash,
                            onBack = { navController.popBackStack() }
                        )
                    }

                    // 11. PDF Tools
                    composable<PdfToolsRoute> {
                        val pdfDocs by pdfToolsViewModel.pdfDocuments.collectAsStateWithLifecycle()
                        val toolsUiState by pdfToolsViewModel.uiState.collectAsStateWithLifecycle()
                        PdfToolsScreen(
                            pdfDocuments = pdfDocs,
                            activeSessionPageCount = sessionPages.size,
                            uiState = toolsUiState,
                            onDismissError = pdfToolsViewModel::clearError,
                            onDismissResult = pdfToolsViewModel::clearResult,
                            onOpenIdScanner = { navController.navigate(IdScannerRoute) },
                            onOpenSignatureCreator = { navController.navigate(SignatureCreatorRoute) },
                            onOpenSignPdf = { navController.navigate(SignPdfRoute()) },
                            onOpenOcrExtractor = { docId -> navController.navigate(OcrExtractorRoute(docId ?: -1L)) },
                            onOpenPageManager = { navController.navigate(PageManagerRoute) },
                            onImportMultipleGalleryImages = { uris ->
                                scannerViewModel.importMultipleMediaUris(uris) {
                                    navController.navigate(PageManagerRoute)
                                }
                            },
                            onImportExternalPdf = pdfToolsViewModel::importExternalPdfUri,
                            onImportMultipleExternalPdfs = pdfToolsViewModel::importMultipleExternalPdfUris,
                            onOpenExternalPdfUri = { uri ->
                                pdfToolsViewModel.openExternalPdfUri(uri) { docId ->
                                    navController.navigate(PdfViewerRoute(docId))
                                }
                            },
                            onOpenDocument = { docId ->
                                pdfToolsViewModel.clearResult()
                                navController.navigate(PdfViewerRoute(docId))
                            },
                            onRenamePdf = pdfToolsViewModel::renamePdf,
                            onDeletePdf = pdfToolsViewModel::deletePdf,
                            onSharePdf = pdfToolsViewModel::sharePdf,
                            onPrintPdf = pdfToolsViewModel::printPdf,
                            onDuplicatePdf = pdfToolsViewModel::duplicatePdf,
                            onInspectInfo = pdfToolsViewModel::inspectPdfInfo,
                            onMergePdfs = pdfToolsViewModel::mergePdfs,
                            onSplitPdf = pdfToolsViewModel::splitPdf,
                            onExtractPages = pdfToolsViewModel::extractPages,
                            onReorderPages = pdfToolsViewModel::reorderPages,
                            onRotatePages = pdfToolsViewModel::rotatePages,
                            onDeletePages = pdfToolsViewModel::deletePages,
                            onDuplicatePages = pdfToolsViewModel::duplicatePages,
                            onExportPdfToImages = pdfToolsViewModel::exportPdfToImages,
                            onReadTextFromUri = pdfToolsViewModel::readTextFromUri,
                            onCreatePdfFromText = pdfToolsViewModel::createPdfFromText,
                            onConvertPdfToDocx = pdfToolsViewModel::convertPdfToDocx,
                            onExtractTextFromPdf = pdfToolsViewModel::extractTextFromPdf,
                            onProtectPdf = pdfToolsViewModel::protectPdf,
                            onUnlockPdf = pdfToolsViewModel::unlockPdf,
                            onWatermarkPdf = pdfToolsViewModel::watermarkPdf,
                            onRemoveWatermark = pdfToolsViewModel::removeWatermark,
                            onAddPageNumbers = pdfToolsViewModel::addPageNumbers,
                            onAddHeaderFooter = pdfToolsViewModel::addHeaderFooter,
                            onCompressPdf = pdfToolsViewModel::compressPdf,
                            onReducePdfSize = pdfToolsViewModel::reducePdfSize,
                            onRepairPdf = pdfToolsViewModel::repairPdf,
                            onRepairExternalPdfUri = pdfToolsViewModel::repairExternalPdfUri,
                            onExportPdfToSaf = pdfToolsViewModel::exportDocumentToSafUri,
                            onExportLocalFileToSaf = pdfToolsViewModel::exportLocalFileToSafUri,
                            onExportTextToSaf = pdfToolsViewModel::exportTextToSafUri,
                            onExportImagesToSafTree = pdfToolsViewModel::exportImagesToSafTree,
                            onShareLocalFile = pdfToolsViewModel::shareLocalFile
                        )
                    }

                    // 12. ID Scanner
                    composable<IdScannerRoute> {
                        val idDocType by scannerViewModel.idDocumentType.collectAsStateWithLifecycle()
                        val frontSide by scannerViewModel.idFrontSide.collectAsStateWithLifecycle()
                        val backSide by scannerViewModel.idBackSide.collectAsStateWithLifecycle()
                        val singleCombinedSheet by scannerViewModel.idSingleCombinedSheet.collectAsStateWithLifecycle()
                        val opState by scannerViewModel.operationState.collectAsStateWithLifecycle()

                        IdScannerScreen(
                            selectedType = idDocType,
                            frontSide = frontSide,
                            backSide = backSide,
                            singleCombinedSheet = singleCombinedSheet,
                            operationState = opState,
                            createCameraTempFile = scannerViewModel::createCameraOutputFile,
                            onSelectDocumentType = scannerViewModel::selectIdDocumentType,
                            onSetSingleCombinedSheet = scannerViewModel::setIdSingleCombinedSheet,
                            onPickFrontUri = scannerViewModel::setIdFrontFromUri,
                            onPickBackUri = scannerViewModel::setIdBackFromUri,
                            onCaptureFrontFile = scannerViewModel::setIdFrontFromFile,
                            onCaptureBackFile = scannerViewModel::setIdBackFromFile,
                            onUpdateSideCrop = scannerViewModel::updateIdSideCrop,
                            onUpdateSideFilter = scannerViewModel::updateIdSideFilter,
                            onRotateSide = scannerViewModel::rotateIdSide,
                            onClearSide = scannerViewModel::clearIdSide,
                            onGenerateIdPdf = scannerViewModel::generateIdCardPdf,
                            onPdfCreated = { docId ->
                                scannerViewModel.resetOperationState()
                                navController.navigate(PdfViewerRoute(docId)) {
                                    popUpTo(HomeRoute) { inclusive = false }
                                }
                            },
                            onClearOperationError = scannerViewModel::resetOperationState,
                            onBack = { navController.popBackStack() }
                        )
                    }

                    // 13. Signature Creator
                    composable<SignatureCreatorRoute> {
                        val signatures by signatureViewModel.signatures.collectAsStateWithLifecycle()
                        val msg by signatureViewModel.message.collectAsStateWithLifecycle()

                        SignatureCreatorScreen(
                            savedSignatures = signatures,
                            statusMessage = msg,
                            onSaveSignature = { name, bytes -> signatureViewModel.saveSignature(name, bytes) },
                            onDeleteSignature = signatureViewModel::deleteSignature,
                            onApplySignatureToPdf = { sigId ->
                                navController.navigate(SignPdfRoute(signatureId = sigId))
                            },
                            onClearMessage = signatureViewModel::clearMessage,
                            onBack = { navController.popBackStack() }
                        )
                    }

                    // 13b. Insert Signature into PDF
                    composable<SignPdfRoute> { entry ->
                        val args = entry.toRoute<SignPdfRoute>()
                        val pdfDocs by signatureViewModel.pdfDocuments.collectAsStateWithLifecycle()
                        val signatures by signatureViewModel.signatures.collectAsStateWithLifecycle()
                        val signState by signatureViewModel.signPdfState.collectAsStateWithLifecycle()
                        val msg by signatureViewModel.message.collectAsStateWithLifecycle()

                        SignPdfScreen(
                            initialDocumentId = args.documentId,
                            initialSignatureId = args.signatureId,
                            pdfDocuments = pdfDocs,
                            savedSignatures = signatures,
                            uiState = signState,
                            statusMessage = msg,
                            onInitSession = signatureViewModel::initSignPdfSession,
                            onSelectDocument = { doc -> signatureViewModel.selectPdfDocument(doc) },
                            onImportPdfFromDevice = signatureViewModel::importExternalPdfForSigning,
                            onUnlockPassword = signatureViewModel::unlockSignPdfPassword,
                            onSelectSignature = signatureViewModel::selectSignatureForPlacement,
                            onSelectPage = signatureViewModel::goToSignPage,
                            onUpdatePlacement = signatureViewModel::updatePlacement,
                            onApplySignature = signatureViewModel::applySignatureToPdf,
                            onDrawNewSignature = { navController.navigate(SignatureCreatorRoute) },
                            onClearMessage = signatureViewModel::clearMessage,
                            onSignedPdfCreated = { newDocId ->
                                navController.navigate(PdfViewerRoute(newDocId)) {
                                    popUpTo(HomeRoute) { inclusive = false }
                                }
                            },
                            onBack = { navController.popBackStack() }
                        )
                    }

                    // 14. Backup
                    composable<BackupRoute> {
                        val backupMsg by settingsViewModel.backupMessage.collectAsStateWithLifecycle()
                        BackupScreen(
                            storageSummary = storageSummary,
                            lastBackupAt = preferences.lastBackupAt,
                            backupMessage = backupMsg,
                            onCreateLocalBackup = settingsViewModel::runLocalBackup,
                            onExportBackupZip = settingsViewModel::exportBackupZipToUri,
                            onOpenAboutPrivacy = { navController.navigate(AboutPrivacyRoute) },
                            onClearBackupMessage = settingsViewModel::clearBackupMessage,
                            onBack = { navController.popBackStack() }
                        )
                    }

                    // 15. Settings
                    composable<SettingsRoute> {
                        LaunchedEffect(Unit) {
                            settingsViewModel.refreshCacheSummary()
                        }
                        SettingsScreen(
                            preferences = preferences,
                            storageSummary = storageSummary,
                            cacheSummary = cacheSummary,
                            biometricCapability = biometricCapability,
                            securityManager = settingsViewModel.securityManager,
                            onSelectTheme = settingsViewModel::setThemeMode,
                            onSelectLanguage = settingsViewModel::setAppLanguage,
                            onSelectFontStyle = settingsViewModel::setFontStyle,
                            onSelectScanQuality = settingsViewModel::setScanQuality,
                            onSelectDefaultPageSize = settingsViewModel::setDefaultPageSize,
                            onToggleAutoEnhance = settingsViewModel::setAutoEnhance,
                            onToggleAppLock = settingsViewModel::setAppLockEnabled,
                            onToggleBiometricUnlock = settingsViewModel::setBiometricUnlockEnabled,
                            onToggleEncryptSensitiveFiles = settingsViewModel::setEncryptSensitiveFiles,
                            onConfigurePin = settingsViewModel::configureOrUpdatePin,
                            onRemovePin = settingsViewModel::removePinAndDisableLock,
                            onLockVaultNow = settingsViewModel::lockVault,
                            onClearTempCache = settingsViewModel::clearTempCache,
                            onOpenBackup = { navController.navigate(BackupRoute) },
                            onOpenRecycleBin = { navController.navigate(RecycleBinRoute) },
                            onOpenAboutPrivacy = { navController.navigate(AboutPrivacyRoute) },
                            onSettingsStatusMessage = settingsViewModel::postSettingsMessage,
                            onBeforeExternalSettingsLaunch = settingsViewModel::suppressNextAutoLock
                        )
                    }

                    // 16. Recycle Bin
                    composable<RecycleBinRoute> {
                        val trashDocs by documentsViewModel.trashDocuments.collectAsStateWithLifecycle()
                        RecycleBinScreen(
                            trashedDocuments = trashDocs,
                            onRestore = documentsViewModel::restoreFromTrash,
                            onDeletePermanently = documentsViewModel::permanentlyDelete,
                            onEmptyBin = documentsViewModel::emptyRecycleBin,
                            onBack = { navController.popBackStack() }
                        )
                    }

                    // 17. About & Privacy
                    composable<AboutPrivacyRoute> {
                        AboutPrivacyScreen(
                            securityManager = settingsViewModel.securityManager,
                            onBack = { navController.popBackStack() }
                        )
                    }
                }
            }
        }
    }

    if (isVaultLocked && preferences.appLockEnabled && (preferences.hasPinConfigured || preferences.biometricUnlockEnabled)) {
        VaultLockScreen(
            biometricAvailable = biometricCapability.isAvailable,
            biometricEnabled = preferences.biometricUnlockEnabled,
            hasPinConfigured = preferences.hasPinConfigured,
            onVerifyPin = settingsViewModel::verifyPin,
            onRequestBiometricPrompt = { onSuccess, onError ->
                val fragmentActivity = context.findFragmentActivity()
                if (fragmentActivity == null) {
                    onError("Biometric prompt requires FragmentActivity")
                } else {
                    settingsViewModel.securityManager.authenticateBiometric(
                        activity = fragmentActivity,
                        title = strings.vaultLockedTitle,
                        subtitle = strings.vaultLockedSubtitle,
                        negativeButtonText = strings.enterPinLabel,
                        allowDeviceCredentialFallback = !preferences.hasPinConfigured,
                        onSuccess = onSuccess,
                        onError = onError
                    )
                }
            },
            onUnlocked = settingsViewModel::unlockVault
        )
    }

    // ML Kit Scanner Progress & Error Handling Dialogs
    when (val state = mlKitScanState) {
        is MlKitScanUiState.PreparingScanner,
        is MlKitScanUiState.SavingResults -> {
            val statusText = when (state) {
                is MlKitScanUiState.PreparingScanner -> "Preparing ML Kit Document Scanner..."
                is MlKitScanUiState.SavingResults -> "Saving ${state.pageCount} scanned page(s) & PDF locally..."
                else -> ""
            }
            Dialog(onDismissRequest = {}) {
                Surface(
                    shape = MaterialTheme.shapes.large,
                    color = MaterialTheme.colorScheme.surface,
                    border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline)
                ) {
                    Column(
                        modifier = Modifier.padding(24.dp),
                        horizontalAlignment = Alignment.CenterHorizontally,
                        verticalArrangement = Arrangement.spacedBy(14.dp)
                    ) {
                        CircularProgressIndicator(color = MaterialTheme.colorScheme.primary)
                        Text(
                            text = statusText,
                            style = MaterialTheme.typography.bodyMedium
                        )
                    }
                }
            }
        }

        is MlKitScanUiState.Error -> {
            AlertDialog(
                onDismissRequest = { scannerViewModel.clearMlKitScanUiState() },
                title = { Text("Scanner Unavailable") },
                text = { Text(state.message) },
                confirmButton = {
                    if (state.canFallbackToCamera) {
                        TextButton(
                            onClick = {
                                scannerViewModel.clearMlKitScanUiState()
                                navController.navigate(CameraScannerRoute)
                            }
                        ) {
                            Text("Use In-App Camera")
                        }
                    } else {
                        TextButton(
                            onClick = {
                                scannerViewModel.clearMlKitScanUiState()
                                launchMlKitScanner(appendModeOnNextResult)
                            }
                        ) {
                            Text("Retry")
                        }
                    }
                },
                dismissButton = {
                    TextButton(onClick = { scannerViewModel.clearMlKitScanUiState() }) {
                        Text("Dismiss")
                    }
                }
            )
        }

        else -> Unit
    }
}
