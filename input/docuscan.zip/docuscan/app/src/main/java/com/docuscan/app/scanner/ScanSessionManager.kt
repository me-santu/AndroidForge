package com.docuscan.app.scanner

import com.docuscan.app.domain.model.ScanFilter
import com.docuscan.app.domain.model.ScanPage
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import java.util.UUID

class ScanSessionManager {
    private val _pages = MutableStateFlow<List<ScanPage>>(emptyList())
    val pages: StateFlow<List<ScanPage>> = _pages.asStateFlow()

    private val _activeDocumentId = MutableStateFlow<Long?>(null)
    val activeDocumentId: StateFlow<Long?> = _activeDocumentId.asStateFlow()

    private val _activeDocumentTitle = MutableStateFlow<String?>(null)
    val activeDocumentTitle: StateFlow<String?> = _activeDocumentTitle.asStateFlow()

    fun startNewSessionFromMlKit(
        documentId: Long,
        title: String,
        scannedPages: List<ScanPage>
    ) {
        _activeDocumentId.value = documentId
        _activeDocumentTitle.value = title
        _pages.value = scannedPages.mapIndexed { idx, page -> page.copy(orderIndex = idx) }
    }

    fun appendPagesFromMlKit(
        newPages: List<ScanPage>,
        newDocumentIdIfEmpty: Long? = null,
        titleIfEmpty: String? = null
    ) {
        if (_pages.value.isEmpty() && newDocumentIdIfEmpty != null) {
            _activeDocumentId.value = newDocumentIdIfEmpty
            _activeDocumentTitle.value = titleIfEmpty
        }
        _pages.update { current ->
            val combined = current + newPages
            combined.mapIndexed { idx, page -> page.copy(orderIndex = idx) }
        }
    }

    fun addPage(sourcePath: String, autoEnhance: Boolean = true): ScanPage {
        val newPage = ScanPage(
            id = UUID.randomUUID().toString(),
            sourcePath = sourcePath,
            filter = if (autoEnhance) ScanFilter.HIGH_CONTRAST else ScanFilter.ORIGINAL,
            rotationDegrees = 0,
            orderIndex = _pages.value.size
        )
        _pages.update { current -> current + newPage }
        return newPage
    }

    fun getPage(pageId: String): ScanPage? = _pages.value.firstOrNull { it.id == pageId }

    fun updateFilter(pageId: String, filter: ScanFilter) {
        _pages.update { list ->
            list.map { if (it.id == pageId) it.copy(filter = filter) else it }
        }
    }

    fun rotatePage(pageId: String, deltaDegrees: Int) {
        _pages.update { list ->
            list.map {
                if (it.id == pageId) {
                    val next = ((it.rotationDegrees + deltaDegrees) % 360 + 360) % 360
                    it.copy(rotationDegrees = next)
                } else {
                    it
                }
            }
        }
    }

    fun movePage(pageId: String, direction: Int) {
        _pages.update { list ->
            val idx = list.indexOfFirst { it.id == pageId }
            val targetIdx = idx + direction
            if (idx < 0 || targetIdx !in list.indices) return@update list
            val mutable = list.toMutableList()
            val item = mutable.removeAt(idx)
            mutable.add(targetIdx, item)
            mutable.mapIndexed { index, page -> page.copy(orderIndex = index) }
        }
    }

    fun removePage(pageId: String) {
        _pages.update { list ->
            list.filterNot { it.id == pageId }
                .mapIndexed { index, page -> page.copy(orderIndex = index) }
        }
    }

    fun clearSession() {
        _pages.value = emptyList()
        _activeDocumentId.value = null
        _activeDocumentTitle.value = null
    }
}
