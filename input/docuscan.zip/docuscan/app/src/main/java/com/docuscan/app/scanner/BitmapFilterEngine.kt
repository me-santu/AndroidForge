package com.docuscan.app.scanner

import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Canvas
import android.graphics.ColorMatrix
import android.graphics.ColorMatrixColorFilter
import android.graphics.Matrix
import android.graphics.Paint
import android.media.ExifInterface
import com.docuscan.app.domain.model.NormalizedCropRect
import com.docuscan.app.domain.model.ScanFilter
import kotlin.math.abs
import kotlin.math.max
import kotlin.math.roundToInt

data class ImageQualityReport(
    val isBlankOrUniform: Boolean,
    val isLikelyBlurry: Boolean,
    val sharpnessScore: Double
)

object BitmapFilterEngine {

    /**
     * Hard upper bound for decoded camera/gallery images before filters or OCR
     * to prevent OutOfMemoryError on low-RAM Android devices.
     */
    const val MAX_SAFE_IMAGE_DIMENSION: Int = 2560

    fun decodeSampledBitmap(
        filePath: String,
        maxDimension: Int = MAX_SAFE_IMAGE_DIMENSION
    ): Bitmap? {
        val safeMaxDim = maxDimension.coerceIn(256, MAX_SAFE_IMAGE_DIMENSION)
        val options = BitmapFactory.Options().apply { inJustDecodeBounds = true }
        BitmapFactory.decodeFile(filePath, options)
        val rawW = options.outWidth
        val rawH = options.outHeight
        if (rawW <= 0 || rawH <= 0) return null

        var inSampleSize = 1
        val largest = max(rawW, rawH)
        while (largest / inSampleSize > safeMaxDim) {
            inSampleSize *= 2
        }

        val decodeOptions = BitmapFactory.Options().apply {
            this.inSampleSize = inSampleSize
            inPreferredConfig = Bitmap.Config.ARGB_8888
        }
        val decoded = BitmapFactory.decodeFile(filePath, decodeOptions) ?: return null
        val oriented = applyExifOrientation(decoded, filePath)
        return ensureWithinMaxDimension(oriented, safeMaxDim, recycleSourceIfScaled = true)
    }

    /**
     * Ensures [bitmap] never exceeds [maxDimension] on its longest edge.
     * If downscaling occurs and [recycleSourceIfScaled] is true, the original bitmap is recycled immediately.
     */
    fun ensureWithinMaxDimension(
        bitmap: Bitmap,
        maxDimension: Int = MAX_SAFE_IMAGE_DIMENSION,
        recycleSourceIfScaled: Boolean = false
    ): Bitmap {
        val safeMaxDim = maxDimension.coerceIn(256, MAX_SAFE_IMAGE_DIMENSION)
        val largest = max(bitmap.width, bitmap.height)
        if (largest <= safeMaxDim || bitmap.width <= 0 || bitmap.height <= 0) {
            return bitmap
        }
        val scale = safeMaxDim.toFloat() / largest.toFloat()
        val targetW = (bitmap.width * scale).roundToInt().coerceAtLeast(1)
        val targetH = (bitmap.height * scale).roundToInt().coerceAtLeast(1)
        return try {
            val scaled = Bitmap.createScaledBitmap(bitmap, targetW, targetH, true)
            if (recycleSourceIfScaled && scaled !== bitmap && !bitmap.isRecycled) {
                bitmap.recycle()
            }
            scaled
        } catch (_: OutOfMemoryError) {
            bitmap
        }
    }

    /**
     * Prepares a high-contrast grayscale bitmap (100% grayscale + 140% contrast)
     * optimized for Tesseract OCR on Bengali matras and conjunct glyphs.
     * Always returns a newly allocated Bitmap; callers must recycle it in a finally block.
     */
    fun prepareForTesseractOcr(
        source: Bitmap,
        rotationDegrees: Int = 0
    ): Bitmap {
        val normalizedRotation = ((rotationDegrees % 360) + 360) % 360
        var working: Bitmap = source
        var ownsWorking = false
        try {
            if (normalizedRotation != 0) {
                val matrix = Matrix().apply { postRotate(normalizedRotation.toFloat()) }
                val rotated = Bitmap.createBitmap(working, 0, 0, working.width, working.height, matrix, true)
                working = rotated
                ownsWorking = rotated !== source
            }

            val capped = ensureWithinMaxDimension(
                bitmap = working,
                maxDimension = MAX_SAFE_IMAGE_DIMENSION,
                recycleSourceIfScaled = ownsWorking
            )
            if (capped !== working) {
                working = capped
                ownsWorking = true
            }

            val output = Bitmap.createBitmap(working.width, working.height, Bitmap.Config.ARGB_8888)
            val canvas = Canvas(output)
            val paint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
                val contrast = 1.40f
                val translate = (-0.5f * contrast + 0.5f) * 255f
                val colorMatrix = ColorMatrix().apply {
                    setSaturation(0f)
                    postConcat(
                        ColorMatrix(
                            floatArrayOf(
                                contrast, 0f, 0f, 0f, translate,
                                0f, contrast, 0f, 0f, translate,
                                0f, 0f, contrast, 0f, translate,
                                0f, 0f, 0f, 1f, 0f
                            )
                        )
                    )
                }
                colorFilter = ColorMatrixColorFilter(colorMatrix)
            }
            canvas.drawBitmap(working, 0f, 0f, paint)
            return output
        } finally {
            if (ownsWorking && working !== source && !working.isRecycled) {
                working.recycle()
            }
        }
    }

    private fun applyExifOrientation(bitmap: Bitmap, filePath: String): Bitmap {
        val orientation = runCatching {
            ExifInterface(filePath).getAttributeInt(
                ExifInterface.TAG_ORIENTATION,
                ExifInterface.ORIENTATION_NORMAL
            )
        }.getOrDefault(ExifInterface.ORIENTATION_NORMAL)

        val matrix = Matrix()
        when (orientation) {
            ExifInterface.ORIENTATION_ROTATE_90 -> matrix.postRotate(90f)
            ExifInterface.ORIENTATION_ROTATE_180 -> matrix.postRotate(180f)
            ExifInterface.ORIENTATION_ROTATE_270 -> matrix.postRotate(270f)
            ExifInterface.ORIENTATION_FLIP_HORIZONTAL -> matrix.postScale(-1f, 1f)
            ExifInterface.ORIENTATION_FLIP_VERTICAL -> matrix.postScale(1f, -1f)
            ExifInterface.ORIENTATION_TRANSPOSE -> {
                matrix.postRotate(90f)
                matrix.postScale(-1f, 1f)
            }
            ExifInterface.ORIENTATION_TRANSVERSE -> {
                matrix.postRotate(270f)
                matrix.postScale(-1f, 1f)
            }
            else -> return bitmap
        }

        return runCatching {
            val oriented = Bitmap.createBitmap(bitmap, 0, 0, bitmap.width, bitmap.height, matrix, true)
            if (oriented !== bitmap && !bitmap.isRecycled) {
                bitmap.recycle()
            }
            oriented
        }.getOrDefault(bitmap)
    }

    fun computeCenteredAspectCrop(
        imageWidth: Int,
        imageHeight: Int,
        targetAspectRatio: Float,
        fillFraction: Float = 0.88f
    ): NormalizedCropRect {
        if (imageWidth <= 0 || imageHeight <= 0 || targetAspectRatio <= 0f) {
            return NormalizedCropRect(0.06f, 0.12f, 0.94f, 0.88f)
        }
        val safeFill = fillFraction.coerceIn(0.30f, 0.98f)
        val imageAspect = imageWidth.toFloat() / imageHeight.toFloat()
        val normWidth: Float
        val normHeight: Float
        if (imageAspect >= targetAspectRatio) {
            normHeight = safeFill
            normWidth = (normHeight * targetAspectRatio / imageAspect).coerceIn(0.16f, safeFill)
        } else {
            normWidth = safeFill
            normHeight = (normWidth * imageAspect / targetAspectRatio).coerceIn(0.16f, safeFill)
        }
        val left = ((1f - normWidth) / 2f).coerceIn(0f, 0.84f)
        val top = ((1f - normHeight) / 2f).coerceIn(0f, 0.84f)
        return NormalizedCropRect(
            left = left,
            top = top,
            right = (left + normWidth).coerceIn(left + 0.14f, 1f),
            bottom = (top + normHeight).coerceIn(top + 0.14f, 1f)
        ).sanitized()
    }

    fun applyTransformAndFilter(
        source: Bitmap,
        rotationDegrees: Int,
        filter: ScanFilter
    ): Bitmap = cropAndTransform(
        source = source,
        cropRect = NormalizedCropRect(),
        rotationDegrees = rotationDegrees,
        filter = filter
    )

    fun cropAndTransform(
        source: Bitmap,
        cropRect: NormalizedCropRect,
        rotationDegrees: Int,
        filter: ScanFilter
    ): Bitmap {
        var current: Bitmap = ensureWithinMaxDimension(
            bitmap = source,
            maxDimension = MAX_SAFE_IMAGE_DIMENSION,
            recycleSourceIfScaled = false
        )

        try {
            if (rotationDegrees % 360 != 0) {
                val matrix = Matrix().apply { postRotate((rotationDegrees % 360).toFloat()) }
                val rotated = Bitmap.createBitmap(current, 0, 0, current.width, current.height, matrix, true)
                if (current !== source && rotated !== current && !current.isRecycled) {
                    current.recycle()
                }
                current = rotated
            }

            val cleanCrop = cropRect.sanitized()
            if (!cleanCrop.isFullFrame && current.width >= 20 && current.height >= 20) {
                val cropX = (cleanCrop.left * current.width).roundToInt().coerceIn(0, current.width - 10)
                val cropY = (cleanCrop.top * current.height).roundToInt().coerceIn(0, current.height - 10)
                val cropW = ((cleanCrop.right - cleanCrop.left) * current.width).roundToInt()
                    .coerceIn(10, current.width - cropX)
                val cropH = ((cleanCrop.bottom - cleanCrop.top) * current.height).roundToInt()
                    .coerceIn(10, current.height - cropY)
                val cropped = Bitmap.createBitmap(current, cropX, cropY, cropW, cropH)
                if (current !== source && cropped !== current && !current.isRecycled) {
                    current.recycle()
                }
                current = cropped
            }

            if (filter == ScanFilter.ORIGINAL) {
                return current
            }

            val filtered = Bitmap.createBitmap(current.width, current.height, Bitmap.Config.ARGB_8888)
            try {
                val canvas = Canvas(filtered)
                val paint = Paint(Paint.ANTI_ALIAS_FLAG)
                val colorMatrix = when (filter) {
                    ScanFilter.ORIGINAL -> ColorMatrix()
                    ScanFilter.DOCUMENT_BW -> {
                        ColorMatrix().apply {
                            setSaturation(0f)
                            val contrast = 1.45f
                            val translate = (-0.5f * contrast + 0.5f) * 255f
                            postConcat(
                                ColorMatrix(
                                    floatArrayOf(
                                        contrast, 0f, 0f, 0f, translate,
                                        0f, contrast, 0f, 0f, translate,
                                        0f, 0f, contrast, 0f, translate,
                                        0f, 0f, 0f, 1f, 0f
                                    )
                                )
                            )
                        }
                    }
                    ScanFilter.HIGH_CONTRAST -> {
                        val contrast = 1.3f
                        val translate = (-0.5f * contrast + 0.5f) * 255f + 10f
                        ColorMatrix(
                            floatArrayOf(
                                contrast, 0f, 0f, 0f, translate,
                                0f, contrast, 0f, 0f, translate,
                                0f, 0f, contrast, 0f, translate,
                                0f, 0f, 0f, 1f, 0f
                            )
                        )
                    }
                    ScanFilter.WARM_PAPER -> {
                        ColorMatrix(
                            floatArrayOf(
                                1.06f, 0f, 0f, 0f, 8f,
                                0f, 1.02f, 0f, 0f, 4f,
                                0f, 0f, 0.90f, 0f, -4f,
                                0f, 0f, 0f, 1f, 0f
                            )
                        )
                    }
                }
                paint.colorFilter = ColorMatrixColorFilter(colorMatrix)
                canvas.drawBitmap(current, 0f, 0f, paint)
            } catch (t: Throwable) {
                if (!filtered.isRecycled) filtered.recycle()
                throw t
            }

            if (current !== source && !current.isRecycled) {
                current.recycle()
            }
            return filtered
        } catch (t: Throwable) {
            if (current !== source && !current.isRecycled) {
                current.recycle()
            }
            throw t
        }
    }

    fun assessImageQuality(bitmap: Bitmap): ImageQualityReport {
        val maxDim = 220
        val scaleRatio = minOf(
            1f,
            maxDim.toFloat() / max(bitmap.width, bitmap.height).coerceAtLeast(1)
        )
        val sampleW = (bitmap.width * scaleRatio).roundToInt().coerceAtLeast(1)
        val sampleH = (bitmap.height * scaleRatio).roundToInt().coerceAtLeast(1)
        val scaled = if (sampleW != bitmap.width || sampleH != bitmap.height) {
            Bitmap.createScaledBitmap(bitmap, sampleW, sampleH, false)
        } else {
            bitmap
        }

        val count = sampleW * sampleH
        val pixels = IntArray(count)
        try {
            scaled.getPixels(pixels, 0, sampleW, 0, 0, sampleW, sampleH)
        } finally {
            if (scaled !== bitmap && !scaled.isRecycled) {
                scaled.recycle()
            }
        }

        val luma = DoubleArray(count)
        var sum = 0.0
        var minLuma = 255.0
        var maxLuma = 0.0
        for (i in 0 until count) {
            val px = pixels[i]
            val r = (px shr 16) and 0xFF
            val g = (px shr 8) and 0xFF
            val b = px and 0xFF
            val y = 0.299 * r + 0.587 * g + 0.114 * b
            luma[i] = y
            sum += y
            if (y < minLuma) minLuma = y
            if (y > maxLuma) maxLuma = y
        }
        val mean = sum / count.coerceAtLeast(1)
        var varSum = 0.0
        for (i in 0 until count) {
            val d = luma[i] - mean
            varSum += d * d
        }
        val variance = varSum / count.coerceAtLeast(1)
        val contrastRange = maxLuma - minLuma
        val isBlank = variance < 10.0 && contrastRange < 28.0

        var edgeSum = 0.0
        var edgeMax = 0.0
        var edgeSamples = 0
        for (y in 1 until sampleH - 1) {
            for (x in 1 until sampleW - 1) {
                val idx = y * sampleW + x
                val gx = abs(luma[idx + 1] - luma[idx - 1])
                val gy = abs(luma[idx + sampleW] - luma[idx - sampleW])
                val mag = gx + gy
                edgeSum += mag
                if (mag > edgeMax) edgeMax = mag
                edgeSamples++
            }
        }
        val avgEdge = if (edgeSamples > 0) edgeSum / edgeSamples else 0.0
        val isBlurry = !isBlank && edgeMax < 42.0 && avgEdge < 6.0

        return ImageQualityReport(
            isBlankOrUniform = isBlank,
            isLikelyBlurry = isBlurry,
            sharpnessScore = edgeMax
        )
    }
}
