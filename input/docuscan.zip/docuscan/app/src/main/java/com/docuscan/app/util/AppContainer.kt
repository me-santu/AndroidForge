package com.docuscan.app.util

import android.content.Context
import com.docuscan.app.data.datastore.UserPreferencesDataSource
import com.docuscan.app.database.DocuScanDatabase
import com.docuscan.app.domain.repository.DocumentRepository
import com.docuscan.app.domain.repository.SettingsRepository
import com.docuscan.app.ocr.OcrEngine
import com.docuscan.app.pdf.PdfAdvancedEngine
import com.docuscan.app.pdf.PdfConversionEngine
import com.docuscan.app.pdf.PdfGenerator
import com.docuscan.app.pdf.PdfRendererHelper
import com.docuscan.app.repository.LocalDocumentRepository
import com.docuscan.app.repository.LocalSettingsRepository
import com.docuscan.app.scanner.DocumentScannerGateway
import com.docuscan.app.scanner.MlKitDocumentScannerManager
import com.docuscan.app.scanner.ScanSessionManager
import com.docuscan.app.security.SecurityManager

class AppContainer(context: Context) {
    private val appContext: Context = context.applicationContext
    private val database: DocuScanDatabase by lazy { DocuScanDatabase.getInstance(appContext) }
    private val prefsDataSource: UserPreferencesDataSource by lazy { UserPreferencesDataSource(appContext) }

    val fileManager: LocalFileManager by lazy { LocalFileManager(appContext) }
    val pdfGenerator: PdfGenerator by lazy { PdfGenerator(context = appContext) }
    val pdfRendererHelper: PdfRendererHelper by lazy { PdfRendererHelper(context = appContext) }
    val pdfAdvancedEngine: PdfAdvancedEngine by lazy { PdfAdvancedEngine(context = appContext) }
    val pdfConversionEngine: PdfConversionEngine by lazy {
        PdfConversionEngine(context = appContext, rendererHelper = pdfRendererHelper)
    }
    val scanSessionManager: ScanSessionManager by lazy { ScanSessionManager() }
    val documentScannerGateway: DocumentScannerGateway by lazy { MlKitDocumentScannerManager(appContext) }
    val ocrEngine: OcrEngine by lazy { OcrEngine(context = appContext) }
    val securityManager: SecurityManager by lazy { SecurityManager(appContext) }

    val documentRepository: DocumentRepository by lazy {
        LocalDocumentRepository(
            documentDao = database.documentDao(),
            folderDao = database.folderDao(),
            signatureDao = database.signatureDao(),
            fileManager = fileManager,
            pdfGenerator = pdfGenerator,
            deletedDocumentDao = database.deletedDocumentDao(),
            securityManager = securityManager,
            pdfAdvancedEngine = pdfAdvancedEngine,
            pdfConversionEngine = pdfConversionEngine
        )
    }

    val settingsRepository: SettingsRepository by lazy {
        LocalSettingsRepository(prefsDataSource)
    }
}
