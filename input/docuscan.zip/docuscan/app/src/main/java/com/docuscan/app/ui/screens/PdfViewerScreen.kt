package com.docuscan.app.ui.screens

import android.net.Uri
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectTransformGestures
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.WindowInsetsSides
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.only
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.safeDrawing
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import com.docuscan.app.ui.icons.LucideIcons
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.AssistChip
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Checkbox
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.SnackbarHost
import androidx.compose.material3.SnackbarHostState
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.minimumInteractiveComponentSize
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.unit.dp
import com.docuscan.app.domain.model.DocumentFileType
import com.docuscan.app.ui.components.DocuScanCard
import com.docuscan.app.ui.components.DocuScanTopBar
import com.docuscan.app.ui.components.ErrorStateView
import com.docuscan.app.ui.components.LoadingStateView
import com.docuscan.app.ui.viewmodel.ViewerUiState
import com.docuscan.app.util.FormatUtils

@Composable
fun PdfViewerScreen(
    documentId: Long,
    uiState: ViewerUiState,
    statusMessage: String?,
    onClearStatusMessage: () -> Unit,
    onLoadDocument: (Long) -> Unit,
    onUnlockWithPassword: (String) -> Unit,
    onSelectPage: (Int) -> Unit,
    onToggleBookmark: (Int) -> Unit,
    onSearchText: (String) -> Unit,
    onClearSearch: () -> Unit,
    onAddAnnotation: (noteText: String, addHighlightBar: Boolean, onNewDocCreated: (Long) -> Unit) -> Unit,
    onExportToUri: (Uri) -> Unit,
    onPrint: () -> Unit,
    onShare: () -> Unit,
    onOpenOcr: (Long) -> Unit,
    onOpenSignPdf: (Long) -> Unit,
    onOpenDocument: (Long) -> Unit,
    onDeleteToTrash: (Long) -> Unit,
    onBack: () -> Unit
) {
    val context = LocalContext.current
    val snackbarHostState = remember { SnackbarHostState() }

    var showSearchBar by remember { mutableStateOf(false) }
    var searchInput by remember { mutableStateOf("") }
    var showAnnotateDialog by remember { mutableStateOf(false) }
    var showOverflowMenu by remember { mutableStateOf(false) }
    var passwordInput by remember { mutableStateOf("") }

    var zoomScale by remember(documentId) { mutableFloatStateOf(1f) }
    var panOffset by remember(documentId) { mutableStateOf(Offset.Zero) }

    val exportSafLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.CreateDocument("application/pdf")
    ) { uri ->
        if (uri != null) {
            onExportToUri(uri)
        }
    }

    LaunchedEffect(documentId) {
        onLoadDocument(documentId)
    }

    LaunchedEffect(statusMessage) {
        if (!statusMessage.isNullOrBlank()) {
            snackbarHostState.showSnackbar(statusMessage)
            onClearStatusMessage()
        }
    }

    val title = when (uiState) {
        is ViewerUiState.Ready -> uiState.document.title
        is ViewerUiState.PasswordRequired -> uiState.document.title
        else -> "Document Viewer"
    }
    val subtitle = (uiState as? ViewerUiState.Ready)?.let {
        "${it.document.fileType.badge} · ${FormatUtils.formatBytes(it.document.sizeBytes)}"
    }

    Scaffold(
        modifier = Modifier.fillMaxSize(),
        containerColor = MaterialTheme.colorScheme.background,
        contentWindowInsets = WindowInsets.safeDrawing.only(
            WindowInsetsSides.Bottom + WindowInsetsSides.Horizontal
        ),
        snackbarHost = { SnackbarHost(snackbarHostState) },
        topBar = {
            DocuScanTopBar(
                title = title,
                subtitle = subtitle,
                onBack = onBack,
                actions = {
                    if (uiState is ViewerUiState.Ready) {
                        val isBookmarked = uiState.currentPageIndex in uiState.bookmarkedPages
                        if (uiState.document.fileType != DocumentFileType.IMAGE) {
                            IconButton(
                                onClick = { showSearchBar = !showSearchBar },
                                modifier = Modifier
                                    .minimumInteractiveComponentSize()
                                    .testTag("viewer_search_btn")
                            ) {
                                Icon(LucideIcons.Search, contentDescription = "Search PDF Text")
                            }
                            IconButton(
                                onClick = { onToggleBookmark(uiState.currentPageIndex) },
                                modifier = Modifier
                                    .minimumInteractiveComponentSize()
                                    .testTag("viewer_bookmark_btn")
                            ) {
                                Icon(
                                    imageVector = if (isBookmarked) LucideIcons.BookmarkFilled else LucideIcons.Bookmark,
                                    contentDescription = if (isBookmarked) "Remove Bookmark" else "Bookmark Page",
                                    tint = if (isBookmarked) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.onBackground
                                )
                            }
                        }
                        IconButton(
                            onClick = onShare,
                            modifier = Modifier
                                .minimumInteractiveComponentSize()
                                .testTag("viewer_share_btn")
                        ) {
                            Icon(LucideIcons.Share2, contentDescription = "Share Document")
                        }
                        Box {
                            IconButton(
                                onClick = { showOverflowMenu = true },
                                modifier = Modifier
                                    .minimumInteractiveComponentSize()
                                    .testTag("viewer_more_btn")
                            ) {
                                Icon(LucideIcons.MoreVertical, contentDescription = "More viewer actions")
                            }
                            DropdownMenu(
                                expanded = showOverflowMenu,
                                onDismissRequest = { showOverflowMenu = false }
                            ) {
                                if (uiState.document.fileType != DocumentFileType.IMAGE) {
                                    DropdownMenuItem(
                                        text = { Text("Highlight & Add Note") },
                                        leadingIcon = { Icon(LucideIcons.FilePen, contentDescription = null) },
                                        onClick = {
                                            showOverflowMenu = false
                                            showAnnotateDialog = true
                                        }
                                    )
                                    DropdownMenuItem(
                                        text = { Text("Print PDF") },
                                        leadingIcon = { Icon(LucideIcons.Printer, contentDescription = null) },
                                        onClick = {
                                            showOverflowMenu = false
                                            onPrint()
                                        }
                                    )
                                    DropdownMenuItem(
                                        text = { Text("Add Signature") },
                                        leadingIcon = { Icon(LucideIcons.PenTool, contentDescription = null) },
                                        onClick = {
                                            showOverflowMenu = false
                                            onOpenSignPdf(uiState.document.id)
                                        }
                                    )
                                    DropdownMenuItem(
                                        text = { Text("Save Copy (SAF)") },
                                        leadingIcon = { Icon(LucideIcons.Download, contentDescription = null) },
                                        onClick = {
                                            showOverflowMenu = false
                                            exportSafLauncher.launch("${uiState.document.title}.pdf")
                                        }
                                    )
                                }
                                DropdownMenuItem(
                                    text = { Text("Extract Text (OCR)") },
                                    leadingIcon = { Icon(LucideIcons.Type, contentDescription = null) },
                                    onClick = {
                                        showOverflowMenu = false
                                        onOpenOcr(uiState.document.id)
                                    }
                                )
                                DropdownMenuItem(
                                    text = { Text("Move to Recycle Bin", color = MaterialTheme.colorScheme.error) },
                                    leadingIcon = {
                                        Icon(
                                            LucideIcons.Trash2,
                                            contentDescription = null,
                                            tint = MaterialTheme.colorScheme.error
                                        )
                                    },
                                    onClick = {
                                        showOverflowMenu = false
                                        onDeleteToTrash(uiState.document.id)
                                        onBack()
                                    }
                                )
                            }
                        }
                    }
                }
            )
        }
    ) { innerPadding ->
        Box(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
                .padding(horizontal = 16.dp, vertical = 8.dp),
            contentAlignment = Alignment.Center
        ) {
            when (uiState) {
                is ViewerUiState.Loading -> LoadingStateView("Rendering document...")
                is ViewerUiState.Error -> ErrorStateView(message = uiState.message)
                is ViewerUiState.PasswordRequired -> {
                    DocuScanCard(
                        modifier = Modifier.fillMaxWidth(),
                        highlighted = true
                    ) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(10.dp)
                        ) {
                            Icon(
                                imageVector = LucideIcons.Lock,
                                contentDescription = "Encrypted PDF",
                                tint = MaterialTheme.colorScheme.primary
                            )
                            Text("Password Protected PDF", style = MaterialTheme.typography.titleMedium)
                        }
                        Spacer(modifier = Modifier.size(10.dp))
                        Text(
                            text = "Enter the password for '${uiState.document.title}' to view pages.",
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                        Spacer(modifier = Modifier.size(10.dp))
                        OutlinedTextField(
                            value = passwordInput,
                            onValueChange = { passwordInput = it },
                            label = { Text("PDF Password") },
                            visualTransformation = PasswordVisualTransformation(),
                            singleLine = true,
                            isError = uiState.errorMessage != null,
                            modifier = Modifier
                                .fillMaxWidth()
                                .testTag("viewer_password_input")
                        )
                        if (uiState.errorMessage != null) {
                            Spacer(modifier = Modifier.size(6.dp))
                            Text(
                                text = uiState.errorMessage,
                                style = MaterialTheme.typography.bodySmall,
                                color = MaterialTheme.colorScheme.error
                            )
                        }
                        Spacer(modifier = Modifier.size(12.dp))
                        Button(
                            onClick = { onUnlockWithPassword(passwordInput) },
                            enabled = passwordInput.isNotEmpty(),
                            colors = ButtonDefaults.buttonColors(
                                containerColor = MaterialTheme.colorScheme.primary,
                                contentColor = MaterialTheme.colorScheme.onPrimary
                            ),
                            modifier = Modifier
                                .fillMaxWidth()
                                .minimumInteractiveComponentSize()
                                .testTag("viewer_unlock_btn")
                        ) {
                            Text("Unlock PDF")
                        }
                    }
                }
                is ViewerUiState.Ready -> {
                    Column(
                        modifier = Modifier.fillMaxSize(),
                        verticalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        if (uiState.isProcessingAction) {
                            LinearProgressIndicator(modifier = Modifier.fillMaxWidth())
                        }

                        if (showSearchBar) {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.spacedBy(8.dp)
                            ) {
                                OutlinedTextField(
                                    value = searchInput,
                                    onValueChange = { searchInput = it },
                                    label = { Text("Search embedded text") },
                                    singleLine = true,
                                    trailingIcon = {
                                        IconButton(
                                            onClick = {
                                                searchInput = ""
                                                onClearSearch()
                                                showSearchBar = false
                                            }
                                        ) {
                                            Icon(LucideIcons.X, contentDescription = "Close search")
                                        }
                                    },
                                    modifier = Modifier
                                        .weight(1f)
                                        .testTag("viewer_search_input")
                                )
                                Button(
                                    onClick = { onSearchText(searchInput) },
                                    enabled = searchInput.isNotBlank(),
                                    modifier = Modifier.minimumInteractiveComponentSize()
                                ) {
                                    Text("Find")
                                }
                            }
                        }

                        if (uiState.searchMatches.isNotEmpty()) {
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .horizontalScroll(rememberScrollState()),
                                horizontalArrangement = Arrangement.spacedBy(8.dp)
                            ) {
                                uiState.searchMatches.forEach { match ->
                                    AssistChip(
                                        onClick = { onSelectPage(match.pageIndex) },
                                        label = { Text("p.${match.pageIndex + 1} (${match.matchCount})") }
                                    )
                                }
                            }
                        }

                        if (uiState.bookmarkedPages.isNotEmpty()) {
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .horizontalScroll(rememberScrollState()),
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.spacedBy(8.dp)
                            ) {
                                Text(
                                    text = "Bookmarks:",
                                    style = MaterialTheme.typography.labelMedium,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant
                                )
                                uiState.bookmarkedPages.forEach { pageIdx ->
                                    AssistChip(
                                        onClick = { onSelectPage(pageIdx) },
                                        label = { Text("Page ${pageIdx + 1}") },
                                        leadingIcon = {
                                            Icon(
                                                LucideIcons.BookmarkFilled,
                                                contentDescription = null,
                                                tint = MaterialTheme.colorScheme.primary,
                                                modifier = Modifier.size(16.dp)
                                            )
                                        }
                                    )
                                }
                            }
                        }

                        // Zoomable single-page viewport
                        Box(
                            modifier = Modifier
                                .weight(1f)
                                .fillMaxWidth()
                                .clip(MaterialTheme.shapes.large)
                                .background(Color(0xFF1A1A1A))
                                .border(1.dp, MaterialTheme.colorScheme.outline, MaterialTheme.shapes.large)
                                .pointerInput(uiState.currentPageIndex) {
                                    detectTransformGestures { _, pan, zoom, _ ->
                                        val newScale = (zoomScale * zoom).coerceIn(1f, 4f)
                                        zoomScale = newScale
                                        panOffset = if (newScale <= 1.02f) {
                                            Offset.Zero
                                        } else {
                                            panOffset + pan
                                        }
                                    }
                                },
                            contentAlignment = Alignment.Center
                        ) {
                            val bmp = uiState.pageBitmap
                            if (bmp != null) {
                                Image(
                                    bitmap = bmp.asImageBitmap(),
                                    contentDescription = "Page ${uiState.currentPageIndex + 1}",
                                    contentScale = ContentScale.Fit,
                                    modifier = Modifier
                                        .fillMaxSize()
                                        .padding(10.dp)
                                        .graphicsLayer {
                                            scaleX = zoomScale
                                            scaleY = zoomScale
                                            translationX = panOffset.x
                                            translationY = panOffset.y
                                        }
                                )
                            } else {
                                ErrorStateView("Could not render page preview.")
                            }

                            // Compact Zoom Controls overlay
                            Surface(
                                shape = RoundedCornerShape(12.dp),
                                color = MaterialTheme.colorScheme.surface.copy(alpha = 0.88f),
                                border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline),
                                modifier = Modifier
                                    .align(Alignment.BottomEnd)
                                    .padding(10.dp)
                            ) {
                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    IconButton(
                                        onClick = {
                                            zoomScale = (zoomScale - 0.5f).coerceAtLeast(1f)
                                            if (zoomScale <= 1.02f) panOffset = Offset.Zero
                                        },
                                        modifier = Modifier.size(40.dp)
                                    ) {
                                        Icon(LucideIcons.ZoomOut, contentDescription = "Zoom out", modifier = Modifier.size(18.dp))
                                    }
                                    Text(
                                        text = "${(zoomScale * 100).toInt()}%",
                                        style = MaterialTheme.typography.labelSmall,
                                        modifier = Modifier
                                            .clickable {
                                                zoomScale = 1f
                                                panOffset = Offset.Zero
                                            }
                                            .padding(horizontal = 4.dp)
                                    )
                                    IconButton(
                                        onClick = { zoomScale = (zoomScale + 0.5f).coerceAtMost(4f) },
                                        modifier = Modifier.size(40.dp)
                                    ) {
                                        Icon(LucideIcons.ZoomIn, contentDescription = "Zoom in", modifier = Modifier.size(18.dp))
                                    }
                                }
                            }
                        }

                        // Page Pager Footer
                        Surface(
                            shape = RoundedCornerShape(16.dp),
                            color = MaterialTheme.colorScheme.surfaceContainer,
                            border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(horizontal = 12.dp, vertical = 8.dp),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                OutlinedButton(
                                    onClick = {
                                        zoomScale = 1f
                                        panOffset = Offset.Zero
                                        onSelectPage(uiState.currentPageIndex - 1)
                                    },
                                    enabled = uiState.currentPageIndex > 0,
                                    modifier = Modifier.minimumInteractiveComponentSize()
                                ) {
                                    Icon(LucideIcons.ChevronLeft, contentDescription = "Previous page")
                                    Spacer(modifier = Modifier.size(4.dp))
                                    Text("Prev")
                                }

                                Text(
                                    text = "Page ${uiState.currentPageIndex + 1} / ${uiState.totalPages}",
                                    style = MaterialTheme.typography.titleSmall,
                                    color = MaterialTheme.colorScheme.primary
                                )

                                OutlinedButton(
                                    onClick = {
                                        zoomScale = 1f
                                        panOffset = Offset.Zero
                                        onSelectPage(uiState.currentPageIndex + 1)
                                    },
                                    enabled = uiState.currentPageIndex < uiState.totalPages - 1,
                                    modifier = Modifier.minimumInteractiveComponentSize()
                                ) {
                                    Text("Next")
                                    Spacer(modifier = Modifier.size(4.dp))
                                    Icon(LucideIcons.ChevronRight, contentDescription = "Next page")
                                }
                            }
                        }
                    }
                }
            }
        }
    }

    if (showAnnotateDialog) {
        var noteText by remember { mutableStateOf("") }
        var includeHighlightBar by remember { mutableStateOf(true) }

        AlertDialog(
            onDismissRequest = { showAnnotateDialog = false },
            title = { Text("Highlight & Annotate Page") },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    Text(
                        text = "Saves a new annotated PDF copy while keeping your original file intact.",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                    OutlinedTextField(
                        value = noteText,
                        onValueChange = { noteText = it },
                        label = { Text("Annotation / Note text") },
                        modifier = Modifier.fillMaxWidth()
                    )
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clickable { includeHighlightBar = !includeHighlightBar },
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Checkbox(
                            checked = includeHighlightBar,
                            onCheckedChange = { includeHighlightBar = it }
                        )
                        Text("Include yellow PDF highlight markup", style = MaterialTheme.typography.bodyMedium)
                    }
                }
            },
            confirmButton = {
                TextButton(
                    enabled = noteText.isNotBlank() || includeHighlightBar,
                    onClick = {
                        showAnnotateDialog = false
                        onAddAnnotation(noteText.trim(), includeHighlightBar) { newDocId ->
                            onOpenDocument(newDocId)
                        }
                    }
                ) { Text("Save Copy") }
            },
            dismissButton = {
                TextButton(onClick = { showAnnotateDialog = false }) { Text("Cancel") }
            }
        )
    }
}
