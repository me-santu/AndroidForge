package com.docuscan.app.domain.model

enum class ThemeMode(val label: String) {
    DARK("Dark"),
    LIGHT("Light"),
    SYSTEM("System")
}

enum class AppLanguage(val code: String, val nativeLabel: String, val englishLabel: String) {
    ENGLISH("en", "English", "English"),
    HINDI("hi", "हिन्दी", "Hindi"),
    BENGALI("bn", "বাংলা", "Bengali")
}

enum class AppFontStyle(val label: String, val subtitle: String) {
    DEFAULT("Default", "Outfit & DM Sans"),
    POPPINS("Poppins", "Geometric modern sans"),
    LEELAWADI("Leelawadi", "Clean humanist sans")
}

enum class ScanQuality(val label: String, val jpegQuality: Int, val maxDimension: Int) {
    STANDARD("Standard (Fast)", 80, 1440),
    HIGH("High (Balanced)", 92, 2048),
    ULTRA("Ultra (Print Ready)", 98, 2800)
}

enum class DocumentFileType(val badge: String) {
    PDF("PDF"),
    IMAGE("IMG"),
    ID_CARD("ID")
}

enum class ScanFilter(val label: String) {
    ORIGINAL("Original"),
    DOCUMENT_BW("Document B&W"),
    HIGH_CONTRAST("Crisp Contrast"),
    WARM_PAPER("Warm Paper")
}

enum class PdfPageSize(val label: String, val widthPt: Int, val heightPt: Int) {
    A4("A4 (210 × 297 mm)", 595, 842),
    A5("A5 (148 × 210 mm)", 420, 595),
    LETTER("US Letter (8.5 × 11 in)", 612, 792),
    CUSTOM("Custom Size", 595, 842),
    FIT_IMAGE("Fit to Image", 0, 0)
}

enum class PdfOrientation(val label: String) {
    PORTRAIT("Portrait"),
    LANDSCAPE("Landscape")
}

enum class PdfCompressionLevel(
    val label: String,
    val jpegQuality: Float,
    val maxDimension: Int
) {
    LOW("Low Compression (Best Quality)", 0.86f, 1800),
    MEDIUM("Balanced Compression", 0.65f, 1400),
    HIGH("High Compression (Smallest File)", 0.42f, 1024)
}

enum class DocumentSortOption(val label: String) {
    DATE_DESC("Newest First"),
    DATE_ASC("Oldest First"),
    NAME_ASC("Name (A–Z)"),
    SIZE_DESC("Largest First")
}

enum class DocumentViewMode {
    LIST,
    GRID
}

enum class IdDocumentType(
    val displayName: String,
    val subtitle: String,
    val requiresBackSide: Boolean,
    val backSlotLabel: String,
    val aspectRatio: Float
) {
    AADHAAR(
        displayName = "Aadhaar",
        subtitle = "Front & Back sides",
        requiresBackSide = true,
        backSlotLabel = "Back Side (Recommended)",
        aspectRatio = 1.586f
    ),
    PAN(
        displayName = "PAN",
        subtitle = "Front card & optional back",
        requiresBackSide = false,
        backSlotLabel = "Back Side (Optional)",
        aspectRatio = 1.586f
    ),
    PASSPORT(
        displayName = "Passport",
        subtitle = "Bio page & optional address page",
        requiresBackSide = false,
        backSlotLabel = "Second / Address Page (Optional)",
        aspectRatio = 1.42f
    ),
    DRIVING_LICENCE(
        displayName = "Driving Licence",
        subtitle = "Front & Back sides",
        requiresBackSide = true,
        backSlotLabel = "Back Side (Recommended)",
        aspectRatio = 1.586f
    ),
    VOTER_ID(
        displayName = "Voter ID",
        subtitle = "Front & Back sides",
        requiresBackSide = true,
        backSlotLabel = "Back Side (Recommended)",
        aspectRatio = 1.586f
    )
}

enum class PdfImageFormat(val extension: String, val mimeType: String, val label: String) {
    JPG("jpg", "image/jpeg", "JPG (Smaller)"),
    PNG("png", "image/png", "PNG (Lossless)")
}

enum class PageNumberPosition(val label: String) {
    BOTTOM_CENTER("Bottom Center"),
    BOTTOM_RIGHT("Bottom Right"),
    BOTTOM_LEFT("Bottom Left"),
    TOP_CENTER("Top Center"),
    TOP_RIGHT("Top Right")
}

enum class PageNumberFormat(val label: String) {
    PAGE_X_OF_N("Page 1 of N"),
    X_SLASH_N("1 / N"),
    X_ONLY("1")
}


