package com.docuscan.app.repository

import android.graphics.Bitmap
import android.net.Uri
import com.docuscan.app.data.mapper.toDomain
import com.docuscan.app.database.dao.DeletedDocumentDao
import com.docuscan.app.database.dao.DocumentDao
import com.docuscan.app.database.dao.FolderDao
import com.docuscan.app.database.dao.SignatureDao
import com.docuscan.app.database.entity.DeletedDocumentEntity
import com.docuscan.app.database.entity.DocumentEntity
import com.docuscan.app.database.entity.DocumentPageEntity
import com.docuscan.app.database.entity.FolderEntity
import com.docuscan.app.database.entity.SignatureEntity
import com.docuscan.app.domain.model.CacheSummary
import com.docuscan.app.domain.model.DeletedDocumentItem
import com.docuscan.app.domain.model.DocumentFileType
import com.docuscan.app.domain.model.DocumentItem
import com.docuscan.app.domain.model.FolderItem
import com.docuscan.app.domain.model.IdDocumentType
import com.docuscan.app.domain.model.IdSideScanState
import com.docuscan.app.domain.model.PageNumberFormat
import com.docuscan.app.domain.model.PageNumberPosition
import com.docuscan.app.domain.model.PdfCompressionLevel
import com.docuscan.app.domain.model.PdfCreationOptions
import com.docuscan.app.domain.model.PdfDocumentInfo
import com.docuscan.app.domain.model.PdfDocxConversionResult
import com.docuscan.app.domain.model.PdfImageFormat
import com.docuscan.app.domain.model.PdfImagesExportResult
import com.docuscan.app.domain.model.PdfOrientation
import com.docuscan.app.domain.model.PdfPageSize
import com.docuscan.app.domain.model.PdfReduceSizeResult
import com.docuscan.app.domain.model.PdfRepairResult
import com.docuscan.app.domain.model.PdfSearchMatch
import com.docuscan.app.domain.model.PdfTextExtractionResult
import com.docuscan.app.domain.model.ScanFilter
import com.docuscan.app.domain.model.ScanPage
import com.docuscan.app.domain.model.ScanQuality
import com.docuscan.app.domain.model.SignatureItem
import com.docuscan.app.domain.model.SignaturePlacement
import com.docuscan.app.domain.model.StorageSummary
import com.docuscan.app.domain.model.WatermarkRemovalResult
import com.docuscan.app.domain.repository.DocumentRepository
import com.docuscan.app.pdf.PdfAdvancedEngine
import com.docuscan.app.pdf.PdfConversionEngine
import com.docuscan.app.pdf.PdfGenerator
import com.docuscan.app.pdf.PdfRendererHelper
import com.docuscan.app.pdf.PdfValidationOutcome
import com.docuscan.app.scanner.BitmapFilterEngine
import com.docuscan.app.security.SecurityManager
import com.docuscan.app.util.LocalFileManager
import kotlinx.coroutines.CoroutineDispatcher
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.flow.flowOf
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.io.FileOutputStream
import java.util.UUID

class LocalDocumentRepository(
    private val documentDao: DocumentDao,
    private val folderDao: FolderDao,
    private val signatureDao: SignatureDao,
    private val fileManager: LocalFileManager,
    private val pdfGenerator: PdfGenerator,
    private val deletedDocumentDao: DeletedDocumentDao? = null,
    private val ioDispatcher: CoroutineDispatcher = Dispatchers.IO,
    private val securityManager: SecurityManager? = null,
    private val pdfAdvancedEngine: PdfAdvancedEngine = PdfAdvancedEngine(ioDispatcher = ioDispatcher),
    private val pdfConversionEngine: PdfConversionEngine = PdfConversionEngine(
        rendererHelper = PdfRendererHelper(ioDispatcher = ioDispatcher),
        ioDispatcher = ioDispatcher
    )
) : DocumentRepository {

    private val toolsOps: PdfToolsOperations by lazy {
        PdfToolsOperations(
            documentDao = documentDao,
            fileManager = fileManager,
            pdfAdvancedEngine = pdfAdvancedEngine,
            pdfConversionEngine = pdfConversionEngine,
            securityManager = securityManager,
            requirePdfSource = ::requirePdfSource,
            insertDerivedDocument = ::insertDerivedDocument,
            getDocumentById = ::getDocumentById
        )
    }

    override fun observeActiveDocuments(): Flow<List<DocumentItem>> =
        combine(
            documentDao.observeActiveDocuments(),
            folderDao.observeAllFolders()
        ) { docs, folders ->
            val folderNames = folders.associate { it.id to it.name }
            docs.map { it.toDomain(folderName = it.folderId?.let(folderNames::get)) }
        }

    override fun observeRecentDocuments(limit: Int): Flow<List<DocumentItem>> =
        combine(
            documentDao.observeRecentDocuments(limit),
            folderDao.observeAllFolders()
        ) { docs, folders ->
            val folderNames = folders.associate { it.id to it.name }
            docs.map { it.toDomain(folderName = it.folderId?.let(folderNames::get)) }
        }

    override fun observeTrashDocuments(): Flow<List<DocumentItem>> =
        documentDao.observeTrashDocuments().map { list -> list.map { it.toDomain() } }

    override fun observeDeletedDocuments(): Flow<List<DeletedDocumentItem>> =
        deletedDocumentDao?.observeDeletedDocuments()?.map { list -> list.map { it.toDomain() } }
            ?: flowOf(emptyList())

    override fun observeFolders(): Flow<List<FolderItem>> =
        combine(
            folderDao.observeAllFolders(),
            documentDao.observeActiveDocuments()
        ) { folders, docs ->
            val counts = docs.groupingBy { it.folderId }.eachCount()
            folders.map { it.toDomain(documentCount = counts[it.id] ?: 0) }
        }

    override fun observeSignatures(): Flow<List<SignatureItem>> =
        signatureDao.observeSignatures().map { list -> list.map { it.toDomain() } }

    override fun observeStorageSummary(): Flow<StorageSummary> =
        combine(
            documentDao.observeActiveDocuments(),
            documentDao.observeTrashDocuments(),
            folderDao.observeAllFolders(),
            signatureDao.observeSignatures()
        ) { activeDocs, trashDocs, folders, signatures ->
            val totalDbBytes = activeDocs.sumOf { it.sizeBytes } + trashDocs.sumOf { it.sizeBytes }
            val diskBytes = fileManager.calculateAppStorageBytes()
            StorageSummary(
                totalUsedBytes = maxOf(totalDbBytes, diskBytes),
                activeDocumentCount = activeDocs.size,
                pdfCount = activeDocs.count { it.fileType == DocumentFileType.PDF.name },
                folderCount = folders.size,
                trashCount = trashDocs.size,
                signatureCount = signatures.size
            )
        }

    override suspend fun getDocumentById(id: Long): DocumentItem? {
        val doc = documentDao.getById(id) ?: return null
        val folderName = doc.folderId?.let { fId ->
            folderDao.getById(fId)?.name
        }
        return doc.toDomain(folderName)
    }

    override suspend fun createFolder(name: String): Result<FolderItem> = runCatching {
        val trimmed = name.trim()
        require(trimmed.isNotEmpty()) { "Folder name cannot be empty." }
        val entity = FolderEntity(name = trimmed)
        val id = folderDao.insertFolder(entity)
        entity.copy(id = id).toDomain(0)
    }

    override suspend fun renameFolder(folderId: Long, newName: String): Result<Unit> = runCatching {
        val trimmed = newName.trim()
        require(trimmed.isNotEmpty()) { "Folder name cannot be empty." }
        folderDao.renameFolder(folderId, trimmed)
    }

    override suspend fun deleteFolder(folderId: Long): Result<Unit> = runCatching {
        folderDao.deleteFolder(folderId)
    }

    override suspend fun importUriToScanFile(uri: Uri): Result<String> = runCatching {
        fileManager.copyUriToScanFile(uri).absolutePath
    }

    override suspend fun importExternalPdfUri(uri: Uri, folderId: Long?): Result<DocumentItem> =
        runCatching {
            val rawName = fileManager.resolveDisplayName(uri)
                ?.substringBeforeLast('.')
                ?.ifBlank { null }
                ?: "Imported_${System.currentTimeMillis()}"
            val pdfFile = fileManager.copyUriToPdfFile(uri, rawName)
            val validation = pdfAdvancedEngine.validatePdf(pdfFile)
            val (pages, locked) = when (validation) {
                is PdfValidationOutcome.Valid -> validation.pageCount to validation.isPasswordProtected
                is PdfValidationOutcome.PasswordRequired -> 1 to true
                is PdfValidationOutcome.Invalid -> {
                    pdfFile.delete()
                    error(validation.reason)
                }
            }
            val now = System.currentTimeMillis()
            val entity = DocumentEntity(
                title = rawName,
                folderId = folderId,
                filePath = pdfFile.absolutePath,
                thumbnailPath = null,
                fileType = DocumentFileType.PDF.name,
                pageCount = pages,
                sizeBytes = pdfFile.length(),
                isPasswordProtected = locked,
                createdAt = now,
                updatedAt = now
            )
            val id = documentDao.insertDocument(entity)
            getDocumentById(id) ?: entity.copy(id = id).toDomain()
        }

    override suspend fun exportDocumentToUri(documentId: Long, destinationUri: Uri): Result<Long> =
        runCatching {
            val doc = documentDao.getById(documentId) ?: error("Document not found.")
            fileManager.copyFileToContentUri(doc.filePath, destinationUri, securityManager)
        }

    override suspend fun saveScannedBatch(
        title: String,
        pageImageUris: List<Uri>,
        pdfUri: Uri?,
        pdfPageCount: Int
    ): Result<Pair<DocumentItem, List<ScanPage>>> = runCatching {
        fileManager.checkStorageAvailable().getOrThrow()
        require(pageImageUris.isNotEmpty() || pdfUri != null) {
            "Scanner returned no pages or PDF output."
        }
        val cleanTitle = title.trim().ifBlank { "Scan_${System.currentTimeMillis()}" }

        val copiedPages = pageImageUris.mapIndexed { index, uri ->
            val copiedFile = fileManager.copyUriToScanFile(uri, pageIndex = index)
            ScanPage(
                id = UUID.randomUUID().toString(),
                sourcePath = copiedFile.absolutePath,
                filter = ScanFilter.ORIGINAL,
                rotationDegrees = 0,
                orderIndex = index
            )
        }

        val pdfFile = if (pdfUri != null) {
            fileManager.copyUriToPdfFile(pdfUri, cleanTitle)
        } else {
            val generated = fileManager.createPdfFile(cleanTitle)
            pdfGenerator.generatePdfFromPages(
                pages = copiedPages,
                outputFile = generated,
                options = PdfCreationOptions(pageSize = PdfPageSize.A4, quality = ScanQuality.HIGH)
            )
            generated
        }

        val finalPageCount = maxOf(pdfPageCount, copiedPages.size).coerceAtLeast(1)
        val now = System.currentTimeMillis()
        val entity = DocumentEntity(
            title = cleanTitle,
            folderId = null,
            filePath = pdfFile.absolutePath,
            thumbnailPath = copiedPages.firstOrNull()?.sourcePath,
            fileType = DocumentFileType.PDF.name,
            pageCount = finalPageCount,
            sizeBytes = pdfFile.length(),
            createdAt = now,
            updatedAt = now
        )
        val docId = documentDao.insertDocument(entity)
        if (copiedPages.isNotEmpty()) {
            val pageEntities = copiedPages.mapIndexed { idx, page ->
                DocumentPageEntity(
                    documentId = docId,
                    imagePath = page.sourcePath,
                    pageIndex = idx,
                    filterName = page.filter.name,
                    rotationDegrees = page.rotationDegrees
                )
            }
            documentDao.insertPages(pageEntities)
        }
        entity.copy(id = docId).toDomain() to copiedPages
    }

    override suspend fun getDocumentPages(documentId: Long): List<ScanPage> {
        return documentDao.getPagesForDocument(documentId).map { entity ->
            val filter = ScanFilter.entries.firstOrNull { it.name == entity.filterName }
                ?: ScanFilter.ORIGINAL
            ScanPage(
                id = "${entity.documentId}_${entity.id}_${entity.pageIndex}",
                sourcePath = entity.imagePath,
                filter = filter,
                rotationDegrees = entity.rotationDegrees,
                orderIndex = entity.pageIndex
            )
        }
    }

    override suspend fun createPdfDocument(
        title: String,
        pages: List<ScanPage>,
        folderId: Long?,
        pageSize: PdfPageSize,
        quality: ScanQuality
    ): Result<DocumentItem> = createPdfDocument(
        title = title,
        pages = pages,
        folderId = folderId,
        options = PdfCreationOptions(pageSize = pageSize, quality = quality)
    )

    override suspend fun createPdfDocument(
        title: String,
        pages: List<ScanPage>,
        folderId: Long?,
        options: PdfCreationOptions
    ): Result<DocumentItem> = runCatching {
        fileManager.checkStorageAvailable().getOrThrow()
        val cleanTitle = title.trim().ifBlank { "Scan_${System.currentTimeMillis()}" }
        val outFile = fileManager.createPdfFile(cleanTitle)
        val pageCount = pdfGenerator.generatePdfFromPages(
            pages = pages,
            outputFile = outFile,
            options = options
        )
        val now = System.currentTimeMillis()
        val entity = DocumentEntity(
            title = cleanTitle,
            folderId = folderId,
            filePath = outFile.absolutePath,
            thumbnailPath = pages.firstOrNull()?.sourcePath,
            fileType = DocumentFileType.PDF.name,
            pageCount = pageCount,
            sizeBytes = outFile.length(),
            isPasswordProtected = options.password.isNotBlank(),
            createdAt = now,
            updatedAt = now
        )
        val docId = documentDao.insertDocument(entity)
        val pageEntities = pages.mapIndexed { idx, page ->
            DocumentPageEntity(
                documentId = docId,
                imagePath = page.sourcePath,
                pageIndex = idx,
                filterName = page.filter.name,
                rotationDegrees = page.rotationDegrees
            )
        }
        documentDao.insertPages(pageEntities)
        getDocumentById(docId) ?: entity.copy(id = docId).toDomain()
    }

    override suspend fun updatePdfDocument(
        documentId: Long,
        title: String,
        pages: List<ScanPage>,
        folderId: Long?,
        pageSize: PdfPageSize,
        quality: ScanQuality
    ): Result<DocumentItem> = updatePdfDocument(
        documentId = documentId,
        title = title,
        pages = pages,
        folderId = folderId,
        options = PdfCreationOptions(pageSize = pageSize, quality = quality)
    )

    override suspend fun updatePdfDocument(
        documentId: Long,
        title: String,
        pages: List<ScanPage>,
        folderId: Long?,
        options: PdfCreationOptions
    ): Result<DocumentItem> = runCatching {
        val existing = documentDao.getById(documentId)
            ?: error("Existing document record not found.")
        val cleanTitle = title.trim().ifBlank { existing.title }
        val outFile = fileManager.createPdfFile(cleanTitle)
        val pageCount = pdfGenerator.generatePdfFromPages(
            pages = pages,
            outputFile = outFile,
            options = options
        )
        val now = System.currentTimeMillis()
        val thumb = pages.firstOrNull()?.sourcePath
        val newSize = outFile.length()
        documentDao.updateDocumentFileAndStats(
            id = documentId,
            title = cleanTitle,
            folderId = folderId,
            filePath = outFile.absolutePath,
            thumbnailPath = thumb,
            pageCount = pageCount,
            sizeBytes = newSize,
            updatedAt = now
        )
        documentDao.deletePagesForDocument(documentId)
        val pageEntities = pages.mapIndexed { idx, page ->
            DocumentPageEntity(
                documentId = documentId,
                imagePath = page.sourcePath,
                pageIndex = idx,
                filterName = page.filter.name,
                rotationDegrees = page.rotationDegrees
            )
        }
        documentDao.insertPages(pageEntities)
        getDocumentById(documentId) ?: existing.copy(
            title = cleanTitle,
            folderId = folderId,
            filePath = outFile.absolutePath,
            thumbnailPath = thumb,
            pageCount = pageCount,
            sizeBytes = newSize,
            updatedAt = now
        ).toDomain()
    }

    override suspend fun saveSingleImageDocument(
        title: String,
        page: ScanPage,
        folderId: Long?
    ): Result<DocumentItem> = runCatching {
        withContext(ioDispatcher) {
            val cleanTitle = title.trim().ifBlank { "Image_${System.currentTimeMillis()}" }
            val outFile = fileManager.createImageDocumentFile(cleanTitle)
            val raw = BitmapFilterEngine.decodeSampledBitmap(page.sourcePath, 2048)
                ?: error("Could not load image file.")
            val processed = BitmapFilterEngine.applyTransformAndFilter(
                raw,
                page.rotationDegrees,
                page.filter
            )
            FileOutputStream(outFile).use { out ->
                processed.compress(Bitmap.CompressFormat.JPEG, 92, out)
            }
            val now = System.currentTimeMillis()
            val entity = DocumentEntity(
                title = cleanTitle,
                folderId = folderId,
                filePath = outFile.absolutePath,
                thumbnailPath = outFile.absolutePath,
                fileType = DocumentFileType.IMAGE.name,
                pageCount = 1,
                sizeBytes = outFile.length(),
                createdAt = now,
                updatedAt = now
            )
            val id = documentDao.insertDocument(entity)
            entity.copy(id = id).toDomain()
        }
    }

    override suspend fun renameDocument(documentId: Long, newTitle: String): Result<Unit> = runCatching {
        val clean = newTitle.trim()
        require(clean.isNotEmpty()) { "Title cannot be empty." }
        documentDao.renameDocument(documentId, clean, System.currentTimeMillis())
    }

    override suspend fun togglePin(documentId: Long): Result<Unit> = runCatching {
        documentDao.togglePin(documentId, System.currentTimeMillis())
    }

    override suspend fun toggleFavorite(documentId: Long): Result<Unit> = runCatching {
        documentDao.toggleFavorite(documentId, System.currentTimeMillis())
    }

    override suspend fun setFavorites(documentIds: List<Long>, isFavorite: Boolean): Result<Unit> =
        runCatching {
            if (documentIds.isNotEmpty()) {
                documentDao.setFavorites(documentIds, isFavorite, System.currentTimeMillis())
            }
        }

    override suspend fun moveDocumentToFolder(documentId: Long, folderId: Long?): Result<Unit> =
        runCatching {
            documentDao.moveDocumentToFolder(documentId, folderId, System.currentTimeMillis())
        }

    override suspend fun moveDocumentsToFolder(documentIds: List<Long>, folderId: Long?): Result<Unit> =
        runCatching {
            if (documentIds.isNotEmpty()) {
                documentDao.moveDocumentsToFolder(documentIds, folderId, System.currentTimeMillis())
            }
        }

    override suspend fun togglePageBookmark(documentId: Long, pageIndex: Int): Result<List<Int>> =
        runCatching {
            val doc = documentDao.getById(documentId) ?: error("Document not found.")
            val current = doc.bookmarkedPages
                .split(",")
                .mapNotNull { it.trim().toIntOrNull() }
                .toMutableSet()
            if (pageIndex in current) current.remove(pageIndex) else current.add(pageIndex)
            val updated = current.sorted()
            documentDao.updateBookmarkedPages(
                id = documentId,
                bookmarkedPages = updated.joinToString(","),
                updatedAt = System.currentTimeMillis()
            )
            updated
        }

    override suspend fun updateOcrText(documentId: Long, ocrText: String): Result<Unit> = runCatching {
        documentDao.updateOcrText(documentId, ocrText, System.currentTimeMillis())
    }

    override suspend fun moveDocumentToTrash(documentId: Long): Result<Unit> = runCatching {
        val now = System.currentTimeMillis()
        val doc = documentDao.getById(documentId)
        documentDao.softDelete(documentId, now)
        if (doc != null) {
            deletedDocumentDao?.insertDeleted(
                DeletedDocumentEntity(
                    originalDocumentId = doc.id,
                    title = doc.title,
                    folderId = doc.folderId,
                    filePath = doc.filePath,
                    thumbnailPath = doc.thumbnailPath,
                    fileType = doc.fileType,
                    pageCount = doc.pageCount,
                    sizeBytes = doc.sizeBytes,
                    deletedAt = now
                )
            )
        }
    }

    override suspend fun moveDocumentsToTrash(documentIds: List<Long>): Result<Unit> = runCatching {
        if (documentIds.isEmpty()) return@runCatching
        val now = System.currentTimeMillis()
        val docs = documentDao.getByIds(documentIds)
        documentDao.softDeleteBatch(documentIds, now)
        docs.forEach { doc ->
            deletedDocumentDao?.insertDeleted(
                DeletedDocumentEntity(
                    originalDocumentId = doc.id,
                    title = doc.title,
                    folderId = doc.folderId,
                    filePath = doc.filePath,
                    thumbnailPath = doc.thumbnailPath,
                    fileType = doc.fileType,
                    pageCount = doc.pageCount,
                    sizeBytes = doc.sizeBytes,
                    deletedAt = now
                )
            )
        }
    }

    override suspend fun restoreDocument(documentId: Long): Result<Unit> = runCatching {
        documentDao.restore(documentId, System.currentTimeMillis())
        deletedDocumentDao?.deleteByOriginalDocumentId(documentId)
    }

    override suspend fun permanentlyDeleteDocument(documentId: Long): Result<Unit> = runCatching {
        val doc = documentDao.getById(documentId)
        val pagePaths = documentDao.getPagesForDocument(documentId).map { it.imagePath }
        val candidates = buildList {
            if (doc != null) {
                add(doc.filePath)
                doc.thumbnailPath?.let { add(it) }
            }
            addAll(pagePaths)
        }.distinct()

        documentDao.deletePagesForDocument(documentId)
        documentDao.deletePermanently(documentId)
        deletedDocumentDao?.deleteByOriginalDocumentId(documentId)

        val stillReferenced = documentDao.getAllReferencedFilePaths().toSet()
        candidates.filter { it !in stillReferenced }.forEach { path ->
            fileManager.deleteFileIfExists(path)
        }
    }

    override suspend fun emptyRecycleBin(): Result<Unit> = runCatching {
        val trashed = documentDao.getAllTrashSync()
        val candidates = mutableSetOf<String>()
        trashed.forEach { doc ->
            candidates.add(doc.filePath)
            doc.thumbnailPath?.let { candidates.add(it) }
            documentDao.getPagesForDocument(doc.id).forEach { page ->
                candidates.add(page.imagePath)
            }
            documentDao.deletePagesForDocument(doc.id)
        }
        documentDao.emptyTrash()
        deletedDocumentDao?.emptyDeletedRecords()

        val stillReferenced = documentDao.getAllReferencedFilePaths().toSet()
        candidates.filter { it !in stillReferenced }.forEach { path ->
            fileManager.deleteFileIfExists(path)
        }
    }

    override suspend fun mergePdfDocuments(
        title: String,
        documentIds: List<Long>,
        folderId: Long?
    ): Result<DocumentItem> = runCatching {
        fileManager.checkStorageAvailable().getOrThrow()
        val docs = documentIds.mapNotNull { documentDao.getById(it) }
            .filter { it.fileType == DocumentFileType.PDF.name || it.fileType == DocumentFileType.ID_CARD.name }
        require(docs.size >= 2) { "Select at least 2 PDF documents to merge." }

        val cleanTitle = title.trim().ifBlank { "Merged_${System.currentTimeMillis()}" }
        val outFile = fileManager.createPdfFile(cleanTitle)
        val tempFiles = mutableListOf<File>()
        try {
            val readableFiles = docs.map { doc ->
                val raw = File(doc.filePath)
                require(raw.exists() && raw.length() > 0L) { "PDF file for '${doc.title}' is missing." }
                val readable = if (securityManager != null && securityManager.isVaultEncryptedFile(raw)) {
                    securityManager.createTempUnsealedCopy(raw, fileManager.appCacheDir).also { tempFiles += it }
                } else {
                    raw
                }
                when (val check = pdfAdvancedEngine.validatePdf(readable)) {
                    is PdfValidationOutcome.PasswordRequired ->
                        error("'${doc.title}' is password protected. Unlock it first before merging.")
                    is PdfValidationOutcome.Invalid ->
                        error("'${doc.title}': ${check.reason}")
                    is PdfValidationOutcome.Valid -> if (check.isPasswordProtected) {
                        error("'${doc.title}' is password protected. Unlock it first before merging.")
                    }
                }
                readable
            }
            val totalPages = pdfGenerator.mergePdfs(
                sourcePdfFiles = readableFiles,
                outputFile = outFile
            )
            insertDerivedPdfDocument(
                title = cleanTitle,
                outFile = outFile,
                folderId = folderId,
                thumbnailPath = docs.firstOrNull()?.thumbnailPath,
                pageCount = totalPages
            )
        } finally {
            tempFiles.forEach { it.delete() }
        }
    }

    private inline fun <T> withReadableFile(filePath: String, block: (File) -> T): T {
        val raw = File(filePath)
        val temp = if (securityManager != null && securityManager.isVaultEncryptedFile(raw)) {
            securityManager.createTempUnsealedCopy(raw, fileManager.appCacheDir)
        } else {
            null
        }
        return try {
            block(temp ?: raw)
        } finally {
            temp?.delete()
        }
    }

    override suspend fun splitPdfDocument(
        sourceDocumentId: Long,
        newTitle: String,
        startPageOneBased: Int,
        endPageOneBased: Int,
        password: String?
    ): Result<DocumentItem> = runCatching {
        fileManager.checkStorageAvailable().getOrThrow()
        val source = requirePdfSource(sourceDocumentId)
        val cleanTitle = newTitle.trim().ifBlank { "${source.title}_Split" }
        val outFile = fileManager.createPdfFile(cleanTitle)
        val pageCount = withReadableFile(source.filePath) { readable ->
            pdfGenerator.splitPdf(
                sourceFile = readable,
                outputFile = outFile,
                startPageOneBased = startPageOneBased,
                endPageOneBased = endPageOneBased,
                password = password
            )
        }
        insertDerivedPdfDocument(cleanTitle, outFile, source.folderId, source.thumbnailPath, pageCount)
    }

    override suspend fun extractPdfPages(
        sourceDocumentId: Long,
        newTitle: String,
        oneBasedPages: List<Int>,
        password: String?
    ): Result<DocumentItem> = runCatching {
        fileManager.checkStorageAvailable().getOrThrow()
        val source = requirePdfSource(sourceDocumentId)
        val cleanTitle = newTitle.trim().ifBlank { "${source.title}_Extracted" }
        val outFile = fileManager.createPdfFile(cleanTitle)
        val pageCount = withReadableFile(source.filePath) { readable ->
            pdfGenerator.extractPages(
                sourceFile = readable,
                outputFile = outFile,
                oneBasedPages = oneBasedPages,
                password = password
            )
        }
        insertDerivedPdfDocument(cleanTitle, outFile, source.folderId, source.thumbnailPath, pageCount)
    }

    override suspend fun rotatePdfPages(
        sourceDocumentId: Long,
        newTitle: String,
        oneBasedPages: Set<Int>,
        deltaDegrees: Int,
        password: String?
    ): Result<DocumentItem> = runCatching {
        fileManager.checkStorageAvailable().getOrThrow()
        val source = requirePdfSource(sourceDocumentId)
        val cleanTitle = newTitle.trim().ifBlank { "${source.title}_Rotated" }
        val outFile = fileManager.createPdfFile(cleanTitle)
        val pageCount = withReadableFile(source.filePath) { readable ->
            pdfGenerator.rotatePdfPages(
                sourceFile = readable,
                outputFile = outFile,
                oneBasedPages = oneBasedPages,
                deltaDegrees = deltaDegrees,
                password = password
            )
        }
        insertDerivedPdfDocument(cleanTitle, outFile, source.folderId, source.thumbnailPath, pageCount)
    }

    override suspend fun deletePdfPages(
        sourceDocumentId: Long,
        newTitle: String,
        oneBasedPagesToDelete: Set<Int>,
        password: String?
    ): Result<DocumentItem> = runCatching {
        fileManager.checkStorageAvailable().getOrThrow()
        val source = requirePdfSource(sourceDocumentId)
        val cleanTitle = newTitle.trim().ifBlank { "${source.title}_Trimmed" }
        val outFile = fileManager.createPdfFile(cleanTitle)
        val pageCount = withReadableFile(source.filePath) { readable ->
            pdfGenerator.deletePdfPages(
                sourceFile = readable,
                outputFile = outFile,
                oneBasedPagesToDelete = oneBasedPagesToDelete,
                password = password
            )
        }
        insertDerivedPdfDocument(cleanTitle, outFile, source.folderId, source.thumbnailPath, pageCount)
    }

    override suspend fun compressPdfDocument(
        sourceDocumentId: Long,
        newTitle: String,
        compressionLevel: PdfCompressionLevel,
        password: String?
    ): Result<DocumentItem> = runCatching {
        fileManager.checkStorageAvailable().getOrThrow()
        val source = requirePdfSource(sourceDocumentId)
        val cleanTitle = newTitle.trim().ifBlank { "${source.title}_Compressed" }
        val outFile = fileManager.createPdfFile(cleanTitle)
        val pageCount = withReadableFile(source.filePath) { readable ->
            pdfGenerator.compressPdf(
                sourceFile = readable,
                outputFile = outFile,
                compressionLevel = compressionLevel,
                password = password
            )
        }
        insertDerivedPdfDocument(cleanTitle, outFile, source.folderId, source.thumbnailPath, pageCount)
    }

    override suspend fun watermarkPdfDocument(
        sourceDocumentId: Long,
        newTitle: String,
        watermarkText: String,
        password: String?
    ): Result<DocumentItem> = runCatching {
        fileManager.checkStorageAvailable().getOrThrow()
        val source = requirePdfSource(sourceDocumentId)
        val cleanTitle = newTitle.trim().ifBlank { "${source.title}_Watermark" }
        val outFile = fileManager.createPdfFile(cleanTitle)
        val pageCount = withReadableFile(source.filePath) { readable ->
            pdfGenerator.addWatermark(
                sourceFile = readable,
                outputFile = outFile,
                watermarkText = watermarkText,
                password = password
            )
        }
        insertDerivedPdfDocument(cleanTitle, outFile, source.folderId, source.thumbnailPath, pageCount)
    }

    override suspend fun protectPdfDocument(
        sourceDocumentId: Long,
        newTitle: String,
        userPassword: String,
        existingPassword: String?
    ): Result<DocumentItem> = runCatching {
        fileManager.checkStorageAvailable().getOrThrow()
        val source = requirePdfSource(sourceDocumentId)
        val cleanTitle = newTitle.trim().ifBlank { "${source.title}_Protected" }
        val outFile = fileManager.createPdfFile(cleanTitle)
        val pageCount = withReadableFile(source.filePath) { readable ->
            pdfGenerator.protectPdfWithPassword(
                sourceFile = readable,
                outputFile = outFile,
                userPassword = userPassword,
                existingPassword = existingPassword
            )
        }
        insertDerivedPdfDocument(
            title = cleanTitle,
            outFile = outFile,
            folderId = source.folderId,
            thumbnailPath = source.thumbnailPath,
            pageCount = pageCount,
            isPasswordProtected = true
        )
    }

    override suspend fun annotatePdfDocument(
        sourceDocumentId: Long,
        newTitle: String,
        pageIndexZeroBased: Int,
        noteText: String,
        addHighlightBar: Boolean,
        password: String?
    ): Result<DocumentItem> = runCatching {
        fileManager.checkStorageAvailable().getOrThrow()
        val source = requirePdfSource(sourceDocumentId)
        val cleanTitle = newTitle.trim().ifBlank { "${source.title}_Annotated" }
        val outFile = fileManager.createPdfFile(cleanTitle)
        val pageCount = withReadableFile(source.filePath) { readable ->
            pdfGenerator.addHighlightOrNoteAnnotation(
                sourceFile = readable,
                outputFile = outFile,
                pageIndexZeroBased = pageIndexZeroBased,
                noteText = noteText,
                addHighlightBar = addHighlightBar,
                password = password
            )
        }
        insertDerivedPdfDocument(
            title = cleanTitle,
            outFile = outFile,
            folderId = source.folderId,
            thumbnailPath = source.thumbnailPath,
            pageCount = pageCount,
            isPasswordProtected = source.isPasswordProtected
        )
    }

    override suspend fun searchTextInPdf(
        documentId: Long,
        query: String,
        password: String?
    ): List<PdfSearchMatch> {
        val doc = documentDao.getById(documentId) ?: return emptyList()
        return runCatching {
            withReadableFile(doc.filePath) { readable ->
                pdfGenerator.searchTextInPdf(readable, query, password)
            }
        }.getOrDefault(emptyList())
    }

    private suspend fun requirePdfSource(sourceDocumentId: Long): DocumentEntity {
        val source = documentDao.getById(sourceDocumentId)
            ?: error("Source PDF not found.")
        require(
            source.fileType == DocumentFileType.PDF.name ||
                source.fileType == DocumentFileType.ID_CARD.name
        ) {
            "Selected document is not a PDF."
        }
        return source
    }

    private suspend fun insertDerivedPdfDocument(
        title: String,
        outFile: File,
        folderId: Long?,
        thumbnailPath: String?,
        pageCount: Int,
        isPasswordProtected: Boolean = false
    ): DocumentItem = insertDerivedDocument(
        title = title,
        outFile = outFile,
        folderId = folderId,
        thumbnailPath = thumbnailPath,
        pageCount = pageCount,
        isPasswordProtected = isPasswordProtected,
        fileType = DocumentFileType.PDF
    )

    private suspend fun insertDerivedDocument(
        title: String,
        outFile: File,
        folderId: Long?,
        thumbnailPath: String?,
        pageCount: Int,
        isPasswordProtected: Boolean = false,
        fileType: DocumentFileType = DocumentFileType.PDF
    ): DocumentItem {
        val now = System.currentTimeMillis()
        val entity = DocumentEntity(
            title = title,
            folderId = folderId,
            filePath = outFile.absolutePath,
            thumbnailPath = thumbnailPath,
            fileType = fileType.name,
            pageCount = pageCount,
            sizeBytes = outFile.length(),
            isPasswordProtected = isPasswordProtected,
            createdAt = now,
            updatedAt = now
        )
        val newId = documentDao.insertDocument(entity)
        return getDocumentById(newId) ?: entity.copy(id = newId).toDomain()
    }

    override suspend fun saveSignature(name: String, pngBytes: ByteArray): Result<SignatureItem> =
        runCatching {
            withContext(ioDispatcher) {
                val outFile = fileManager.createSignatureFile()
                FileOutputStream(outFile).use { it.write(pngBytes) }
                val entity = SignatureEntity(
                    name = name.trim().ifBlank { "Signature" },
                    filePath = outFile.absolutePath
                )
                val id = signatureDao.insertSignature(entity)
                entity.copy(id = id).toDomain()
            }
        }

    override suspend fun deleteSignature(signatureId: Long): Result<Unit> = runCatching {
        val sig = signatureDao.getById(signatureId)
        if (sig != null) {
            fileManager.deleteFileIfExists(sig.filePath)
        }
        signatureDao.deleteSignature(signatureId)
    }

    override suspend fun createIdCardPdfDocument(
        title: String,
        docType: IdDocumentType,
        frontSide: IdSideScanState,
        backSide: IdSideScanState?,
        singleCombinedSheet: Boolean,
        quality: ScanQuality,
        password: String?,
        encryptInVault: Boolean
    ): Result<DocumentItem> = runCatching {
        fileManager.checkStorageAvailable().getOrThrow()
        val cleanTitle = title.trim().ifBlank { "${docType.displayName}_Scan_${System.currentTimeMillis()}" }
        val outFile = fileManager.createPdfFile(cleanTitle)
        val pageCount = pdfGenerator.generateIdCardPdf(
            docType = docType,
            frontSide = frontSide,
            backSide = backSide,
            singleCombinedSheet = singleCombinedSheet,
            quality = quality,
            outputFile = outFile,
            password = password
        )
        if (encryptInVault && securityManager != null) {
            withContext(ioDispatcher) {
                securityManager.sealFileInPlace(outFile)
            }
        }
        val now = System.currentTimeMillis()
        val entity = DocumentEntity(
            title = cleanTitle,
            folderId = null,
            filePath = outFile.absolutePath,
            thumbnailPath = frontSide.imagePath,
            fileType = DocumentFileType.ID_CARD.name,
            pageCount = pageCount,
            sizeBytes = outFile.length(),
            isPasswordProtected = !password.isNullOrBlank(),
            createdAt = now,
            updatedAt = now
        )
        val docId = documentDao.insertDocument(entity)
        getDocumentById(docId) ?: entity.copy(id = docId).toDomain()
    }

    override suspend fun insertSignatureIntoPdf(
        sourceDocumentId: Long,
        newTitle: String,
        signatureId: Long,
        placement: SignaturePlacement,
        password: String?
    ): Result<DocumentItem> = runCatching {
        fileManager.checkStorageAvailable().getOrThrow()
        val source = requirePdfSource(sourceDocumentId)
        val sig = signatureDao.getById(signatureId)
            ?: error("Selected signature not found.")
        val cleanTitle = newTitle.trim().ifBlank { "${source.title}_Signed" }
        val outFile = fileManager.createPdfFile(cleanTitle)
        val pageCount = withReadableFile(source.filePath) { readable ->
            pdfGenerator.insertSignatureIntoPdf(
                sourceFile = readable,
                outputFile = outFile,
                signaturePngFile = File(sig.filePath),
                pageIndexZeroBased = placement.pageIndex,
                normX = placement.normX,
                normY = placement.normY,
                normWidth = placement.normWidth,
                password = password
            )
        }
        insertDerivedPdfDocument(
            title = cleanTitle,
            outFile = outFile,
            folderId = source.folderId,
            thumbnailPath = source.thumbnailPath,
            pageCount = pageCount,
            isPasswordProtected = source.isPasswordProtected && !password.isNullOrEmpty()
        )
    }

    override suspend fun sealDocumentInVault(documentId: Long): Result<Boolean> = runCatching {
        withContext(ioDispatcher) {
            val sec = securityManager ?: error("SecurityManager not initialized.")
            val doc = documentDao.getById(documentId) ?: error("Document not found.")
            val file = File(doc.filePath)
            require(file.exists()) { "Document file missing on device." }
            sec.sealFileInPlace(file)
        }
    }

    override suspend fun unsealDocumentInVault(documentId: Long): Result<Boolean> = runCatching {
        withContext(ioDispatcher) {
            val sec = securityManager ?: error("SecurityManager not initialized.")
            val doc = documentDao.getById(documentId) ?: error("Document not found.")
            val file = File(doc.filePath)
            require(file.exists()) { "Document file missing on device." }
            sec.unsealFileInPlace(file)
        }
    }

    override suspend fun isDocumentVaultEncrypted(documentId: Long): Boolean = withContext(ioDispatcher) {
        val sec = securityManager ?: return@withContext false
        val doc = documentDao.getById(documentId) ?: return@withContext false
        sec.isVaultEncryptedFile(File(doc.filePath))
    }

    override suspend fun getCacheSummary(): CacheSummary = withContext(ioDispatcher) {
        val referenced = documentDao.getAllReferencedFilePaths().toSet()
        fileManager.computeCacheSummary(referenced)
    }

    override suspend fun clearTempCache(): Result<Long> = runCatching {
        withContext(ioDispatcher) {
            val referenced = documentDao.getAllReferencedFilePaths().toSet()
            fileManager.clearTemporaryCache(referenced)
        }
    }

    private suspend fun buildBackupManifestJson(): JSONObject {
        val activeDocs = documentDao.observeActiveDocuments().first()
        val folders = folderDao.observeAllFolders().first()
        val signatures = signatureDao.observeSignatures().first()

        return JSONObject().apply {
            put("app", "DocuScan")
            put("formatVersion", 2)
            put("createdAt", System.currentTimeMillis())
            put("documentCount", activeDocs.size)
            put("folderCount", folders.size)
            put("signatureCount", signatures.size)
            put("folders", JSONArray().apply {
                folders.forEach { folder ->
                    put(JSONObject().apply {
                        put("id", folder.id)
                        put("name", folder.name)
                        put("createdAt", folder.createdAt)
                    })
                }
            })
            put("documents", JSONArray().apply {
                activeDocs.forEach { doc ->
                    put(JSONObject().apply {
                        put("id", doc.id)
                        put("title", doc.title)
                        put("fileType", doc.fileType)
                        put("pageCount", doc.pageCount)
                        put("sizeBytes", doc.sizeBytes)
                        put("isFavorite", doc.isFavorite)
                        put("isPasswordProtected", doc.isPasswordProtected)
                        put("archiveEntry", "documents/${File(doc.filePath).name}")
                    })
                }
            })
        }
    }

    override suspend fun createLocalBackupManifest(): Result<String> = runCatching {
        withContext(ioDispatcher) {
            fileManager.checkStorageAvailable().getOrThrow()
            val root = buildBackupManifestJson()
            val manifestFile = fileManager.createBackupManifestFile()
            manifestFile.writeText(root.toString(2))
            manifestFile.absolutePath
        }
    }

    override suspend fun exportFullBackupArchive(destinationUri: Uri): Result<Long> = runCatching {
        withContext(ioDispatcher) {
            fileManager.checkStorageAvailable().getOrThrow()
            val manifestJson = buildBackupManifestJson().toString(2).toByteArray(Charsets.UTF_8)
            val activeDocs = documentDao.observeActiveDocuments().first()
            val signatures = signatureDao.observeSignatures().first()

            val fileEntries = mutableListOf<Pair<String, File>>()
            val seenNames = mutableSetOf<String>()
            activeDocs.forEach { doc ->
                val f = File(doc.filePath)
                if (f.exists() && seenNames.add("documents/${f.name}")) {
                    fileEntries += "documents/${f.name}" to f
                }
            }
            signatures.forEach { sig ->
                val f = File(sig.filePath)
                if (f.exists() && seenNames.add("signatures/${f.name}")) {
                    fileEntries += "signatures/${f.name}" to f
                }
            }

            fileManager.exportZipArchiveToUri(
                jsonEntries = listOf("docuscan_backup.json" to manifestJson),
                fileEntries = fileEntries,
                destinationUri = destinationUri,
                securityManager = securityManager
            )
        }
    }

    override suspend fun duplicatePdfDocument(sourceDocumentId: Long, newTitle: String): Result<DocumentItem> =
        toolsOps.duplicatePdfDocument(sourceDocumentId, newTitle)

    override suspend fun inspectPdfInfo(documentId: Long, password: String?): Result<PdfDocumentInfo> =
        toolsOps.inspectPdfInfo(documentId, password)

    override suspend fun reorderPdfPages(
        sourceDocumentId: Long,
        newTitle: String,
        oneBasedNewOrder: List<Int>,
        password: String?
    ): Result<DocumentItem> = toolsOps.reorderPdfPages(sourceDocumentId, newTitle, oneBasedNewOrder, password)

    override suspend fun duplicatePdfPages(
        sourceDocumentId: Long,
        newTitle: String,
        oneBasedPagesToDuplicate: List<Int>,
        insertAdjacent: Boolean,
        password: String?
    ): Result<DocumentItem> = toolsOps.duplicatePdfPages(
        sourceDocumentId,
        newTitle,
        oneBasedPagesToDuplicate,
        insertAdjacent,
        password
    )

    override suspend fun createPdfFromText(
        title: String,
        text: String,
        folderId: Long?,
        pageSize: PdfPageSize,
        orientation: PdfOrientation,
        marginPt: Float,
        fontSizePt: Float,
        includePageNumbers: Boolean,
        password: String
    ): Result<DocumentItem> = toolsOps.createPdfFromText(
        title,
        text,
        folderId,
        pageSize,
        orientation,
        marginPt,
        fontSizePt,
        includePageNumbers,
        password
    )

    override suspend fun extractTextFromPdf(
        sourceDocumentId: Long,
        startPageOneBased: Int,
        endPageOneBased: Int,
        password: String?
    ): Result<PdfTextExtractionResult> =
        toolsOps.extractTextFromPdf(sourceDocumentId, startPageOneBased, endPageOneBased, password)

    override suspend fun convertPdfToDocx(
        sourceDocumentId: Long,
        outputTitle: String,
        includePageImagesFallback: Boolean,
        password: String?
    ): Result<PdfDocxConversionResult> =
        toolsOps.convertPdfToDocx(sourceDocumentId, outputTitle, includePageImagesFallback, password)

    override suspend fun exportPdfToImages(
        sourceDocumentId: Long,
        format: PdfImageFormat,
        pageIndicesOneBased: List<Int>,
        quality: Int,
        saveToLibrary: Boolean,
        password: String?
    ): Result<PdfImagesExportResult> =
        toolsOps.exportPdfToImages(sourceDocumentId, format, pageIndicesOneBased, quality, saveToLibrary, password)

    override suspend fun unlockPdfDocument(
        sourceDocumentId: Long,
        newTitle: String,
        password: String
    ): Result<DocumentItem> = toolsOps.unlockPdfDocument(sourceDocumentId, newTitle, password)

    override suspend fun removeWatermarkFromPdf(
        sourceDocumentId: Long,
        newTitle: String,
        matchText: String?,
        password: String?
    ): Result<WatermarkRemovalResult> =
        toolsOps.removeWatermarkFromPdf(sourceDocumentId, newTitle, matchText, password)

    override suspend fun addPageNumbersToPdf(
        sourceDocumentId: Long,
        newTitle: String,
        position: PageNumberPosition,
        format: PageNumberFormat,
        startNumber: Int,
        password: String?
    ): Result<DocumentItem> =
        toolsOps.addPageNumbersToPdf(sourceDocumentId, newTitle, position, format, startNumber, password)

    override suspend fun addHeaderFooterToPdf(
        sourceDocumentId: Long,
        newTitle: String,
        headerText: String,
        footerText: String,
        includeDate: Boolean,
        fontSizePt: Float,
        password: String?
    ): Result<DocumentItem> = toolsOps.addHeaderFooterToPdf(
        sourceDocumentId,
        newTitle,
        headerText,
        footerText,
        includeDate,
        fontSizePt,
        password
    )

    override suspend fun reducePdfSizeDocument(
        sourceDocumentId: Long,
        newTitle: String,
        maxImageDimension: Int,
        jpegQuality: Float,
        stripMetadata: Boolean,
        password: String?
    ): Result<PdfReduceSizeResult> = toolsOps.reducePdfSizeDocument(
        sourceDocumentId,
        newTitle,
        maxImageDimension,
        jpegQuality,
        stripMetadata,
        password
    )

    override suspend fun repairPdfDocument(
        sourceDocumentId: Long,
        newTitle: String,
        password: String?
    ): Result<PdfRepairResult> = toolsOps.repairPdfDocument(sourceDocumentId, newTitle, password)

    override suspend fun repairExternalPdfUri(
        uri: Uri,
        newTitle: String,
        password: String?
    ): Result<PdfRepairResult> = toolsOps.repairExternalPdfUri(uri, newTitle, password)
}
