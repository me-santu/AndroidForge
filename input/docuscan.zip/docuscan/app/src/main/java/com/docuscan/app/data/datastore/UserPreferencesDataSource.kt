package com.docuscan.app.data.datastore

import android.content.Context
import androidx.datastore.core.DataStore
import androidx.datastore.preferences.core.Preferences
import androidx.datastore.preferences.core.booleanPreferencesKey
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.core.longPreferencesKey
import androidx.datastore.preferences.core.stringPreferencesKey
import androidx.datastore.preferences.preferencesDataStore
import com.docuscan.app.domain.model.AppFontStyle
import com.docuscan.app.domain.model.AppLanguage
import com.docuscan.app.domain.model.PdfPageSize
import com.docuscan.app.domain.model.ScanQuality
import com.docuscan.app.domain.model.ThemeMode
import com.docuscan.app.domain.model.UserPreferences
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map

private val Context.dataStore: DataStore<Preferences> by preferencesDataStore(name = "docuscan_prefs")

class UserPreferencesDataSource(private val context: Context) {

    private object Keys {
        val THEME_MODE = stringPreferencesKey("theme_mode")
        val APP_LANGUAGE = stringPreferencesKey("app_language")
        val FONT_STYLE = stringPreferencesKey("font_style")
        val ONBOARDING_COMPLETED = booleanPreferencesKey("onboarding_completed")
        val SCAN_QUALITY = stringPreferencesKey("scan_quality")
        val DEFAULT_PAGE_SIZE = stringPreferencesKey("default_page_size")
        val AUTO_ENHANCE = booleanPreferencesKey("auto_enhance")
        val APP_LOCK_ENABLED = booleanPreferencesKey("app_lock_enabled")
        val BIOMETRIC_UNLOCK_ENABLED = booleanPreferencesKey("biometric_unlock_enabled")
        val ENCRYPT_SENSITIVE_FILES = booleanPreferencesKey("encrypt_sensitive_files")
        val SEALED_PIN_RECORD = stringPreferencesKey("sealed_pin_record")
        val LAST_BACKUP_AT = longPreferencesKey("last_backup_at")
    }

    val preferences: Flow<UserPreferences> = context.dataStore.data.map { prefs ->
        UserPreferences(
            themeMode = prefs[Keys.THEME_MODE]?.let { name ->
                ThemeMode.entries.firstOrNull { it.name == name }
            } ?: ThemeMode.DARK,
            appLanguage = prefs[Keys.APP_LANGUAGE]?.let { name ->
                AppLanguage.entries.firstOrNull { it.name == name }
            } ?: AppLanguage.ENGLISH,
            fontStyle = prefs[Keys.FONT_STYLE]?.let { name ->
                AppFontStyle.entries.firstOrNull { it.name == name }
            } ?: AppFontStyle.POPPINS,
            onboardingCompleted = prefs[Keys.ONBOARDING_COMPLETED] ?: false,
            scanQuality = prefs[Keys.SCAN_QUALITY]?.let { name ->
                ScanQuality.entries.firstOrNull { it.name == name }
            } ?: ScanQuality.HIGH,
            defaultPageSize = prefs[Keys.DEFAULT_PAGE_SIZE]?.let { name ->
                PdfPageSize.entries.firstOrNull { it.name == name }
            } ?: PdfPageSize.A4,
            autoEnhance = prefs[Keys.AUTO_ENHANCE] ?: true,
            appLockEnabled = prefs[Keys.APP_LOCK_ENABLED] ?: false,
            biometricUnlockEnabled = prefs[Keys.BIOMETRIC_UNLOCK_ENABLED] ?: false,
            encryptSensitiveFiles = prefs[Keys.ENCRYPT_SENSITIVE_FILES] ?: false,
            sealedPinRecord = prefs[Keys.SEALED_PIN_RECORD],
            lastBackupAt = prefs[Keys.LAST_BACKUP_AT]
        )
    }

    suspend fun setThemeMode(mode: ThemeMode) {
        context.dataStore.edit { it[Keys.THEME_MODE] = mode.name }
    }

    suspend fun setAppLanguage(language: AppLanguage) {
        context.dataStore.edit { it[Keys.APP_LANGUAGE] = language.name }
    }

    suspend fun setFontStyle(fontStyle: AppFontStyle) {
        context.dataStore.edit { it[Keys.FONT_STYLE] = fontStyle.name }
    }

    suspend fun setOnboardingCompleted(completed: Boolean) {
        context.dataStore.edit { it[Keys.ONBOARDING_COMPLETED] = completed }
    }

    suspend fun setScanQuality(quality: ScanQuality) {
        context.dataStore.edit { it[Keys.SCAN_QUALITY] = quality.name }
    }

    suspend fun setDefaultPageSize(pageSize: PdfPageSize) {
        context.dataStore.edit { it[Keys.DEFAULT_PAGE_SIZE] = pageSize.name }
    }

    suspend fun setAutoEnhance(enabled: Boolean) {
        context.dataStore.edit { it[Keys.AUTO_ENHANCE] = enabled }
    }

    suspend fun setAppLockEnabled(enabled: Boolean) {
        context.dataStore.edit { it[Keys.APP_LOCK_ENABLED] = enabled }
    }

    suspend fun setBiometricUnlockEnabled(enabled: Boolean) {
        context.dataStore.edit { it[Keys.BIOMETRIC_UNLOCK_ENABLED] = enabled }
    }

    suspend fun setEncryptSensitiveFiles(enabled: Boolean) {
        context.dataStore.edit { it[Keys.ENCRYPT_SENSITIVE_FILES] = enabled }
    }

    suspend fun setSealedPinRecord(record: String?) {
        context.dataStore.edit {
            if (record == null) {
                it.remove(Keys.SEALED_PIN_RECORD)
            } else {
                it[Keys.SEALED_PIN_RECORD] = record
            }
        }
    }

    suspend fun updateLastBackupAt(timestamp: Long) {
        context.dataStore.edit { it[Keys.LAST_BACKUP_AT] = timestamp }
    }
}
