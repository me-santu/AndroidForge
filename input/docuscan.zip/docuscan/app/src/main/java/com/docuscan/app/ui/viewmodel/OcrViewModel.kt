package com.docuscan.app.ui.viewmodel

import android.net.Uri
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.docuscan.app.domain.model.DocumentFileType
import com.docuscan.app.domain.model.DocumentItem
import com.docuscan.app.domain.model.ScanPage
import com.docuscan.app.domain.repository.DocumentRepository
import com.docuscan.app.ocr.DetectedLanguageInfo
import com.docuscan.app.ocr.OcrEngine
import com.docuscan.app.ocr.OcrLanguageDetector
import com.docuscan.app.ocr.OcrPageResult
import com.docuscan.app.ocr.OcrScript
import com.docuscan.app.pdf.PdfRendererHelper
import com.docuscan.app.util.LocalFileManager
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch

enum class OcrSourceKind {
    DOCUMENT,
    STANDALONE_IMAGE,
    SCAN_SESSION
}

sealed interface OcrRunState {
    data object Idle : OcrRunState
    data class Extracting(val currentPage: Int, val totalPages: Int) : OcrRunState
    data class Success(
        val pageResults: List<OcrPageResult>,
        val warnings: List<String> = emptyList(),
        val detectedLanguage: DetectedLanguageInfo? = null,
        val effectiveScript: OcrScript? = null
    ) : OcrRunState
    data class Error(val message: String, val canRetry: Boolean = true) : OcrRunState
}

data class OcrSearchMatch(
    val lineNumber: Int,
    val snippet: String,
    val occurrenceCount: Int
)

data class OcrUiState(
    val sourceKind: OcrSourceKind = OcrSourceKind.DOCUMENT,
    val selectedDocumentId: Long = -1L,
    val sourceTitle: String = "",
    val standaloneImagePath: String? = null,
    val sessionPages: List<ScanPage> = emptyList(),
    val selectedScript: OcrScript = OcrScript.AUTO,
    val detectedLanguage: DetectedLanguageInfo? = null,
    val detectedScriptUsed: OcrScript? = null,
    val pdfPassword: String = "",
    val runState: OcrRunState = OcrRunState.Idle,
    val editableText: String = "",
    val searchQuery: String = "",
    val searchMatches: List<OcrSearchMatch> = emptyList(),
    val totalMatchCount: Int = 0,
    val statusMessage: String? = null
)

class OcrViewModel(
    private val ocrEngine: OcrEngine,
    private val documentRepository: DocumentRepository,
    private val pdfRendererHelper: PdfRendererHelper,
    private val fileManager: LocalFileManager
) : ViewModel() {

    private val _uiState = MutableStateFlow(OcrUiState())
    val uiState: StateFlow<OcrUiState> = _uiState.asStateFlow()

    fun initializeWithDocument(document: DocumentItem?) {
        val current = _uiState.value
        if (document == null) return
        if (current.sourceKind == OcrSourceKind.DOCUMENT && current.selectedDocumentId == document.id && current.sourceTitle.isNotEmpty()) {
            return
        }
        selectDocument(document)
    }

    fun selectDocument(document: DocumentItem) {
        val detectedFromExisting = document.ocrText.takeIf { it.isNotBlank() }?.let {
            OcrLanguageDetector.detectByUnicodeScript(it)
        }
        _uiState.update {
            it.copy(
                sourceKind = OcrSourceKind.DOCUMENT,
                selectedDocumentId = document.id,
                sourceTitle = document.title,
                standaloneImagePath = null,
                runState = OcrRunState.Idle,
                editableText = document.ocrText,
                detectedLanguage = detectedFromExisting,
                detectedScriptUsed = detectedFromExisting?.suggestedOcrScript,
                searchQuery = "",
                searchMatches = emptyList(),
                totalMatchCount = 0
            )
        }
    }

    fun importImageUriForOcr(uri: Uri) {
        viewModelScope.launch {
            _uiState.update { it.copy(runState = OcrRunState.Extracting(1, 1)) }
            documentRepository.importUriToScanFile(uri)
                .onSuccess { path ->
                    val label = fileManager.resolveDisplayName(uri) ?: "Imported Image"
                    _uiState.update {
                        it.copy(
                            sourceKind = OcrSourceKind.STANDALONE_IMAGE,
                            selectedDocumentId = -1L,
                            sourceTitle = label,
                            standaloneImagePath = path,
                            editableText = "",
                            detectedLanguage = null,
                            detectedScriptUsed = null,
                            searchQuery = "",
                            searchMatches = emptyList(),
                            totalMatchCount = 0
                        )
                    }
                    runExtraction()
                }
                .onFailure { err ->
                    _uiState.update {
                        it.copy(runState = OcrRunState.Error(err.message ?: "Failed to load selected image.", canRetry = false))
                    }
                }
        }
    }

    fun importExternalPdfForOcr(uri: Uri) {
        viewModelScope.launch {
            _uiState.update { it.copy(runState = OcrRunState.Extracting(1, 1)) }
            documentRepository.importExternalPdfUri(uri)
                .onSuccess { imported ->
                    selectDocument(imported)
                    if (imported.isPasswordProtected) {
                        _uiState.update {
                            it.copy(statusMessage = "Loaded '${imported.title}'. Enter its password below, then tap Extract Text.")
                        }
                    } else {
                        _uiState.update {
                            it.copy(statusMessage = "Loaded '${imported.title}' from device")
                        }
                        runExtraction()
                    }
                }
                .onFailure { err ->
                    _uiState.update {
                        it.copy(
                            runState = OcrRunState.Error(
                                err.message ?: "Failed to import selected PDF from device.",
                                canRetry = false
                            )
                        )
                    }
                }
        }
    }

    fun loadImageFileForOcr(filePath: String, title: String = "Captured Photo") {
        _uiState.update {
            it.copy(
                sourceKind = OcrSourceKind.STANDALONE_IMAGE,
                selectedDocumentId = -1L,
                sourceTitle = title,
                standaloneImagePath = filePath,
                editableText = "",
                detectedLanguage = null,
                detectedScriptUsed = null,
                searchQuery = "",
                searchMatches = emptyList(),
                totalMatchCount = 0
            )
        }
        runExtraction()
    }

    fun selectScanSession(pages: List<ScanPage>, title: String = "Active Scan Session") {
        _uiState.update {
            it.copy(
                sourceKind = OcrSourceKind.SCAN_SESSION,
                selectedDocumentId = -1L,
                sourceTitle = title,
                sessionPages = pages,
                standaloneImagePath = null,
                runState = OcrRunState.Idle
            )
        }
    }

    fun selectScript(script: OcrScript) {
        _uiState.update { it.copy(selectedScript = script) }
    }

    fun updatePdfPassword(password: String) {
        _uiState.update { it.copy(pdfPassword = password) }
    }

    fun runExtraction() {
        val state = _uiState.value
        val script = state.selectedScript
        if (!ocrEngine.isScriptSupported(script)) {
            _uiState.update {
                it.copy(
                    runState = OcrRunState.Error(
                        message = "${script.label}: ${script.engineDescription}",
                        canRetry = false
                    )
                )
            }
            return
        }

        viewModelScope.launch {
            _uiState.update { it.copy(runState = OcrRunState.Extracting(1, 1)) }

            val result = when (state.sourceKind) {
                OcrSourceKind.STANDALONE_IMAGE -> {
                    val path = state.standaloneImagePath
                    if (path.isNullOrBlank()) {
                        Result.failure(IllegalStateException("Select an image first to extract text."))
                    } else {
                        ocrEngine.extractTextFromImageFile(path, script)
                    }
                }
                OcrSourceKind.SCAN_SESSION -> {
                    ocrEngine.extractTextFromScanPages(
                        pages = state.sessionPages,
                        script = script,
                        onProgress = { curr, total ->
                            _uiState.update { it.copy(runState = OcrRunState.Extracting(curr, total)) }
                        }
                    )
                }
                OcrSourceKind.DOCUMENT -> {
                    val doc = documentRepository.getDocumentById(state.selectedDocumentId)
                    if (doc == null) {
                        Result.failure(IllegalStateException("Select a document first to extract text."))
                    } else if (doc.fileType == DocumentFileType.IMAGE) {
                        ocrEngine.extractTextFromImageFile(doc.filePath, script)
                    } else {
                        ocrEngine.extractTextFromPdf(
                            pdfPath = doc.filePath,
                            pdfRendererHelper = pdfRendererHelper,
                            script = script,
                            password = state.pdfPassword.takeIf { it.isNotEmpty() },
                            onProgress = { curr, total ->
                                _uiState.update { it.copy(runState = OcrRunState.Extracting(curr, total)) }
                            }
                        )
                    }
                }
            }

            result.onSuccess { extraction ->
                _uiState.update { prev ->
                    val updated = prev.copy(
                        runState = OcrRunState.Success(
                            pageResults = extraction.pages,
                            warnings = extraction.warnings,
                            detectedLanguage = extraction.detectedLanguage,
                            effectiveScript = extraction.effectiveScript
                        ),
                        detectedLanguage = extraction.detectedLanguage,
                        detectedScriptUsed = extraction.effectiveScript,
                        editableText = extraction.combinedText
                    )
                    recomputeSearch(updated, updated.searchQuery)
                }
            }.onFailure { err ->
                _uiState.update {
                    it.copy(
                        runState = OcrRunState.Error(
                            message = err.message ?: "Text recognition failed. Verify image clarity and retry.",
                            canRetry = err !is UnsupportedOperationException
                        )
                    )
                }
            }
        }
    }

    fun updateEditableText(newText: String) {
        val quickDetected = newText.trim().takeIf { it.length >= 4 }?.let {
            OcrLanguageDetector.detectByUnicodeScript(it)
        }
        _uiState.update { prev ->
            recomputeSearch(
                prev.copy(
                    editableText = newText,
                    detectedLanguage = quickDetected ?: prev.detectedLanguage
                ),
                prev.searchQuery
            )
        }
    }

    fun updateSearchQuery(query: String) {
        _uiState.update { prev -> recomputeSearch(prev, query) }
    }

    private fun recomputeSearch(state: OcrUiState, query: String): OcrUiState {
        val clean = query.trim()
        if (clean.isEmpty() || state.editableText.isBlank()) {
            return state.copy(searchQuery = query, searchMatches = emptyList(), totalMatchCount = 0)
        }
        val lines = state.editableText.lines()
        val matches = mutableListOf<OcrSearchMatch>()
        var totalHits = 0
        lines.forEachIndexed { idx, line ->
            var cursor = line.indexOf(clean, ignoreCase = true)
            if (cursor >= 0) {
                var countOnLine = 0
                while (cursor >= 0) {
                    countOnLine++
                    cursor = line.indexOf(clean, cursor + clean.length, ignoreCase = true)
                }
                totalHits += countOnLine
                matches.add(
                    OcrSearchMatch(
                        lineNumber = idx + 1,
                        snippet = line.trim().take(120),
                        occurrenceCount = countOnLine
                    )
                )
            }
        }
        return state.copy(
            searchQuery = query,
            searchMatches = matches,
            totalMatchCount = totalHits
        )
    }

    fun saveExtractedNotesToDocument(onSaved: () -> Unit = {}) {
        val state = _uiState.value
        val docId = state.selectedDocumentId
        if (docId <= 0L) {
            _uiState.update { it.copy(statusMessage = "Save notes is available when a vault document is selected. Use Save as TXT for standalone photos.") }
            return
        }
        viewModelScope.launch {
            documentRepository.updateOcrText(docId, state.editableText)
                .onSuccess {
                    _uiState.update { it.copy(statusMessage = "Saved extracted text to '${state.sourceTitle}'") }
                    onSaved()
                }
                .onFailure { err ->
                    _uiState.update { it.copy(statusMessage = err.message ?: "Could not save OCR text") }
                }
        }
    }

    fun saveAsTxtToUri(destinationUri: Uri) {
        val text = _uiState.value.editableText
        if (text.isBlank()) return
        viewModelScope.launch {
            runCatching { fileManager.writeTextToUri(text, destinationUri) }
                .onSuccess { _uiState.update { it.copy(statusMessage = "Saved .txt file cleanly") } }
                .onFailure { err -> _uiState.update { it.copy(statusMessage = err.message ?: "Failed exporting .txt") } }
        }
    }

    fun saveAsTxtLocalAndShare() {
        val state = _uiState.value
        if (state.editableText.isBlank()) return
        viewModelScope.launch {
            runCatching {
                val base = state.sourceTitle.ifBlank { "OCR_Text" }
                fileManager.writeTextFile(base, state.editableText)
            }.onSuccess { file ->
                fileManager.shareFile(file.absolutePath, "text/plain", "Save or Share TXT")
                _uiState.update { it.copy(statusMessage = "Saved '${file.name}' locally") }
            }.onFailure { err ->
                _uiState.update { it.copy(statusMessage = err.message ?: "Could not write TXT file") }
            }
        }
    }

    fun clearStatusMessage() {
        _uiState.update { it.copy(statusMessage = null) }
    }
}
