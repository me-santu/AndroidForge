package com.example.ui.screens

import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.CallMerge
import androidx.compose.material.icons.automirrored.filled.RotateRight
import androidx.compose.material.icons.filled.Article
import androidx.compose.material.icons.filled.Badge
import androidx.compose.material.icons.filled.Build
import androidx.compose.material.icons.filled.Collections
import androidx.compose.material.icons.filled.Compress
import androidx.compose.material.icons.filled.ContentCopy
import androidx.compose.material.icons.filled.ContentCut
import androidx.compose.material.icons.filled.ControlPointDuplicate
import androidx.compose.material.icons.filled.DeleteForever
import androidx.compose.material.icons.filled.DeleteSweep
import androidx.compose.material.icons.filled.Description
import androidx.compose.material.icons.filled.Draw
import androidx.compose.material.icons.filled.DriveFileRenameOutline
import androidx.compose.material.icons.filled.FilterNone
import androidx.compose.material.icons.filled.FolderOpen
import androidx.compose.material.icons.filled.FormatListNumbered
import androidx.compose.material.icons.filled.Image
import androidx.compose.material.icons.filled.Info
import androidx.compose.material.icons.filled.LayersClear
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.LockOpen
import androidx.compose.material.icons.filled.PictureAsPdf
import androidx.compose.material.icons.filled.Print
import androidx.compose.material.icons.filled.Reorder
import androidx.compose.material.icons.filled.Share
import androidx.compose.material.icons.filled.SwapVert
import androidx.compose.material.icons.filled.TextFields
import androidx.compose.material.icons.filled.TextSnippet
import androidx.compose.material.icons.filled.Tune
import androidx.compose.material.icons.filled.ViewAgenda
import androidx.compose.material.icons.filled.Visibility
import androidx.compose.material.icons.filled.WaterDrop
import androidx.compose.ui.graphics.vector.ImageVector

enum class PdfToolCategory(val title: String) {
    MANAGEMENT("PDF Management"),
    EDITING("PDF Editing"),
    CONVERSION("PDF Conversion"),
    SECURITY("PDF Security & Stamp"),
    OPTIMIZATION("PDF Optimization"),
    SUITES("Document & Scan Suites")
}

enum class PdfToolId(
    val category: PdfToolCategory,
    val title: String,
    val subtitle: String,
    val badge: String,
    val icon: ImageVector,
    val testTag: String
) {
    // Management
    OPEN_PDF(
        PdfToolCategory.MANAGEMENT,
        "Open PDF",
        "Pick any PDF from Android storage via SAF & open it",
        "SAF",
        Icons.Filled.FolderOpen,
        "tool_open_pdf"
    ),
    VIEW_PDF(
        PdfToolCategory.MANAGEMENT,
        "View PDF",
        "Open a saved or imported PDF in zoomable viewer",
        "Viewer",
        Icons.Filled.Visibility,
        "tool_view_pdf"
    ),
    RENAME_PDF(
        PdfToolCategory.MANAGEMENT,
        "Rename PDF",
        "Update the display title of a saved PDF document",
        "Manage",
        Icons.Filled.DriveFileRenameOutline,
        "tool_rename_pdf"
    ),
    DELETE_PDF(
        PdfToolCategory.MANAGEMENT,
        "Delete PDF",
        "Move to Recycle Bin or permanently erase from storage",
        "Manage",
        Icons.Filled.DeleteForever,
        "tool_delete_pdf"
    ),
    SHARE_PDF(
        PdfToolCategory.MANAGEMENT,
        "Share PDF",
        "Send any PDF securely via Android Share Sheet",
        "Share",
        Icons.Filled.Share,
        "tool_share_pdf"
    ),
    PRINT_PDF(
        PdfToolCategory.MANAGEMENT,
        "Print PDF",
        "Send document directly to Android Print Manager",
        "Print",
        Icons.Filled.Print,
        "tool_print_pdf"
    ),
    DUPLICATE_PDF(
        PdfToolCategory.MANAGEMENT,
        "Duplicate PDF",
        "Create an independent editable copy in your library",
        "Copy",
        Icons.Filled.ContentCopy,
        "tool_duplicate_pdf"
    ),
    PDF_INFO(
        PdfToolCategory.MANAGEMENT,
        "PDF Information",
        "Inspect page count, dimensions, PDF version, encryption & metadata",
        "Inspect",
        Icons.Filled.Info,
        "tool_pdf_info"
    ),

    // Editing
    MERGE_PDF(
        PdfToolCategory.EDITING,
        "Merge PDF",
        "Combine 2 or more PDFs in your chosen order into one file",
        "Merge",
        Icons.AutoMirrored.Filled.CallMerge,
        "tool_merge_pdf"
    ),
    SPLIT_PDF(
        PdfToolCategory.EDITING,
        "Split PDF",
        "Extract a contiguous page range into a new PDF",
        "Split",
        Icons.Filled.ContentCut,
        "tool_split_pdf"
    ),
    EXTRACT_PAGES(
        PdfToolCategory.EDITING,
        "Extract Pages",
        "Pick individual pages (e.g. 1, 3, 5) into a separate PDF",
        "Extract",
        Icons.Filled.FilterNone,
        "tool_extract_pages"
    ),
    REORDER_PAGES(
        PdfToolCategory.EDITING,
        "Reorder Pages",
        "Move individual PDF pages up/down into a new sequence",
        "Order",
        Icons.Filled.SwapVert,
        "tool_reorder_pages"
    ),
    REARRANGE_PAGES(
        PdfToolCategory.EDITING,
        "Rearrange Pages",
        "Custom arrange, reverse, or move pages to top/bottom",
        "Arrange",
        Icons.Filled.Reorder,
        "tool_rearrange_pages"
    ),
    ROTATE_PAGES(
        PdfToolCategory.EDITING,
        "Rotate Pages",
        "Rotate all or selected PDF pages by 90°, 180°, or 270°",
        "Rotate",
        Icons.AutoMirrored.Filled.RotateRight,
        "tool_rotate_pages"
    ),
    DELETE_PAGES(
        PdfToolCategory.EDITING,
        "Delete Pages",
        "Remove unwanted pages and save a clean PDF copy",
        "Trim",
        Icons.Filled.DeleteSweep,
        "tool_delete_pages"
    ),
    DUPLICATE_PAGES(
        PdfToolCategory.EDITING,
        "Duplicate Pages",
        "Clone selected pages inside a PDF (adjacent or appended)",
        "Clone",
        Icons.Filled.ControlPointDuplicate,
        "tool_duplicate_pages"
    ),

    // Conversion
    IMAGES_TO_PDF(
        PdfToolCategory.CONVERSION,
        "Images to PDF",
        "Select gallery images or edit current scan session into a PDF",
        "Creator",
        Icons.Filled.PictureAsPdf,
        "tool_images_to_pdf"
    ),
    PDF_TO_IMAGES(
        PdfToolCategory.CONVERSION,
        "PDF to Images",
        "Render PDF pages to JPG or PNG, save to library or export ZIP",
        "Export",
        Icons.Filled.Collections,
        "tool_pdf_to_images"
    ),
    PDF_TO_JPG(
        PdfToolCategory.CONVERSION,
        "PDF to JPG",
        "Convert PDF pages to high-quality JPG images",
        "JPG",
        Icons.Filled.Image,
        "tool_pdf_to_jpg"
    ),
    PDF_TO_PNG(
        PdfToolCategory.CONVERSION,
        "PDF to PNG",
        "Convert PDF pages to lossless PNG images",
        "PNG",
        Icons.Filled.Image,
        "tool_pdf_to_png"
    ),
    TEXT_TO_PDF(
        PdfToolCategory.CONVERSION,
        "Text to PDF",
        "Type text or import .txt into a formatted multi-page PDF",
        "Generate",
        Icons.Filled.TextSnippet,
        "tool_text_to_pdf"
    ),
    PDF_TO_DOCX(
        PdfToolCategory.CONVERSION,
        "PDF to Word (DOCX)",
        "Export PDF text & page fallback snapshots to Word .docx",
        "DOCX",
        Icons.Filled.Description,
        "tool_pdf_to_docx"
    ),
    PDF_TO_TEXT(
        PdfToolCategory.CONVERSION,
        "PDF to Text",
        "Extract embedded selectable text, copy, share, or save .txt",
        "Text",
        Icons.Filled.Article,
        "tool_pdf_to_text"
    ),

    // Security & Stamp
    PROTECT_PDF(
        PdfToolCategory.SECURITY,
        "Protect PDF with Password",
        "Encrypt any PDF copy with AES-128 password protection",
        "AES-128",
        Icons.Filled.Lock,
        "tool_protect_pdf"
    ),
    UNLOCK_PDF(
        PdfToolCategory.SECURITY,
        "Unlock PDF",
        "Remove password protection when you know the current password",
        "Unlock",
        Icons.Filled.LockOpen,
        "tool_unlock_pdf"
    ),
    ADD_WATERMARK(
        PdfToolCategory.SECURITY,
        "Add Watermark",
        "Stamp diagonal semi-transparent text across all PDF pages",
        "Stamp",
        Icons.Filled.WaterDrop,
        "tool_watermark_pdf"
    ),
    REMOVE_WATERMARK(
        PdfToolCategory.SECURITY,
        "Remove Watermark",
        "Strip watermark annotations, layers & matching text overlays",
        "Clean",
        Icons.Filled.LayersClear,
        "tool_remove_watermark"
    ),
    ADD_PAGE_NUMBERS(
        PdfToolCategory.SECURITY,
        "Add Page Numbers",
        "Stamp customizable page numbers at top or bottom margin",
        "Pages",
        Icons.Filled.FormatListNumbered,
        "tool_add_page_numbers"
    ),
    ADD_HEADER_FOOTER(
        PdfToolCategory.SECURITY,
        "Add Header and Footer",
        "Add document header, footer text, and optional date stamp",
        "Layout",
        Icons.Filled.ViewAgenda,
        "tool_add_header_footer"
    ),

    // Optimization
    COMPRESS_PDF(
        PdfToolCategory.OPTIMIZATION,
        "Compress PDF",
        "Shrink PDF file size using Low, Balanced, or High presets",
        "Preset",
        Icons.Filled.Compress,
        "tool_compress_pdf"
    ),
    REDUCE_PDF_SIZE(
        PdfToolCategory.OPTIMIZATION,
        "Reduce PDF Size",
        "Fine-tune max image resolution, JPEG quality & strip metadata",
        "Optimize",
        Icons.Filled.Tune,
        "tool_reduce_pdf_size"
    ),
    REPAIR_PDF(
        PdfToolCategory.OPTIMIZATION,
        "Repair PDF",
        "Trim header junk & rebuild XRef / page tree where recoverable",
        "Recover",
        Icons.Filled.Build,
        "tool_repair_pdf"
    ),

    // Suites
    ID_SCANNER(
        PdfToolCategory.SUITES,
        "ID Document Scanner",
        "Aadhaar, PAN, Passport, Driving Licence & Voter ID workflows",
        "Studio",
        Icons.Filled.Badge,
        "tool_id_scanner"
    ),
    SIGNATURE_CREATOR(
        PdfToolCategory.SUITES,
        "Signature Creator",
        "Draw & store reusable transparent signatures",
        "Sign",
        Icons.Filled.Draw,
        "tool_signature_creator"
    ),
    SIGN_PDF(
        PdfToolCategory.SUITES,
        "Sign PDF Document",
        "Place, resize & reposition your saved signature on any PDF page",
        "Place",
        Icons.Filled.Draw,
        "tool_sign_pdf"
    ),
    OCR_EXTRACTOR(
        PdfToolCategory.SUITES,
        "OCR Text Extractor",
        "Extract English & Hindi text from images and scanned PDFs",
        "ML Kit v2",
        Icons.Filled.TextFields,
        "tool_ocr_extractor"
    )
}
