package com.example.ui.screens

import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowDownward
import androidx.compose.material.icons.filled.ArrowUpward
import androidx.compose.material.icons.filled.FileOpen
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.SwapVert
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Checkbox
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FilterChipDefaults
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.RadioButton
import androidx.compose.material3.Slider
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.unit.dp
import com.example.domain.model.DocumentItem
import com.example.domain.model.PageNumberFormat
import com.example.domain.model.PageNumberPosition
import com.example.domain.model.PdfCompressionLevel
import com.example.domain.model.PdfImageFormat
import com.example.util.FormatUtils
import kotlin.math.roundToInt

data class PdfToolWorkspaceCallbacks(
    val onPickPdfSafForSelection: () -> Unit,
    val onPickDamagedPdfSafRepair: (title: String, password: String?) -> Unit,
    val onViewPdf: (Long) -> Unit,
    val onRenamePdf: (Long, String) -> Unit,
    val onDeletePdf: (Long, Boolean) -> Unit,
    val onSharePdf: (DocumentItem) -> Unit,
    val onPrintPdf: (DocumentItem) -> Unit,
    val onDuplicatePdf: (Long, String) -> Unit,
    val onInspectInfo: (Long, String?) -> Unit,
    val onSplitPdf: (Long, String, Int, Int, String?) -> Unit,
    val onExtractPages: (Long, String, List<Int>, String?) -> Unit,
    val onReorderPages: (Long, String, List<Int>, String, String?) -> Unit,
    val onRotatePages: (Long, String, Set<Int>, Int, String?) -> Unit,
    val onDeletePages: (Long, String, Set<Int>, String?) -> Unit,
    val onDuplicatePages: (Long, String, List<Int>, Boolean, String?) -> Unit,
    val onExportImages: (Long, PdfImageFormat, List<Int>, Int, Boolean, String?) -> Unit,
    val onPdfToDocx: (Long, String, Boolean, String?) -> Unit,
    val onPdfToText: (Long, Int, Int, String?) -> Unit,
    val onProtectPdf: (Long, String, String, String?) -> Unit,
    val onUnlockPdf: (Long, String, String) -> Unit,
    val onAddWatermark: (Long, String, String, String?) -> Unit,
    val onRemoveWatermark: (Long, String, String?, String?) -> Unit,
    val onAddPageNumbers: (Long, String, PageNumberPosition, PageNumberFormat, Int, String?) -> Unit,
    val onAddHeaderFooter: (Long, String, String, String, Boolean, Float, String?) -> Unit,
    val onCompressPdf: (Long, String, PdfCompressionLevel, String?) -> Unit,
    val onReduceSize: (Long, String, Int, Float, Boolean, String?) -> Unit,
    val onRepairPdf: (Long, String, String?) -> Unit
)

@OptIn(ExperimentalLayoutApi::class)
@Composable
fun PdfToolWorkspaceDialog(
    tool: PdfToolId,
    pdfDocuments: List<DocumentItem>,
    preferredSelectedDocId: Long?,
    callbacks: PdfToolWorkspaceCallbacks,
    onDismiss: () -> Unit
) {
    var selectedDocId by remember(tool) {
        mutableStateOf(
            preferredSelectedDocId?.takeIf { id -> pdfDocuments.any { it.id == id } }
                ?: pdfDocuments.firstOrNull()?.id
                ?: -1L
        )
    }
    LaunchedEffect(pdfDocuments, preferredSelectedDocId) {
        if (preferredSelectedDocId != null && pdfDocuments.any { it.id == preferredSelectedDocId }) {
            selectedDocId = preferredSelectedDocId
        } else if (selectedDocId <= 0L && pdfDocuments.isNotEmpty()) {
            selectedDocId = pdfDocuments.first().id
        }
    }

    val selectedDoc = pdfDocuments.firstOrNull { it.id == selectedDocId }
    val defaultSuffix = remember(tool) {
        when (tool) {
            PdfToolId.RENAME_PDF -> ""
            PdfToolId.DUPLICATE_PDF -> "_Copy"
            PdfToolId.SPLIT_PDF -> "_Split"
            PdfToolId.EXTRACT_PAGES -> "_Extracted"
            PdfToolId.REORDER_PAGES -> "_Reordered"
            PdfToolId.REARRANGE_PAGES -> "_Rearranged"
            PdfToolId.ROTATE_PAGES -> "_Rotated"
            PdfToolId.DELETE_PAGES -> "_Trimmed"
            PdfToolId.DUPLICATE_PAGES -> "_DupPages"
            PdfToolId.PDF_TO_DOCX -> "_Word"
            PdfToolId.PROTECT_PDF -> "_Protected"
            PdfToolId.UNLOCK_PDF -> "_Unlocked"
            PdfToolId.ADD_WATERMARK -> "_Watermark"
            PdfToolId.REMOVE_WATERMARK -> "_Clean"
            PdfToolId.ADD_PAGE_NUMBERS -> "_Numbered"
            PdfToolId.ADD_HEADER_FOOTER -> "_HeaderFooter"
            PdfToolId.COMPRESS_PDF -> "_Compressed"
            PdfToolId.REDUCE_PDF_SIZE -> "_Reduced"
            PdfToolId.REPAIR_PDF -> "_Repaired"
            else -> ""
        }
    }
    var outputTitle by remember(selectedDocId, tool) {
        mutableStateOf((selectedDoc?.title ?: "DocuScan") + defaultSuffix)
    }

    var startStr by remember(selectedDocId, tool) { mutableStateOf("1") }
    var endStr by remember(selectedDocId, tool) {
        mutableStateOf((selectedDoc?.pageCount ?: 1).coerceAtLeast(1).toString())
    }
    var pageListInput by remember { mutableStateOf("1") }
    var deletePermanent by remember { mutableStateOf(false) }

    // Page reorder / rearrange interactive list
    val pageOrderList = remember(selectedDocId, selectedDoc?.pageCount, tool) {
        mutableStateListOf<Int>().apply {
            val count = (selectedDoc?.pageCount ?: 1).coerceIn(1, 200)
            addAll(1..count)
        }
    }

    var dupInsertAdjacent by remember { mutableStateOf(true) }
    var rotationDegrees by remember { mutableIntStateOf(90) }

    // PDF to Images
    var imageFormat by remember(tool) {
        mutableStateOf(
            when (tool) {
                PdfToolId.PDF_TO_PNG -> PdfImageFormat.PNG
                else -> PdfImageFormat.JPG
            }
        )
    }
    var saveImagesToLibrary by remember { mutableStateOf(true) }
    var imagePagesFilter by remember { mutableStateOf("") }

    // DOCX
    var includeImageFallback by remember { mutableStateOf(true) }

    // Security / Stamps
    var newPasswordInput by remember { mutableStateOf("") }
    var unlockPasswordInput by remember { mutableStateOf("") }
    var watermarkInput by remember { mutableStateOf("CONFIDENTIAL") }
    var removeWmMatchText by remember { mutableStateOf("") }
    var pageNumPosition by remember { mutableStateOf(PageNumberPosition.BOTTOM_CENTER) }
    var pageNumFormat by remember { mutableStateOf(PageNumberFormat.PAGE_X_OF_N) }
    var pageNumStartStr by remember { mutableStateOf("1") }
    var headerInput by remember { mutableStateOf("") }
    var footerInput by remember { mutableStateOf("") }
    var includeDateInFooter by remember { mutableStateOf(true) }

    // Compression / Reduce Size
    var compressionLevel by remember { mutableStateOf(PdfCompressionLevel.MEDIUM) }
    var reduceMaxDim by remember { mutableIntStateOf(1280) }
    var reduceQuality by remember { mutableFloatStateOf(0.55f) }
    var reduceStripMeta by remember { mutableStateOf(true) }

    val needsOutputTitleField = tool in setOf(
        PdfToolId.RENAME_PDF,
        PdfToolId.DUPLICATE_PDF,
        PdfToolId.SPLIT_PDF,
        PdfToolId.EXTRACT_PAGES,
        PdfToolId.REORDER_PAGES,
        PdfToolId.REARRANGE_PAGES,
        PdfToolId.ROTATE_PAGES,
        PdfToolId.DELETE_PAGES,
        PdfToolId.DUPLICATE_PAGES,
        PdfToolId.PDF_TO_DOCX,
        PdfToolId.PROTECT_PDF,
        PdfToolId.UNLOCK_PDF,
        PdfToolId.ADD_WATERMARK,
        PdfToolId.REMOVE_WATERMARK,
        PdfToolId.ADD_PAGE_NUMBERS,
        PdfToolId.ADD_HEADER_FOOTER,
        PdfToolId.COMPRESS_PDF,
        PdfToolId.REDUCE_PDF_SIZE,
        PdfToolId.REPAIR_PDF
    )

    val canExecute = selectedDocId > 0L &&
        (!needsOutputTitleField || outputTitle.isNotBlank()) &&
        when (tool) {
            PdfToolId.PROTECT_PDF -> newPasswordInput.isNotBlank()
            PdfToolId.UNLOCK_PDF -> unlockPasswordInput.isNotBlank()
            PdfToolId.ADD_WATERMARK -> watermarkInput.isNotBlank()
            PdfToolId.ADD_HEADER_FOOTER -> headerInput.isNotBlank() || footerInput.isNotBlank() || includeDateInFooter
            PdfToolId.DELETE_PAGES -> {
                val count = selectedDoc?.pageCount ?: 1
                val parsed = parsePageNumbersInput(pageListInput).filter { it in 1..count }.toSet()
                parsed.isNotEmpty() && parsed.size < count
            }
            else -> true
        }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text(tool.title) },
        text = {
            Column(
                modifier = Modifier
                    .heightIn(max = 450.dp)
                    .verticalScroll(rememberScrollState()),
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                OutlinedButton(
                    onClick = {
                        if (tool == PdfToolId.REPAIR_PDF) {
                            onDismiss()
                            callbacks.onPickDamagedPdfSafRepair(outputTitle, unlockPasswordInput.ifBlank { null })
                        } else {
                            callbacks.onPickPdfSafForSelection()
                        }
                    },
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("tool_dialog_pick_saf_btn")
                ) {
                    Icon(Icons.Filled.FileOpen, contentDescription = null, modifier = Modifier.size(18.dp))
                    Spacer(modifier = Modifier.size(6.dp))
                    Text(
                        if (tool == PdfToolId.REPAIR_PDF) {
                            "Select Damaged PDF from Device"
                        } else {
                            "Select PDF from Device"
                        }
                    )
                }

                if (needsOutputTitleField) {
                    OutlinedTextField(
                        value = outputTitle,
                        onValueChange = { outputTitle = it },
                        label = { Text(if (tool == PdfToolId.RENAME_PDF) "New Document Title" else "Output File Name") },
                        singleLine = true,
                        modifier = Modifier
                            .fillMaxWidth()
                            .testTag("tool_dialog_output_title")
                    )
                }

                Text("Select source PDF (${pdfDocuments.size}):", style = MaterialTheme.typography.labelMedium)
                if (pdfDocuments.isEmpty()) {
                    Text(
                        text = "No PDFs in library yet. Tap 'Select PDF from Device' above to pick any PDF from your phone.",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                } else {
                    pdfDocuments.forEach { doc ->
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .clickable { selectedDocId = doc.id },
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            RadioButton(
                                selected = selectedDocId == doc.id,
                                onClick = { selectedDocId = doc.id }
                            )
                            Column(modifier = Modifier.weight(1f)) {
                                Row(
                                    verticalAlignment = Alignment.CenterVertically,
                                    horizontalArrangement = Arrangement.spacedBy(4.dp)
                                ) {
                                    Text(doc.title, style = MaterialTheme.typography.bodySmall)
                                    if (doc.isPasswordProtected) {
                                        Icon(
                                            Icons.Filled.Lock,
                                            contentDescription = "Locked",
                                            modifier = Modifier.size(13.dp),
                                            tint = MaterialTheme.colorScheme.primary
                                        )
                                    }
                                }
                                Text(
                                    text = "${doc.pageCount}p · ${FormatUtils.formatBytes(doc.sizeBytes)}",
                                    style = MaterialTheme.typography.labelSmall,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant
                                )
                            }
                        }
                    }
                }

                HorizontalDivider()

                when (tool) {
                    PdfToolId.DELETE_PDF -> {
                        Text(
                            text = if (deletePermanent) {
                                "Permanent delete removes the file from internal storage immediately and cannot be undone."
                            } else {
                                "Move to Recycle Bin keeps the file recoverable."
                            },
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .clickable { deletePermanent = !deletePermanent },
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Checkbox(
                                checked = deletePermanent,
                                onCheckedChange = { deletePermanent = it }
                            )
                            Text("Permanently erase immediately", style = MaterialTheme.typography.bodySmall)
                        }
                    }

                    PdfToolId.SPLIT_PDF,
                    PdfToolId.PDF_TO_TEXT -> {
                        val maxPage = (selectedDoc?.pageCount ?: 1).coerceAtLeast(1)
                        Text("Page range (1..$maxPage):", style = MaterialTheme.typography.labelMedium)
                        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            OutlinedTextField(
                                value = startStr,
                                onValueChange = { startStr = it.filter(Char::isDigit) },
                                label = { Text("From") },
                                singleLine = true,
                                modifier = Modifier.weight(1f)
                            )
                            OutlinedTextField(
                                value = endStr,
                                onValueChange = { endStr = it.filter(Char::isDigit) },
                                label = { Text("To") },
                                singleLine = true,
                                modifier = Modifier.weight(1f)
                            )
                        }
                    }

                    PdfToolId.EXTRACT_PAGES -> {
                        OutlinedTextField(
                            value = pageListInput,
                            onValueChange = { pageListInput = it },
                            label = { Text("Pages to extract (e.g. 1, 3, 5)") },
                            singleLine = true,
                            modifier = Modifier.fillMaxWidth()
                        )
                    }

                    PdfToolId.REORDER_PAGES,
                    PdfToolId.REARRANGE_PAGES -> {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text("New Page Sequence:", style = MaterialTheme.typography.labelMedium)
                            TextButton(
                                onClick = {
                                    val reversed = pageOrderList.reversed()
                                    pageOrderList.clear()
                                    pageOrderList.addAll(reversed)
                                }
                            ) {
                                Icon(Icons.Filled.SwapVert, contentDescription = null, modifier = Modifier.size(16.dp))
                                Spacer(modifier = Modifier.size(4.dp))
                                Text("Reverse All")
                            }
                        }
                        pageOrderList.forEachIndexed { idx, origPage ->
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Text(
                                    text = "Position ${idx + 1}: Original Page $origPage",
                                    style = MaterialTheme.typography.bodySmall,
                                    modifier = Modifier.weight(1f)
                                )
                                IconButton(
                                    enabled = idx > 0,
                                    onClick = {
                                        val moved = pageOrderList.removeAt(idx)
                                        pageOrderList.add(idx - 1, moved)
                                    }
                                ) {
                                    Icon(Icons.Filled.ArrowUpward, contentDescription = "Move up", modifier = Modifier.size(16.dp))
                                }
                                IconButton(
                                    enabled = idx < pageOrderList.lastIndex,
                                    onClick = {
                                        val moved = pageOrderList.removeAt(idx)
                                        pageOrderList.add(idx + 1, moved)
                                    }
                                ) {
                                    Icon(Icons.Filled.ArrowDownward, contentDescription = "Move down", modifier = Modifier.size(16.dp))
                                }
                            }
                        }
                    }

                    PdfToolId.ROTATE_PAGES -> {
                        Text("Rotation Angle:", style = MaterialTheme.typography.labelMedium)
                        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            listOf(90, 180, 270).forEach { deg ->
                                FilterChip(
                                    selected = rotationDegrees == deg,
                                    onClick = { rotationDegrees = deg },
                                    label = { Text("$deg°") },
                                    colors = FilterChipDefaults.filterChipColors(
                                        selectedContainerColor = MaterialTheme.colorScheme.primary,
                                        selectedLabelColor = MaterialTheme.colorScheme.onPrimary
                                    )
                                )
                            }
                        }
                        OutlinedTextField(
                            value = pageListInput,
                            onValueChange = { pageListInput = it },
                            label = { Text("Pages (blank = all pages)") },
                            singleLine = true,
                            modifier = Modifier.fillMaxWidth()
                        )
                    }

                    PdfToolId.DELETE_PAGES -> {
                        val total = (selectedDoc?.pageCount ?: 1).coerceAtLeast(1)
                        if (total <= 1) {
                            Text(
                                text = "This PDF has only 1 page. A PDF document must keep at least 1 page.",
                                style = MaterialTheme.typography.bodySmall,
                                color = MaterialTheme.colorScheme.error
                            )
                        }
                        OutlinedTextField(
                            value = pageListInput,
                            onValueChange = { pageListInput = it },
                            label = { Text("Pages to remove (1..$total, leave >= 1 page)") },
                            singleLine = true,
                            modifier = Modifier.fillMaxWidth()
                        )
                    }

                    PdfToolId.DUPLICATE_PAGES -> {
                        OutlinedTextField(
                            value = pageListInput,
                            onValueChange = { pageListInput = it },
                            label = { Text("Pages to duplicate (e.g. 1, 2)") },
                            singleLine = true,
                            modifier = Modifier.fillMaxWidth()
                        )
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .clickable { dupInsertAdjacent = !dupInsertAdjacent },
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Checkbox(
                                checked = dupInsertAdjacent,
                                onCheckedChange = { dupInsertAdjacent = it }
                            )
                            Text("Insert copy right after original page", style = MaterialTheme.typography.bodySmall)
                        }
                    }

                    PdfToolId.PDF_TO_IMAGES,
                    PdfToolId.PDF_TO_JPG,
                    PdfToolId.PDF_TO_PNG -> {
                        if (tool == PdfToolId.PDF_TO_IMAGES) {
                            Text("Image Format:", style = MaterialTheme.typography.labelMedium)
                            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                PdfImageFormat.entries.forEach { fmt ->
                                    FilterChip(
                                        selected = imageFormat == fmt,
                                        onClick = { imageFormat = fmt },
                                        label = { Text(fmt.label) },
                                        colors = FilterChipDefaults.filterChipColors(
                                            selectedContainerColor = MaterialTheme.colorScheme.primary,
                                            selectedLabelColor = MaterialTheme.colorScheme.onPrimary
                                        )
                                    )
                                }
                            }
                        } else {
                            Text("Output Format: ${imageFormat.label}", style = MaterialTheme.typography.labelMedium)
                        }
                        OutlinedTextField(
                            value = imagePagesFilter,
                            onValueChange = { imagePagesFilter = it },
                            label = { Text("Pages (blank = all pages)") },
                            singleLine = true,
                            modifier = Modifier.fillMaxWidth()
                        )
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .clickable { saveImagesToLibrary = !saveImagesToLibrary },
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Checkbox(
                                checked = saveImagesToLibrary,
                                onCheckedChange = { saveImagesToLibrary = it }
                            )
                            Text("Also save rendered images in DocuScan library", style = MaterialTheme.typography.bodySmall)
                        }
                    }

                    PdfToolId.PDF_TO_DOCX -> {
                        Text(
                            text = "Converts selectable text paragraphs into real .docx Word format. Scanned/image-only pages can be embedded as visual snapshots.",
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .clickable { includeImageFallback = !includeImageFallback },
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Checkbox(
                                checked = includeImageFallback,
                                onCheckedChange = { includeImageFallback = it }
                            )
                            Text("Include image fallback for scanned pages", style = MaterialTheme.typography.bodySmall)
                        }
                    }

                    PdfToolId.PROTECT_PDF -> {
                        OutlinedTextField(
                            value = newPasswordInput,
                            onValueChange = { newPasswordInput = it },
                            label = { Text("New AES-128 Password") },
                            visualTransformation = PasswordVisualTransformation(),
                            singleLine = true,
                            modifier = Modifier
                                .fillMaxWidth()
                                .testTag("protect_new_password_input")
                        )
                    }

                    PdfToolId.UNLOCK_PDF -> {
                        Text(
                            text = "Unlocks password-protected PDFs only when you provide the valid current password.",
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                        OutlinedTextField(
                            value = unlockPasswordInput,
                            onValueChange = { unlockPasswordInput = it },
                            label = { Text("Known PDF Password") },
                            visualTransformation = PasswordVisualTransformation(),
                            singleLine = true,
                            modifier = Modifier
                                .fillMaxWidth()
                                .testTag("unlock_password_input")
                        )
                    }

                    PdfToolId.ADD_WATERMARK -> {
                        OutlinedTextField(
                            value = watermarkInput,
                            onValueChange = { watermarkInput = it },
                            label = { Text("Watermark text") },
                            singleLine = true,
                            modifier = Modifier.fillMaxWidth()
                        )
                    }

                    PdfToolId.REMOVE_WATERMARK -> {
                        Text(
                            text = "Strips PDF Watermark/Stamp annotations, watermark layers, and matching text overlays. Note: watermarks flattened into raster images or vector curves cannot be removed automatically.",
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                        OutlinedTextField(
                            value = removeWmMatchText,
                            onValueChange = { removeWmMatchText = it },
                            label = { Text("Watermark text to match (optional)") },
                            placeholder = { Text("e.g. CONFIDENTIAL or DRAFT") },
                            singleLine = true,
                            modifier = Modifier.fillMaxWidth()
                        )
                    }

                    PdfToolId.ADD_PAGE_NUMBERS -> {
                        Text("Position:", style = MaterialTheme.typography.labelMedium)
                        FlowRow(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                            PageNumberPosition.entries.forEach { pos ->
                                FilterChip(
                                    selected = pageNumPosition == pos,
                                    onClick = { pageNumPosition = pos },
                                    label = { Text(pos.label) },
                                    colors = FilterChipDefaults.filterChipColors(
                                        selectedContainerColor = MaterialTheme.colorScheme.primary,
                                        selectedLabelColor = MaterialTheme.colorScheme.onPrimary
                                    )
                                )
                            }
                        }
                        Text("Format:", style = MaterialTheme.typography.labelMedium)
                        FlowRow(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                            PageNumberFormat.entries.forEach { fmt ->
                                FilterChip(
                                    selected = pageNumFormat == fmt,
                                    onClick = { pageNumFormat = fmt },
                                    label = { Text(fmt.label) },
                                    colors = FilterChipDefaults.filterChipColors(
                                        selectedContainerColor = MaterialTheme.colorScheme.primary,
                                        selectedLabelColor = MaterialTheme.colorScheme.onPrimary
                                    )
                                )
                            }
                        }
                        OutlinedTextField(
                            value = pageNumStartStr,
                            onValueChange = { pageNumStartStr = it.filter(Char::isDigit) },
                            label = { Text("Start numbering at") },
                            singleLine = true,
                            modifier = Modifier.fillMaxWidth()
                        )
                    }

                    PdfToolId.ADD_HEADER_FOOTER -> {
                        OutlinedTextField(
                            value = headerInput,
                            onValueChange = { headerInput = it },
                            label = { Text("Header text (top)") },
                            singleLine = true,
                            modifier = Modifier.fillMaxWidth()
                        )
                        OutlinedTextField(
                            value = footerInput,
                            onValueChange = { footerInput = it },
                            label = { Text("Footer text (bottom)") },
                            singleLine = true,
                            modifier = Modifier.fillMaxWidth()
                        )
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .clickable { includeDateInFooter = !includeDateInFooter },
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Checkbox(
                                checked = includeDateInFooter,
                                onCheckedChange = { includeDateInFooter = it }
                            )
                            Text("Append today's date to footer", style = MaterialTheme.typography.bodySmall)
                        }
                    }

                    PdfToolId.COMPRESS_PDF -> {
                        Text("Compression Preset:", style = MaterialTheme.typography.labelMedium)
                        PdfCompressionLevel.entries.forEach { level ->
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .clickable { compressionLevel = level },
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                RadioButton(
                                    selected = compressionLevel == level,
                                    onClick = { compressionLevel = level }
                                )
                                Text(level.label, style = MaterialTheme.typography.bodySmall)
                            }
                        }
                    }

                    PdfToolId.REDUCE_PDF_SIZE -> {
                        Text("Max Image Resolution:", style = MaterialTheme.typography.labelMedium)
                        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            listOf(900, 1280, 1800).forEach { dim ->
                                FilterChip(
                                    selected = reduceMaxDim == dim,
                                    onClick = { reduceMaxDim = dim },
                                    label = { Text("${dim}px") },
                                    colors = FilterChipDefaults.filterChipColors(
                                        selectedContainerColor = MaterialTheme.colorScheme.primary,
                                        selectedLabelColor = MaterialTheme.colorScheme.onPrimary
                                    )
                                )
                            }
                        }
                        Text(
                            text = "JPEG Quality: ${(reduceQuality * 100).roundToInt()}%",
                            style = MaterialTheme.typography.labelMedium
                        )
                        Slider(
                            value = reduceQuality,
                            onValueChange = { reduceQuality = it },
                            valueRange = 0.25f..0.90f
                        )
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .clickable { reduceStripMeta = !reduceStripMeta },
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Checkbox(
                                checked = reduceStripMeta,
                                onCheckedChange = { reduceStripMeta = it }
                            )
                            Text("Strip XMP metadata & embedded page thumbnails", style = MaterialTheme.typography.bodySmall)
                        }
                    }

                    PdfToolId.REPAIR_PDF -> {
                        Text(
                            text = "Repairs damaged XRef tables, leading junk bytes before %PDF-, or reconstructs readable pages. Severely corrupted files or locked PDFs without password cannot be rebuilt.",
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }

                    else -> Unit
                }

                if (selectedDoc?.isPasswordProtected == true &&
                    tool !in setOf(
                        PdfToolId.UNLOCK_PDF,
                        PdfToolId.VIEW_PDF,
                        PdfToolId.RENAME_PDF,
                        PdfToolId.DELETE_PDF,
                        PdfToolId.SHARE_PDF,
                        PdfToolId.PRINT_PDF,
                        PdfToolId.DUPLICATE_PDF
                    )
                ) {
                    OutlinedTextField(
                        value = unlockPasswordInput,
                        onValueChange = { unlockPasswordInput = it },
                        label = { Text("Current PDF Password") },
                        visualTransformation = PasswordVisualTransformation(),
                        singleLine = true,
                        modifier = Modifier.fillMaxWidth()
                    )
                }
            }
        },
        confirmButton = {
            TextButton(
                enabled = canExecute,
                onClick = {
                    val doc = selectedDoc ?: return@TextButton
                    val pwd = unlockPasswordInput.ifBlank { null }
                    val parsedPages = parsePageNumbersInput(pageListInput)
                    val titleClean = outputTitle.trim()

                    onDismiss()
                    when (tool) {
                        PdfToolId.VIEW_PDF -> callbacks.onViewPdf(doc.id)
                        PdfToolId.RENAME_PDF -> callbacks.onRenamePdf(doc.id, titleClean)
                        PdfToolId.DELETE_PDF -> callbacks.onDeletePdf(doc.id, deletePermanent)
                        PdfToolId.SHARE_PDF -> callbacks.onSharePdf(doc)
                        PdfToolId.PRINT_PDF -> callbacks.onPrintPdf(doc)
                        PdfToolId.DUPLICATE_PDF -> callbacks.onDuplicatePdf(doc.id, titleClean)
                        PdfToolId.PDF_INFO -> callbacks.onInspectInfo(doc.id, pwd)
                        PdfToolId.SPLIT_PDF -> {
                            val s = startStr.toIntOrNull()?.coerceIn(1, doc.pageCount.coerceAtLeast(1)) ?: 1
                            val e = endStr.toIntOrNull()?.coerceIn(s, doc.pageCount.coerceAtLeast(s)) ?: s
                            callbacks.onSplitPdf(doc.id, titleClean, s, e, pwd)
                        }
                        PdfToolId.EXTRACT_PAGES -> {
                            callbacks.onExtractPages(doc.id, titleClean, parsedPages.ifEmpty { listOf(1) }, pwd)
                        }
                        PdfToolId.REORDER_PAGES,
                        PdfToolId.REARRANGE_PAGES -> {
                            callbacks.onReorderPages(doc.id, titleClean, pageOrderList.toList(), tool.title, pwd)
                        }
                        PdfToolId.ROTATE_PAGES -> {
                            val targets = if (pageListInput.isBlank()) emptySet() else parsedPages.toSet()
                            callbacks.onRotatePages(doc.id, titleClean, targets, rotationDegrees, pwd)
                        }
                        PdfToolId.DELETE_PAGES -> {
                            callbacks.onDeletePages(doc.id, titleClean, parsedPages.toSet(), pwd)
                        }
                        PdfToolId.DUPLICATE_PAGES -> {
                            callbacks.onDuplicatePages(
                                doc.id,
                                titleClean,
                                parsedPages.ifEmpty { listOf(1) },
                                dupInsertAdjacent,
                                pwd
                            )
                        }
                        PdfToolId.PDF_TO_IMAGES,
                        PdfToolId.PDF_TO_JPG,
                        PdfToolId.PDF_TO_PNG -> {
                            val targets = if (imagePagesFilter.isBlank()) emptyList() else parsePageNumbersInput(imagePagesFilter)
                            callbacks.onExportImages(doc.id, imageFormat, targets, 90, saveImagesToLibrary, pwd)
                        }
                        PdfToolId.PDF_TO_DOCX -> {
                            callbacks.onPdfToDocx(doc.id, titleClean, includeImageFallback, pwd)
                        }
                        PdfToolId.PDF_TO_TEXT -> {
                            val s = startStr.toIntOrNull()?.coerceIn(1, doc.pageCount.coerceAtLeast(1)) ?: 1
                            val e = endStr.toIntOrNull()?.coerceIn(s, doc.pageCount.coerceAtLeast(s)) ?: doc.pageCount.coerceAtLeast(s)
                            callbacks.onPdfToText(doc.id, s, e, pwd)
                        }
                        PdfToolId.PROTECT_PDF -> callbacks.onProtectPdf(doc.id, titleClean, newPasswordInput, pwd)
                        PdfToolId.UNLOCK_PDF -> callbacks.onUnlockPdf(doc.id, titleClean, unlockPasswordInput)
                        PdfToolId.ADD_WATERMARK -> callbacks.onAddWatermark(doc.id, titleClean, watermarkInput.trim(), pwd)
                        PdfToolId.REMOVE_WATERMARK -> callbacks.onRemoveWatermark(doc.id, titleClean, removeWmMatchText.ifBlank { null }, pwd)
                        PdfToolId.ADD_PAGE_NUMBERS -> {
                            val startAt = pageNumStartStr.toIntOrNull()?.coerceAtLeast(1) ?: 1
                            callbacks.onAddPageNumbers(doc.id, titleClean, pageNumPosition, pageNumFormat, startAt, pwd)
                        }
                        PdfToolId.ADD_HEADER_FOOTER -> {
                            callbacks.onAddHeaderFooter(doc.id, titleClean, headerInput, footerInput, includeDateInFooter, 10f, pwd)
                        }
                        PdfToolId.COMPRESS_PDF -> callbacks.onCompressPdf(doc.id, titleClean, compressionLevel, pwd)
                        PdfToolId.REDUCE_PDF_SIZE -> callbacks.onReduceSize(doc.id, titleClean, reduceMaxDim, reduceQuality, reduceStripMeta, pwd)
                        PdfToolId.REPAIR_PDF -> callbacks.onRepairPdf(doc.id, titleClean, pwd)
                        else -> Unit
                    }
                },
                modifier = Modifier.testTag("tool_dialog_confirm_btn")
            ) {
                Text(
                    when (tool) {
                        PdfToolId.VIEW_PDF -> "Open Viewer"
                        PdfToolId.SHARE_PDF -> "Share PDF"
                        PdfToolId.PRINT_PDF -> "Print PDF"
                        PdfToolId.DELETE_PDF -> if (deletePermanent) "Erase" else "Move to Bin"
                        PdfToolId.RENAME_PDF -> "Rename"
                        PdfToolId.PDF_INFO -> "Inspect"
                        else -> "Run Tool"
                    }
                )
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) { Text("Cancel") }
        }
    )
}

private fun parsePageNumbersInput(raw: String): List<Int> =
    raw.split(",", " ", ";")
        .mapNotNull { it.trim().toIntOrNull() }
        .filter { it >= 1 }
