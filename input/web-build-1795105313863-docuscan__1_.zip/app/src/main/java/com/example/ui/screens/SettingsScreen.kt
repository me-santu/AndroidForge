package com.example.ui.screens

import android.content.Context
import android.content.ContextWrapper
import android.content.Intent
import android.provider.Settings
import androidx.activity.compose.BackHandler
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.automirrored.filled.KeyboardArrowRight
import androidx.compose.material.icons.filled.Palette
import androidx.compose.material.icons.filled.PrivacyTip
import androidx.compose.material.icons.filled.Shield
import androidx.compose.material.icons.filled.Storage
import androidx.compose.material.icons.filled.Tune
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.unit.dp
import androidx.fragment.app.FragmentActivity
import com.example.BuildConfig
import com.example.domain.model.AppLanguage
import com.example.domain.model.CacheSummary
import com.example.domain.model.PdfPageSize
import com.example.domain.model.ScanQuality
import com.example.domain.model.StorageSummary
import com.example.domain.model.ThemeMode
import com.example.domain.model.UserPreferences
import com.example.security.BiometricCapability
import com.example.security.SecurityManager
import com.example.ui.components.DocuScanCard
import com.example.ui.components.PhaseStatusChip
import com.example.util.FormatUtils
import com.example.util.LocalAppStrings

enum class SettingsCategory {
    APPEARANCE,
    SCANNING_PDF,
    SECURITY_BIOMETRICS,
    STORAGE_BACKUP
}

private tailrec fun Context.findSettingsFragmentActivity(): FragmentActivity? = when (this) {
    is FragmentActivity -> this
    is ContextWrapper -> baseContext.findSettingsFragmentActivity()
    else -> null
}

@Composable
fun SettingsScreen(
    preferences: UserPreferences,
    storageSummary: StorageSummary,
    cacheSummary: CacheSummary,
    biometricCapability: BiometricCapability,
    securityManager: SecurityManager,
    onSelectTheme: (ThemeMode) -> Unit,
    onSelectLanguage: (AppLanguage) -> Unit,
    onSelectScanQuality: (ScanQuality) -> Unit,
    onSelectDefaultPageSize: (PdfPageSize) -> Unit,
    onToggleAutoEnhance: (Boolean) -> Unit,
    onToggleAppLock: (Boolean) -> Unit,
    onToggleBiometricUnlock: (Boolean) -> Unit,
    onToggleEncryptSensitiveFiles: (Boolean) -> Unit,
    onConfigurePin: (newPin: String, enableLock: Boolean) -> Result<Unit>,
    onRemovePin: () -> Unit,
    onLockVaultNow: () -> Unit,
    onClearTempCache: () -> Unit,
    onOpenBackup: () -> Unit,
    onOpenRecycleBin: () -> Unit,
    onOpenAboutPrivacy: () -> Unit,
    onSettingsStatusMessage: (String) -> Unit = {},
    onBeforeExternalSettingsLaunch: () -> Unit = {},
    modifier: Modifier = Modifier
) {
    val strings = LocalAppStrings.current
    val context = LocalContext.current

    var selectedCategory by remember { mutableStateOf<SettingsCategory?>(null) }
    var showPinSetupDialog by remember { mutableStateOf(false) }
    var enableLockAfterPinSetup by remember { mutableStateOf(true) }
    var pinInput by remember { mutableStateOf("") }
    var pinConfirmInput by remember { mutableStateOf("") }
    var pinDialogError by remember { mutableStateOf<String?>(null) }

    BackHandler(enabled = selectedCategory != null) {
        selectedCategory = null
    }

    fun launchBiometricVerification(
        title: String,
        subtitle: String,
        onVerified: () -> Unit
    ) {
        val activity = context.findSettingsFragmentActivity()
        if (activity == null) {
            onVerified()
            return
        }
        securityManager.authenticateBiometric(
            activity = activity,
            title = title,
            subtitle = subtitle,
            negativeButtonText = "Cancel",
            allowDeviceCredentialFallback = true,
            onSuccess = onVerified,
            onError = { err ->
                if (err.isNotBlank()) {
                    onSettingsStatusMessage(err)
                }
            }
        )
    }

    fun openDeviceBiometricSettings() {
        onBeforeExternalSettingsLaunch()
        val enrollIntent = securityManager.createBiometricEnrollIntent().apply {
            addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        }
        val launched = runCatching { context.startActivity(enrollIntent) }.isSuccess
        if (!launched) {
            runCatching {
                context.startActivity(
                    Intent(Settings.ACTION_SECURITY_SETTINGS).apply {
                        addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                    }
                )
            }.onFailure {
                onSettingsStatusMessage("Open Android Settings > Security to enroll fingerprint or screen lock.")
            }
        }
    }

    val activeCat = selectedCategory

    Column(modifier = modifier.fillMaxSize()) {
        if (activeCat != null) {
            val catTitle = when (activeCat) {
                SettingsCategory.APPEARANCE -> strings.catAppearanceTitle
                SettingsCategory.SCANNING_PDF -> strings.catScanningTitle
                SettingsCategory.SECURITY_BIOMETRICS -> strings.catSecurityTitle
                SettingsCategory.STORAGE_BACKUP -> strings.catStorageTitle
            }
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 8.dp, vertical = 6.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                IconButton(
                    onClick = { selectedCategory = null },
                    modifier = Modifier.testTag("settings_category_back_btn")
                ) {
                    Icon(
                        imageVector = Icons.AutoMirrored.Filled.ArrowBack,
                        contentDescription = "Back to Settings categories"
                    )
                }
                Column(modifier = Modifier.weight(1f)) {
                    Text(catTitle, style = MaterialTheme.typography.headlineSmall)
                    Text(
                        text = strings.settingsTitle,
                        style = MaterialTheme.typography.labelMedium,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
            }
        }

        LazyColumn(
            modifier = Modifier
                .weight(1f)
                .fillMaxWidth()
                .testTag("settings_list"),
            contentPadding = PaddingValues(horizontal = 16.dp, vertical = 12.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            if (activeCat == null) {
                // Top-level Categorized Settings Hub
                item {
                    Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
                        Text(strings.settingsTitle, style = MaterialTheme.typography.headlineMedium)
                        Text(
                            text = strings.settingsSubtitle,
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                }

                item {
                    SettingsCategoryCard(
                        title = strings.catAppearanceTitle,
                        subtitle = "${preferences.themeMode.label} · ${preferences.appLanguage.nativeLabel}",
                        badge = preferences.appLanguage.code.uppercase(),
                        icon = Icons.Filled.Palette,
                        highlighted = false,
                        testTag = "settings_cat_appearance",
                        onClick = { selectedCategory = SettingsCategory.APPEARANCE }
                    )
                }

                item {
                    SettingsCategoryCard(
                        title = strings.catScanningTitle,
                        subtitle = "${preferences.scanQuality.label} · ${preferences.defaultPageSize.label} · Auto-Enhance ${if (preferences.autoEnhance) "ON" else "OFF"}",
                        badge = preferences.defaultPageSize.label,
                        icon = Icons.Filled.Tune,
                        highlighted = false,
                        testTag = "settings_cat_scanning",
                        onClick = { selectedCategory = SettingsCategory.SCANNING_PDF }
                    )
                }

                item {
                    val secSummary = buildString {
                        append(if (preferences.appLockEnabled) "App Lock ON" else "App Lock OFF")
                        if (preferences.biometricUnlockEnabled) append(" · Biometric ON")
                        if (preferences.hasPinConfigured) append(" · PIN Set")
                        if (!preferences.biometricUnlockEnabled && !preferences.hasPinConfigured) {
                            append(" · ${if (biometricCapability.isAvailable) "Biometric Ready" else "Keystore Vault"}")
                        }
                    }
                    SettingsCategoryCard(
                        title = strings.catSecurityTitle,
                        subtitle = secSummary,
                        badge = if (preferences.appLockEnabled) "Protected" else "Vault",
                        icon = Icons.Filled.Shield,
                        highlighted = preferences.appLockEnabled,
                        testTag = "settings_cat_security",
                        onClick = { selectedCategory = SettingsCategory.SECURITY_BIOMETRICS }
                    )
                }

                item {
                    SettingsCategoryCard(
                        title = strings.catStorageTitle,
                        subtitle = "${FormatUtils.formatBytes(storageSummary.totalUsedBytes)} vault · ${FormatUtils.formatBytes(cacheSummary.totalClearableCacheBytes)} cache · ${storageSummary.trashCount} in Bin",
                        badge = "${storageSummary.activeDocumentCount} files",
                        icon = Icons.Filled.Storage,
                        highlighted = false,
                        testTag = "settings_cat_storage",
                        onClick = { selectedCategory = SettingsCategory.STORAGE_BACKUP }
                    )
                }

                item {
                    SettingsCategoryCard(
                        title = strings.catAboutTitle,
                        subtitle = "DocuScan v${BuildConfig.VERSION_NAME} · ${strings.aboutAndPrivacySubtitle}",
                        badge = "Offline",
                        icon = Icons.Filled.PrivacyTip,
                        highlighted = false,
                        testTag = "settings_about_privacy_row",
                        onClick = onOpenAboutPrivacy
                    )
                }
            } else {
                // Inside Selected Category
                item {
                    when (activeCat) {
                        SettingsCategory.APPEARANCE -> AppearanceSettingsSection(
                            preferences = preferences,
                            onSelectTheme = onSelectTheme,
                            onSelectLanguage = onSelectLanguage
                        )
                        SettingsCategory.SCANNING_PDF -> ScanningPdfSettingsSection(
                            preferences = preferences,
                            onSelectScanQuality = onSelectScanQuality,
                            onSelectDefaultPageSize = onSelectDefaultPageSize,
                            onToggleAutoEnhance = onToggleAutoEnhance
                        )
                        SettingsCategory.SECURITY_BIOMETRICS -> SecuritySettingsSection(
                            preferences = preferences,
                            biometricCapability = biometricCapability,
                            securityManager = securityManager,
                            onToggleAppLock = onToggleAppLock,
                            onRequestPinSetup = { enableAfter ->
                                enableLockAfterPinSetup = enableAfter
                                pinInput = ""
                                pinConfirmInput = ""
                                pinDialogError = null
                                showPinSetupDialog = true
                            },
                            onToggleBiometricUnlock = { wantEnabled ->
                                if (wantEnabled) {
                                    launchBiometricVerification(
                                        title = strings.biometricUnlock,
                                        subtitle = "Confirm your fingerprint, face, or screen lock to enable Biometric Unlock",
                                        onVerified = { onToggleBiometricUnlock(true) }
                                    )
                                } else {
                                    onToggleBiometricUnlock(false)
                                }
                            },
                            onTestBiometricUnlock = {
                                launchBiometricVerification(
                                    title = strings.testBiometricUnlock,
                                    subtitle = "Verify your fingerprint, face, or screen lock",
                                    onVerified = {
                                        onSettingsStatusMessage("Biometric authentication succeeded!")
                                    }
                                )
                            },
                            onOpenBiometricEnrollment = ::openDeviceBiometricSettings,
                            onToggleEncryptSensitiveFiles = onToggleEncryptSensitiveFiles,
                            onRemovePin = onRemovePin,
                            onLockVaultNow = onLockVaultNow
                        )
                        SettingsCategory.STORAGE_BACKUP -> StorageBackupSettingsSection(
                            storageSummary = storageSummary,
                            cacheSummary = cacheSummary,
                            onClearTempCache = onClearTempCache,
                            onOpenBackup = onOpenBackup,
                            onOpenRecycleBin = onOpenRecycleBin
                        )
                    }
                }
            }
        }
    }

    if (showPinSetupDialog) {
        AlertDialog(
            onDismissRequest = { showPinSetupDialog = false },
            title = { Text(if (preferences.hasPinConfigured) strings.changePin else strings.setPin) },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    Text(
                        text = "Enter a 4–8 digit PIN. It is hashed with a random salt and sealed using Android Keystore AES-256-GCM.",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                    OutlinedTextField(
                        value = pinInput,
                        onValueChange = { value ->
                            if (value.length <= 8 && value.all(Char::isDigit)) {
                                pinInput = value
                                pinDialogError = null
                            }
                        },
                        label = { Text("New PIN (4–8 digits)") },
                        singleLine = true,
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.NumberPassword),
                        visualTransformation = PasswordVisualTransformation(),
                        modifier = Modifier
                            .fillMaxWidth()
                            .testTag("pin_setup_input")
                    )
                    OutlinedTextField(
                        value = pinConfirmInput,
                        onValueChange = { value ->
                            if (value.length <= 8 && value.all(Char::isDigit)) {
                                pinConfirmInput = value
                                pinDialogError = null
                            }
                        },
                        label = { Text("Confirm PIN") },
                        singleLine = true,
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.NumberPassword),
                        visualTransformation = PasswordVisualTransformation(),
                        modifier = Modifier
                            .fillMaxWidth()
                            .testTag("pin_setup_confirm_input")
                    )
                    if (!pinDialogError.isNullOrBlank()) {
                        Text(
                            text = pinDialogError!!,
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.error
                        )
                    }
                }
            },
            confirmButton = {
                TextButton(
                    onClick = {
                        when {
                            pinInput.length !in 4..8 -> {
                                pinDialogError = "PIN must be 4 to 8 digits."
                            }
                            pinInput != pinConfirmInput -> {
                                pinDialogError = "PINs do not match."
                            }
                            else -> {
                                onConfigurePin(pinInput, enableLockAfterPinSetup)
                                    .onSuccess { showPinSetupDialog = false }
                                    .onFailure { pinDialogError = it.message ?: "Could not save PIN" }
                            }
                        }
                    },
                    modifier = Modifier.testTag("pin_setup_save_btn")
                ) {
                    Text("Save PIN")
                }
            },
            dismissButton = {
                TextButton(onClick = { showPinSetupDialog = false }) { Text("Cancel") }
            }
        )
    }
}

@Composable
private fun SettingsCategoryCard(
    title: String,
    subtitle: String,
    badge: String,
    icon: ImageVector,
    highlighted: Boolean,
    testTag: String,
    onClick: () -> Unit
) {
    DocuScanCard(
        highlighted = highlighted,
        onClick = onClick,
        modifier = Modifier
            .fillMaxWidth()
            .testTag(testTag)
    ) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            Box(
                modifier = Modifier
                    .size(44.dp)
                    .clip(RoundedCornerShape(12.dp))
                    .background(MaterialTheme.colorScheme.primaryContainer),
                contentAlignment = Alignment.Center
            ) {
                Icon(
                    imageVector = icon,
                    contentDescription = title,
                    tint = MaterialTheme.colorScheme.primary,
                    modifier = Modifier.size(22.dp)
                )
            }
            Column(
                modifier = Modifier.weight(1f),
                verticalArrangement = Arrangement.spacedBy(3.dp)
            ) {
                Text(
                    text = title,
                    style = MaterialTheme.typography.titleMedium,
                    color = MaterialTheme.colorScheme.onSurface
                )
                Text(
                    text = subtitle,
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
            PhaseStatusChip(text = badge, highlighted = highlighted)
            Icon(
                imageVector = Icons.AutoMirrored.Filled.KeyboardArrowRight,
                contentDescription = null,
                tint = MaterialTheme.colorScheme.onSurfaceVariant
            )
        }
    }
}
