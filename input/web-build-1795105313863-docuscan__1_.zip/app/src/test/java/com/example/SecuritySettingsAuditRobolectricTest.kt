package com.example

import android.content.Context
import android.graphics.Bitmap
import android.graphics.Color
import android.net.Uri
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.getValue
import androidx.compose.ui.test.assertIsDisplayed
import androidx.compose.ui.test.hasTestTag
import androidx.compose.ui.test.junit4.createComposeRule
import androidx.compose.ui.test.onNodeWithTag
import androidx.compose.ui.test.onNodeWithText
import androidx.compose.ui.test.performClick
import androidx.compose.ui.test.performScrollTo
import androidx.compose.ui.test.performScrollToNode
import androidx.compose.ui.test.performTextInput
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.room.Room
import androidx.test.core.app.ApplicationProvider
import com.example.database.DocuScanDatabase
import com.example.domain.model.AppLanguage
import com.example.domain.model.IdDocumentType
import com.example.domain.model.IdSideScanState
import com.example.domain.model.PdfCreationOptions
import com.example.domain.model.PdfPageSize
import com.example.domain.model.ScanFilter
import com.example.domain.model.ScanPage
import com.example.domain.model.ScanQuality
import com.example.domain.model.StorageSummary
import com.example.domain.model.ThemeMode
import com.example.domain.model.UserPreferences
import com.example.domain.repository.SettingsRepository
import com.example.pdf.PdfGenerator
import com.example.repository.LocalDocumentRepository
import com.example.security.SecurityManager
import com.example.settings.SettingsViewModel
import com.example.ui.screens.AboutPrivacyScreen
import com.example.ui.screens.BackupScreen
import com.example.ui.screens.SettingsScreen
import com.example.ui.screens.VaultLockScreen
import com.example.ui.theme.DocuScanTheme
import com.example.util.LocalAppStrings
import com.example.util.LocalFileManager
import com.example.util.stringsForLanguage
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.ExperimentalCoroutinesApi
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.test.StandardTestDispatcher
import kotlinx.coroutines.test.advanceUntilIdle
import kotlinx.coroutines.test.resetMain
import kotlinx.coroutines.test.runTest
import kotlinx.coroutines.test.setMain
import org.junit.After
import org.junit.Assert.assertArrayEquals
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Before
import org.junit.Rule
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config
import java.io.File
import java.io.FileOutputStream
import java.util.zip.ZipInputStream

@OptIn(ExperimentalCoroutinesApi::class)
@RunWith(RobolectricTestRunner::class)
@Config(sdk = [36])
class SecuritySettingsAuditRobolectricTest {

    @get:Rule
    val composeTestRule = createComposeRule()

    private lateinit var context: Context
    private lateinit var fileManager: LocalFileManager
    private lateinit var pdfGenerator: PdfGenerator
    private lateinit var securityManager: SecurityManager
    private lateinit var db: DocuScanDatabase
    private lateinit var repository: LocalDocumentRepository
    private lateinit var settingsRepository: AuditInMemorySettingsRepository
    private val testDispatcher = StandardTestDispatcher()

    @Before
    fun setup() {
        Dispatchers.setMain(testDispatcher)
        context = ApplicationProvider.getApplicationContext()
        fileManager = LocalFileManager(context, ioDispatcher = testDispatcher)
        pdfGenerator = PdfGenerator(context = context, ioDispatcher = testDispatcher)
        securityManager = SecurityManager(context)
        db = Room.databaseBuilder(context, DocuScanDatabase::class.java, "security_audit_test.db")
            .allowMainThreadQueries()
            .setQueryExecutor { it.run() }
            .setTransactionExecutor { it.run() }
            .build()
        repository = LocalDocumentRepository(
            documentDao = db.documentDao(),
            folderDao = db.folderDao(),
            signatureDao = db.signatureDao(),
            fileManager = fileManager,
            pdfGenerator = pdfGenerator,
            deletedDocumentDao = db.deletedDocumentDao(),
            securityManager = securityManager,
            ioDispatcher = testDispatcher
        )
        settingsRepository = AuditInMemorySettingsRepository()
    }

    @After
    fun tearDown() {
        db.close()
        context.deleteDatabase("security_audit_test.db")
        fileManager.scansDir.deleteRecursively()
        fileManager.documentsDir.deleteRecursively()
        fileManager.signaturesDir.deleteRecursively()
        fileManager.backupsDir.deleteRecursively()
        Dispatchers.resetMain()
    }

    @Test
    fun `security manager encrypts and decrypts bytes and vault files in place`() {
        val samplePdfBytes = "%PDF-1.4\n%DocuScan confidential payload\n%%EOF".toByteArray()
        val encrypted = securityManager.encryptBytes(samplePdfBytes)
        assertTrue(securityManager.isVaultPayload(encrypted))
        assertFalse(samplePdfBytes.contentEquals(encrypted))
        assertArrayEquals(samplePdfBytes, securityManager.decryptBytes(encrypted))

        val docFile = File(fileManager.documentsDir, "secret_doc.pdf").apply {
            writeBytes(samplePdfBytes)
        }
        assertFalse(securityManager.isVaultEncryptedFile(docFile))
        assertTrue(securityManager.sealFileInPlace(docFile))
        assertTrue(securityManager.isVaultEncryptedFile(docFile))
        assertFalse(docFile.readBytes().decodeToString().startsWith("%PDF-1.4"))

        // Plain bytes readable transparently + temp copy cleaned up cleanly
        assertArrayEquals(samplePdfBytes, securityManager.readFilePlainBytes(docFile))
        val tempCopy = securityManager.createTempUnsealedCopy(docFile, context.cacheDir)
        assertArrayEquals(samplePdfBytes, tempCopy.readBytes())
        tempCopy.delete()

        assertTrue(securityManager.unsealFileInPlace(docFile))
        assertFalse(securityManager.isVaultEncryptedFile(docFile))
        assertArrayEquals(samplePdfBytes, docFile.readBytes())
    }

    @Test
    fun `security manager creates and verifies stretched salted PIN records`() {
        val sealed = securityManager.createSealedPinRecord("2580")
        assertFalse(sealed.contains("2580"))
        assertTrue(securityManager.verifyPin("2580", sealed))
        assertFalse(securityManager.verifyPin("0000", sealed))
        assertFalse(securityManager.verifyPin("2580", "tampered_payload"))
        assertFalse(securityManager.verifyPin("", sealed))
    }

    @Test
    fun `permanent delete removes PDF thumbnail and unreferenced page images while preserving shared files`() = runTest(testDispatcher) {
        val pageImg1 = createBitmapFile(File(fileManager.scansDir, "page_1.jpg"), Color.DKGRAY)
        val pageImg2 = createBitmapFile(File(fileManager.scansDir, "page_2.jpg"), Color.BLUE)

        val pages = listOf(
            ScanPage(id = "p1", sourcePath = pageImg1.absolutePath, orderIndex = 0, filter = ScanFilter.ORIGINAL),
            ScanPage(id = "p2", sourcePath = pageImg2.absolutePath, orderIndex = 1, filter = ScanFilter.HIGH_CONTRAST)
        )
        val created = repository.createPdfDocument(
            title = "Tax_Receipt",
            pages = pages,
            folderId = null,
            options = PdfCreationOptions(pageSize = PdfPageSize.A4, quality = ScanQuality.STANDARD)
        ).getOrThrow()

        val pdfFile = File(created.filePath)
        val thumbFile = created.thumbnailPath?.let { File(it) }
        assertTrue(pdfFile.exists())
        assertTrue(thumbFile != null && thumbFile.exists())
        assertTrue(pageImg1.exists())
        assertTrue(pageImg2.exists())

        repository.moveDocumentToTrash(created.id).getOrThrow()
        repository.permanentlyDeleteDocument(created.id).getOrThrow()

        assertFalse("PDF file must be deleted on permanent delete", pdfFile.exists())
        assertFalse("Thumbnail must be deleted on permanent delete", thumbFile!!.exists())
        assertFalse("Page image 1 must be deleted when no document references it", pageImg1.exists())
        assertFalse("Page image 2 must be deleted when no document references it", pageImg2.exists())
    }

    @Test
    fun `low storage guard rejects operations safely and cache cleanup spares saved documents`() {
        runTest(testDispatcher) {
            val lowCheck = fileManager.checkStorageAvailable(
                minimumRequiredBytes = 8L * 1024L * 1024L,
                availableBytes = 512L * 1024L // 512 KB available < 8 MB required
            )
            assertTrue(lowCheck.isFailure)

            // Create one saved PDF + temp cache + orphaned scan file
            val img = createBitmapFile(File(fileManager.scansDir, "active_page.jpg"), Color.GRAY)
            val doc = repository.createPdfDocument(
                title = "Keep_Saved",
                pages = listOf(ScanPage(id = "keep", sourcePath = img.absolutePath, orderIndex = 0)),
                folderId = null,
                options = PdfCreationOptions()
            ).getOrThrow()

            val tempCacheFile = File(context.cacheDir, "view_unsealed_old.tmp").apply {
                writeBytes(ByteArray(4096) { 1 })
            }
            val orphanScan = File(fileManager.scansDir, "orphan_leftover.jpg").apply {
                writeBytes(ByteArray(2048) { 2 })
            }

            val summaryBefore = repository.getCacheSummary()
            assertTrue(summaryBefore.totalClearableCacheBytes >= 6144L)
            assertTrue(File(doc.filePath).exists())

            val freed = repository.clearTempCache().getOrThrow()
            assertTrue(freed >= 6144L)
            assertFalse(tempCacheFile.exists())
            assertFalse(orphanScan.exists())
            assertTrue("Saved PDF must NOT be touched by cache cleanup", File(doc.filePath).exists())
            assertTrue("Referenced page image must NOT be touched by cache cleanup", img.exists())
        }
    }

    @Test
    fun `keystore encrypted ID card PDF seals on disk and exports readable decrypted ZIP backup`() = runTest(testDispatcher) {
        val frontImg = createBitmapFile(File(fileManager.scansDir, "id_front.jpg"), Color.DKGRAY)
        val backImg = createBitmapFile(File(fileManager.scansDir, "id_back.jpg"), Color.LTGRAY)

        val idDoc = repository.createIdCardPdfDocument(
            title = "Aadhaar_Local_Vault",
            docType = IdDocumentType.AADHAAR,
            frontSide = IdSideScanState(imagePath = frontImg.absolutePath),
            backSide = IdSideScanState(imagePath = backImg.absolutePath),
            singleCombinedSheet = true,
            quality = ScanQuality.STANDARD,
            password = null,
            encryptInVault = true
        ).getOrThrow()

        val vaultFile = File(idDoc.filePath)
        assertTrue(securityManager.isVaultEncryptedFile(vaultFile))
        assertTrue(repository.isDocumentVaultEncrypted(idDoc.id))

        val zipDest = File(context.cacheDir, "export_backup_test.zip")
        val bytesWritten = repository.exportFullBackupArchive(Uri.fromFile(zipDest)).getOrThrow()
        assertTrue(bytesWritten > 0L && zipDest.exists())

        val entryNames = mutableListOf<String>()
        var pdfBytesInZip: ByteArray? = null
        ZipInputStream(zipDest.inputStream()).use { zis ->
            var entry = zis.nextEntry
            while (entry != null) {
                entryNames.add(entry.name)
                if (entry.name.endsWith(".pdf")) {
                    pdfBytesInZip = zis.readBytes()
                }
                zis.closeEntry()
                entry = zis.nextEntry
            }
        }

        assertTrue(entryNames.contains("docuscan_backup.json"))
        assertTrue(entryNames.any { it.startsWith("documents/") && it.endsWith(".pdf") })
        assertTrue(
            "ZIP export should contain unsealed valid PDF header",
            pdfBytesInZip?.decodeToString(0, 5) == "%PDF-"
        )
    }

    @Test
    fun `settings screen updates theme EN HI BN language page size and configures vault PIN lock`() {
        val settingsViewModel = SettingsViewModel(
            settingsRepository = settingsRepository,
            documentRepository = repository,
            securityManager = securityManager
        )

        composeTestRule.setContent {
            val prefs by settingsViewModel.preferences.collectAsStateWithLifecycle()
            val cacheSummary by settingsViewModel.cacheSummary.collectAsStateWithLifecycle()
            val bioCap by settingsViewModel.biometricCapability.collectAsStateWithLifecycle()
            CompositionLocalProvider(LocalAppStrings provides stringsForLanguage(prefs.appLanguage)) {
                DocuScanTheme(themeMode = prefs.themeMode) {
                    SettingsScreen(
                        preferences = prefs,
                        storageSummary = StorageSummary(activeDocumentCount = 2, pdfCount = 2),
                        cacheSummary = cacheSummary,
                        biometricCapability = bioCap,
                        securityManager = securityManager,
                        onSelectTheme = settingsViewModel::setThemeMode,
                        onSelectLanguage = settingsViewModel::setAppLanguage,
                        onSelectScanQuality = settingsViewModel::setScanQuality,
                        onSelectDefaultPageSize = settingsViewModel::setDefaultPageSize,
                        onToggleAutoEnhance = settingsViewModel::setAutoEnhance,
                        onToggleAppLock = settingsViewModel::setAppLockEnabled,
                        onToggleBiometricUnlock = settingsViewModel::setBiometricUnlockEnabled,
                        onToggleEncryptSensitiveFiles = settingsViewModel::setEncryptSensitiveFiles,
                        onConfigurePin = settingsViewModel::configureOrUpdatePin,
                        onRemovePin = settingsViewModel::removePinAndDisableLock,
                        onLockVaultNow = settingsViewModel::lockVault,
                        onClearTempCache = settingsViewModel::clearTempCache,
                        onOpenBackup = {},
                        onOpenRecycleBin = {},
                        onOpenAboutPrivacy = {}
                    )
                }
            }
        }

        composeTestRule.waitForIdle()

        // 1. Open Appearance & Language category
        composeTestRule.onNodeWithTag("settings_cat_appearance").performClick()
        composeTestRule.waitForIdle()

        // Switch theme Dark -> Light -> System
        composeTestRule.onNodeWithTag("theme_option_light").performScrollTo().performClick()
        composeTestRule.waitForIdle()
        testDispatcher.scheduler.advanceUntilIdle()
        assertEquals(ThemeMode.LIGHT, settingsViewModel.preferences.value.themeMode)

        composeTestRule.onNodeWithTag("theme_option_system").performScrollTo().performClick()
        composeTestRule.waitForIdle()
        testDispatcher.scheduler.advanceUntilIdle()
        assertEquals(ThemeMode.SYSTEM, settingsViewModel.preferences.value.themeMode)

        // Switch language English -> Hindi -> Bengali
        composeTestRule.onNodeWithTag("lang_option_hi").performScrollTo().performClick()
        composeTestRule.waitForIdle()
        testDispatcher.scheduler.advanceUntilIdle()
        composeTestRule.waitForIdle()
        assertEquals(AppLanguage.HINDI, settingsViewModel.preferences.value.appLanguage)
        composeTestRule.onNodeWithText("सेटिंग्स").assertIsDisplayed()

        composeTestRule.onNodeWithTag("lang_option_bn").performScrollTo().performClick()
        composeTestRule.waitForIdle()
        testDispatcher.scheduler.advanceUntilIdle()
        composeTestRule.waitForIdle()
        assertEquals(AppLanguage.BENGALI, settingsViewModel.preferences.value.appLanguage)
        composeTestRule.onNodeWithText("সেটিংস").assertIsDisplayed()

        // Switch back to English and return to Categories list
        composeTestRule.onNodeWithTag("lang_option_en").performScrollTo().performClick()
        composeTestRule.waitForIdle()
        testDispatcher.scheduler.advanceUntilIdle()
        composeTestRule.onNodeWithTag("settings_category_back_btn").performClick()
        composeTestRule.waitForIdle()

        // 2. Open Scanning & PDF Defaults category and change page size
        composeTestRule.onNodeWithTag("settings_cat_scanning").performClick()
        composeTestRule.waitForIdle()
        composeTestRule.onNodeWithTag("page_size_option_letter").performScrollTo().performClick()
        composeTestRule.waitForIdle()
        testDispatcher.scheduler.advanceUntilIdle()
        composeTestRule.waitForIdle()
        assertEquals(PdfPageSize.LETTER, settingsViewModel.preferences.value.defaultPageSize)
        composeTestRule.onNodeWithTag("settings_category_back_btn").performClick()
        composeTestRule.waitForIdle()

        // 3. Open Security & Biometric Lock category and configure Vault PIN
        composeTestRule.onNodeWithTag("settings_cat_security").performClick()
        composeTestRule.waitForIdle()
        composeTestRule.onNodeWithTag("settings_list")
            .performScrollToNode(hasTestTag("settings_set_pin_btn"))
        composeTestRule.onNodeWithTag("settings_set_pin_btn").performScrollTo().performClick()
        composeTestRule.waitForIdle()
        composeTestRule.onNodeWithTag("pin_setup_input").performTextInput("1234")
        composeTestRule.onNodeWithTag("pin_setup_confirm_input").performTextInput("1234")
        composeTestRule.onNodeWithTag("pin_setup_save_btn").performClick()
        composeTestRule.waitForIdle()
        testDispatcher.scheduler.advanceUntilIdle()
        composeTestRule.waitForIdle()

        assertTrue(settingsViewModel.preferences.value.hasPinConfigured)
        assertTrue(settingsViewModel.preferences.value.appLockEnabled)
        assertTrue(settingsViewModel.verifyPin("1234"))

        // Verify background auto-lock locks vault cleanly and resume refreshes state
        settingsViewModel.onAppBackgrounded()
        assertTrue(settingsViewModel.isVaultLocked.value)
        settingsViewModel.unlockVault()
        assertFalse(settingsViewModel.isVaultLocked.value)

        // Verify Storage category opens cleanly
        composeTestRule.onNodeWithTag("settings_category_back_btn").performClick()
        composeTestRule.waitForIdle()
        composeTestRule.onNodeWithTag("settings_cat_storage").performClick()
        composeTestRule.waitForIdle()
        composeTestRule.onNodeWithTag("settings_clear_cache_btn").performScrollTo().assertIsDisplayed()
    }

    @Test
    fun `vault lock screen supports biometric-only unlock without manual PIN`() {
        var promptRequested = false
        var unlocked = false

        composeTestRule.setContent {
            CompositionLocalProvider(LocalAppStrings provides stringsForLanguage(AppLanguage.ENGLISH)) {
                DocuScanTheme {
                    VaultLockScreen(
                        biometricAvailable = true,
                        biometricEnabled = true,
                        hasPinConfigured = false,
                        onVerifyPin = { false },
                        onRequestBiometricPrompt = { onSuccess, _ ->
                            promptRequested = true
                            onSuccess()
                        },
                        onUnlocked = { unlocked = true }
                    )
                }
            }
        }

        composeTestRule.onNodeWithTag("biometric_unlock_btn").assertIsDisplayed()
        composeTestRule.onNodeWithTag("biometric_unlock_btn").performClick()
        composeTestRule.waitForIdle()

        assertTrue(promptRequested)
        assertTrue(unlocked)
    }

    @Test
    fun `vault lock screen rejects wrong pin and unlocks with correct pin`() {
        val sealed = securityManager.createSealedPinRecord("4321")
        var unlocked = false

        composeTestRule.setContent {
            CompositionLocalProvider(LocalAppStrings provides stringsForLanguage(AppLanguage.ENGLISH)) {
                DocuScanTheme {
                    VaultLockScreen(
                        biometricAvailable = false,
                        biometricEnabled = false,
                        onVerifyPin = { candidate -> securityManager.verifyPin(candidate, sealed) },
                        onRequestBiometricPrompt = { _, _ -> },
                        onUnlocked = { unlocked = true }
                    )
                }
            }
        }

        // Enter wrong PIN 9999
        listOf("9", "9", "9", "9").forEach { digit ->
            composeTestRule.onNodeWithTag("pin_key_$digit").performScrollTo().performClick()
        }
        composeTestRule.onNodeWithTag("pin_unlock_btn").performScrollTo().performClick()
        composeTestRule.waitForIdle()
        assertFalse(unlocked)
        composeTestRule.onNodeWithTag("lock_error_text").performScrollTo().assertIsDisplayed()

        // Enter correct PIN 4321
        listOf("4", "3", "2", "1").forEach { digit ->
            composeTestRule.onNodeWithTag("pin_key_$digit").performScrollTo().performClick()
        }
        composeTestRule.onNodeWithTag("pin_unlock_btn").performScrollTo().performClick()
        composeTestRule.waitForIdle()
        assertTrue(unlocked)
    }

    @Test
    fun `backup and about privacy screens render genuine disclosures with no placeholder labels`() {
        composeTestRule.setContent {
            CompositionLocalProvider(LocalAppStrings provides stringsForLanguage(AppLanguage.ENGLISH)) {
                DocuScanTheme {
                    AboutPrivacyScreen(
                        securityManager = securityManager,
                        onBack = {}
                    )
                }
            }
        }
        composeTestRule.waitForIdle()
        composeTestRule.onNodeWithText("AES-256-GCM").assertIsDisplayed()
        composeTestRule.onNodeWithText("Optional Firebase & Cloud Costs", substring = true).performScrollTo().assertIsDisplayed()
    }

    @Test
    fun `backup screen displays SAF ZIP export and offline firebase disclosure`() {
        composeTestRule.setContent {
            CompositionLocalProvider(LocalAppStrings provides stringsForLanguage(AppLanguage.ENGLISH)) {
                DocuScanTheme {
                    BackupScreen(
                        storageSummary = StorageSummary(activeDocumentCount = 3, pdfCount = 2, totalUsedBytes = 4096),
                        lastBackupAt = null,
                        backupMessage = null,
                        onCreateLocalBackup = {},
                        onExportBackupZip = {},
                        onOpenAboutPrivacy = {},
                        onClearBackupMessage = {},
                        onBack = {}
                    )
                }
            }
        }
        composeTestRule.waitForIdle()
        composeTestRule.onNodeWithTag("backup_export_zip_btn").assertIsDisplayed()
        composeTestRule.onNodeWithTag("backup_create_snapshot_btn").assertIsDisplayed()
        composeTestRule.onNodeWithTag("backup_view_firebase_details_btn").performScrollTo().assertIsDisplayed()
    }

    private fun createBitmapFile(target: File, color: Int): File {
        target.parentFile?.mkdirs()
        val bmp = Bitmap.createBitmap(240, 320, Bitmap.Config.ARGB_8888)
        bmp.eraseColor(color)
        FileOutputStream(target).use { out ->
            bmp.compress(Bitmap.CompressFormat.JPEG, 90, out)
        }
        bmp.recycle()
        return target
    }

    private class AuditInMemorySettingsRepository : SettingsRepository {
        private val state = MutableStateFlow(UserPreferences())
        override val preferences: Flow<UserPreferences> = state
        override suspend fun setThemeMode(mode: ThemeMode) { state.update { it.copy(themeMode = mode) } }
        override suspend fun setAppLanguage(language: AppLanguage) { state.update { it.copy(appLanguage = language) } }
        override suspend fun setOnboardingCompleted(completed: Boolean) { state.update { it.copy(onboardingCompleted = completed) } }
        override suspend fun setScanQuality(quality: ScanQuality) { state.update { it.copy(scanQuality = quality) } }
        override suspend fun setDefaultPageSize(pageSize: PdfPageSize) { state.update { it.copy(defaultPageSize = pageSize) } }
        override suspend fun setAutoEnhance(enabled: Boolean) { state.update { it.copy(autoEnhance = enabled) } }
        override suspend fun setAppLockEnabled(enabled: Boolean) { state.update { it.copy(appLockEnabled = enabled) } }
        override suspend fun setBiometricUnlockEnabled(enabled: Boolean) { state.update { it.copy(biometricUnlockEnabled = enabled) } }
        override suspend fun setEncryptSensitiveFiles(enabled: Boolean) { state.update { it.copy(encryptSensitiveFiles = enabled) } }
        override suspend fun setSealedPinRecord(record: String?) { state.update { it.copy(sealedPinRecord = record) } }
        override suspend fun updateLastBackupAt(timestamp: Long) { state.update { it.copy(lastBackupAt = timestamp) } }
    }
}
