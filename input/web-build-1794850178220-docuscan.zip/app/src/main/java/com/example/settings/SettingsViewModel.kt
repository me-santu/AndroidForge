package com.example.settings

import android.net.Uri
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.example.domain.model.AppLanguage
import com.example.domain.model.CacheSummary
import com.example.domain.model.PdfPageSize
import com.example.domain.model.ScanQuality
import com.example.domain.model.StorageSummary
import com.example.domain.model.ThemeMode
import com.example.domain.model.UserPreferences
import com.example.domain.repository.DocumentRepository
import com.example.domain.repository.SettingsRepository
import com.example.security.BiometricCapability
import com.example.security.SecurityManager
import com.example.util.FormatUtils
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch

class SettingsViewModel(
    private val settingsRepository: SettingsRepository,
    private val documentRepository: DocumentRepository,
    val securityManager: SecurityManager
) : ViewModel() {

    val preferences: StateFlow<UserPreferences> = settingsRepository.preferences
        .stateIn(
            scope = viewModelScope,
            started = SharingStarted.WhileSubscribed(5000),
            initialValue = UserPreferences()
        )

    val storageSummary: StateFlow<StorageSummary> = documentRepository.observeStorageSummary()
        .stateIn(
            scope = viewModelScope,
            started = SharingStarted.WhileSubscribed(5000),
            initialValue = StorageSummary()
        )

    private val _cacheSummary = MutableStateFlow(CacheSummary())
    val cacheSummary: StateFlow<CacheSummary> = _cacheSummary.asStateFlow()

    private val _biometricCapability = MutableStateFlow(securityManager.checkBiometricCapability())
    val biometricCapability: StateFlow<BiometricCapability> = _biometricCapability.asStateFlow()

    private val _backupMessage = MutableStateFlow<String?>(null)
    val backupMessage: StateFlow<String?> = _backupMessage.asStateFlow()

    private val _settingsMessage = MutableStateFlow<String?>(null)
    val settingsMessage: StateFlow<String?> = _settingsMessage.asStateFlow()

    private val _isVaultLocked = MutableStateFlow(false)
    val isVaultLocked: StateFlow<Boolean> = _isVaultLocked.asStateFlow()

    init {
        refreshCacheSummary()
        viewModelScope.launch {
            val initial = settingsRepository.preferences.first()
            if (initial.appLockEnabled && initial.hasPinConfigured) {
                _isVaultLocked.value = true
            }
        }
    }

    fun lockVault() {
        if (preferences.value.hasPinConfigured) {
            _isVaultLocked.value = true
        } else {
            _settingsMessage.value = "Set a Vault PIN before locking"
        }
    }

    fun unlockVault() {
        _isVaultLocked.value = false
    }

    fun setThemeMode(mode: ThemeMode) {
        viewModelScope.launch { settingsRepository.setThemeMode(mode) }
    }

    fun setAppLanguage(language: AppLanguage) {
        viewModelScope.launch { settingsRepository.setAppLanguage(language) }
    }

    fun setOnboardingCompleted(completed: Boolean) {
        viewModelScope.launch { settingsRepository.setOnboardingCompleted(completed) }
    }

    fun setScanQuality(quality: ScanQuality) {
        viewModelScope.launch { settingsRepository.setScanQuality(quality) }
    }

    fun setDefaultPageSize(pageSize: PdfPageSize) {
        viewModelScope.launch { settingsRepository.setDefaultPageSize(pageSize) }
    }

    fun setAutoEnhance(enabled: Boolean) {
        viewModelScope.launch { settingsRepository.setAutoEnhance(enabled) }
    }

    fun setEncryptSensitiveFiles(enabled: Boolean) {
        viewModelScope.launch {
            settingsRepository.setEncryptSensitiveFiles(enabled)
            _settingsMessage.value = if (enabled) {
                "New ID scans will be encrypted with Android Keystore"
            } else {
                "Auto Keystore encryption for ID scans disabled"
            }
        }
    }

    fun configureOrUpdatePin(newPin: String, enableLock: Boolean = true): Result<Unit> {
        return runCatching {
            val sealed = securityManager.createSealedPinRecord(newPin)
            viewModelScope.launch {
                settingsRepository.setSealedPinRecord(sealed)
                if (enableLock) {
                    settingsRepository.setAppLockEnabled(true)
                }
                _settingsMessage.value = "Vault PIN saved cleanly in Android Keystore"
            }
        }
    }

    fun removePinAndDisableLock() {
        viewModelScope.launch {
            settingsRepository.setAppLockEnabled(false)
            settingsRepository.setBiometricUnlockEnabled(false)
            settingsRepository.setSealedPinRecord(null)
            _settingsMessage.value = "Vault App Lock and PIN removed"
        }
    }

    fun setAppLockEnabled(enabled: Boolean) {
        viewModelScope.launch {
            val current = settingsRepository.preferences.first()
            if (enabled && !current.hasPinConfigured) {
                _settingsMessage.value = "Set a 4–8 digit Vault PIN first to enable App Lock"
                return@launch
            }
            settingsRepository.setAppLockEnabled(enabled)
        }
    }

    fun setBiometricUnlockEnabled(enabled: Boolean) {
        viewModelScope.launch {
            if (enabled) {
                val cap = securityManager.checkBiometricCapability()
                _biometricCapability.value = cap
                if (!cap.isAvailable) {
                    _settingsMessage.value = cap.statusLabel
                    return@launch
                }
            }
            settingsRepository.setBiometricUnlockEnabled(enabled)
        }
    }

    fun verifyPin(candidatePin: String): Boolean {
        return securityManager.verifyPin(candidatePin, preferences.value.sealedPinRecord)
    }

    fun refreshCacheSummary() {
        viewModelScope.launch {
            _cacheSummary.value = documentRepository.getCacheSummary()
            _biometricCapability.value = securityManager.checkBiometricCapability()
        }
    }

    fun clearTempCache() {
        viewModelScope.launch {
            documentRepository.clearTempCache()
                .onSuccess { freed ->
                    _cacheSummary.value = documentRepository.getCacheSummary()
                    _settingsMessage.value = if (freed > 0L) {
                        "Cleared ${FormatUtils.formatBytes(freed)} of temporary cache"
                    } else {
                        "Temporary cache is already clean"
                    }
                }
                .onFailure { err ->
                    _settingsMessage.value = err.message ?: "Failed to clear temporary cache"
                }
        }
    }

    fun runLocalBackup() {
        viewModelScope.launch {
            documentRepository.createLocalBackupManifest()
                .onSuccess { path ->
                    settingsRepository.updateLastBackupAt(System.currentTimeMillis())
                    refreshCacheSummary()
                    _backupMessage.value = "Local backup index saved: ${path.substringAfterLast('/')}"
                }
                .onFailure { err ->
                    _backupMessage.value = "Backup failed: ${err.message}"
                }
        }
    }

    fun exportBackupZipToUri(destinationUri: Uri) {
        viewModelScope.launch {
            documentRepository.exportFullBackupArchive(destinationUri)
                .onSuccess { bytes ->
                    settingsRepository.updateLastBackupAt(System.currentTimeMillis())
                    _backupMessage.value = "Exported ZIP backup (${FormatUtils.formatBytes(bytes)})"
                }
                .onFailure { err ->
                    _backupMessage.value = "ZIP backup failed: ${err.message}"
                }
        }
    }

    fun clearBackupMessage() {
        _backupMessage.value = null
    }

    fun clearSettingsMessage() {
        _settingsMessage.value = null
    }
}
