package com.example.util

import android.content.Context
import com.example.data.datastore.UserPreferencesDataSource
import com.example.database.DocuScanDatabase
import com.example.domain.repository.DocumentRepository
import com.example.domain.repository.SettingsRepository
import com.example.ocr.OcrEngine
import com.example.pdf.PdfGenerator
import com.example.pdf.PdfRendererHelper
import com.example.repository.LocalDocumentRepository
import com.example.repository.LocalSettingsRepository
import com.example.scanner.DocumentScannerGateway
import com.example.scanner.MlKitDocumentScannerManager
import com.example.scanner.ScanSessionManager
import com.example.security.SecurityManager

class AppContainer(context: Context) {
    private val database: DocuScanDatabase by lazy { DocuScanDatabase.getInstance(context) }
    private val prefsDataSource: UserPreferencesDataSource by lazy { UserPreferencesDataSource(context) }

    val fileManager: LocalFileManager by lazy { LocalFileManager(context) }
    val pdfGenerator: PdfGenerator by lazy { PdfGenerator(context = context) }
    val pdfRendererHelper: PdfRendererHelper by lazy { PdfRendererHelper(context = context) }
    val scanSessionManager: ScanSessionManager by lazy { ScanSessionManager() }
    val documentScannerGateway: DocumentScannerGateway by lazy { MlKitDocumentScannerManager(context) }
    val ocrEngine: OcrEngine by lazy { OcrEngine() }
    val securityManager: SecurityManager by lazy { SecurityManager(context.applicationContext) }

    val documentRepository: DocumentRepository by lazy {
        LocalDocumentRepository(
            documentDao = database.documentDao(),
            folderDao = database.folderDao(),
            signatureDao = database.signatureDao(),
            fileManager = fileManager,
            pdfGenerator = pdfGenerator,
            deletedDocumentDao = database.deletedDocumentDao(),
            securityManager = securityManager
        )
    }

    val settingsRepository: SettingsRepository by lazy {
        LocalSettingsRepository(prefsDataSource)
    }
}
