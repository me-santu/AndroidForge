package com.example.ui.theme

import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import com.example.domain.model.ThemeMode

private val DocuDarkColorScheme = darkColorScheme(
    primary = DocuGold,
    onPrimary = DarkBackground,
    primaryContainer = DocuGoldContainerDark,
    onPrimaryContainer = DocuGoldOnContainerDark,
    secondary = DocuGoldPressed,
    onSecondary = DarkBackground,
    secondaryContainer = DarkCardElevated,
    onSecondaryContainer = DarkTextPrimary,
    tertiary = TealAccent,
    onTertiary = DarkBackground,
    background = DarkBackground,
    onBackground = DarkTextPrimary,
    surface = DarkSurface,
    onSurface = DarkTextPrimary,
    surfaceVariant = DarkCard,
    onSurfaceVariant = DarkTextSecondary,
    surfaceContainerLowest = DarkBackground,
    surfaceContainerLow = DarkSurface,
    surfaceContainer = DarkCard,
    surfaceContainerHigh = DarkCardElevated,
    surfaceContainerHighest = ColorTokens.DarkHighest,
    outline = DarkBorder,
    outlineVariant = ColorTokens.DarkOutlineVariant,
    error = ErrorRedDark,
    onError = DarkBackground
)

private val DocuLightColorScheme = lightColorScheme(
    primary = LightGold,
    onPrimary = LightTextPrimary,
    primaryContainer = LightGoldContainer,
    onPrimaryContainer = LightGoldOnContainer,
    secondary = DocuGoldPressed,
    onSecondary = LightTextPrimary,
    secondaryContainer = LightCardElevated,
    onSecondaryContainer = LightTextPrimary,
    tertiary = TealAccentDark,
    onTertiary = LightSurface,
    background = LightBackground,
    onBackground = LightTextPrimary,
    surface = LightSurface,
    onSurface = LightTextPrimary,
    surfaceVariant = LightCard,
    onSurfaceVariant = LightTextSecondary,
    surfaceContainerLowest = LightSurface,
    surfaceContainerLow = LightBackground,
    surfaceContainer = LightCard,
    surfaceContainerHigh = LightCardElevated,
    surfaceContainerHighest = ColorTokens.LightHighest,
    outline = LightBorder,
    outlineVariant = ColorTokens.LightOutlineVariant,
    error = ErrorRedLight,
    onError = LightSurface
)

private object ColorTokens {
    val DarkHighest = androidx.compose.ui.graphics.Color(0xFF343434)
    val DarkOutlineVariant = androidx.compose.ui.graphics.Color(0xFF2B2B2B)
    val LightHighest = androidx.compose.ui.graphics.Color(0xFFDDD9CC)
    val LightOutlineVariant = androidx.compose.ui.graphics.Color(0xFFE6E3D8)
}

@Composable
fun DocuScanTheme(
    themeMode: ThemeMode = ThemeMode.DARK,
    content: @Composable () -> Unit
) {
    val isDark = when (themeMode) {
        ThemeMode.DARK -> true
        ThemeMode.LIGHT -> false
        ThemeMode.SYSTEM -> isSystemInDarkTheme()
    }

    val colorScheme = if (isDark) DocuDarkColorScheme else DocuLightColorScheme

    MaterialTheme(
        colorScheme = colorScheme,
        typography = DocuScanTypography,
        shapes = DocuScanShapes,
        content = content
    )
}
