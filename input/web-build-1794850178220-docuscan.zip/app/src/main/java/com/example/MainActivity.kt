package com.example

import android.os.Bundle
import androidx.activity.SystemBarStyle
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.fragment.app.FragmentActivity
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewmodel.compose.viewModel
import com.example.domain.model.ThemeMode
import com.example.navigation.DocuScanNavHost
import com.example.settings.SettingsViewModel
import com.example.ui.theme.DocuScanTheme
import com.example.ui.viewmodel.DocuScanViewModelFactory
import com.example.ui.viewmodel.DocumentsViewModel
import com.example.ui.viewmodel.OcrViewModel
import com.example.ui.viewmodel.ScannerViewModel
import com.example.ui.viewmodel.SignatureViewModel
import com.example.ui.viewmodel.ViewerViewModel
import com.example.util.AppLocaleHelper
import com.example.util.LocalAppStrings
import com.example.util.stringsForLanguage

class MainActivity : FragmentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge(
            statusBarStyle = SystemBarStyle.dark(android.graphics.Color.TRANSPARENT),
            navigationBarStyle = SystemBarStyle.dark(android.graphics.Color.TRANSPARENT)
        )

        val container = (application as DocuScanApplication).container
        val factory = DocuScanViewModelFactory(container)

        setContent {
            val settingsViewModel: SettingsViewModel = viewModel(factory = factory)
            val documentsViewModel: DocumentsViewModel = viewModel(factory = factory)
            val scannerViewModel: ScannerViewModel = viewModel(factory = factory)
            val viewerViewModel: ViewerViewModel = viewModel(factory = factory)
            val signatureViewModel: SignatureViewModel = viewModel(factory = factory)
            val ocrViewModel: OcrViewModel = viewModel(factory = factory)

            val preferences by settingsViewModel.preferences.collectAsStateWithLifecycle()
            val systemDark = isSystemInDarkTheme()
            val isDark = when (preferences.themeMode) {
                ThemeMode.DARK -> true
                ThemeMode.LIGHT -> false
                ThemeMode.SYSTEM -> systemDark
            }

            LaunchedEffect(isDark) {
                val barStyle = if (isDark) {
                    SystemBarStyle.dark(android.graphics.Color.TRANSPARENT)
                } else {
                    SystemBarStyle.light(
                        android.graphics.Color.TRANSPARENT,
                        android.graphics.Color.TRANSPARENT
                    )
                }
                enableEdgeToEdge(statusBarStyle = barStyle, navigationBarStyle = barStyle)
            }

            LaunchedEffect(preferences.appLanguage) {
                AppLocaleHelper.applyLocaleToContext(this@MainActivity, preferences.appLanguage)
            }

            val localizedStrings = stringsForLanguage(preferences.appLanguage)
            CompositionLocalProvider(LocalAppStrings provides localizedStrings) {
                DocuScanTheme(themeMode = preferences.themeMode) {
                    DocuScanNavHost(
                        documentsViewModel = documentsViewModel,
                        scannerViewModel = scannerViewModel,
                        viewerViewModel = viewerViewModel,
                        signatureViewModel = signatureViewModel,
                        ocrViewModel = ocrViewModel,
                        settingsViewModel = settingsViewModel
                    )
                }
            }
        }
    }
}
