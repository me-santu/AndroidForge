package com.example.ui.screens

import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.CallMerge
import androidx.compose.material.icons.automirrored.filled.RotateRight
import androidx.compose.material.icons.filled.Badge
import androidx.compose.material.icons.filled.Compress
import androidx.compose.material.icons.filled.ContentCut
import androidx.compose.material.icons.filled.DeleteSweep
import androidx.compose.material.icons.filled.Draw
import androidx.compose.material.icons.filled.FilterNone
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.PictureAsPdf
import androidx.compose.material.icons.filled.TextFields
import androidx.compose.material.icons.filled.WaterDrop
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Checkbox
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FilterChipDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.RadioButton
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.unit.dp
import com.example.domain.model.DocumentItem
import com.example.domain.model.PdfCompressionLevel
import com.example.ui.components.DocuScanCard
import com.example.ui.components.ErrorStateView
import com.example.ui.components.PhaseStatusChip
import com.example.ui.viewmodel.OperationState
import com.example.util.FormatUtils

private enum class PdfSingleTool {
    SPLIT,
    EXTRACT,
    ROTATE,
    DELETE_PAGES,
    COMPRESS,
    WATERMARK,
    PROTECT
}

@Composable
fun PdfToolsScreen(
    pdfDocuments: List<DocumentItem>,
    operationState: OperationState,
    onDismissOperationError: () -> Unit,
    onOpenIdScanner: () -> Unit,
    onOpenSignatureCreator: () -> Unit,
    onOpenSignPdf: () -> Unit,
    onOpenOcrExtractor: () -> Unit,
    onOpenPageManager: () -> Unit,
    onMergePdfs: (title: String, selectedIds: List<Long>, onCreated: (DocumentItem) -> Unit) -> Unit,
    onSplitPdf: (sourceId: Long, title: String, startPage: Int, endPage: Int, password: String?, onCreated: (DocumentItem) -> Unit) -> Unit,
    onExtractPages: (sourceId: Long, title: String, pages: List<Int>, password: String?, onCreated: (DocumentItem) -> Unit) -> Unit,
    onRotatePages: (sourceId: Long, title: String, pages: Set<Int>, degrees: Int, password: String?, onCreated: (DocumentItem) -> Unit) -> Unit,
    onDeletePages: (sourceId: Long, title: String, pagesToDelete: Set<Int>, password: String?, onCreated: (DocumentItem) -> Unit) -> Unit,
    onCompressPdf: (sourceId: Long, title: String, level: PdfCompressionLevel, password: String?, onCreated: (DocumentItem) -> Unit) -> Unit,
    onWatermarkPdf: (sourceId: Long, title: String, watermarkText: String, password: String?, onCreated: (DocumentItem) -> Unit) -> Unit,
    onProtectPdf: (sourceId: Long, title: String, userPassword: String, existingPassword: String?, onCreated: (DocumentItem) -> Unit) -> Unit,
    onOpenDocument: (Long) -> Unit,
    modifier: Modifier = Modifier
) {
    var showMergeDialog by remember { mutableStateOf(false) }
    var activeTool by remember { mutableStateOf<PdfSingleTool?>(null) }

    LazyColumn(
        modifier = modifier.fillMaxSize(),
        contentPadding = PaddingValues(horizontal = 16.dp, vertical = 14.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        item {
            Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
                Text("PDF & Document Tools", style = MaterialTheme.typography.headlineMedium)
                Text(
                    text = "Real local PDF processing — original source files are always preserved",
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
        }

        if (operationState is OperationState.Working) {
            item {
                DocuScanCard(highlighted = true) {
                    Text("Processing PDF locally...", style = MaterialTheme.typography.titleSmall)
                    Spacer(modifier = Modifier.size(8.dp))
                    LinearProgressIndicator(modifier = Modifier.fillMaxWidth())
                }
            }
        }

        if (operationState is OperationState.Error) {
            item {
                DocuScanCard {
                    ErrorStateView(
                        message = operationState.message,
                        onRetry = onDismissOperationError
                    )
                }
            }
        }

        item {
            ToolRowCard(
                title = "Merge PDFs",
                subtitle = if (pdfDocuments.size >= 2) {
                    "Combine ${pdfDocuments.size} local PDFs into one file"
                } else {
                    "Create or import at least 2 PDFs to merge"
                },
                icon = Icons.AutoMirrored.Filled.CallMerge,
                badge = "Ready",
                badgeHighlighted = true,
                enabled = pdfDocuments.size >= 2,
                testTag = "tool_merge_pdf",
                onClick = { showMergeDialog = true }
            )
        }

        item {
            ToolRowCard(
                title = "Split PDF by Range",
                subtitle = "Save a contiguous page range into a new PDF",
                icon = Icons.Filled.ContentCut,
                badge = "Ready",
                badgeHighlighted = true,
                enabled = pdfDocuments.isNotEmpty(),
                testTag = "tool_split_pdf",
                onClick = { activeTool = PdfSingleTool.SPLIT }
            )
        }

        item {
            ToolRowCard(
                title = "Extract Specific Pages",
                subtitle = "Pick individual pages (e.g. 1, 3, 5) into a new PDF",
                icon = Icons.Filled.FilterNone,
                badge = "Ready",
                badgeHighlighted = true,
                enabled = pdfDocuments.isNotEmpty(),
                testTag = "tool_extract_pages",
                onClick = { activeTool = PdfSingleTool.EXTRACT }
            )
        }

        item {
            ToolRowCard(
                title = "Rotate PDF Pages",
                subtitle = "Rotate all or selected PDF pages by 90°, 180°, or 270°",
                icon = Icons.AutoMirrored.Filled.RotateRight,
                badge = "Ready",
                badgeHighlighted = true,
                enabled = pdfDocuments.isNotEmpty(),
                testTag = "tool_rotate_pages",
                onClick = { activeTool = PdfSingleTool.ROTATE }
            )
        }

        item {
            ToolRowCard(
                title = "Delete PDF Pages",
                subtitle = "Remove unwanted pages and save a clean PDF copy",
                icon = Icons.Filled.DeleteSweep,
                badge = "Ready",
                badgeHighlighted = true,
                enabled = pdfDocuments.isNotEmpty(),
                testTag = "tool_delete_pages",
                onClick = { activeTool = PdfSingleTool.DELETE_PAGES }
            )
        }

        item {
            ToolRowCard(
                title = "Compress PDF",
                subtitle = "Reduce PDF file size with Low, Balanced, or High compression",
                icon = Icons.Filled.Compress,
                badge = "Ready",
                badgeHighlighted = true,
                enabled = pdfDocuments.isNotEmpty(),
                testTag = "tool_compress_pdf",
                onClick = { activeTool = PdfSingleTool.COMPRESS }
            )
        }

        item {
            ToolRowCard(
                title = "Add Text Watermark",
                subtitle = "Stamp diagonal semi-transparent text across all pages",
                icon = Icons.Filled.WaterDrop,
                badge = "Ready",
                badgeHighlighted = true,
                enabled = pdfDocuments.isNotEmpty(),
                testTag = "tool_watermark_pdf",
                onClick = { activeTool = PdfSingleTool.WATERMARK }
            )
        }

        item {
            ToolRowCard(
                title = "Password Protect PDF",
                subtitle = "Encrypt any PDF copy with AES-128 password protection",
                icon = Icons.Filled.Lock,
                badge = "AES-128",
                badgeHighlighted = true,
                enabled = pdfDocuments.isNotEmpty(),
                testTag = "tool_protect_pdf",
                onClick = { activeTool = PdfSingleTool.PROTECT }
            )
        }

        item {
            ToolRowCard(
                title = "Images to PDF",
                subtitle = "Assemble & reorder pages into A4, A5, Letter, or Custom PDF",
                icon = Icons.Filled.PictureAsPdf,
                badge = "Creator",
                badgeHighlighted = true,
                enabled = true,
                testTag = "tool_images_to_pdf",
                onClick = onOpenPageManager
            )
        }

        item {
            ToolRowCard(
                title = "ID Document Scanner",
                subtitle = "Aadhaar, PAN, Passport, Driving Licence & Voter ID workflows",
                icon = Icons.Filled.Badge,
                badge = "Ready",
                badgeHighlighted = true,
                enabled = true,
                testTag = "tool_id_scanner",
                onClick = onOpenIdScanner
            )
        }

        item {
            ToolRowCard(
                title = "Signature Creator",
                subtitle = "Draw & store reusable transparent signatures",
                icon = Icons.Filled.Draw,
                badge = "Ready",
                badgeHighlighted = true,
                enabled = true,
                testTag = "tool_signature_creator",
                onClick = onOpenSignatureCreator
            )
        }

        item {
            ToolRowCard(
                title = "Sign PDF Document",
                subtitle = "Place, resize & reposition your saved signature on any PDF page",
                icon = Icons.Filled.Draw,
                badge = "Ready",
                badgeHighlighted = true,
                enabled = pdfDocuments.isNotEmpty(),
                testTag = "tool_sign_pdf",
                onClick = onOpenSignPdf
            )
        }

        item {
            ToolRowCard(
                title = "OCR Text Extractor",
                subtitle = "Extract English & Hindi text from images and PDFs offline",
                icon = Icons.Filled.TextFields,
                badge = "ML Kit v2",
                badgeHighlighted = true,
                enabled = true,
                testTag = "tool_ocr_extractor",
                onClick = onOpenOcrExtractor
            )
        }
    }

    if (showMergeDialog) {
        val selectedIds = remember { mutableStateListOf<Long>() }
        var mergeTitle by remember { mutableStateOf("Merged_${System.currentTimeMillis() % 10000}") }

        AlertDialog(
            onDismissRequest = { showMergeDialog = false },
            title = { Text("Merge Local PDFs") },
            text = {
                Column(
                    modifier = Modifier
                        .heightIn(max = 360.dp)
                        .verticalScroll(rememberScrollState()),
                    verticalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    OutlinedTextField(
                        value = mergeTitle,
                        onValueChange = { mergeTitle = it },
                        label = { Text("Output PDF Title") },
                        singleLine = true,
                        modifier = Modifier.fillMaxWidth()
                    )
                    Text("Select 2 or more PDFs:", style = MaterialTheme.typography.labelMedium)
                    pdfDocuments.filter { !it.isPasswordProtected }.forEach { doc ->
                        val checked = doc.id in selectedIds
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .clickable {
                                    if (checked) selectedIds.remove(doc.id) else selectedIds.add(doc.id)
                                },
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Checkbox(
                                checked = checked,
                                onCheckedChange = {
                                    if (checked) selectedIds.remove(doc.id) else selectedIds.add(doc.id)
                                }
                            )
                            Text(
                                text = "${doc.title} (${doc.pageCount}p)",
                                style = MaterialTheme.typography.bodyMedium
                            )
                        }
                    }
                }
            },
            confirmButton = {
                TextButton(
                    enabled = selectedIds.size >= 2 && mergeTitle.isNotBlank(),
                    onClick = {
                        showMergeDialog = false
                        onMergePdfs(mergeTitle, selectedIds.toList()) { created ->
                            onOpenDocument(created.id)
                        }
                    }
                ) { Text("Merge") }
            },
            dismissButton = {
                TextButton(onClick = { showMergeDialog = false }) { Text("Cancel") }
            }
        )
    }

    activeTool?.let { tool ->
        SinglePdfToolDialog(
            tool = tool,
            pdfDocuments = pdfDocuments,
            onDismiss = { activeTool = null },
            onSplitPdf = onSplitPdf,
            onExtractPages = onExtractPages,
            onRotatePages = onRotatePages,
            onDeletePages = onDeletePages,
            onCompressPdf = onCompressPdf,
            onWatermarkPdf = onWatermarkPdf,
            onProtectPdf = onProtectPdf,
            onOpenDocument = onOpenDocument
        )
    }
}

@Composable
private fun SinglePdfToolDialog(
    tool: PdfSingleTool,
    pdfDocuments: List<DocumentItem>,
    onDismiss: () -> Unit,
    onSplitPdf: (Long, String, Int, Int, String?, (DocumentItem) -> Unit) -> Unit,
    onExtractPages: (Long, String, List<Int>, String?, (DocumentItem) -> Unit) -> Unit,
    onRotatePages: (Long, String, Set<Int>, Int, String?, (DocumentItem) -> Unit) -> Unit,
    onDeletePages: (Long, String, Set<Int>, String?, (DocumentItem) -> Unit) -> Unit,
    onCompressPdf: (Long, String, PdfCompressionLevel, String?, (DocumentItem) -> Unit) -> Unit,
    onWatermarkPdf: (Long, String, String, String?, (DocumentItem) -> Unit) -> Unit,
    onProtectPdf: (Long, String, String, String?, (DocumentItem) -> Unit) -> Unit,
    onOpenDocument: (Long) -> Unit
) {
    var selectedDocId by remember { mutableStateOf(pdfDocuments.firstOrNull()?.id ?: -1L) }
    val selectedDoc = pdfDocuments.firstOrNull { it.id == selectedDocId }

    val defaultSuffix = when (tool) {
        PdfSingleTool.SPLIT -> "_Split"
        PdfSingleTool.EXTRACT -> "_Extracted"
        PdfSingleTool.ROTATE -> "_Rotated"
        PdfSingleTool.DELETE_PAGES -> "_Trimmed"
        PdfSingleTool.COMPRESS -> "_Compressed"
        PdfSingleTool.WATERMARK -> "_Watermarked"
        PdfSingleTool.PROTECT -> "_Protected"
    }
    var outputTitle by remember(selectedDocId, tool) {
        mutableStateOf((selectedDoc?.title ?: "DocuScan") + defaultSuffix)
    }
    var startStr by remember { mutableStateOf("1") }
    var endStr by remember { mutableStateOf("1") }
    var pageListInput by remember { mutableStateOf("1") }
    var rotationDegrees by remember { mutableIntStateOf(90) }
    var compressionLevel by remember { mutableStateOf(PdfCompressionLevel.MEDIUM) }
    var watermarkInput by remember { mutableStateOf("CONFIDENTIAL") }
    var newPasswordInput by remember { mutableStateOf("") }
    var unlockPasswordInput by remember { mutableStateOf("") }

    val title = when (tool) {
        PdfSingleTool.SPLIT -> "Split PDF by Range"
        PdfSingleTool.EXTRACT -> "Extract Specific Pages"
        PdfSingleTool.ROTATE -> "Rotate PDF Pages"
        PdfSingleTool.DELETE_PAGES -> "Delete PDF Pages"
        PdfSingleTool.COMPRESS -> "Compress PDF"
        PdfSingleTool.WATERMARK -> "Add Text Watermark"
        PdfSingleTool.PROTECT -> "Password Protect PDF"
    }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text(title) },
        text = {
            Column(
                modifier = Modifier
                    .heightIn(max = 420.dp)
                    .verticalScroll(rememberScrollState()),
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                OutlinedTextField(
                    value = outputTitle,
                    onValueChange = { outputTitle = it },
                    label = { Text("New PDF Title") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )
                Text("Select source PDF:", style = MaterialTheme.typography.labelMedium)
                pdfDocuments.take(8).forEach { doc ->
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clickable { selectedDocId = doc.id },
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        RadioButton(
                            selected = selectedDocId == doc.id,
                            onClick = { selectedDocId = doc.id }
                        )
                        Text(
                            text = "${doc.title} (${doc.pageCount}p · ${FormatUtils.formatBytes(doc.sizeBytes)})",
                            style = MaterialTheme.typography.bodySmall
                        )
                    }
                }

                when (tool) {
                    PdfSingleTool.SPLIT -> {
                        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            OutlinedTextField(
                                value = startStr,
                                onValueChange = { startStr = it.filter(Char::isDigit) },
                                label = { Text("From page") },
                                singleLine = true,
                                modifier = Modifier.weight(1f)
                            )
                            OutlinedTextField(
                                value = endStr,
                                onValueChange = { endStr = it.filter(Char::isDigit) },
                                label = { Text("To page") },
                                singleLine = true,
                                modifier = Modifier.weight(1f)
                            )
                        }
                    }
                    PdfSingleTool.EXTRACT -> {
                        OutlinedTextField(
                            value = pageListInput,
                            onValueChange = { pageListInput = it },
                            label = { Text("Pages (e.g. 1, 3, 4)") },
                            singleLine = true,
                            modifier = Modifier.fillMaxWidth()
                        )
                    }
                    PdfSingleTool.ROTATE -> {
                        Text("Rotation Angle:", style = MaterialTheme.typography.labelMedium)
                        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            listOf(90, 180, 270).forEach { deg ->
                                FilterChip(
                                    selected = rotationDegrees == deg,
                                    onClick = { rotationDegrees = deg },
                                    label = { Text("${deg}°") },
                                    colors = FilterChipDefaults.filterChipColors(
                                        selectedContainerColor = MaterialTheme.colorScheme.primary,
                                        selectedLabelColor = MaterialTheme.colorScheme.onPrimary
                                    )
                                )
                            }
                        }
                        OutlinedTextField(
                            value = pageListInput,
                            onValueChange = { pageListInput = it },
                            label = { Text("Pages (leave blank for all pages)") },
                            singleLine = true,
                            modifier = Modifier.fillMaxWidth()
                        )
                    }
                    PdfSingleTool.DELETE_PAGES -> {
                        OutlinedTextField(
                            value = pageListInput,
                            onValueChange = { pageListInput = it },
                            label = { Text("Pages to remove (e.g. 2, 4)") },
                            singleLine = true,
                            modifier = Modifier.fillMaxWidth()
                        )
                    }
                    PdfSingleTool.COMPRESS -> {
                        Text("Compression Quality:", style = MaterialTheme.typography.labelMedium)
                        PdfCompressionLevel.entries.forEach { level ->
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .clickable { compressionLevel = level },
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                RadioButton(
                                    selected = compressionLevel == level,
                                    onClick = { compressionLevel = level }
                                )
                                Text(level.label, style = MaterialTheme.typography.bodySmall)
                            }
                        }
                    }
                    PdfSingleTool.WATERMARK -> {
                        OutlinedTextField(
                            value = watermarkInput,
                            onValueChange = { watermarkInput = it },
                            label = { Text("Watermark text") },
                            singleLine = true,
                            modifier = Modifier.fillMaxWidth()
                        )
                    }
                    PdfSingleTool.PROTECT -> {
                        OutlinedTextField(
                            value = newPasswordInput,
                            onValueChange = { newPasswordInput = it },
                            label = { Text("New AES-128 Password") },
                            visualTransformation = PasswordVisualTransformation(),
                            singleLine = true,
                            modifier = Modifier.fillMaxWidth()
                        )
                    }
                }

                if (selectedDoc?.isPasswordProtected == true) {
                    OutlinedTextField(
                        value = unlockPasswordInput,
                        onValueChange = { unlockPasswordInput = it },
                        label = { Text("Current PDF Password") },
                        visualTransformation = PasswordVisualTransformation(),
                        singleLine = true,
                        modifier = Modifier.fillMaxWidth()
                    )
                }
            }
        },
        confirmButton = {
            TextButton(
                enabled = selectedDocId > 0L && outputTitle.isNotBlank() && when (tool) {
                    PdfSingleTool.WATERMARK -> watermarkInput.isNotBlank()
                    PdfSingleTool.PROTECT -> newPasswordInput.isNotBlank()
                    else -> true
                },
                onClick = {
                    val pwd = unlockPasswordInput.ifBlank { null }
                    val parsedPages = pageListInput
                        .split(",", " ", ";")
                        .mapNotNull { it.trim().toIntOrNull() }
                        .filter { it >= 1 }

                    onDismiss()
                    val onCreated: (DocumentItem) -> Unit = { created -> onOpenDocument(created.id) }
                    when (tool) {
                        PdfSingleTool.SPLIT -> {
                            val s = startStr.toIntOrNull()?.coerceAtLeast(1) ?: 1
                            val e = endStr.toIntOrNull()?.coerceAtLeast(s) ?: s
                            onSplitPdf(selectedDocId, outputTitle, s, e, pwd, onCreated)
                        }
                        PdfSingleTool.EXTRACT -> {
                            val pages = parsedPages.ifEmpty { listOf(1) }
                            onExtractPages(selectedDocId, outputTitle, pages, pwd, onCreated)
                        }
                        PdfSingleTool.ROTATE -> {
                            val pages = if (pageListInput.isBlank()) emptySet() else parsedPages.toSet()
                            onRotatePages(selectedDocId, outputTitle, pages, rotationDegrees, pwd, onCreated)
                        }
                        PdfSingleTool.DELETE_PAGES -> {
                            val pages = parsedPages.toSet().ifEmpty { setOf(1) }
                            onDeletePages(selectedDocId, outputTitle, pages, pwd, onCreated)
                        }
                        PdfSingleTool.COMPRESS -> {
                            onCompressPdf(selectedDocId, outputTitle, compressionLevel, pwd, onCreated)
                        }
                        PdfSingleTool.WATERMARK -> {
                            onWatermarkPdf(selectedDocId, outputTitle, watermarkInput.trim(), pwd, onCreated)
                        }
                        PdfSingleTool.PROTECT -> {
                            onProtectPdf(selectedDocId, outputTitle, newPasswordInput, pwd, onCreated)
                        }
                    }
                }
            ) { Text("Run Tool") }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) { Text("Cancel") }
        }
    )
}

@Composable
private fun ToolRowCard(
    title: String,
    subtitle: String,
    icon: ImageVector,
    badge: String,
    badgeHighlighted: Boolean,
    enabled: Boolean,
    testTag: String,
    onClick: () -> Unit
) {
    DocuScanCard(
        modifier = Modifier
            .fillMaxWidth()
            .testTag(testTag),
        onClick = if (enabled) onClick else null
    ) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            Icon(
                imageVector = icon,
                contentDescription = title,
                tint = if (enabled) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.onSurfaceVariant,
                modifier = Modifier.size(28.dp)
            )
            Column(
                modifier = Modifier.weight(1f),
                verticalArrangement = Arrangement.spacedBy(3.dp)
            ) {
                Text(
                    text = title,
                    style = MaterialTheme.typography.titleMedium,
                    color = if (enabled) MaterialTheme.colorScheme.onSurface else MaterialTheme.colorScheme.onSurfaceVariant
                )
                Text(
                    text = subtitle,
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
            PhaseStatusChip(text = badge, highlighted = badgeHighlighted && enabled)
        }
    }
}
