package com.example.navigation

import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Build
import androidx.compose.material.icons.filled.Folder
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material.icons.outlined.Build
import androidx.compose.material.icons.outlined.Folder
import androidx.compose.material.icons.outlined.Home
import androidx.compose.material.icons.outlined.Settings
import androidx.compose.ui.graphics.vector.ImageVector
import com.example.util.LocalizedStrings
import kotlinx.serialization.Serializable

@Serializable
data object SplashRoute

@Serializable
data object OnboardingRoute

@Serializable
data object HomeRoute

@Serializable
data object CameraScannerRoute

@Serializable
data class ImageEditorRoute(val pageId: String)

@Serializable
data object PageManagerRoute

@Serializable
data object PdfCreatorRoute

@Serializable
data class OcrExtractorRoute(val documentId: Long = -1L)

@Serializable
data class DocumentsRoute(val folderId: Long = -1L)

@Serializable
data class PdfViewerRoute(val documentId: Long)

@Serializable
data object PdfToolsRoute

@Serializable
data object IdScannerRoute

@Serializable
data object SignatureCreatorRoute

@Serializable
data class SignPdfRoute(val documentId: Long = -1L, val signatureId: Long = -1L)

@Serializable
data object BackupRoute

@Serializable
data object SettingsRoute

@Serializable
data object RecycleBinRoute

@Serializable
data object AboutPrivacyRoute

enum class BottomNavDestination(
    val label: String,
    val selectedIcon: ImageVector,
    val unselectedIcon: ImageVector,
    val testTag: String
) {
    HOME(
        label = "Home",
        selectedIcon = Icons.Filled.Home,
        unselectedIcon = Icons.Outlined.Home,
        testTag = "nav_home"
    ),
    DOCUMENTS(
        label = "Documents",
        selectedIcon = Icons.Filled.Folder,
        unselectedIcon = Icons.Outlined.Folder,
        testTag = "nav_documents"
    ),
    TOOLS(
        label = "Tools",
        selectedIcon = Icons.Filled.Build,
        unselectedIcon = Icons.Outlined.Build,
        testTag = "nav_tools"
    ),
    SETTINGS(
        label = "Settings",
        selectedIcon = Icons.Filled.Settings,
        unselectedIcon = Icons.Outlined.Settings,
        testTag = "nav_settings"
    );

    fun localizedLabel(strings: LocalizedStrings): String = when (this) {
        HOME -> strings.navHome
        DOCUMENTS -> strings.navDocuments
        TOOLS -> strings.navTools
        SETTINGS -> strings.navSettings
    }
}
