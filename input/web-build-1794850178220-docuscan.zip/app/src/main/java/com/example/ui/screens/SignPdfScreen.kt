package com.example.ui.screens

import android.graphics.BitmapFactory
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.NavigateBefore
import androidx.compose.material.icons.automirrored.filled.NavigateNext
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.Description
import androidx.compose.material.icons.filled.Draw
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.OpenWith
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FilterChipDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Slider
import androidx.compose.material3.SnackbarHost
import androidx.compose.material3.SnackbarHostState
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.minimumInteractiveComponentSize
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.unit.IntOffset
import androidx.compose.ui.unit.dp
import coil.compose.AsyncImage
import com.example.domain.model.DocumentItem
import com.example.domain.model.SignatureItem
import com.example.ui.components.DocuScanCard
import com.example.ui.components.DocuScanTopBar
import com.example.ui.components.EmptyStateView
import com.example.ui.components.ErrorStateView
import com.example.ui.components.LoadingStateView
import com.example.ui.viewmodel.SignPdfUiState
import java.io.File
import kotlin.math.roundToInt

@Composable
fun SignPdfScreen(
    initialDocumentId: Long,
    initialSignatureId: Long,
    pdfDocuments: List<DocumentItem>,
    savedSignatures: List<SignatureItem>,
    uiState: SignPdfUiState,
    statusMessage: String?,
    onInitSession: (docId: Long, sigId: Long) -> Unit,
    onSelectDocument: (DocumentItem) -> Unit,
    onUnlockPassword: (String) -> Unit,
    onSelectSignature: (Long) -> Unit,
    onSelectPage: (Int) -> Unit,
    onUpdatePlacement: (normX: Float, normY: Float, normWidth: Float) -> Unit,
    onApplySignature: (newTitle: String, onCreated: (DocumentItem) -> Unit) -> Unit,
    onDrawNewSignature: () -> Unit,
    onClearMessage: () -> Unit,
    onSignedPdfCreated: (Long) -> Unit,
    onBack: () -> Unit
) {
    val snackbarHostState = remember { SnackbarHostState() }
    var outputTitle by remember(uiState.selectedDocument?.id) {
        mutableStateOf(
            uiState.selectedDocument?.let { "${it.title}_Signed" } ?: "Signed_Document"
        )
    }
    var passwordInput by remember { mutableStateOf("") }

    LaunchedEffect(initialDocumentId, initialSignatureId) {
        onInitSession(initialDocumentId, initialSignatureId)
    }

    LaunchedEffect(statusMessage) {
        if (!statusMessage.isNullOrBlank()) {
            snackbarHostState.showSnackbar(statusMessage)
            onClearMessage()
        }
    }

    val selectedSignature = savedSignatures.firstOrNull { it.id == uiState.selectedSignatureId }
    val sigAspectRatio = remember(selectedSignature?.filePath) {
        val path = selectedSignature?.filePath
        if (path.isNullOrBlank()) {
            2.2f
        } else {
            val opts = BitmapFactory.Options().apply { inJustDecodeBounds = true }
            BitmapFactory.decodeFile(path, opts)
            if (opts.outWidth > 0 && opts.outHeight > 0) {
                (opts.outWidth.toFloat() / opts.outHeight.toFloat()).coerceIn(0.6f, 5f)
            } else {
                2.2f
            }
        }
    }

    Scaffold(
        modifier = Modifier
            .fillMaxSize()
            .statusBarsPadding()
            .navigationBarsPadding(),
        containerColor = MaterialTheme.colorScheme.background,
        snackbarHost = { SnackbarHost(snackbarHostState) },
        topBar = {
            DocuScanTopBar(
                title = "Sign PDF Document",
                subtitle = "Drag to reposition & slider to resize",
                onBack = onBack
            )
        }
    ) { innerPadding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
                .verticalScroll(rememberScrollState())
                .padding(horizontal = 16.dp, vertical = 12.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            if (pdfDocuments.isEmpty()) {
                EmptyStateView(
                    title = "No PDF documents found",
                    subtitle = "Create or import a PDF first before inserting your signature.",
                    actionLabel = "Go Back",
                    onAction = onBack
                )
                return@Column
            }

            if (savedSignatures.isEmpty()) {
                EmptyStateView(
                    title = "No saved signatures yet",
                    subtitle = "Draw and save a handwritten signature first, then place it onto any PDF page.",
                    actionLabel = "Create Signature",
                    onAction = onDrawNewSignature
                )
                return@Column
            }

            // Document & Signature Pickers
            DocuScanCard {
                Text("1. Target PDF Document", style = MaterialTheme.typography.titleSmall)
                Spacer(modifier = Modifier.height(6.dp))
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .horizontalScroll(rememberScrollState()),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    pdfDocuments.forEach { doc ->
                        FilterChip(
                            selected = uiState.selectedDocument?.id == doc.id,
                            onClick = { onSelectDocument(doc) },
                            label = { Text("${doc.title} (${doc.pageCount}p)") },
                            leadingIcon = {
                                Icon(Icons.Filled.Description, contentDescription = null, modifier = Modifier.size(16.dp))
                            },
                            colors = FilterChipDefaults.filterChipColors(
                                selectedContainerColor = MaterialTheme.colorScheme.primary,
                                selectedLabelColor = MaterialTheme.colorScheme.onPrimary
                            )
                        )
                    }
                }

                Spacer(modifier = Modifier.height(10.dp))
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text("2. Select Signature", style = MaterialTheme.typography.titleSmall)
                    OutlinedButton(onClick = onDrawNewSignature) {
                        Icon(Icons.Filled.Draw, contentDescription = null, modifier = Modifier.size(16.dp))
                        Spacer(modifier = Modifier.size(4.dp))
                        Text("Draw New")
                    }
                }
                Spacer(modifier = Modifier.height(6.dp))
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .horizontalScroll(rememberScrollState()),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    savedSignatures.forEach { sig ->
                        val isSelected = uiState.selectedSignatureId == sig.id
                        Surface(
                            onClick = { onSelectSignature(sig.id) },
                            shape = MaterialTheme.shapes.medium,
                            color = MaterialTheme.colorScheme.surface,
                            border = BorderStroke(
                                width = if (isSelected) 2.dp else 1.dp,
                                color = if (isSelected) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.outline
                            )
                        ) {
                            Column(
                                modifier = Modifier.padding(8.dp),
                                horizontalAlignment = Alignment.CenterHorizontally,
                                verticalArrangement = Arrangement.spacedBy(4.dp)
                            ) {
                                Box(
                                    modifier = Modifier
                                        .size(width = 104.dp, height = 46.dp)
                                        .clip(RoundedCornerShape(8.dp))
                                        .background(Color(0xFFFAF9F6)),
                                    contentAlignment = Alignment.Center
                                ) {
                                    AsyncImage(
                                        model = File(sig.filePath),
                                        contentDescription = sig.name,
                                        contentScale = ContentScale.Fit,
                                        modifier = Modifier
                                            .fillMaxSize()
                                            .padding(4.dp)
                                    )
                                }
                                Text(sig.name, style = MaterialTheme.typography.labelSmall, maxLines = 1)
                            }
                        }
                    }
                }
            }

            // Interactive PDF Canvas + Draggable & Resizable Signature Overlay
            when {
                uiState.requiresPassword -> {
                    DocuScanCard(highlighted = true) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            Icon(Icons.Filled.Lock, contentDescription = null, tint = MaterialTheme.colorScheme.primary)
                            Text("Enter PDF Password to Place Signature", style = MaterialTheme.typography.titleSmall)
                        }
                        Spacer(modifier = Modifier.height(8.dp))
                        OutlinedTextField(
                            value = passwordInput,
                            onValueChange = { passwordInput = it },
                            label = { Text("PDF Password") },
                            visualTransformation = PasswordVisualTransformation(),
                            isError = uiState.passwordError != null,
                            singleLine = true,
                            modifier = Modifier.fillMaxWidth()
                        )
                        if (uiState.passwordError != null) {
                            Text(
                                text = uiState.passwordError,
                                style = MaterialTheme.typography.bodySmall,
                                color = MaterialTheme.colorScheme.error
                            )
                        }
                        Spacer(modifier = Modifier.height(8.dp))
                        Button(
                            onClick = { onUnlockPassword(passwordInput) },
                            enabled = passwordInput.isNotEmpty(),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Text("Unlock PDF")
                        }
                    }
                }
                uiState.isLoadingPage -> {
                    DocuScanCard {
                        LoadingStateView("Rendering PDF page...")
                    }
                }
                uiState.renderError != null -> {
                    DocuScanCard {
                        ErrorStateView(uiState.renderError)
                    }
                }
                uiState.pageBitmap != null -> {
                    val bmp = uiState.pageBitmap
                    val pageAspect = (bmp.width.toFloat() / bmp.height.coerceAtLeast(1).toFloat()).coerceIn(0.45f, 2.2f)
                    val placement = uiState.placement
                    val density = LocalDensity.current

                    DocuScanCard {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(
                                text = "Drag signature on Page ${uiState.currentPageIndex + 1}",
                                style = MaterialTheme.typography.titleSmall
                            )
                            Text(
                                text = "W ${(placement.normWidth * 100).roundToInt()}% · (${(placement.normX * 100).roundToInt()}%, ${(placement.normY * 100).roundToInt()}%)",
                                style = MaterialTheme.typography.labelSmall,
                                color = MaterialTheme.colorScheme.primary
                            )
                        }
                        Spacer(modifier = Modifier.height(8.dp))

                        BoxWithConstraints(
                            modifier = Modifier
                                .fillMaxWidth()
                                .aspectRatio(pageAspect)
                                .clip(RoundedCornerShape(12.dp))
                                .background(Color.White)
                                .border(1.dp, MaterialTheme.colorScheme.outline, RoundedCornerShape(12.dp))
                        ) {
                            val boxW = constraints.maxWidth.toFloat().coerceAtLeast(1f)
                            val boxH = constraints.maxHeight.toFloat().coerceAtLeast(1f)

                            Image(
                                bitmap = bmp.asImageBitmap(),
                                contentDescription = "PDF page ${uiState.currentPageIndex + 1}",
                                contentScale = ContentScale.FillBounds,
                                modifier = Modifier.fillMaxSize()
                            )

                            if (selectedSignature != null) {
                                val sigWidthPx = (placement.normWidth * boxW).coerceIn(40f, boxW * 0.85f)
                                val sigHeightPx = (sigWidthPx / sigAspectRatio).coerceIn(24f, boxH * 0.70f)
                                val sigOffsetX = (placement.normX * boxW).coerceIn(0f, (boxW - sigWidthPx).coerceAtLeast(0f))
                                val sigOffsetY = (placement.normY * boxH).coerceIn(0f, (boxH - sigHeightPx).coerceAtLeast(0f))

                                val sigWidthDp = with(density) { sigWidthPx.toDp() }
                                val sigHeightDp = with(density) { sigHeightPx.toDp() }

                                Box(
                                    modifier = Modifier
                                        .offset { IntOffset(sigOffsetX.roundToInt(), sigOffsetY.roundToInt()) }
                                        .width(sigWidthDp)
                                        .height(sigHeightDp)
                                        .background(MaterialTheme.colorScheme.primary.copy(alpha = 0.08f))
                                        .border(1.5.dp, MaterialTheme.colorScheme.primary, RoundedCornerShape(6.dp))
                                        .pointerInput(boxW, boxH, placement.normWidth, placement.normX, placement.normY) {
                                            detectDragGestures { change, dragAmount ->
                                                change.consume()
                                                val nextNormX = ((sigOffsetX + dragAmount.x) / boxW)
                                                    .coerceIn(0f, (1f - placement.normWidth).coerceAtLeast(0f))
                                                val maxNormY = ((boxH - sigHeightPx) / boxH).coerceIn(0f, 0.92f)
                                                val nextNormY = ((sigOffsetY + dragAmount.y) / boxH)
                                                    .coerceIn(0f, maxNormY)
                                                onUpdatePlacement(nextNormX, nextNormY, placement.normWidth)
                                            }
                                        }
                                        .testTag("sign_pdf_overlay")
                                ) {
                                    AsyncImage(
                                        model = File(selectedSignature.filePath),
                                        contentDescription = "Placed signature",
                                        contentScale = ContentScale.FillBounds,
                                        modifier = Modifier.fillMaxSize()
                                    )

                                    // Corner resize badge
                                    Surface(
                                        shape = CircleShape,
                                        color = MaterialTheme.colorScheme.primary,
                                        modifier = Modifier
                                            .align(Alignment.BottomEnd)
                                            .size(22.dp)
                                            .pointerInput(boxW, placement.normX, placement.normY, placement.normWidth) {
                                                detectDragGestures { change, dragAmount ->
                                                    change.consume()
                                                    val deltaNormW = dragAmount.x / boxW
                                                    val nextWidth = (placement.normWidth + deltaNormW).coerceIn(0.10f, 0.78f)
                                                    onUpdatePlacement(placement.normX, placement.normY, nextWidth)
                                                }
                                            }
                                    ) {
                                        Box(contentAlignment = Alignment.Center) {
                                            Icon(
                                                imageVector = Icons.Filled.OpenWith,
                                                contentDescription = "Drag to resize",
                                                tint = MaterialTheme.colorScheme.onPrimary,
                                                modifier = Modifier.size(13.dp)
                                            )
                                        }
                                    }
                                }
                            }
                        }

                        // Page Pager
                        if (uiState.totalPages > 1) {
                            Spacer(modifier = Modifier.height(10.dp))
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                OutlinedButton(
                                    onClick = { onSelectPage(uiState.currentPageIndex - 1) },
                                    enabled = uiState.currentPageIndex > 0,
                                    modifier = Modifier.minimumInteractiveComponentSize()
                                ) {
                                    Icon(Icons.AutoMirrored.Filled.NavigateBefore, contentDescription = "Previous page")
                                    Text("Prev")
                                }
                                Text(
                                    text = "Page ${uiState.currentPageIndex + 1} / ${uiState.totalPages}",
                                    style = MaterialTheme.typography.titleSmall
                                )
                                OutlinedButton(
                                    onClick = { onSelectPage(uiState.currentPageIndex + 1) },
                                    enabled = uiState.currentPageIndex < uiState.totalPages - 1,
                                    modifier = Modifier.minimumInteractiveComponentSize()
                                ) {
                                    Text("Next")
                                    Icon(Icons.AutoMirrored.Filled.NavigateNext, contentDescription = "Next page")
                                }
                            }
                        }

                        Spacer(modifier = Modifier.height(10.dp))
                        Text(
                            text = "Signature Width (${(placement.normWidth * 100).roundToInt()}%)",
                            style = MaterialTheme.typography.labelMedium
                        )
                        Slider(
                            value = placement.normWidth,
                            onValueChange = { newW ->
                                onUpdatePlacement(placement.normX, placement.normY, newW)
                            },
                            valueRange = 0.10f..0.75f,
                            modifier = Modifier.testTag("sign_pdf_size_slider")
                        )

                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            OutlinedButton(
                                onClick = { onUpdatePlacement(0.08f, 0.78f, placement.normWidth) },
                                modifier = Modifier.weight(1f)
                            ) { Text("Bottom Left") }
                            OutlinedButton(
                                onClick = {
                                    val centeredX = ((1f - placement.normWidth) / 2f).coerceIn(0f, 0.85f)
                                    onUpdatePlacement(centeredX, 0.78f, placement.normWidth)
                                },
                                modifier = Modifier.weight(1f)
                            ) { Text("Center") }
                            OutlinedButton(
                                onClick = {
                                    val rightX = (0.92f - placement.normWidth).coerceIn(0f, 0.85f)
                                    onUpdatePlacement(rightX, 0.78f, placement.normWidth)
                                },
                                modifier = Modifier.weight(1f)
                            ) { Text("Bottom Right") }
                        }
                    }

                    // Filename + Save Signed Copy
                    DocuScanCard {
                        OutlinedTextField(
                            value = outputTitle,
                            onValueChange = { outputTitle = it },
                            label = { Text("Signed PDF Filename") },
                            singleLine = true,
                            modifier = Modifier
                                .fillMaxWidth()
                                .testTag("sign_pdf_filename_input")
                        )
                        Spacer(modifier = Modifier.height(10.dp))
                        Button(
                            onClick = {
                                onApplySignature(outputTitle) { created ->
                                    onSignedPdfCreated(created.id)
                                }
                            },
                            enabled = !uiState.isSaving && selectedSignature != null && outputTitle.isNotBlank(),
                            colors = ButtonDefaults.buttonColors(
                                containerColor = MaterialTheme.colorScheme.primary,
                                contentColor = MaterialTheme.colorScheme.onPrimary
                            ),
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(52.dp)
                                .testTag("sign_pdf_save_btn")
                        ) {
                            if (uiState.isSaving) {
                                CircularProgressIndicator(
                                    color = MaterialTheme.colorScheme.onPrimary,
                                    modifier = Modifier.size(20.dp),
                                    strokeWidth = 2.dp
                                )
                                Spacer(modifier = Modifier.size(8.dp))
                                Text("Embedding Signature...")
                            } else {
                                Icon(Icons.Filled.Check, contentDescription = null, modifier = Modifier.size(20.dp))
                                Spacer(modifier = Modifier.size(8.dp))
                                Text("Save Signed PDF Copy")
                            }
                        }
                    }
                }
            }
        }
    }
}
