package com.example.domain.repository

import android.net.Uri
import com.example.domain.model.AppLanguage
import com.example.domain.model.CacheSummary
import com.example.domain.model.DeletedDocumentItem
import com.example.domain.model.DocumentItem
import com.example.domain.model.FolderItem
import com.example.domain.model.IdDocumentType
import com.example.domain.model.IdSideScanState
import com.example.domain.model.PdfCompressionLevel
import com.example.domain.model.PdfCreationOptions
import com.example.domain.model.PdfPageSize
import com.example.domain.model.PdfSearchMatch
import com.example.domain.model.ScanPage
import com.example.domain.model.ScanQuality
import com.example.domain.model.SignatureItem
import com.example.domain.model.SignaturePlacement
import com.example.domain.model.StorageSummary
import com.example.domain.model.ThemeMode
import com.example.domain.model.UserPreferences
import kotlinx.coroutines.flow.Flow

interface DocumentRepository {
    fun observeActiveDocuments(): Flow<List<DocumentItem>>
    fun observeRecentDocuments(limit: Int = 8): Flow<List<DocumentItem>>
    fun observeTrashDocuments(): Flow<List<DocumentItem>>
    fun observeDeletedDocuments(): Flow<List<DeletedDocumentItem>>
    fun observeFolders(): Flow<List<FolderItem>>
    fun observeSignatures(): Flow<List<SignatureItem>>
    fun observeStorageSummary(): Flow<StorageSummary>
    suspend fun getDocumentById(id: Long): DocumentItem?

    suspend fun createFolder(name: String): Result<FolderItem>
    suspend fun renameFolder(folderId: Long, newName: String): Result<Unit>
    suspend fun deleteFolder(folderId: Long): Result<Unit>

    suspend fun importUriToScanFile(uri: Uri): Result<String>
    suspend fun importExternalPdfUri(uri: Uri, folderId: Long? = null): Result<DocumentItem>
    suspend fun exportDocumentToUri(documentId: Long, destinationUri: Uri): Result<Long>

    suspend fun saveScannedBatch(
        title: String,
        pageImageUris: List<Uri>,
        pdfUri: Uri?,
        pdfPageCount: Int
    ): Result<Pair<DocumentItem, List<ScanPage>>>

    suspend fun getDocumentPages(documentId: Long): List<ScanPage>

    suspend fun createPdfDocument(
        title: String,
        pages: List<ScanPage>,
        folderId: Long?,
        pageSize: PdfPageSize,
        quality: ScanQuality
    ): Result<DocumentItem>

    suspend fun createPdfDocument(
        title: String,
        pages: List<ScanPage>,
        folderId: Long?,
        options: PdfCreationOptions
    ): Result<DocumentItem>

    suspend fun updatePdfDocument(
        documentId: Long,
        title: String,
        pages: List<ScanPage>,
        folderId: Long?,
        pageSize: PdfPageSize,
        quality: ScanQuality
    ): Result<DocumentItem>

    suspend fun updatePdfDocument(
        documentId: Long,
        title: String,
        pages: List<ScanPage>,
        folderId: Long?,
        options: PdfCreationOptions
    ): Result<DocumentItem>

    suspend fun saveSingleImageDocument(
        title: String,
        page: ScanPage,
        folderId: Long?
    ): Result<DocumentItem>

    suspend fun renameDocument(documentId: Long, newTitle: String): Result<Unit>
    suspend fun togglePin(documentId: Long): Result<Unit>
    suspend fun toggleFavorite(documentId: Long): Result<Unit>
    suspend fun setFavorites(documentIds: List<Long>, isFavorite: Boolean): Result<Unit>
    suspend fun moveDocumentToFolder(documentId: Long, folderId: Long?): Result<Unit>
    suspend fun moveDocumentsToFolder(documentIds: List<Long>, folderId: Long?): Result<Unit>
    suspend fun togglePageBookmark(documentId: Long, pageIndex: Int): Result<List<Int>>
    suspend fun updateOcrText(documentId: Long, ocrText: String): Result<Unit>
    suspend fun moveDocumentToTrash(documentId: Long): Result<Unit>
    suspend fun moveDocumentsToTrash(documentIds: List<Long>): Result<Unit>
    suspend fun restoreDocument(documentId: Long): Result<Unit>
    suspend fun permanentlyDeleteDocument(documentId: Long): Result<Unit>
    suspend fun emptyRecycleBin(): Result<Unit>

    suspend fun mergePdfDocuments(
        title: String,
        documentIds: List<Long>,
        folderId: Long?
    ): Result<DocumentItem>

    suspend fun splitPdfDocument(
        sourceDocumentId: Long,
        newTitle: String,
        startPageOneBased: Int,
        endPageOneBased: Int,
        password: String? = null
    ): Result<DocumentItem>

    suspend fun extractPdfPages(
        sourceDocumentId: Long,
        newTitle: String,
        oneBasedPages: List<Int>,
        password: String? = null
    ): Result<DocumentItem>

    suspend fun rotatePdfPages(
        sourceDocumentId: Long,
        newTitle: String,
        oneBasedPages: Set<Int> = emptySet(),
        deltaDegrees: Int = 90,
        password: String? = null
    ): Result<DocumentItem>

    suspend fun deletePdfPages(
        sourceDocumentId: Long,
        newTitle: String,
        oneBasedPagesToDelete: Set<Int>,
        password: String? = null
    ): Result<DocumentItem>

    suspend fun compressPdfDocument(
        sourceDocumentId: Long,
        newTitle: String,
        compressionLevel: PdfCompressionLevel,
        password: String? = null
    ): Result<DocumentItem>

    suspend fun watermarkPdfDocument(
        sourceDocumentId: Long,
        newTitle: String,
        watermarkText: String,
        password: String? = null
    ): Result<DocumentItem>

    suspend fun protectPdfDocument(
        sourceDocumentId: Long,
        newTitle: String,
        userPassword: String,
        existingPassword: String? = null
    ): Result<DocumentItem>

    suspend fun annotatePdfDocument(
        sourceDocumentId: Long,
        newTitle: String,
        pageIndexZeroBased: Int,
        noteText: String,
        addHighlightBar: Boolean = true,
        password: String? = null
    ): Result<DocumentItem>

    suspend fun searchTextInPdf(
        documentId: Long,
        query: String,
        password: String? = null
    ): List<PdfSearchMatch>

    suspend fun saveSignature(name: String, pngBytes: ByteArray): Result<SignatureItem>
    suspend fun deleteSignature(signatureId: Long): Result<Unit>

    suspend fun createIdCardPdfDocument(
        title: String,
        docType: IdDocumentType,
        frontSide: IdSideScanState,
        backSide: IdSideScanState?,
        singleCombinedSheet: Boolean,
        quality: ScanQuality,
        password: String? = null,
        encryptInVault: Boolean = false
    ): Result<DocumentItem>

    suspend fun insertSignatureIntoPdf(
        sourceDocumentId: Long,
        newTitle: String,
        signatureId: Long,
        placement: SignaturePlacement,
        password: String? = null
    ): Result<DocumentItem>

    suspend fun sealDocumentInVault(documentId: Long): Result<Boolean>
    suspend fun unsealDocumentInVault(documentId: Long): Result<Boolean>
    suspend fun isDocumentVaultEncrypted(documentId: Long): Boolean

    suspend fun getCacheSummary(): CacheSummary
    suspend fun clearTempCache(): Result<Long>

    suspend fun createLocalBackupManifest(): Result<String>
    suspend fun exportFullBackupArchive(destinationUri: Uri): Result<Long>
}

interface SettingsRepository {
    val preferences: Flow<UserPreferences>
    suspend fun setThemeMode(mode: ThemeMode)
    suspend fun setAppLanguage(language: AppLanguage) {}
    suspend fun setOnboardingCompleted(completed: Boolean)
    suspend fun setScanQuality(quality: ScanQuality)
    suspend fun setDefaultPageSize(pageSize: PdfPageSize) {}
    suspend fun setAutoEnhance(enabled: Boolean)
    suspend fun setAppLockEnabled(enabled: Boolean)
    suspend fun setBiometricUnlockEnabled(enabled: Boolean) {}
    suspend fun setEncryptSensitiveFiles(enabled: Boolean) {}
    suspend fun setSealedPinRecord(record: String?) {}
    suspend fun updateLastBackupAt(timestamp: Long)
}
