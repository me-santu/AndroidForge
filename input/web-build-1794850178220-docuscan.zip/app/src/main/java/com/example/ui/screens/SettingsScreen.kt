package com.example.ui.screens

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.KeyboardArrowRight
import androidx.compose.material.icons.filled.AspectRatio
import androidx.compose.material.icons.filled.AutoAwesome
import androidx.compose.material.icons.filled.Backup
import androidx.compose.material.icons.filled.CleaningServices
import androidx.compose.material.icons.filled.DeleteOutline
import androidx.compose.material.icons.filled.Fingerprint
import androidx.compose.material.icons.filled.FolderOpen
import androidx.compose.material.icons.filled.HighQuality
import androidx.compose.material.icons.filled.Key
import androidx.compose.material.icons.filled.Language
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.Palette
import androidx.compose.material.icons.filled.PrivacyTip
import androidx.compose.material.icons.filled.Shield
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FilterChipDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Switch
import androidx.compose.material3.SwitchDefaults
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.minimumInteractiveComponentSize
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.unit.dp
import com.example.BuildConfig
import com.example.domain.model.AppLanguage
import com.example.domain.model.CacheSummary
import com.example.domain.model.PdfPageSize
import com.example.domain.model.ScanQuality
import com.example.domain.model.StorageSummary
import com.example.domain.model.ThemeMode
import com.example.domain.model.UserPreferences
import com.example.security.BiometricCapability
import com.example.security.SecurityManager
import com.example.ui.components.DocuScanCard
import com.example.ui.components.PhaseStatusChip
import com.example.util.FormatUtils
import com.example.util.LocalAppStrings

@OptIn(ExperimentalLayoutApi::class)
@Composable
fun SettingsScreen(
    preferences: UserPreferences,
    storageSummary: StorageSummary,
    cacheSummary: CacheSummary,
    biometricCapability: BiometricCapability,
    securityManager: SecurityManager,
    onSelectTheme: (ThemeMode) -> Unit,
    onSelectLanguage: (AppLanguage) -> Unit,
    onSelectScanQuality: (ScanQuality) -> Unit,
    onSelectDefaultPageSize: (PdfPageSize) -> Unit,
    onToggleAutoEnhance: (Boolean) -> Unit,
    onToggleAppLock: (Boolean) -> Unit,
    onToggleBiometricUnlock: (Boolean) -> Unit,
    onToggleEncryptSensitiveFiles: (Boolean) -> Unit,
    onConfigurePin: (newPin: String, enableLock: Boolean) -> Result<Unit>,
    onRemovePin: () -> Unit,
    onLockVaultNow: () -> Unit,
    onClearTempCache: () -> Unit,
    onOpenBackup: () -> Unit,
    onOpenRecycleBin: () -> Unit,
    onOpenAboutPrivacy: () -> Unit,
    modifier: Modifier = Modifier
) {
    val strings = LocalAppStrings.current
    var showPinSetupDialog by remember { mutableStateOf(false) }
    var enableLockAfterPinSetup by remember { mutableStateOf(true) }
    var pinInput by remember { mutableStateOf("") }
    var pinConfirmInput by remember { mutableStateOf("") }
    var pinDialogError by remember { mutableStateOf<String?>(null) }

    LazyColumn(
        modifier = modifier
            .fillMaxSize()
            .testTag("settings_list"),
        contentPadding = PaddingValues(horizontal = 16.dp, vertical = 14.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        item {
            Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
                Text(strings.settingsTitle, style = MaterialTheme.typography.headlineMedium)
                Text(
                    text = strings.settingsSubtitle,
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
        }

        // Theme Selection: Dark / Light / System
        item {
            DocuScanCard {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    Icon(
                        imageVector = Icons.Filled.Palette,
                        contentDescription = null,
                        tint = MaterialTheme.colorScheme.primary
                    )
                    Text(strings.appTheme, style = MaterialTheme.typography.titleMedium)
                }
                Spacer(modifier = Modifier.height(10.dp))
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    ThemeMode.entries.forEach { mode ->
                        FilterChip(
                            selected = preferences.themeMode == mode,
                            onClick = { onSelectTheme(mode) },
                            label = { Text(mode.label) },
                            colors = FilterChipDefaults.filterChipColors(
                                selectedContainerColor = MaterialTheme.colorScheme.primary,
                                selectedLabelColor = MaterialTheme.colorScheme.onPrimary
                            ),
                            modifier = Modifier
                                .weight(1f)
                                .testTag("theme_option_${mode.name.lowercase()}")
                        )
                    }
                }
            }
        }

        // Interface Language: English / Hindi / Bengali
        item {
            DocuScanCard {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    Icon(
                        imageVector = Icons.Filled.Language,
                        contentDescription = null,
                        tint = MaterialTheme.colorScheme.primary
                    )
                    Text(strings.interfaceLanguage, style = MaterialTheme.typography.titleMedium)
                }
                Spacer(modifier = Modifier.height(10.dp))
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    AppLanguage.entries.forEach { lang ->
                        FilterChip(
                            selected = preferences.appLanguage == lang,
                            onClick = { onSelectLanguage(lang) },
                            label = { Text(lang.nativeLabel) },
                            colors = FilterChipDefaults.filterChipColors(
                                selectedContainerColor = MaterialTheme.colorScheme.primary,
                                selectedLabelColor = MaterialTheme.colorScheme.onPrimary
                            ),
                            modifier = Modifier
                                .weight(1f)
                                .testTag("lang_option_${lang.code}")
                        )
                    }
                }
            }
        }

        // Scan Quality, Default Page Size & Auto-Enhance
        item {
            DocuScanCard {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    Icon(
                        imageVector = Icons.Filled.HighQuality,
                        contentDescription = null,
                        tint = MaterialTheme.colorScheme.primary
                    )
                    Text(strings.pdfDefaults, style = MaterialTheme.typography.titleMedium)
                }
                Spacer(modifier = Modifier.height(10.dp))
                Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                    ScanQuality.entries.forEach { quality ->
                        FilterChip(
                            selected = preferences.scanQuality == quality,
                            onClick = { onSelectScanQuality(quality) },
                            label = { Text(quality.label) },
                            colors = FilterChipDefaults.filterChipColors(
                                selectedContainerColor = MaterialTheme.colorScheme.primary,
                                selectedLabelColor = MaterialTheme.colorScheme.onPrimary
                            ),
                            modifier = Modifier
                                .fillMaxWidth()
                                .testTag("quality_option_${quality.name.lowercase()}")
                        )
                    }
                }

                Spacer(modifier = Modifier.height(12.dp))
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    Icon(
                        imageVector = Icons.Filled.AspectRatio,
                        contentDescription = null,
                        tint = MaterialTheme.colorScheme.primary,
                        modifier = Modifier.size(20.dp)
                    )
                    Text(strings.defaultPageSize, style = MaterialTheme.typography.titleSmall)
                }
                Spacer(modifier = Modifier.height(8.dp))
                FlowRow(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                    verticalArrangement = Arrangement.spacedBy(4.dp)
                ) {
                    PdfPageSize.entries.forEach { pageSize ->
                        FilterChip(
                            selected = preferences.defaultPageSize == pageSize,
                            onClick = { onSelectDefaultPageSize(pageSize) },
                            label = { Text(pageSize.label) },
                            colors = FilterChipDefaults.filterChipColors(
                                selectedContainerColor = MaterialTheme.colorScheme.primary,
                                selectedLabelColor = MaterialTheme.colorScheme.onPrimary
                            ),
                            modifier = Modifier.testTag("page_size_option_${pageSize.name.lowercase()}")
                        )
                    }
                }

                Spacer(modifier = Modifier.height(12.dp))
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(10.dp),
                        modifier = Modifier.weight(1f)
                    ) {
                        Icon(
                            imageVector = Icons.Filled.AutoAwesome,
                            contentDescription = null,
                            tint = MaterialTheme.colorScheme.primary
                        )
                        Column {
                            Text(strings.autoEnhanceTitle, style = MaterialTheme.typography.titleSmall)
                            Text(
                                text = strings.autoEnhanceSubtitle,
                                style = MaterialTheme.typography.bodySmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                    }
                    Switch(
                        checked = preferences.autoEnhance,
                        onCheckedChange = onToggleAutoEnhance,
                        colors = SwitchDefaults.colors(checkedThumbColor = MaterialTheme.colorScheme.onPrimary)
                    )
                }
            }
        }

        // Security Settings: Keystore, App Lock PIN, Biometric, Sensitive Encryption
        item {
            DocuScanCard(highlighted = preferences.appLockEnabled) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(10.dp),
                        modifier = Modifier.weight(1f)
                    ) {
                        Icon(
                            imageVector = Icons.Filled.Shield,
                            contentDescription = null,
                            tint = MaterialTheme.colorScheme.primary
                        )
                        Column {
                            Text(strings.securitySettingsTitle, style = MaterialTheme.typography.titleMedium)
                            Text(
                                text = securityManager.keystoreProviderLabel,
                                style = MaterialTheme.typography.labelSmall,
                                color = MaterialTheme.colorScheme.primary
                            )
                        }
                    }
                    PhaseStatusChip(
                        text = if (preferences.appLockEnabled) "Locked" else "Keystore",
                        highlighted = preferences.appLockEnabled
                    )
                }

                Spacer(modifier = Modifier.height(12.dp))

                // Vault App Lock Toggle
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(10.dp),
                        modifier = Modifier.weight(1f)
                    ) {
                        Icon(Icons.Filled.Lock, contentDescription = null, tint = MaterialTheme.colorScheme.primary)
                        Column {
                            Text(strings.vaultAppLock, style = MaterialTheme.typography.titleSmall)
                            Text(
                                text = if (preferences.hasPinConfigured) {
                                    "Require PIN or biometrics when opening DocuScan"
                                } else {
                                    "Set a 4–8 digit Vault PIN to enable App Lock"
                                },
                                style = MaterialTheme.typography.bodySmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                    }
                    Switch(
                        checked = preferences.appLockEnabled,
                        onCheckedChange = { wantEnabled ->
                            if (wantEnabled && !preferences.hasPinConfigured) {
                                enableLockAfterPinSetup = true
                                pinInput = ""
                                pinConfirmInput = ""
                                pinDialogError = null
                                showPinSetupDialog = true
                            } else {
                                onToggleAppLock(wantEnabled)
                            }
                        },
                        modifier = Modifier.testTag("settings_app_lock_switch")
                    )
                }

                Spacer(modifier = Modifier.height(10.dp))

                // Biometric Unlock Toggle
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(10.dp),
                        modifier = Modifier.weight(1f)
                    ) {
                        Icon(
                            Icons.Filled.Fingerprint,
                            contentDescription = null,
                            tint = MaterialTheme.colorScheme.primary
                        )
                        Column {
                            Text(strings.biometricUnlock, style = MaterialTheme.typography.titleSmall)
                            Text(
                                text = biometricCapability.statusLabel,
                                style = MaterialTheme.typography.bodySmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                    }
                    Switch(
                        checked = preferences.biometricUnlockEnabled,
                        enabled = preferences.hasPinConfigured && biometricCapability.isAvailable,
                        onCheckedChange = onToggleBiometricUnlock,
                        modifier = Modifier.testTag("settings_biometric_switch")
                    )
                }

                Spacer(modifier = Modifier.height(10.dp))

                // Encrypt ID Scans with Android Keystore Toggle
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(10.dp),
                        modifier = Modifier.weight(1f)
                    ) {
                        Icon(Icons.Filled.Key, contentDescription = null, tint = MaterialTheme.colorScheme.primary)
                        Column {
                            Text(strings.encryptIdScans, style = MaterialTheme.typography.titleSmall)
                            Text(
                                text = "Wrap saved Aadhaar, PAN & ID PDFs using AES-256-GCM",
                                style = MaterialTheme.typography.bodySmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                    }
                    Switch(
                        checked = preferences.encryptSensitiveFiles,
                        onCheckedChange = onToggleEncryptSensitiveFiles,
                        modifier = Modifier.testTag("settings_encrypt_ids_switch")
                    )
                }

                Spacer(modifier = Modifier.height(12.dp))

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    OutlinedButton(
                        onClick = {
                            enableLockAfterPinSetup = !preferences.hasPinConfigured || preferences.appLockEnabled
                            pinInput = ""
                            pinConfirmInput = ""
                            pinDialogError = null
                            showPinSetupDialog = true
                        },
                        modifier = Modifier
                            .weight(1f)
                            .minimumInteractiveComponentSize()
                            .testTag("settings_set_pin_btn")
                    ) {
                        Text(if (preferences.hasPinConfigured) strings.changePin else strings.setPin)
                    }
                    if (preferences.hasPinConfigured) {
                        OutlinedButton(
                            onClick = onRemovePin,
                            modifier = Modifier
                                .weight(1f)
                                .minimumInteractiveComponentSize()
                                .testTag("settings_remove_pin_btn")
                        ) {
                            Text(strings.removePin, color = MaterialTheme.colorScheme.error)
                        }
                    }
                }

                if (preferences.appLockEnabled && preferences.hasPinConfigured) {
                    Spacer(modifier = Modifier.height(8.dp))
                    Button(
                        onClick = onLockVaultNow,
                        colors = ButtonDefaults.buttonColors(
                            containerColor = MaterialTheme.colorScheme.primary,
                            contentColor = MaterialTheme.colorScheme.onPrimary
                        ),
                        modifier = Modifier
                            .fillMaxWidth()
                            .minimumInteractiveComponentSize()
                            .testTag("settings_lock_now_btn")
                    ) {
                        Icon(Icons.Filled.Lock, contentDescription = null, modifier = Modifier.size(18.dp))
                        Spacer(modifier = Modifier.size(6.dp))
                        Text(strings.lockNow)
                    }
                }
            }
        }

        // Save Location & Storage Info
        item {
            DocuScanCard {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    Icon(
                        imageVector = Icons.Filled.FolderOpen,
                        contentDescription = null,
                        tint = MaterialTheme.colorScheme.primary
                    )
                    Text(strings.saveLocationTitle, style = MaterialTheme.typography.titleMedium)
                }
                Spacer(modifier = Modifier.height(6.dp))
                Text(
                    text = strings.saveLocationSubtitle,
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
                Spacer(modifier = Modifier.height(8.dp))
                Text(
                    text = cacheSummary.saveDirectoryPath.ifBlank { "App-private storage/files/documents" },
                    style = MaterialTheme.typography.labelSmall,
                    color = MaterialTheme.colorScheme.primary
                )
                if (cacheSummary.usableSpaceBytes > 0L) {
                    Text(
                        text = "${FormatUtils.formatBytes(cacheSummary.usableSpaceBytes)} free on device",
                        style = MaterialTheme.typography.labelSmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                        modifier = Modifier.padding(top = 4.dp)
                    )
                }
            }
        }

        // Cache Management
        item {
            DocuScanCard {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(10.dp),
                        modifier = Modifier.weight(1f)
                    ) {
                        Icon(
                            imageVector = Icons.Filled.CleaningServices,
                            contentDescription = null,
                            tint = MaterialTheme.colorScheme.primary
                        )
                        Column {
                            Text(strings.cacheManagementTitle, style = MaterialTheme.typography.titleMedium)
                            Text(
                                text = "Temp cache: ${FormatUtils.formatBytes(cacheSummary.totalClearableCacheBytes)} · Vault files: ${FormatUtils.formatBytes(cacheSummary.documentsBytes)}",
                                style = MaterialTheme.typography.bodySmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                    }
                }
                Spacer(modifier = Modifier.height(10.dp))
                OutlinedButton(
                    onClick = onClearTempCache,
                    modifier = Modifier
                        .fillMaxWidth()
                        .minimumInteractiveComponentSize()
                        .testTag("settings_clear_cache_btn")
                ) {
                    Text(strings.clearTempCache)
                }
            }
        }

        // Backup & Recycle Bin & About Links
        item {
            DocuScanCard(
                onClick = onOpenBackup,
                modifier = Modifier
                    .fillMaxWidth()
                    .testTag("settings_backup_row")
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        Icon(Icons.Filled.Backup, contentDescription = null, tint = MaterialTheme.colorScheme.primary)
                        Column {
                            Text(strings.backupAndVault, style = MaterialTheme.typography.titleSmall)
                            Text(
                                text = "${FormatUtils.formatBytes(storageSummary.totalUsedBytes)} used locally",
                                style = MaterialTheme.typography.bodySmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                    }
                    Icon(Icons.AutoMirrored.Filled.KeyboardArrowRight, contentDescription = null)
                }
            }
        }

        item {
            DocuScanCard(
                onClick = onOpenRecycleBin,
                modifier = Modifier
                    .fillMaxWidth()
                    .testTag("settings_recycle_bin_row")
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        Icon(Icons.Filled.DeleteOutline, contentDescription = null, tint = MaterialTheme.colorScheme.error)
                        Column {
                            Text(strings.recycleBin, style = MaterialTheme.typography.titleSmall)
                            Text(
                                text = "${storageSummary.trashCount} deleted document(s)",
                                style = MaterialTheme.typography.bodySmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                    }
                    Icon(Icons.AutoMirrored.Filled.KeyboardArrowRight, contentDescription = null)
                }
            }
        }

        item {
            DocuScanCard(
                onClick = onOpenAboutPrivacy,
                modifier = Modifier
                    .fillMaxWidth()
                    .testTag("settings_about_privacy_row")
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(10.dp),
                        modifier = Modifier.weight(1f)
                    ) {
                        Icon(Icons.Filled.PrivacyTip, contentDescription = null, tint = MaterialTheme.colorScheme.primary)
                        Column {
                            Text(strings.aboutAndPrivacy, style = MaterialTheme.typography.titleSmall)
                            Text(
                                text = "DocuScan v${BuildConfig.VERSION_NAME} · ${strings.aboutAndPrivacySubtitle}",
                                style = MaterialTheme.typography.bodySmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                    }
                    Icon(Icons.AutoMirrored.Filled.KeyboardArrowRight, contentDescription = null)
                }
            }
        }
    }

    if (showPinSetupDialog) {
        AlertDialog(
            onDismissRequest = { showPinSetupDialog = false },
            title = { Text(if (preferences.hasPinConfigured) strings.changePin else strings.setPin) },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    Text(
                        text = "Enter a 4–8 digit PIN. It is hashed with a random salt and sealed using Android Keystore AES-256-GCM.",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                    OutlinedTextField(
                        value = pinInput,
                        onValueChange = { value ->
                            if (value.length <= 8 && value.all(Char::isDigit)) {
                                pinInput = value
                                pinDialogError = null
                            }
                        },
                        label = { Text("New PIN (4–8 digits)") },
                        singleLine = true,
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.NumberPassword),
                        visualTransformation = PasswordVisualTransformation(),
                        modifier = Modifier
                            .fillMaxWidth()
                            .testTag("pin_setup_input")
                    )
                    OutlinedTextField(
                        value = pinConfirmInput,
                        onValueChange = { value ->
                            if (value.length <= 8 && value.all(Char::isDigit)) {
                                pinConfirmInput = value
                                pinDialogError = null
                            }
                        },
                        label = { Text("Confirm PIN") },
                        singleLine = true,
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.NumberPassword),
                        visualTransformation = PasswordVisualTransformation(),
                        modifier = Modifier
                            .fillMaxWidth()
                            .testTag("pin_setup_confirm_input")
                    )
                    if (!pinDialogError.isNullOrBlank()) {
                        Text(
                            text = pinDialogError!!,
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.error
                        )
                    }
                }
            },
            confirmButton = {
                TextButton(
                    onClick = {
                        when {
                            pinInput.length !in 4..8 -> {
                                pinDialogError = "PIN must be 4 to 8 digits."
                            }
                            pinInput != pinConfirmInput -> {
                                pinDialogError = "PINs do not match."
                            }
                            else -> {
                                onConfigurePin(pinInput, enableLockAfterPinSetup)
                                    .onSuccess { showPinSetupDialog = false }
                                    .onFailure { pinDialogError = it.message ?: "Could not save PIN" }
                            }
                        }
                    },
                    modifier = Modifier.testTag("pin_setup_save_btn")
                ) {
                    Text("Save PIN")
                }
            },
            dismissButton = {
                TextButton(onClick = { showPinSetupDialog = false }) { Text("Cancel") }
            }
        )
    }
}
