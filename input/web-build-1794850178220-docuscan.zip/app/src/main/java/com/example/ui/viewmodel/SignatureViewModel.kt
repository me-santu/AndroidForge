package com.example.ui.viewmodel

import android.graphics.Bitmap
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.example.domain.model.DocumentFileType
import com.example.domain.model.DocumentItem
import com.example.domain.model.SignatureItem
import com.example.domain.model.SignaturePlacement
import com.example.domain.repository.DocumentRepository
import com.example.pdf.PdfRenderOutcome
import com.example.pdf.PdfRendererHelper
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch

data class SignPdfUiState(
    val selectedDocument: DocumentItem? = null,
    val selectedSignatureId: Long = -1L,
    val currentPageIndex: Int = 0,
    val totalPages: Int = 1,
    val pageBitmap: Bitmap? = null,
    val requiresPassword: Boolean = false,
    val passwordError: String? = null,
    val placement: SignaturePlacement = SignaturePlacement(),
    val isLoadingPage: Boolean = false,
    val isSaving: Boolean = false,
    val renderError: String? = null
)

class SignatureViewModel(
    private val repository: DocumentRepository,
    private val pdfRendererHelper: PdfRendererHelper? = null
) : ViewModel() {

    val signatures: StateFlow<List<SignatureItem>> = repository.observeSignatures()
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val pdfDocuments: StateFlow<List<DocumentItem>> = repository.observeActiveDocuments()
        .map { list -> list.filter { it.fileType == DocumentFileType.PDF || it.fileType == DocumentFileType.ID_CARD } }
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    private val _message = MutableStateFlow<String?>(null)
    val message: StateFlow<String?> = _message.asStateFlow()

    private val _signPdfState = MutableStateFlow(SignPdfUiState())
    val signPdfState: StateFlow<SignPdfUiState> = _signPdfState.asStateFlow()

    private var activePdfPassword: String? = null

    fun saveSignature(name: String, pngBytes: ByteArray, onSaved: (SignatureItem) -> Unit = {}) {
        viewModelScope.launch {
            repository.saveSignature(name, pngBytes)
                .onSuccess { sig ->
                    _message.value = "Signature '${sig.name}' saved locally"
                    _signPdfState.update { it.copy(selectedSignatureId = sig.id) }
                    onSaved(sig)
                }
                .onFailure { _message.value = it.message ?: "Failed to save signature" }
        }
    }

    fun deleteSignature(signatureId: Long) {
        viewModelScope.launch {
            repository.deleteSignature(signatureId)
                .onSuccess {
                    if (_signPdfState.value.selectedSignatureId == signatureId) {
                        _signPdfState.update { it.copy(selectedSignatureId = -1L) }
                    }
                    _message.value = "Signature removed"
                }
        }
    }

    fun initSignPdfSession(initialDocId: Long, initialSignatureId: Long) {
        viewModelScope.launch {
            if (initialSignatureId > 0L) {
                _signPdfState.update { it.copy(selectedSignatureId = initialSignatureId) }
            } else if (_signPdfState.value.selectedSignatureId <= 0L) {
                val firstSig = signatures.value.firstOrNull()
                if (firstSig != null) {
                    _signPdfState.update { it.copy(selectedSignatureId = firstSig.id) }
                }
            }

            if (initialDocId > 0L) {
                val doc = repository.getDocumentById(initialDocId)
                if (doc != null) {
                    selectPdfDocument(doc)
                }
            } else if (_signPdfState.value.selectedDocument == null) {
                val firstDoc = pdfDocuments.value.firstOrNull()
                if (firstDoc != null) {
                    selectPdfDocument(firstDoc)
                }
            }
        }
    }

    fun selectPdfDocument(doc: DocumentItem, password: String? = null) {
        activePdfPassword = password
        _signPdfState.update {
            it.copy(
                selectedDocument = doc,
                currentPageIndex = 0,
                totalPages = doc.pageCount.coerceAtLeast(1),
                placement = it.placement.copy(pageIndex = 0),
                requiresPassword = false,
                passwordError = null,
                renderError = null
            )
        }
        loadSignPage(doc, pageIndex = 0, password = password)
    }

    fun unlockSignPdfPassword(password: String) {
        val doc = _signPdfState.value.selectedDocument ?: return
        activePdfPassword = password
        loadSignPage(doc, _signPdfState.value.currentPageIndex, password)
    }

    fun goToSignPage(pageIndex: Int) {
        val state = _signPdfState.value
        val doc = state.selectedDocument ?: return
        if (pageIndex !in 0 until state.totalPages) return
        _signPdfState.update {
            it.copy(
                currentPageIndex = pageIndex,
                placement = it.placement.copy(pageIndex = pageIndex)
            )
        }
        loadSignPage(doc, pageIndex, activePdfPassword)
    }

    private fun loadSignPage(doc: DocumentItem, pageIndex: Int, password: String?) {
        val helper = pdfRendererHelper ?: return
        viewModelScope.launch {
            _signPdfState.update { it.copy(isLoadingPage = true, renderError = null) }
            when (val outcome = helper.renderPageOutcome(doc.filePath, pageIndex, 1000, password)) {
                is PdfRenderOutcome.Success -> {
                    _signPdfState.update {
                        it.copy(
                            isLoadingPage = false,
                            pageBitmap = outcome.bitmap,
                            totalPages = outcome.totalPages.coerceAtLeast(1),
                            requiresPassword = false,
                            passwordError = null,
                            renderError = null
                        )
                    }
                }
                is PdfRenderOutcome.PasswordRequired -> {
                    _signPdfState.update {
                        it.copy(
                            isLoadingPage = false,
                            pageBitmap = null,
                            requiresPassword = true,
                            passwordError = if (password != null) "Incorrect password." else null
                        )
                    }
                }
                is PdfRenderOutcome.Error -> {
                    _signPdfState.update {
                        it.copy(
                            isLoadingPage = false,
                            renderError = outcome.message
                        )
                    }
                }
            }
        }
    }

    fun selectSignatureForPlacement(signatureId: Long) {
        _signPdfState.update { it.copy(selectedSignatureId = signatureId) }
    }

    fun updatePlacement(normX: Float, normY: Float, normWidth: Float) {
        val safeW = normWidth.coerceIn(0.08f, 0.80f)
        val safeX = normX.coerceIn(0f, (1f - safeW).coerceAtLeast(0f))
        val safeY = normY.coerceIn(0f, 0.90f)
        _signPdfState.update {
            it.copy(
                placement = SignaturePlacement(
                    pageIndex = it.currentPageIndex,
                    normX = safeX,
                    normY = safeY,
                    normWidth = safeW
                )
            )
        }
    }

    fun applySignatureToPdf(newTitle: String, onCreated: (DocumentItem) -> Unit) {
        val state = _signPdfState.value
        val doc = state.selectedDocument
        if (doc == null) {
            _message.value = "Select a PDF document first."
            return
        }
        val sigId = state.selectedSignatureId
        if (sigId <= 0L) {
            _message.value = "Select or draw a signature first."
            return
        }
        viewModelScope.launch {
            _signPdfState.update { it.copy(isSaving = true) }
            repository.insertSignatureIntoPdf(
                sourceDocumentId = doc.id,
                newTitle = newTitle,
                signatureId = sigId,
                placement = state.placement.copy(pageIndex = state.currentPageIndex),
                password = activePdfPassword
            ).onSuccess { created ->
                _signPdfState.update { it.copy(isSaving = false) }
                _message.value = "Signed PDF '${created.title}' saved"
                onCreated(created)
            }.onFailure { err ->
                _signPdfState.update { it.copy(isSaving = false) }
                _message.value = err.message ?: "Failed to embed signature into PDF"
            }
        }
    }

    fun clearMessage() {
        _message.value = null
    }
}
