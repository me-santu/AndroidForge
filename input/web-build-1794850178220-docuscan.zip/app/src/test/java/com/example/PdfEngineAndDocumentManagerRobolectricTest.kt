package com.example

import android.app.Application
import android.content.Context
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.net.Uri
import androidx.room.Room
import androidx.sqlite.db.SupportSQLiteDatabase
import androidx.sqlite.db.SupportSQLiteOpenHelper
import androidx.sqlite.db.framework.FrameworkSQLiteOpenHelperFactory
import androidx.test.core.app.ApplicationProvider
import com.example.database.DocuScanDatabase
import com.example.domain.model.DocumentSortOption
import com.example.domain.model.PdfCompressionLevel
import com.example.domain.model.PdfCreationOptions
import com.example.domain.model.PdfOrientation
import com.example.domain.model.PdfPageSize
import com.example.domain.model.ScanFilter
import com.example.domain.model.ScanPage
import com.example.domain.model.ScanQuality
import com.example.pdf.PdfGenerator
import com.example.pdf.PdfRenderOutcome
import com.example.pdf.PdfRendererHelper
import com.example.repository.LocalDocumentRepository
import com.example.ui.viewmodel.DocumentsUiState
import com.example.ui.viewmodel.DocumentsViewModel
import com.example.ui.viewmodel.ViewerUiState
import com.example.ui.viewmodel.ViewerViewModel
import com.example.util.LocalFileManager
import com.tom_roush.pdfbox.android.PDFBoxResourceLoader
import com.tom_roush.pdfbox.pdmodel.PDDocument
import com.tom_roush.pdfbox.pdmodel.PDPage
import com.tom_roush.pdfbox.pdmodel.PDPageContentStream
import com.tom_roush.pdfbox.pdmodel.font.PDType1Font
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.ExperimentalCoroutinesApi
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.test.StandardTestDispatcher
import kotlinx.coroutines.test.advanceUntilIdle
import kotlinx.coroutines.test.resetMain
import kotlinx.coroutines.test.runTest
import kotlinx.coroutines.test.setMain
import org.junit.After
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertTrue
import org.junit.Before
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.Shadows
import org.robolectric.annotation.Config
import java.io.File
import java.io.FileOutputStream
import java.util.UUID

@OptIn(ExperimentalCoroutinesApi::class)
@RunWith(RobolectricTestRunner::class)
@Config(sdk = [36])
class PdfEngineAndDocumentManagerRobolectricTest {

    private lateinit var context: Context
    private lateinit var fileManager: LocalFileManager
    private lateinit var pdfGenerator: PdfGenerator
    private lateinit var pdfRendererHelper: PdfRendererHelper
    private lateinit var db: DocuScanDatabase
    private lateinit var repository: LocalDocumentRepository
    private val testDispatcher = StandardTestDispatcher()

    @Before
    fun setup() {
        Dispatchers.setMain(testDispatcher)
        context = ApplicationProvider.getApplicationContext()
        if (!PDFBoxResourceLoader.isReady()) {
            PDFBoxResourceLoader.init(context)
        }
        fileManager = LocalFileManager(context, ioDispatcher = testDispatcher)
        pdfGenerator = PdfGenerator(context = context, ioDispatcher = testDispatcher)
        pdfRendererHelper = PdfRendererHelper(context = context, ioDispatcher = testDispatcher)
        db = Room.databaseBuilder(context, DocuScanDatabase::class.java, "pdf_engine_test.db")
            .allowMainThreadQueries()
            .setQueryExecutor { it.run() }
            .setTransactionExecutor { it.run() }
            .build()
        repository = LocalDocumentRepository(
            documentDao = db.documentDao(),
            folderDao = db.folderDao(),
            signatureDao = db.signatureDao(),
            fileManager = fileManager,
            pdfGenerator = pdfGenerator,
            deletedDocumentDao = db.deletedDocumentDao(),
            ioDispatcher = testDispatcher
        )
    }

    @After
    fun tearDown() {
        db.close()
        context.deleteDatabase("pdf_engine_test.db")
        context.deleteDatabase("migration_v1_v2.db")
        fileManager.scansDir.deleteRecursively()
        fileManager.documentsDir.deleteRecursively()
        fileManager.backupsDir.deleteRecursively()
        Dispatchers.resetMain()
    }

    @Test
    fun `create multi-page pdf from multiple images with A5 landscape margins and page numbers`() = runTest(testDispatcher) {
        val tempDir = File(context.cacheDir, "img_inputs").apply { mkdirs() }
        val img1 = createDetailedBitmapJpeg(File(tempDir, "m1.jpg"), 800, 1000, Color.DKGRAY)
        val img2 = createDetailedBitmapJpeg(File(tempDir, "m2.jpg"), 800, 1000, Color.BLUE)
        val img3 = createDetailedBitmapJpeg(File(tempDir, "m3.jpg"), 800, 1000, Color.RED)

        val pages = listOf(img1, img2, img3).mapIndexed { idx, file ->
            ScanPage(
                id = UUID.randomUUID().toString(),
                sourcePath = file.absolutePath,
                filter = ScanFilter.ORIGINAL,
                rotationDegrees = 0,
                orderIndex = idx
            )
        }

        val options = PdfCreationOptions(
            pageSize = PdfPageSize.A5,
            orientation = PdfOrientation.LANDSCAPE,
            marginPt = 36f,
            includePageNumbers = true,
            quality = ScanQuality.HIGH
        )

        val result = repository.createPdfDocument("Multi_A5_Report", pages, null, options)
        assertTrue(result.isSuccess)
        val doc = result.getOrThrow()
        assertEquals(3, doc.pageCount)
        assertTrue(File(doc.filePath).exists())

        // Verify page dimensions (A5 Landscape: 595 x 420 pt) & embedded footer text
        PDDocument.load(File(doc.filePath)).use { pdDoc ->
            assertEquals(3, pdDoc.numberOfPages)
            val box = pdDoc.getPage(0).mediaBox
            assertEquals(595f, box.width, 1f)
            assertEquals(420f, box.height, 1f)
        }

        val matches = repository.searchTextInPdf(doc.id, "Page 2 of 3")
        assertEquals(1, matches.size)
        assertEquals(1, matches.first().pageIndex)
        // Source images preserved untouched
        assertTrue(img1.exists() && img2.exists() && img3.exists())
    }

    @Test
    fun `create custom size and letter pdf with watermark and aes password protection and reopen in viewer`() = runTest(testDispatcher) {
        val tempDir = File(context.cacheDir, "custom_inputs").apply { mkdirs() }
        val img = createDetailedBitmapJpeg(File(tempDir, "c1.jpg"), 600, 800, Color.GREEN)
        val page = ScanPage("p1", img.absolutePath, ScanFilter.ORIGINAL, 0, 0)

        val customDoc = repository.createPdfDocument(
            title = "Custom_Secure_Doc",
            pages = listOf(page),
            folderId = null,
            options = PdfCreationOptions(
                pageSize = PdfPageSize.CUSTOM,
                customWidthPt = 400,
                customHeightPt = 600,
                orientation = PdfOrientation.PORTRAIT,
                marginPt = 20f,
                includePageNumbers = true,
                watermarkText = "CONFIDENTIAL",
                password = "secret123"
            )
        ).getOrThrow()

        assertTrue(customDoc.isPasswordProtected)
        // Without password should require password
        val lockedOutcome = pdfRendererHelper.renderPageOutcome(customDoc.filePath, 0)
        assertTrue(lockedOutcome is PdfRenderOutcome.PasswordRequired)

        // ViewerViewModel unlocks with real password & toggles bookmark
        val viewerVm = ViewerViewModel(repository, pdfRendererHelper, fileManager)
        viewerVm.loadDocument(customDoc.id)
        advanceUntilIdle()
        assertTrue(viewerVm.uiState.value is ViewerUiState.PasswordRequired)

        viewerVm.unlockWithPassword("secret123")
        advanceUntilIdle()
        val ready = viewerVm.uiState.value as? ViewerUiState.Ready
        assertNotNull(ready)
        assertNotNull(ready!!.pageBitmap)

        viewerVm.toggleBookmark(0)
        advanceUntilIdle()
        val reloaded = repository.getDocumentById(customDoc.id)!!
        assertEquals(listOf(0), reloaded.bookmarkedPages)
    }

    @Test
    fun `merge two pdfs split pages extract pages rotate and delete preserving sources`() = runTest(testDispatcher) {
        val tempDir = File(context.cacheDir, "pdf_ops").apply { mkdirs() }
        val pdfAFile = createTextPdf(File(tempDir, "a.pdf"), listOf("Alpha Page 1", "Alpha Page 2"))
        val pdfBFile = createTextPdf(File(tempDir, "b.pdf"), listOf("Beta Page 1", "Beta Page 2", "Beta Page 3"))

        val docA = repository.importExternalPdfUri(Uri.fromFile(pdfAFile)).getOrThrow()
        val docB = repository.importExternalPdfUri(Uri.fromFile(pdfBFile)).getOrThrow()

        val merged = repository.mergePdfDocuments("Merged_AB", listOf(docA.id, docB.id), null).getOrThrow()
        assertEquals(5, merged.pageCount)
        assertTrue(File(docA.filePath).exists() && File(docB.filePath).exists())

        // Split pages 2..4 -> 3 pages
        val split = repository.splitPdfDocument(merged.id, "Split_2_4", 2, 4).getOrThrow()
        assertEquals(3, split.pageCount)
        val splitSearch = repository.searchTextInPdf(split.id, "Beta Page 1")
        assertEquals(1, splitSearch.size)

        // Extract pages 1 and 5 -> 2 pages
        val extracted = repository.extractPdfPages(merged.id, "Extract_1_5", listOf(1, 5)).getOrThrow()
        assertEquals(2, extracted.pageCount)
        assertEquals(1, repository.searchTextInPdf(extracted.id, "Beta Page 3").size)

        // Rotate page 1 by 90 degrees
        val rotated = repository.rotatePdfPages(extracted.id, "Rotated_Doc", setOf(1), 90).getOrThrow()
        PDDocument.load(File(rotated.filePath)).use { pdDoc ->
            assertEquals(90, pdDoc.getPage(0).rotation)
            assertEquals(0, pdDoc.getPage(1).rotation)
        }

        // Delete page 1 from merged -> 4 pages remain, merged stays 5 pages
        val deleted = repository.deletePdfPages(merged.id, "Trimmed_Doc", setOf(1)).getOrThrow()
        assertEquals(4, deleted.pageCount)
        assertEquals(5, repository.getDocumentById(merged.id)?.pageCount)
    }

    @Test
    fun `compress pdf with real images reduces file size and reopens cleanly`() = runTest(testDispatcher) {
        val tempDir = File(context.cacheDir, "compress_sim").apply { mkdirs() }
        val bigPhoto1 = createHighDetailNoiseBitmapJpeg(File(tempDir, "noise1.jpg"), 1800, 2400)
        val bigPhoto2 = createHighDetailNoiseBitmapJpeg(File(tempDir, "noise2.jpg"), 1800, 2400)

        val pages = listOf(
            ScanPage("1", bigPhoto1.absolutePath, ScanFilter.ORIGINAL, 0, 0),
            ScanPage("2", bigPhoto2.absolutePath, ScanFilter.ORIGINAL, 0, 1)
        )
        val original = repository.createPdfDocument(
            title = "Ultra_Original",
            pages = pages,
            folderId = null,
            options = PdfCreationOptions(pageSize = PdfPageSize.A4, quality = ScanQuality.ULTRA)
        ).getOrThrow()

        val compressed = repository.compressPdfDocument(
            sourceDocumentId = original.id,
            newTitle = "Compressed_High",
            compressionLevel = PdfCompressionLevel.HIGH
        ).getOrThrow()

        assertTrue(
            "Expected compressed (${compressed.sizeBytes}) < original (${original.sizeBytes})",
            compressed.sizeBytes < original.sizeBytes
        )
        assertEquals(2, compressed.pageCount)
        val outcome = pdfRendererHelper.renderPageOutcome(compressed.filePath, 0)
        assertTrue(outcome is PdfRenderOutcome.Success)
    }

    @Test
    fun `annotate and highlight saves new copy while preserving source pdf`() = runTest(testDispatcher) {
        val tempDir = File(context.cacheDir, "annotate_sim").apply { mkdirs() }
        val srcPdf = createTextPdf(File(tempDir, "contract.pdf"), listOf("Clause 1", "Clause 2"))
        val doc = repository.importExternalPdfUri(Uri.fromFile(srcPdf)).getOrThrow()

        val annotated = repository.annotatePdfDocument(
            sourceDocumentId = doc.id,
            newTitle = "Contract_Annotated",
            pageIndexZeroBased = 0,
            noteText = "Reviewed and approved",
            addHighlightBar = true
        ).getOrThrow()

        assertTrue(annotated.id != doc.id)
        assertTrue(annotated.filePath != doc.filePath)
        PDDocument.load(File(annotated.filePath)).use { pdDoc ->
            assertEquals(2, pdDoc.getPage(0).annotations.size)
        }
        PDDocument.load(File(doc.filePath)).use { origDoc ->
            assertEquals(0, origDoc.getPage(0).annotations.size)
        }
    }

    @Test
    fun `file manager folders rename move favorites sort trash restore permanent delete export and share`() = runTest(testDispatcher) {
        val vm = DocumentsViewModel(repository, fileManager)

        // Create & rename folder
        vm.createFolder("Invoices")
        vm.createFolder("TempFolder")
        advanceUntilIdle()
        val folders = repository.observeFolders().first()
        assertEquals(2, folders.size)
        val invoices = folders.first { it.name == "Invoices" }
        vm.renameFolder(invoices.id, "Tax_2026")
        advanceUntilIdle()
        assertTrue(repository.observeFolders().first().any { it.name == "Tax_2026" })

        // Create two PDFs
        val tempDir = File(context.cacheDir, "fm_sim").apply { mkdirs() }
        val pdf1 = createTextPdf(File(tempDir, "zeta.pdf"), listOf("Zeta content"))
        val pdf2 = createTextPdf(File(tempDir, "alpha.pdf"), listOf("Alpha content", "Extra page"))

        val doc1 = repository.importExternalPdfUri(Uri.fromFile(pdf1)).getOrThrow()
        val doc2 = repository.importExternalPdfUri(Uri.fromFile(pdf2)).getOrThrow()

        // Rename, favorite, move
        vm.renameDocument(doc1.id, "Zeta_Renamed")
        vm.toggleFavorite(doc2.id)
        vm.moveDocumentToFolder(doc2.id, invoices.id)
        advanceUntilIdle()

        // Sort by Name A-Z
        vm.setSortOption(DocumentSortOption.NAME_ASC)
        advanceUntilIdle()
        val successState = vm.documentsUiState.first { it is DocumentsUiState.Success } as DocumentsUiState.Success
        assertEquals(listOf("alpha", "Zeta_Renamed"), successState.documents.map { it.title })
        assertTrue(successState.documents.first().isFavorite)
        assertEquals("Tax_2026", successState.documents.first().folderName)

        // Trash -> verify DeletedDocumentEntity + restore -> verify active again -> permanent delete
        vm.moveToTrash(doc1.id)
        advanceUntilIdle()
        assertEquals(1, repository.observeTrashDocuments().first().size)
        assertEquals(1, repository.observeDeletedDocuments().first().size)

        vm.restoreFromTrash(doc1.id)
        advanceUntilIdle()
        assertEquals(0, repository.observeTrashDocuments().first().size)
        assertEquals(0, repository.observeDeletedDocuments().first().size)
        assertEquals(2, repository.observeActiveDocuments().first().size)

        // SAF Export to a user-selected file URI
        val safExportTarget = File(tempDir, "saf_exported.pdf")
        val bytesWritten = repository.exportDocumentToUri(doc2.id, Uri.fromFile(safExportTarget)).getOrThrow()
        assertTrue(bytesWritten > 0L)
        assertTrue(safExportTarget.exists() && safExportTarget.length() == File(doc2.filePath).length())

        // Share intent check via Robolectric ShadowApplication
        vm.shareDocument(doc2)
        val startedChooser = Shadows.shadowOf(context as Application).nextStartedActivity
        assertNotNull(startedChooser)
        assertEquals(Intent.ACTION_CHOOSER, startedChooser.action)
        val wrappedShare = startedChooser.getParcelableExtra(Intent.EXTRA_INTENT, Intent::class.java)
        assertNotNull(wrappedShare)
        assertEquals(Intent.ACTION_SEND, wrappedShare!!.action)
        assertEquals("application/pdf", wrappedShare.type)

        // Permanent deletion deletes file & DB record
        val doc1Path = repository.getDocumentById(doc1.id)!!.filePath
        vm.moveToTrash(doc1.id)
        advanceUntilIdle()
        vm.permanentlyDelete(doc1.id)
        advanceUntilIdle()
        assertFalse(File(doc1Path).exists())
        assertEquals(1, repository.observeActiveDocuments().first().size)
    }

    @Test
    fun `room migration 1 to 2 preserves existing documents and folders and adds new columns`() {
        val dbName = "migration_v1_v2.db"
        val callback = object : SupportSQLiteOpenHelper.Callback(1) {
            override fun onCreate(db: SupportSQLiteDatabase) {
                db.execSQL(
                    "CREATE TABLE IF NOT EXISTS folders (id INTEGER PRIMARY KEY AUTOINCREMENT NOT NULL, name TEXT NOT NULL, accentHex INTEGER NOT NULL, createdAt INTEGER NOT NULL)"
                )
                db.execSQL(
                    """
                    CREATE TABLE IF NOT EXISTS documents (
                        id INTEGER PRIMARY KEY AUTOINCREMENT NOT NULL,
                        title TEXT NOT NULL,
                        folderId INTEGER,
                        filePath TEXT NOT NULL,
                        thumbnailPath TEXT,
                        fileType TEXT NOT NULL,
                        pageCount INTEGER NOT NULL,
                        sizeBytes INTEGER NOT NULL,
                        ocrText TEXT NOT NULL,
                        createdAt INTEGER NOT NULL,
                        updatedAt INTEGER NOT NULL,
                        isPinned INTEGER NOT NULL,
                        isDeleted INTEGER NOT NULL,
                        deletedAt INTEGER,
                        FOREIGN KEY(folderId) REFERENCES folders(id) ON DELETE SET NULL
                    )
                    """.trimIndent()
                )
                db.execSQL("CREATE INDEX IF NOT EXISTS index_documents_folderId ON documents(folderId)")
                db.execSQL("CREATE INDEX IF NOT EXISTS index_documents_isDeleted ON documents(isDeleted)")
                db.execSQL(
                    """
                    CREATE TABLE IF NOT EXISTS document_pages (
                        id INTEGER PRIMARY KEY AUTOINCREMENT NOT NULL,
                        documentId INTEGER NOT NULL,
                        imagePath TEXT NOT NULL,
                        pageIndex INTEGER NOT NULL,
                        filterName TEXT NOT NULL,
                        rotationDegrees INTEGER NOT NULL,
                        FOREIGN KEY(documentId) REFERENCES documents(id) ON DELETE CASCADE
                    )
                    """.trimIndent()
                )
                db.execSQL("CREATE INDEX IF NOT EXISTS index_document_pages_documentId ON document_pages(documentId)")
                db.execSQL(
                    "CREATE TABLE IF NOT EXISTS signatures (id INTEGER PRIMARY KEY AUTOINCREMENT NOT NULL, name TEXT NOT NULL, filePath TEXT NOT NULL, createdAt INTEGER NOT NULL)"
                )
                db.execSQL("INSERT INTO folders (id, name, accentHex, createdAt) VALUES (10, 'LegacyFolder', 4294296898, 1000)")
                db.execSQL(
                    """
                    INSERT INTO documents (id, title, folderId, filePath, thumbnailPath, fileType, pageCount, sizeBytes, ocrText, createdAt, updatedAt, isPinned, isDeleted, deletedAt)
                    VALUES (20, 'LegacyDoc', 10, '/tmp/legacy.pdf', NULL, 'PDF', 2, 2048, 'hello', 1000, 2000, 1, 0, NULL)
                    """.trimIndent()
                )
            }

            override fun onUpgrade(db: SupportSQLiteDatabase, oldVersion: Int, newVersion: Int) = Unit
        }
        FrameworkSQLiteOpenHelperFactory().create(
            SupportSQLiteOpenHelper.Configuration.builder(context)
                .name(dbName)
                .callback(callback)
                .build()
        ).writableDatabase.close()

        val migratedDb = Room.databaseBuilder(context, DocuScanDatabase::class.java, dbName)
            .addMigrations(DocuScanDatabase.MIGRATION_1_2)
            .allowMainThreadQueries()
            .build()

        val migratedFolder = migratedDb.folderDao().let {
            kotlinx.coroutines.runBlocking { it.getById(10L) }
        }
        assertNotNull(migratedFolder)
        assertEquals("LegacyFolder", migratedFolder!!.name)

        val migratedDoc = kotlinx.coroutines.runBlocking { migratedDb.documentDao().getById(20L) }
        assertNotNull(migratedDoc)
        assertEquals("LegacyDoc", migratedDoc!!.title)
        assertFalse(migratedDoc.isFavorite)
        assertFalse(migratedDoc.isPasswordProtected)
        assertEquals("", migratedDoc.bookmarkedPages)
        migratedDb.close()
    }

    private fun createDetailedBitmapJpeg(file: File, width: Int, height: Int, color: Int): File {
        val bmp = Bitmap.createBitmap(width, height, Bitmap.Config.ARGB_8888)
        val canvas = Canvas(bmp)
        canvas.drawColor(Color.WHITE)
        val paint = Paint().apply { this.color = color }
        canvas.drawRect(40f, 40f, width - 40f, height - 40f, paint)
        FileOutputStream(file).use { out -> bmp.compress(Bitmap.CompressFormat.JPEG, 95, out) }
        bmp.recycle()
        return file
    }

    private fun createHighDetailNoiseBitmapJpeg(file: File, width: Int, height: Int): File {
        val bmp = Bitmap.createBitmap(width, height, Bitmap.Config.ARGB_8888)
        val pixels = IntArray(width * height)
        var seed = 42
        for (i in pixels.indices) {
            seed = seed * 1664525 + 1013904223
            val r = (seed ushr 16) and 0xFF
            val g = (seed ushr 8) and 0xFF
            val b = seed and 0xFF
            pixels[i] = Color.rgb(r, g, b)
        }
        bmp.setPixels(pixels, 0, width, 0, 0, width, height)
        FileOutputStream(file).use { out -> bmp.compress(Bitmap.CompressFormat.JPEG, 98, out) }
        bmp.recycle()
        return file
    }

    private fun createTextPdf(file: File, pageTexts: List<String>): File {
        PDDocument().use { doc ->
            pageTexts.forEach { text ->
                val page = PDPage()
                doc.addPage(page)
                PDPageContentStream(doc, page).use { stream ->
                    stream.beginText()
                    stream.setFont(PDType1Font.HELVETICA, 14f)
                    stream.newLineAtOffset(72f, 700f)
                    stream.showText(text)
                    stream.endText()
                }
            }
            doc.save(file)
        }
        return file
    }
}
